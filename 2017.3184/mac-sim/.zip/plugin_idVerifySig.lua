local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name="plugin.idVerifySig", publisherId="com.cabagomez", version=1}

local function showWarning(functionName)
    print( functionName .. " WARNING: idVerifySig plugin is only supported on iOS devices.")
end

function lib.init()
    showWarning("idVerifySig.init()")
end

function lib.getSignature()
    showWarning("idVerifySig.getSignature()")
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
