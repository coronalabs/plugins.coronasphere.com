local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.ble', publisherId='com.clalastudio' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation startine here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local PLUGIN_NAME = require "plugin_PLUGIN_NAME"
--    PLUGIN_NAME:showPopup()
--    
function showWarning()
    native.showAlert( 'Not Supported', 'The ble plugin is only supported on an iOS Device. Please build for device', { 'OK' } )
end

function lib.discover()
    showWarning()
end

function lib.stopDiscover()
    showWarning()
end

function lib.connect()
    showWarning()
end

function lib.disconnect()
    showWarning()
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
