local Library = require "CoronaLibrary"

local lib = Library:new{ name='plugin.tapfortap', publisherId='com.tapfortap' }

local printWarnings = true;

lib.printWarnings = function(enable)
    printWarnings = enable
end

lib.initialize = function(apiKey)
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.initialize' is not available on the simulator, no ads will appear." )
    end
end

lib.setYearOfBirth = function(yearOfBirth)
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap' is not available on the simulator, no ads will appear." )
    end
end

lib.setGender = function(gender)
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.setYearOfBirth' is not available on the simulator, no ads will appear." )
    end
end

lib.setLocation = function(latitude, longitude)
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap' is not available on the simulator, no ads will appear." )
    end
end

lib.setUserAccountId = function(userAccountId)
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.setLocation' is not available on the simulator, no ads will appear." )
    end
end

lib.getVersion = function()
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.getVersion' is not available on the simulator, no ads will appear." )
    end
    return "N/A"
end

lib.createAdView = function(...)
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.createAdView' is not available on the simulator, no ads will appear." )
    end
end

lib.removeAdView = function()
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.removeAdView' is not available on the simulator, no ads will appear." )
    end
end

lib.setAdViewListener = function(apiKey)
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.setAdViewListener' is not available on the simulator, no ads will appear." )
    end
end

lib.prepareInterstitial = function()
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.prepareInterstitial' is not available on the simulator, no ads will appear." )
    end
end

lib.showInterstitial = function()
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.showInterstitial' is not available on the simulator, no ads will appear." )
    end
end

lib.interstitialIsReady = function()
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.interstitialIsReady' is not available on the simulator, no ads will appear." )
    end
end

lib.setInterstitialListener = function(apiKey)
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.setInterstitialListener' is not available on the simulator, no ads will appear." )
    end
end

lib.prepareAppWall = function()
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.prepareAppWall' is not available on the simulator, no ads will appear." )
    end
end

lib.showAppWall = function()
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.showAppWall' is not available on the simulator, no ads will appear." )
    end
end

lib.appWallIsReady = function()
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.appWallIsReady' is not available on the simulator, no ads will appear." )
    end
end

lib.setAppWallListener = function(apiKey)
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.setAppWallListener' is not available on the simulator, no ads will appear." )
    end
end

lib.setDevelopment = function(apiKey)
    if printWarnings then
        print( "WARNING: 'plugin.tapfortap.setDevelopment' is not available on the simulator, no ads will appear." )
    end
end

return lib
