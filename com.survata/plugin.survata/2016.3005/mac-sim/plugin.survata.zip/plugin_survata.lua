local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.survata', publisherId='com.survata' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local PLUGIN_NAME = require "plugin_PLUGIN_NAME"
--    PLUGIN_NAME.test()
--    
lib.show = function(listener)
	native.showAlert( "Survata", "This plugin is not available on this platform", { 'OK' } )
	print( "This plugin is not available on this platform" )
end

lib.init = function(publisherId,listener,testMode)
	print( "This plugin is not available on this platform" )
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
