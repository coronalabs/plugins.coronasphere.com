local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{name = 'plugin.loopme', publisherId = 'com.loopme', version = 1.0}
-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation startine here)
------------------------------------------------------------------------------- 
local function showWarning()
    print('Warning: Not Supported. The LoopMe plugin is only supported on a Win simulator.')
end

lib.init = showWarning
lib.load = showWarning
lib.isLoaded = showWarning
lib.show = showWarning
-- Return an instance
return lib