local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.wifiManager', publisherId='tech.scotth' }

-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.init= defaultFunction
lib.isEnabled= defaultFunction
lib.setEnabled= defaultFunction
lib.addNetwork= defaultFunction
lib.removeNetwork= defaultFunction
lib.disconnect= defaultFunction
lib.connectNetwork= defaultFunction
lib.disableNetwork= defaultFunction
lib.listNetworks= defaultFunction
lib.startScan= defaultFunction
lib.getScanResults= defaultFunction
lib.enableLocation= defaultFunction
lib.isLocationEnabled= defaultFunction

lib.getCurrentNetwork= function (  )
	return "Not Supported", "Not Supported"
end
lib.getCurrentMacAddress= defaultFunction


-- Return an instance
return lib
