local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.facebookAnalytics', publisherId='tech.scotth' }
-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.init = defaultFunction
lib.debug = defaultFunction
lib.setUserID = defaultFunction
lib.setUserProperties = defaultFunction
lib.logPurchase = defaultFunction
lib.logEvent = defaultFunction
lib.limitEventUsage = defaultFunction
-- Return an instance
return lib