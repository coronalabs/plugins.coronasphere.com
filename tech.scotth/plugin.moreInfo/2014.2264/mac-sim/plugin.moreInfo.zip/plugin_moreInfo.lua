local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.moreInfo', publisherId='tech.scotth' }

-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
	return "Not Supported"
end
local function getPlatform()
	return "macOS"
end
local function getKeyboardSize()
	return 0,0
end
local function getColorMode()
	return "light"
end
lib.getBatteryLevel = defaultFunction
lib.getBatteryState = defaultFunction
lib.getTotalSpace = defaultFunction
lib.getTotalFreeSpace = defaultFunction
lib.getNetworkStatus = defaultFunction
lib.getPlatform = getPlatform
lib.isMuted = defaultFunction
lib.getMaxTextureMemoryUnits = defaultFunction
lib.getMaxTextureMemorySize = defaultFunction
lib.isHeadsetPluggedIn = defaultFunction
lib.isMusicPlaying = defaultFunction
lib.isBluetoothEnabled = defaultFunction
lib.getKeyboardSize = getKeyboardSize
lib.getSettingFontSize = getKeyboardSize
lib.getColorMode = getColorMode

lib.init = defaultFunction

-- Return an instance
return lib
