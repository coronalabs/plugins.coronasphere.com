local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.ibeacon', publisherId='tech.scotth' }

-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.search= defaultFunction
lib.setTimer= defaultFunction
lib.stopUUIDSearch= defaultFunction
lib.stopAllSearchs= defaultFunction
lib.startTransmitting= defaultFunction
lib.stopTransmitting= defaultFunction
lib.canAccess= defaultFunction

-- Return an instance
return lib