local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.equalizer', publisherId='tech.scotth' }

-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.initEqualizer= defaultFunction
lib.getBandLevelRange= defaultFunction
lib.getNumberOfBands= defaultFunction
lib.getBandFreqRange= defaultFunction
lib.getCenterFreq= defaultFunction
lib.setBandLevel= defaultFunction
lib.getBandLevel= defaultFunction
lib.initReverb= defaultFunction
lib.setReverb= defaultFunction
lib.getReverb= defaultFunction

-- Return an instance
return lib
