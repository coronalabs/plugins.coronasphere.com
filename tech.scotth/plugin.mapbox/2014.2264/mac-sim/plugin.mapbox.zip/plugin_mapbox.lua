local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.mapbox', publisherId='tech.scotth' }
-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.init = defaultFunction
lib.newView = defaultFunction
lib.locationServicesEnabled = function (  )
	return true
end
lib.requestLocationServices = defaultFunction
-- Return an instance
return lib