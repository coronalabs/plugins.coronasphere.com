local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.firestore', publisherId='tech.scotth' }

-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.init= defaultFunction
lib.setData= defaultFunction
lib.updateData= defaultFunction
lib.readDataInCollection= defaultFunction
lib.readDataInDocument= defaultFunction
lib.deleteData= defaultFunction
lib.checkRealtime= defaultFunction
lib.stopRealtime= defaultFunction




-- Return an instance
return lib
