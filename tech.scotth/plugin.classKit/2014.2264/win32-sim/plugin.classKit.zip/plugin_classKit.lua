local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.classKit', publisherId='tech.scotth' }

-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.init= defaultFunction
lib.addContent= defaultFunction
lib.createActivity= defaultFunction
lib.destoryActivity= defaultFunction
lib.isActivityRunning= defaultFunction
lib.stopActivity= defaultFunction
lib.startActivity= defaultFunction
lib.addItemActivity= defaultFunction
lib.setProgressActivity= defaultFunction
lib.addPrimaryItemActivity= defaultFunction
lib.startContext= defaultFunction
lib.stopContext= defaultFunction
lib.isContextActive= defaultFunction
lib.removeContext= defaultFunction
lib.saveData= defaultFunction

-- Return an instance
return lib
