local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.appmetrica', publisherId='tech.scotth' }

-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.init= defaultFunction
lib.setUserProfileID= defaultFunction
lib.setGender= defaultFunction
lib.setAge= defaultFunction
lib.setName= defaultFunction
lib.setDidUserEnableNotifcation= defaultFunction
lib.setCustomUserInfo= defaultFunction
lib.setLocationTracking= defaultFunction
lib.setVersion= defaultFunction
lib.reportEvent= defaultFunction
lib.reportError= defaultFunction
       
-- Return an instance
return lib
