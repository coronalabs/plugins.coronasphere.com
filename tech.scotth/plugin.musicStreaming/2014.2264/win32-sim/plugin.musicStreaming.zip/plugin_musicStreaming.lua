local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.musicStreaming', publisherId='tech.scotth' }

-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.init = defaultFunction
lib.play = defaultFunction
lib.getDuration = defaultFunction
lib.getProgress = defaultFunction
lib.pause = defaultFunction
lib.resume = defaultFunction
lib.stop = defaultFunction
lib.getVolume = defaultFunction
lib.setVolume = defaultFunction
lib.addToQueue = defaultFunction
lib.isPaused = defaultFunction
lib.seek = defaultFunction
lib.checkAudio = defaultFunction

-- Return an instance
return lib
