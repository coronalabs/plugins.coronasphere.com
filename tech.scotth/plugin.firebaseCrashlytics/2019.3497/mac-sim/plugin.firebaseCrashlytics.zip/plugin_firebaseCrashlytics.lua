local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.firebaseCrashlytics', publisherId='tech.scotth' }
-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.init = defaultFunction
lib.setUserIdentifier = defaultFunction
lib.setUserName = defaultFunction
lib.setUserEmail = defaultFunction
lib.sendCrash = defaultFunction
lib.setStringValue = defaultFunction
lib.setIntValue = defaultFunction
lib.setFloatValue = defaultFunction
lib.setBoolValue = defaultFunction
lib.recordError = defaultFunction
-- Return an instance
return lib