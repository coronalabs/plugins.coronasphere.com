local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.externalStorage', publisherId='tech.scotth' }

-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.getFile = defaultFunction
lib.copyFile = defaultFunction
lib.deleteFile = defaultFunction
lib.listFiles = defaultFunction
lib.doesFileExist = defaultFunction
lib.makeFolder = defaultFunction
lib.isSdCardConnected = function ()
	return false
end
lib.sdCardPath = function ()
	return ""
end
lib.totalSpace = function ()
	return 0
end
lib.spaceAvailable = function ()
	return 0
end
lib.getExternalFilesDir = function ()
	return ""
end
lib.rename = defaultFunction
-- Return an instance
return lib