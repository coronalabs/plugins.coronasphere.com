local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.firebaseAuth', publisherId='tech.scotth' }
-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.init = defaultFunction
lib.createAccount = defaultFunction
lib.signIn = defaultFunction
lib.sendVerification = defaultFunction
lib.isSignedIn = defaultFunction
lib.getUID = defaultFunction
lib.getEmail = defaultFunction
lib.isEmailVerified = defaultFunction
lib.getDisplayName = defaultFunction
lib.getPhoneNumber = defaultFunction
lib.getPhotoUrl = defaultFunction
lib.setPhotoUrl = defaultFunction
lib.setEmail = defaultFunction
lib.updatePassword = defaultFunction
lib.deleteAccount = defaultFunction
lib.signOut = defaultFunction
lib.setDisplayName = defaultFunction
lib.getRefreshToken = defaultFunction
lib.sendVerificationCode = defaultFunction
lib.signInWithPhoneNumber = defaultFunction
lib.signInWithGoogle = defaultFunction
lib.signInWithFacebook = defaultFunction
lib.signInWithTwitter = defaultFunction
lib.signInWithGithub = defaultFunction
lib.signInWithCustomToken = defaultFunction
lib.signInAnonymously = defaultFunction
lib.isAnonymous = defaultFunction
lib.isNetworkAvailable = defaultFunction
lib.doesEmailExist = defaultFunction
lib.resetPassword = defaultFunction
lib.setAPNSToken = defaultFunction

-- Return an instance
return lib