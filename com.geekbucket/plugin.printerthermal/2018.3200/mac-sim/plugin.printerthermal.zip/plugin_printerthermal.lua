local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='printerthermal', publisherId='com.geekbucket' }

-- Default implementations
local function defaultFunction()
    print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end
lib.init = defaultFunction
lib.validateConnection = defaultFunction
lib.feedPaper = defaultFunction
lib.writeText = defaultFunction
lib.writeTextBig = defaultFunction
lib.writeImage = defaultFunction

-- Return an instance
return lib