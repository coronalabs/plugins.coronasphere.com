local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.bluetoothbytes', publisherId='com.spacekace' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------

lib.init = function(listener)
	-- handles all events
	-- native.showAlert( 'Not supported on this platform', 'bluetoothbytes.init', { 'OK' } )
	print( 'Not supported on this platform: bluetoothbytes.init' )
end

lib.isEnabled = function()
	-- returns boolean, if true bluetooth is enabled
	-- native.showAlert( 'Not supported on this platform', 'bluetoothbytes.isEnabled', { 'OK' } )
	print( 'Not supported on this platform: bluetoothbytes.isEnabled' )
end

lib.search = function()
	-- search for bluetooth devices
	-- native.showAlert( 'Not supported on this platform', 'bluetoothbytes.search', { 'OK' } )
	print( 'Not supported on this platform: bluetoothbytes.search' )
end

lib.send = function(bytes, deviceID)
	-- send message to devices (deviceID is only supported on iOS).  bytes is a table array of integers
	-- native.showAlert( 'Not supported on this platform', 'bluetoothbytes.send', { 'OK' } )
	print( 'Not supported on this platform: bluetoothbytes.send' )
end

lib.setBufferSize = function(bufferSize)
	-- set the size of the buffer that reads bytes from the bluetooth device
	-- native.showAlert( 'Not supported on this platform', 'bluetoothbytes.setBufferSize', { 'OK' } )
	print( 'Not supported on this platform: bluetoothbytes.setBufferSize' )
end

lib.setFillBuffer = function(fillBuffer)
	-- let the plugin know to fill buffer before sending event
	-- native.showAlert( 'Not supported on this platform', 'bluetoothbytes.setFillBuffer', { 'OK' } )
	print( 'Not supported on this platform: bluetoothbytes.setFillBuffer' )
end

lib.setMessageFormat = function(messageFormat)
	-- set the format that you want to receive the data from the device: bytes | string
	-- native.showAlert( 'Not supported on this platform', 'bluetoothbytes.setMessageFormat', { 'OK' } )
	print( 'Not supported on this platform: bluetoothbytes.setMessageFormat' )
end

lib.enable = function(enabled)
	-- enable bluetooth (android only)
	-- native.showAlert( 'Not supported on this platform', 'bluetoothbytes.enable', { 'OK' } )
	print( 'Not supported on this platform: bluetoothbytes.enable' )
end

lib.connect = function(deviceID)
	-- connect with with deviceID(string)
	-- native.showAlert( 'Not supported on this platform', 'bluetoothbytes.connect', { 'OK' } )
	print( 'Not supported on this platform: bluetoothbytes.connect' )
end

lib.disconnect = function(deviceID)
	-- disconnect from device with deviceID(string)
	-- native.showAlert( 'Not supported on this platform', 'bluetoothbytes.disconnect', { 'OK' } )
	print( 'Not supported on this platform: bluetoothbytes.disconnect' )
end

lib.getDevices = function()
	-- get configured devices, returns array with data in each table (only works on Android)
	-- native.showAlert( 'Not supported on this platform', 'bluetoothbytes.getDevices', { 'OK' } )
	print( 'Not supported on this platform: bluetoothbytes.getDevices' )
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
