local Library = require "CoronaLibrary";
local json = require("json");
local crypto = require("crypto");
local ltn12 = require("ltn12");
local mime = require("mime");

-- Create library
local lib = Library:new{ name='plugin.together', publisherId='com.playstogether' };
--local lib = {};

g_TogetherPrintEnabled			= true;
g_Together						= nil;
g_CurrentGameInstance 			= nil;
g_CurrentLeaderboard 			= nil;
g_CurrentUserNotification 		= nil;
g_CurrentAchievement 			= nil;
g_CurrentUserAchievement 		= nil;
g_CurrentItem 					= nil;
g_CurrentUserItem 				= nil;
g_CurrentChatRoom 				= nil;
g_CurrentChatMessage			= nil;
g_CurrentFriend					= nil;
g_CurrentUserMessage			= nil;
g_CurrentUserPurchase			= nil;
g_Facebook						= require("facebook");

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation startine here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local together = require "plugin_together"
--    together.test()
--    

--module(..., package.seeall)

-------------------------------------------------------------------------------
-- MultipartFormData.lua ------------------------------------------------------
-------------------------------------------------------------------------------
table.val_to_str = function( v )
  if "string" == type( v ) then
    v = string.gsub( v, "\n", "\\n" )
    if string.match( string.gsub(v,"[^'\"]",""), '^"+$' ) then
      return "'" .. v .. "'"
    end
    return '"' .. string.gsub(v,'"', '\\"' ) .. '"'
  else
    return "table" == type( v ) and table.tostring( v ) or
      tostring( v )
  end
end

table.key_to_str  = function( k )
  if "string" == type( k ) and string.match( k, "^[_%a][_%a%d]*$" ) then
    return k
  else
    return "[" .. table.val_to_str( k ) .. "]"
  end
end

table.tostring = function( tbl )
  local result, done = {}, {}
  for k, v in ipairs( tbl ) do
    table.insert( result, table.val_to_str( v ) )
    done[ k ] = true
  end
  for k, v in pairs( tbl ) do
    if not done[ k ] then
      table.insert( result,
        table.key_to_str( k ) .. "=" .. table.val_to_str( v ) )
    end
  end
  return "{" .. table.concat( result, "," ) .. "}"
end


lib.MultipartFormData = {};
lib.MultipartFormData.__index = lib.MultipartFormData;

-----------------
-- Constructor --
-----------------

function lib.MultipartFormData.New()
	local self = {};
	setmetatable(self, lib.MultipartFormData);
	
	self.boundary = "MPFD-"..crypto.digest( crypto.sha1, "MultipartFormData"..tostring(object)..tostring(os.time())..tostring(os.clock()), false )
    self.isClass = true;
	self.headers = {};
	self.elements = {};
  
    self.headers["MIME-Version"] = "1.0"
  
  	return self;
end

function lib.MultipartFormData:getBody()
        local src = {}
        
        -- always need two CRLF's as the beginning
        table.insert(src, ltn12.source.chain(ltn12.source.string("\n\n"), mime.normalize()))
        
        for i = 1, #self.elements do
                local el = self.elements[i]
                if el then
                        if el.intent == "field" then
                                local elData = {
                                        "--"..self.boundary.."\n",
                                        "content-disposition: form-data; name=\"",
                                        el.name,
                                        "\"\n\n",
                                        el.value,
                                        "\n"
                                }
                                
                                local elBody = table.concat(elData)
                                table.insert(src, ltn12.source.chain(ltn12.source.string(elBody), mime.normalize()))
                        elseif el.intent == "file" then
                                local elData = {
                                        "--"..self.boundary.."\n",
                                        "content-disposition: form-data; name=\"",
                                        el.name,
                                        "\"; filename=\"",
                                        el.filename,
                                        "\"\n",
                                        "Content-Type: ",
                                        el.mimetype,
                                        "\n",
                                        "Content-Transfer-Encoding: ",
                                        el.encoding,
                                        "\n\n",
                                }
                                local elHeader = table.concat(elData)
                                
                                local elFile = io.open( el.path, "rb" )
                                assert(elFile)
                                local fileSource = ltn12.source.cat(
                                                        ltn12.source.chain(ltn12.source.string(elHeader), mime.normalize()),
                                                        ltn12.source.chain(
                                                                        ltn12.source.file(elFile), 
                                                                        ltn12.filter.chain(
                                                                                mime.encode(el.encoding), 
                                                                                mime.wrap()
                                                                        )
                                                                ),
                                                        ltn12.source.chain(ltn12.source.string("\n"), mime.normalize())
                                                )
                                
                                table.insert(src, fileSource)
                        
                        elseif el.intent == "largedata" then
                                local elData = {
                                        "--"..self.boundary.."\n",
                                        "content-disposition: form-data; name=\"",
                                        el.name,
                                        "\"; filename=\"",
                                        el.filename,
                                        "\"\n",
                                        "Content-Type: ",
                                        el.mimetype,
                                        "\n",
                                        "Content-Transfer-Encoding: ",
                                        el.encoding,
                                        "\n\n",
                                }
                                local elHeader = table.concat(elData)
                                
--                                print("****  el.largeData) = " .. el.largedata); 
                                local fileSource = ltn12.source.cat(
                                                        ltn12.source.chain(ltn12.source.string(elHeader), mime.normalize()),
                                                        ltn12.source.chain(
                                                                        ltn12.source.string(el.largedata), 
                                                                        ltn12.filter.chain(
                                                                                mime.encode(el.encoding), 
                                                                                mime.wrap()
                                                                        )
                                                                ),
                                                        ltn12.source.chain(ltn12.source.string("\n"), mime.normalize())
                                                )
                                table.insert(src, fileSource)
                        end
                end
        end
        
        -- always need to end the body
        table.insert(src, ltn12.source.chain(ltn12.source.string("\n--"..self.boundary.."--\n"), mime.normalize()))
        
        local source = ltn12.source.empty()
        for i = 1, #src do
                source = ltn12.source.cat(source, src[i])
        end
        
        local sink, data = ltn12.sink.table()
        ltn12.pump.all(source,sink)     
        local body = table.concat(data)
        
        -- update the headers we now know how to add based on the multipart data we just generated.
        self.headers["Content-Type"] = "multipart/form-data; charset=UTF-8; boundary="..self.boundary
        self.headers["Content-Length"] = string.len(body) -- must be total length of body

        return body
end

function lib.MultipartFormData:getHeaders()
        assert(self.headers["Content-Type"])
        assert(self.headers["Content-Length"])
        return self.headers;
end
 
function lib.MultipartFormData:addHeader(name, value)
        self.headers[name] = value
end
 
function lib.MultipartFormData:setBoundry(string)
        self.boundary = string
end
 
function lib.MultipartFormData:addField(name, value)
        self:add("field", name, value)
end
 
function lib.MultipartFormData:addFile(name, path, mimeType, remoteFileName)
        -- For Corona, we can really only use base64 as a simple binary 
        -- won't work with their network.request method.
        local element = {intent="file", name=name, path=path, 
                mimetype = mimeType, filename = remoteFileName, encoding = "base64"}
        self:addElement(element)
end

function lib.MultipartFormData:addLargeData(name, largeData)
--	print("MultipartFormData:addLargeData()");
--	print("   name = " .. name);
--	print("   largeData = " .. largeData);

    -- For Corona, we can really only use base64 as a simple binary 
    -- won't work with their network.request method.
    local element = {intent="largedata", name=name, path="a", 
                mimetype = "text/plain", filename = "b", largedata = largeData, encoding = "base64"}
    self:addElement(element)
end

function lib.MultipartFormData:add(intent, name, value)
        local element = {intent=intent, name=name, value=value}
        self:addElement(element)
end
 
function lib.MultipartFormData:addElement(element)
        table.insert(self.elements, element)
end
 
function lib.MultipartFormData:toString()
        return "MultipartFormData [elementCount:"..tostring(#self.elements)..", headerCount:"..tostring(#self.headers).."]" 
end

-------------------------------------------------------------------------------
-- TogetherNotification.lua ------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherNotification = {};
lib.TogetherNotification.__index = lib.TogetherNotification;

-- @class TogetherNotification
-- Object containing push notification specific data utilized by the Together:SendPushNotification method
-- @member string alert The alert message displayed to the receiving user
-- @member number badge The badge number displayed by the push notification(APNS Only)
-- @member string sound The name of a sound to be played along with the push notification
-- @member table custom A table of extra data passed along with the push notification to be handled by the receiver's client


-----------------
-- Constructor --
-----------------

-- @classmethod TogetherNotification:New()
-- Creates a new instance of a TogetherNotification class.
-- @param string alert
-- @param number badge
-- @param string sound
-- @param table custom
-- @return TogetherNotification
function lib.TogetherNotification.New(alert, badge, sound, custom)
	local self = {};
	setmetatable(self, lib.TogetherNotification);

	self.alert							= alert;
	self.bage							= badge or nil;
	self.sound							= sound or nil;
	
	local platform = system.getInfo("platformName");
	if(platform == "Android") then
		self.custom = {custom= custom or nil};
	elseif(platform == "iPhone OS") then
		self.custom = custom or nil;
	end
	
	return self;
end

-------------------------------------------------------------------------------
-- Callback.lua ---------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherCallback = {};
lib.TogetherCallback.__index = lib.TogetherCallback;

-- @class TogetherCallback
-- Event object containing results passed to every callback as a response from a network method being called.
-- @member boolean Success Was the network call successful(TRUE) or resulted in error/unexpected(FALSE)
-- @member string Status A status code associated to the result of the network call
-- @member string Message An often more detailed description of the result of the network call status
-- @member table ResponseObj Custom table of data containing logical results of the network call itself

-----------------
-- Constructor --
-----------------

function lib.TogetherCallback.New(namespace, action, parameters)
	local self = {};
	setmetatable(self, lib.TogetherCallback);

   	self.Namespace				= namespace;
   	self.Action					= action;
   	self.Parameters				= parameters;
   		
	self.Success				= false;
	self.Status					= "";
	self.Description			= "";
	self.Response				= "";
	self.ResponseObj			= nil;

	self.NewObject				= nil;

	return self;
end

function lib.TogetherCallback:ExecuteCallbackFunc(callbackFunc)
	if (callbackFunc ~= nil) then
		callbackFunc(self);
	end
end

function lib.TogetherCallback:ExecuteCallbackFuncEx(callbackFunc, status, description)
	self.Status = status;
	self.Description = description;

	self.Success = false;
	if (status == "Success") then
		self.Success = true;
	end

	if (callbackFunc ~= nil) then
		callbackFunc(self);
	end
end

function lib.TogetherCallback:Dump()
	print("TogetherCallback:");
	print("   Namespace         = " .. self.Namespace);
	print("   Action            = " .. self.Action);
	print("   Parameters        = " .. self.Parameters);
	print("   Success           = " .. self.Success);
	print("   Status            = " .. self.Status);
	print("   Description       = " .. self.Description);
	print("   ResponseObj       = " .. self.ResponseObj);

	if (self.NewObject == nil) then
		print("   NewObject         = (nil)");
	else
		print("   NewObject         = Newly created object");
	end
end


-- return TogetherCallback;


-------------------------------------------------------------------------------
-- TogetherCache.lua ----------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherCache = {};
lib.TogetherCache.__index = lib.TogetherCache;


-----------------
-- Constructor --
-----------------

function lib.TogetherCache.New()
	local self = {};
	setmetatable(self, lib.TogetherCache);
	
	self.UserGuid				= "";
    
	return self;
end

function lib.TogetherCache:Load()
	return self:LoadEx("TogetherCache.txt");
end

function lib.TogetherCache:LoadEx(filename)
	local path = system.pathForFile(filename, system.DocumentsDirectory);
    local contents = "";
    local myTable = {};
    local file = io.open(path, "r");

    if (file ~= nil) then
    	lib.togetherPrint("   Cache file '" .. filename .. "' opened.");     
    	-- Read all contents of file into a string.
    	local contents = file:read("*a");
    	myTable = json.decode(contents);
    	io.close(file);
    	self.UserGuid = myTable.UserGuid;
    	lib.togetherPrint("   CacheUserGuid = " .. self.UserGuid);
       	return true;
   	else
--   	    native.showAlert("Error", "Unable to open file for reading " .. path, { "OK" } );
   		lib.togetherPrint("   Unable to open cache file '" .. filename .. "'.");
   	end

    return false;
end


function lib.TogetherCache:Save()
	return self:SaveEx("TogetherCache.txt");
end

function lib.TogetherCache:SaveEx(filename)
	local path = system.pathForFile(filename, system.DocumentsDirectory);
    local file = io.open(path, "w");
    
    if (file ~= nil) then
        local contents = json.encode(self);
        file:write(contents);
        io.close(file);
        file = nil;
        return true;
    else
--    	native.showAlert("Error", "Unable to open file for writing " .. path, { "OK" } );
        return false;
    end
end

function lib.TogetherCache:Erase()
	self:EraseEx("TogetherCache.txt");
end

function lib.TogetherCache:EraseEx(filename)
	local path = system.pathForFile(filename, system.DocumentsDirectory);
    os.remove(path);
end

function lib.TogetherCache:Dump()
	print("TogetherCache:");
	print("   UserGuid      = " .. self.UserGuid);
end


-- return TogetherCache;

-------------------------------------------------------------------------------
-- TogetherSocialFacebook.lua -----------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherSocialFacebook = {};
lib.TogetherSocialFacebook.__index = lib.TogetherSocialFacebook;


-- @class TogetherSocialFacebook
-- The TogetherSocialFacebook class handles all Facebook related operations.
-- @member string FacebookAppID The ID of the Facebook Application that is passed into the facebook.login() function.
-- @member table FacebookPrivileges The privileges to request from facebook whenever the User logs in.
-- @member FriendManager FriendManager The FriendManager also accessible from g_Together.FriendManager
-- @member table FacebookFriends A table of external Facebook friends
-- @member table FacebookFriendsDictionaryBySocialID A table of external Facebook friends where each key is a Friend's FacebookID
-- @member boolean FacebookFriendsRetrieved A boolean indicating whether Facebook friends have been retrieved during this session


-----------------
-- Constructor --
-----------------

function lib.TogetherSocialFacebook.New()
	local self = {};
	setmetatable(self, lib.TogetherSocialFacebook);

	self.FacebookAppID 							= "";
	self.FacebookPrivileges						= nil;
	self.FriendManager							= nil;
	self.FacebookFriends						= {};
	self.FacebookFriendsDictionaryBySocialID	= {};
	self.FacebookFriendsRetrieved				= false;

	self._RequestType							= "";
	self._TogetherFacebookUser					= nil;

	return self;
end

-- @classmethod TogetherSocialFacebook:Initialize()
-- Initializes the instance so it can connect to Facebook.
-- @param string facebookAppID The Facebook Application ID to authenticate with
-- @param table facebookPrivileges The privileges to authenticate with
function lib.TogetherSocialFacebook:Initialize(facebookAppID, facebookPrivileges)
	self.FacebookAppID = facebookAppID;
	self.FacebookPrivileges = FacebookPrivileges;
end

-- @classmethod TogetherSocialFacebook:GetFacebookFriendCount()
-- Gets the number of FacebookFriends currently managed internally.
-- @return number
function lib.TogetherSocialFacebook:GetFacebookFriendCount()
	return table.getn(self.FacebookFriends);
end

-- @classmethod TogetherSocialFacebook:GetFacebookFriend()
-- Finds the Facebook friend at the specified index.
-- @param number index The index of the friend to find
-- @return TogetherExternalFriend
function lib.TogetherSocialFacebook:GetFacebookFriend(index)
	if index < 1 then
		return nil;
	end
	
	if index > table.getn(self.FacebookFriends) then
		return nil;
	end
	
	return self.FacebookFriends[index];
end

-- @classmethod TogetherSocialFacebook:FindBySocialID()
-- Finds the Facebook friend by their Facebook ID.
-- @param string socialID The index of the FacebookFriend to find if it exists, otherwise returns nil
-- @return ExternalFriend
function lib.TogetherSocialFacebook:FindBySocialID(socialID)
	return self.FacebookFriendsDictionaryBySocialID[tostring(socialID)];
end

function lib.TogetherSocialFacebook:DumpFriends()
	print("FacebookFriends:");

	-- Dump all the Friends as well.
	local facebookFriendCount = table.getn(self.FacebookFriends);
	print("   FacebookFriendCount   = " .. facebookFriendCount);

    for i=1, facebookFriendCount do
    	self.FacebookFriends[i]:DumpEx("   ");
    end
end


-- @classmethod TogetherSocialFacebook:Login()
-- Attempts to log into Facebook. After successfully connecting, this will also
-- register the user with their profile information. If this user has already
-- registered through Facebook before, the accounts will be merged. Additionally, 
-- their Facebook friends list will be retrieved and synchronized to their Together 
-- friends list.
-- @param TogetherFacebookUser togetherFacebookUser An instance of a FacebookUser object that gets filled in with their Facebook information.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherSocialFacebook:Login(togetherFacebookUser, callbackFunc)
	self._TogetherFacebookUser = togetherFacebookUser;

	-- Callback called after FacebookUser has been registered with the logged in User.
	local function onRegisterFacebookUser(callback)
		if (callback.Success) then
			lib.togetherPrint("   success");
		    if (self.FacebookFriendsRetrieved == false) then
				self._RequestType = "GetMyFriends";
    			g_Facebook.request("me/friends");
    		else
    			callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
			end
		else
			callback:ExecuteCallbackFuncEx(callbackFunc, callback.Status, callback.Description);
		end
	end

	local function listener(event)
    	if ("session" == event.type) then
    		-- upon successful login, request list of friends of the signed in user
    		if ("login" == event.phase) then
    			lib.togetherPrint("************** Just logged in.");
    			lib.togetherPrint("************** Getting user information.");

    			self._RequestType = "GetMyInfo";
    			g_Facebook.request("me");
 
    			-- Fetch access token for use in Facebook's API
    			local access_token = event.token;
    			lib.togetherPrint(access_token);
    		end
    	elseif ("request" == event.type) then
    		if (self._RequestType == "GetMyInfo") then
    			lib.togetherPrint("   Got User information.");
    			-- event.response is a JSON object from the FB server
    			local response = event.response;
 
   				-- if request succeeds, create a scrolling list of friend names
    			if (event.isError) then
    				local callback = lib.TogetherCallback:New("", "", "");
    				callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Sorry, there was a problem retrieving your Facebook info");
    				return;
    			end
    			
    			self:_ProcessFacebookLoginResponse(togetherFacebookUser, response);
    			
  				-- Register the User as a Facebook User.
  				lib.togetherPrint("************** Calling g_Together:RegisterFacebookUser()");
   			 	g_Together:RegisterFacebookUser(togetherFacebookUser, onRegisterFacebookUser);
    			    		
    		elseif (self._RequestType == "GetMyFriends") then
    			lib.togetherPrint("************** Got my friends.");
	        	if (event.isError) then
	  				local callback = lib.TogetherCallback:New("", "", "");
    				callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Sorry, there was a problem retrieving your Facebook friends");
        	 	else
        	 		lib.togetherPrint("************** Calling self:_ProcessFacebookFriends()");
        			self:_ProcessFacebookFriends(event.response);
        	
	        		-- Sync the Friend list.
	        		lib.togetherPrint("************** Attempting to synch friends.");
					self.FriendManager:SynchFriends("FB", self.FacebookFriends, callbackFunc);
				end
            end
   		
		elseif ("dialog" == event.type) then
    		lib.togetherPrint("dialog", event.response);
    	end
    end

	
    -- NOTE: You must provide a valid application id provided from Facebook.
    if (self.FacebookAppID ~= "") then
    	lib.togetherPrint("**************  facebook.login(" .. self.FacebookAppID .. ")");
		g_Facebook.login(self.FacebookAppID, listener, self.FacebookPrivileges);
	else
       	local function onComplete(event)
	   		system.openURL("http://developers.facebook.com/setup");
        end

       	native.showAlert("Error", "To develop for Facebook Connect, you need to get an application id from Facebook's website.", { "Learn More" }, onComplete);
    end
end

-- Processes the Facebook Login response.
function lib.TogetherSocialFacebook:_ProcessFacebookLoginResponse(togetherFacebookUser, response)
	lib.togetherPrint("TogetherSocialFacebook:_ProcessFacebookLoginResponse()");
	lib.togetherPrint(response);

	local meJson = json.decode(response);

	self._TogetherFacebookUser:ProcessFacebookMeJson(meJson);
end

-- @classmethod TogetherSocialFacebook:Logout()
-- Attempts to log the user out of Facebook if connected
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherSocialFacebook:Logout(callbackFunc)

	-- listener for "fbconnect" events
	local function onLoggedOutOfFacebook(event)
   		if ("session" == event.type) then
       		-- upon successful login, immediately logout
       		if ("login" == event.phase) then
            	g_Facebook.logout();
            	callbackFunc("Success", "");
            end
        end
    end

	-- first argument is the app id that you get from Facebook
	g_Facebook.login(self.FacebookAppID, onLoggedOutOfFacebook);    	
end

-- @classmethod TogetherSocialFacebook:SendPost()
-- Submits a wall post to the active user's wall
-- @boldnote This method does not display a dialog box
-- @param string postName The name/title of the wall post
-- @param string postDescription The description of the wall post
-- @param string postMessage A message for the wall post
-- @param string postPictureLink A media link for the wall post
-- @param string postCaption The caption for the wall post
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherSocialFacebook:SendPost(postName, postDescription, postMessage, postPictureLink, postCaption, callbackFunc)
	lib.togetherPrint("TogetherSocialFacebook:SendPost()");
	lib.togetherPrint("   postName         = " .. postName);
	lib.togetherPrint("   postDescription  = " .. postDescription);
	lib.togetherPrint("   postMessage      = " .. postMessage);
	lib.togetherPrint("   postLink         = " .. postPictureLink);
    lib.togetherPrint("   postCaption      = " .. postCaption);

	local function facebookListener(event)
		if (event.type == "session") then
        	if (event.phase == "login") then
        		lib.togetherPrint("Sending wallpost to facebook");

            	postMsg = {
	   				name = postName,
    				description = postDescription,
    				message = postMessage,
    				link = postPictureLink,
    				caption = postCaption
              	}
            	
            	g_Facebook.request("me/feed", "POST", postMsg);
        	else
--				showAlert("Login Error", "Error logging into Facebook");
        		local callback = lib.TogetherCallback:New("", "", "");
    			callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Error logging into Facebook");
			end

		-- this handles the message received from a facebook dialog.
    	elseif ("dialog" == event.type) then
--        	lib.togetherPrint(event.response);
           	if (event.isError) then
--            	showAlert("Message Not Posted", "Sorry, there was a problem posting to Facebook");
				local callback = lib.TogetherCallback:New("", "", "");
    			callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Sorry, there was a problem posting to Facebook");   
        	else
--            	showAlert("Message Posted", "High score posted to Facebook");
				local callback = lib.TogetherCallback:New("", "", "");
    			callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");   
            end
        
        -- this handles the message received after a POST command
    	elseif (event.type == "request") then    
        	if (event.isError) then
--            	showAlert("Message Not Posted", "Sorry, there was a problem posting to Facebook");
				local callback = lib.TogetherCallback:New("", "", "");
    			callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Sorry, there was a problem posting to Facebook");   
        	else
--            	showAlert("Message Posted", "High score posted to Facebook");
				local callback = lib.TogetherCallback:New("", "", "");
    			callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");   
            end
        end
    end

	g_Facebook.login(self.FacebookAppID, facebookListener, self.FacebookPrivileges);
end

-- @classmethod TogetherSocialFacebook:SendPostToUser()
-- Submits a wall post to a User's wall
-- @boldnote This method will attempt to display a Facebook dialog
-- @param ExternalFriend who The receiver of the wall post must be a friend
-- @param string postName A name/title for the wall post
-- @param string postDescription The description of the wall post
-- @param string postMessage A message for the wall post
-- @param string postPictureLink A media link for the wall post
-- @param string postCaption The caption for the wall post
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherSocialFacebook:SendPostToFacebookUser(facebookID, postName, postDescription, postLink, postPictureLink, callbackFunc)
	lib.togetherPrint("TogetherSocialFacebook:SendPostToFacebookUser()");
	lib.togetherPrint("   facebookID          = " .. facebookID);
	lib.togetherPrint("   postName            = " .. postName);
	lib.togetherPrint("   postDescription     = " .. postDescription);
	lib.togetherPrint("   postLink            = " .. postLink);
	lib.togetherPrint("   postPictureLink     = " .. postPictureLink);

	local function facebookListener(event)
    	if (event.type == "session") then
        	if (event.phase == "login") then
            	local dialogPost = {
				--        app_id = APPID,
        				  to = facebookID,
        				  link = postLink,
        				  message = "This is a test.",
        				  picture = postPictureLink,
        				  name = postName,
        				  description = postDescription
 				}
				g_Facebook.showDialog("feed", dialogPost);
        	else
--				showAlert("Login Error", "Error logging into Facebook");
        		local callback = lib.TogetherCallback:New("", "", "");
    			callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Error logging into Facebook");
			end

		-- this handles the message received from a facebook dialog.
    	elseif ("dialog" == event.type) then
--        	lib.togetherPrint(event.response);
        	-- When canceled:   fbconnect://success
        	-- When posted:  	fbconnect://success?post_id=100001710404488_145863902246237
           	if (event.isError) then
--            	showAlert("Message Not Posted", "Sorry, there was a problem posting to Facebook");
				local callback = lib.TogetherCallback:New("", "", "");
    			callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Sorry, there was a problem posting to Facebook");   
        	else
				local indexOfPostID = string.find(event.response, "post_id");
				if (indexOfPostID == nil) then
					local callback = lib.TogetherCallback:New("", "", "");
    				callback:ExecuteCallbackFuncEx(callbackFunc, "Canceled", "");
    			else  
					local callback = lib.TogetherCallback:New("", "", "");
    				callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    			end   
            end
        
        -- this handles the message received after a POST command
    	elseif (event.type == "request") then    
        	if (event.isError) then
--            	showAlert("Message Not Posted", "Sorry, there was a problem posting to Facebook");
				local callback = lib.TogetherCallback:New("", "", "");
    			callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Sorry, there was a problem posting to Facebook");   
        	else
--            	showAlert("Message Posted", "High score posted to Facebook");
				local callback = lib.TogetherCallback:New("", "", "");
    			callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");   
            end
        end
    end

	g_Facebook.login(self.FacebookAppID, facebookListener, self.FacebookPrivileges);
end

-- @classmethod TogetherSocialFacebook:GetFriends()
-- Retrieves your Facebook friends list and synchronizes it with your Together friends list
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherSocialFacebook:GetFriends(callbackFunc)
	lib.togetherPrint("TogetherSocialFacebook:GetFriends()");

	-- Lets check to see if TogetherPlatform thinks that the User is logged
	-- into Facebook.
	if (g_Together:IsUserFacebookRegistered() == false) then
		local callback = lib.TogetherCallback:New("", "", "");
    	callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Please log into Facebook first");
    	return;
	end

	local function facebookListener(event)
    	if (event.type == "session") then
        	if (event.phase == "login") then
        		g_Facebook.request("me/friends");
	       	else
				local callback = lib.TogetherCallback:New("", "", "");
    			callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Error logging into Facebook");
			end
			return;
    	end
          
    	-- this handles the message received after a POST command
    	if (event.type == "request") then    
        	if (event.isError) then
--            	showAlert("Message Not Posted", "Sorry, there was a problem posting to Facebook");
  				local callback = lib.TogetherCallback:New("", "", "");
    			callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Sorry, there was a problem retrieving your Facebook friends");
         	else
        		self:_ProcessFacebookFriends(event.response);

       			-- Sync the Friend list.
				self.FriendManager:SynchFriends("FB", self.FacebookFriends, callbackFunc);
            end
        end
    end

	g_Facebook.login(self.FacebookAppID, facebookListener, self.FacebookPrivileges);
end 

lib.externalFriends_SortByCompareFunc = function(a, b)
	return string.lower(a.Name) < string.lower(b.Name);
end

function lib.TogetherSocialFacebook:_ProcessFacebookFriends(response)
	lib.togetherPrint("************** TogetherSocialFacebook:_ProcessFacebookFriends()");
	lib.togetherPrint(response);

	local jsonResponse = json.decode(response);
	lib.togetherPrint("*** Facebook Friends:");

	local externalFriend = nil;

	self.FacebookFriends = {};
	self.FacebookFriendsDictionaryBySocialID = {};

	-- Iterate through all the Facebook Friends and populate externalFriends array.
	for name, value in pairs (jsonResponse.data) do
   	   	lib.togetherPrint("**************    FacebookFriend:  name='" .. value.name .. "', id=" .. value.id);
   	   	externalFriend = lib.TogetherExternalFriend:New();
   	   	externalFriend.FriendType 	= "FB";
   	   	externalFriend.FriendID		= tostring(value.id);
   	   	externalFriend.Name			= value.name;
   	   	
   	   	table.insert(self.FacebookFriends, externalFriend);
		self.FacebookFriendsDictionaryBySocialID[tostring(externalFriend.FriendID)] = externalFriend;
   	end

	self.FacebookFriendsRetrieved = true;
--({"data":[{"name":"Erin Ebber","id":"7383782706"},{"name":"Nabie Yahoo","id":"90732385330"}]

	-- Sort the list of external friends.
	table.sort(self.FacebookFriends, lib.externalFriends_SortByCompareFunc);

	lib.togetherPrint("************** Done processing facebook friends.");
end


-- return TogetherSocialFacebook;

-------------------------------------------------------------------------------
-- Social.lua -----------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherSocial = {};
lib.TogetherSocial.__index = lib.TogetherSocial;


-- @class TogetherSocial
-- The TogetherSocial class wraps various Social APIs.
-- @member TogetherSocialFacebook Facebook A TogetherSocialFacebook class instance capable of handling all facebook related operations.

-----------------
-- Constructor --
-----------------

function lib.TogetherSocial.New()
	local self = {};
	setmetatable(self, lib.TogetherSocial);
	
	self.Facebook = lib.TogetherSocialFacebook:New();

	return self;
end


-- return TogetherSocial;


-------------------------------------------------------------------------------
-- FacebookUser.lua -----------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherFacebookUser = {};
lib.TogetherFacebookUser.__index = lib.TogetherFacebookUser;


-- @class TogetherFacebookUser
-- The TogetherFacebookUser class represents a together FacebookUser.
-- @member number FacebookUserID The ID of the FacebookUser.
-- @member number FacebookID The FacebookID of the Facebook user.
-- @member string Name The name of the Facebook user.
-- @member string FirstName The first name of the Facebook user.
-- @member string LastName The last name of the Facebook user. 
-- @member string link The link associated with the Facebook user.
-- @member string Username The username associated with the Facebook user.
-- @member string Gender The gender of the Facebook user.
-- @member string Locale The locale of the Facebook user.

-----------------
-- Constructor --
-----------------

function lib.TogetherFacebookUser.New()
	local self = {};
	setmetatable(self, lib.TogetherFacebookUser);
	
	self.FacebookUserID 		= 0;
	self.FacebookID				= 0;
	self.Name					= "";
	self.FirstName				= "";
	self.LastName				= "";
	self.Link					= "";
	self.Username				= "";
	self.Gender					= "";
	self.Locale					= "";

	return self;
end

function lib.TogetherFacebookUser:ProcessFacebookUserJson(facebookUserJson)
	self.FacebookUserID 		= facebookUserJson.FacebookUserID;
	self.FacebookID				= facebookUserJson.FacebookID;
	self.Name					= facebookUserJson.Name;
	self.FirstName				= facebookUserJson.FirstName;
	self.LastName				= facebookUserJson.LastName;
	self.Link					= facebookUserJson.Link;
	self.Username				= facebookUserJson.Username;
	self.Gender					= facebookUserJson.Gender;
	self.Locale					= facebookUserJson.Locale;
end

function lib.TogetherFacebookUser:ProcessFacebookMeJson(meJson)
	self.FacebookID				= meJson.id;
	self.Name					= meJson.name;
	self.FirstName				= meJson.first_name;
	self.LastName				= meJson.last_name;
	self.Link					= meJson.link;
	self.Username				= meJson.username;
	self.Gender					= meJson.gender;
	self.Locale					= meJson.locale;
end

function lib.TogetherFacebookUser:Dump()
	self:DumpEx("");
end

function lib.TogetherFacebookUser:DumpEx(spacing)
	print(spacing .. "TogetherFacebookUser:");
	print(spacing .. "   FacebookUserID       = " .. tostring(self.FacebookUserID));
	print(spacing .. "   FacebookID           = " .. tostring(self.FacebookID));
	print(spacing .. "   Name                 = " .. tostring(self.Name));
	print(spacing .. "   FirstName            = " .. tostring(self.FirstName));
	print(spacing .. "   LastName             = " .. tostring(self.LastName));
	print(spacing .. "   Link                 = " .. tostring(self.Link));
	print(spacing .. "   Username             = " .. tostring(self.Username));
	print(spacing .. "   Gender               = " .. tostring(self.Gender));
	print(spacing .. "   Locale               = " .. tostring(self.Locale));
end


-- return TogetherFacebookUser;

-------------------------------------------------------------------------------
-- CustomUser.lua -------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherCustomUser = {};
lib.TogetherCustomUser.__index = lib.TogetherCustomUser;


-- @class TogetherCustomUser
-- The TogetherCustomUser class represents a together CustomUser.
-- @member number CustomUserID The ID of the CustomUser.
-- @member string Email The email of the Custom User.
-- @member string Name The name of the Custom User.

-----------------
-- Constructor --
-----------------

function lib.TogetherCustomUser.New()
	local self = {};
	setmetatable(self, lib.TogetherCustomUser);
	
	self.CustomUserID 			= "";
	self.Email					= "";
	self.Name					= "";

	return self;
end

function lib.TogetherCustomUser:ProcessCustomUserJson(customUserJson)
	self.CustomUserID 			= customUserJson.CustomUserID;
	self.Email					= customUserJson.Email;
	self.Name					= customUserJson.Name;
end

function lib.TogetherCustomUser:Dump()
	self:DumpEx("");
end

function lib.TogetherCustomUser:DumpEx(spacing)
	print(spacing .. "TogetherCustomUser:");
	print(spacing .. "   CustomUserID         = " .. self.CustomUserID);
	print(spacing .. "   Email                = " .. self.Email);
	print(spacing .. "   Name                 = " .. self.Name);
end


-- return TogetherCustomUser;

-------------------------------------------------------------------------------
-- Property.lua ---------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherProperty = {};
lib.TogetherProperty.__index = lib.TogetherProperty;

-- @class TogetherProperty
-- A TogetherProperty is a simple name/value pair that managed by a PropertyCollection.
-- @member string Name The name of this property
-- @member string Value The value of this property

-----------------
-- Constructor --
-----------------

-- @classmethod TogetherProperty:New()
-- Creates a new TogetherProperty
-- @return TogetherProperty
function lib.TogetherProperty.New()
	local self = {};
	setmetatable(self, lib.TogetherProperty);

	self.Name					= "";
	self.Value					= "";

	return self;
end

function lib.TogetherProperty:ProcessNodePropertyJson(nodePropertyJson)
	self.Name					= nodePropertyJson.Name;
	self.Value					= nodePropertyJson.Value;
end

function lib.TogetherProperty:ToString()
	local retString = "Property:" ..
		"\n\tName = " .. self.Name ..
		"\n\tValue = ";
	if (self.Value ~= nil) then
		retString = retString .. self.Value;
	end

	return retString;
end

function lib.TogetherProperty:Dump()
	self:Dump("");
end

function lib.TogetherProperty:DumpEx(spacing)
	print(spacing .. "TogetherProperty:");
	print(spacing .. "   Name                   = " .. self.Name);
	if (self.Value == nil) then
		print(spacing .. "   Value                  = (nil)");
	else
		print(spacing .. "   Value                  = " .. self.Value);
	end
end


-- return TogetherProperty;

-------------------------------------------------------------------------------
-- PropertyCollection.lua -----------------------------------------------------
-------------------------------------------------------------------------------
lib.PropertyCollection = {};
lib.PropertyCollection.__index = lib.PropertyCollection;

-- @class PropertyCollection
-- The PropertyCollection class contains a list of TogetherProperties and additional child PropertyCollections.
-- @member string Name The name of this collection node.
-- @boldnote PropertyCollections allow children with matching names, but this is not suggested as it could result in unexpected search results.
-- @member table Properties A list of TogetherProperties.
-- @member table Children A list of children PropertyCollections.

-----------------
-- Constructor --
-----------------

-- @classmethod PropertyCollection:New()
-- Creates a new PropertyCollection object
-- @return PropertyCollection
function lib.PropertyCollection.New()
	local self = {};
	setmetatable(self, lib.PropertyCollection);

	self.Name					= "";
	self.Properties				= {};
	self.Children				= {};

	return self;
end


-- @classmethod PropertyCollection:FindProperty()
-- Gets the property with the specified name if it exists, otherwise returns nil.
-- @param string propertyName The name of the property to find
-- @return TogetherProperty
function lib.PropertyCollection:FindProperty(propertyName)
	local propsCount = self:GetCount();
	for i=1, propsCount do
		if (self.Properties[i].Name == propertyName) then
			return self.Properties[i];
		end
	end
	return nil;
end


-- @classmethod PropertyCollection:Get()
-- Gets the property value with the specified name if it exists, otherwise returns nil.
-- @param string propertyName The name of the property to find
-- @return string
function lib.PropertyCollection:Get(propertyName)
	local property = self:FindProperty(propertyName);
	if (property == nil) then
		return nil;
	end
	return property.Value;
end

-- @classmethod PropertyCollection:GetEx()
-- Gets the value of the property with the specified name if it exists, otherwise this 
-- will create the new property with the default value and return that value.
-- @param string propertyName The name of the property to find
-- @param string defaultValue The value to be returned when the property is not found
-- @return string
function lib.PropertyCollection:GetEx(propertyName, defaultValue)
	local propertyValue = self:Get(propertyName);
	if (propertyValue ~= nil) then
		return propertyValue;
	else
		self:Set(propertyName, defaultValue);
		return defaultValue;
	end
end


-- @classmethod PropertyCollection:Set()
-- Sets the value of the property with the specified name if it exists, otherwise creates it with the set value.
-- @param string propertyName The name of the property to set or create
-- @param string propertyValue The value to set for the property
-- @return TogetherProperty
function lib.PropertyCollection:Set(propertyName, propertyValue)
	local property = self:FindProperty(propertyName);
	if (property == nil) then
		property = lib.TogetherProperty:New();
		table.insert(self.Properties, property);
	end

	property.Name = propertyName;
	property.Value = propertyValue;
	
	return property;
end


-- @classmethod PropertyCollection:HasProperty()
-- Checks to see whether a property with the specified name exists.
-- @param string propertyName The name of the property to check for
-- @return boolean
function lib.PropertyCollection:HasProperty(propertyName)
	if (self.Properties[propertyName] == nil) then
		return false;
	end
	return true;
end


-- @classmethod PropertyCollection:GetCount()
-- Returns the number of properties in the collection. This does not include children collections.
-- @return number
function lib.PropertyCollection:GetCount()
	return table.getn(self.Properties);
end


-- @classmethod PropertyCollection:GetAt()
-- Gets the property at the specified index.
-- @param number index The index to return from the collection
-- @return TogetherProperty
function lib.PropertyCollection:GetAt(index)
	return self.Properties[index];
end

function lib.PropertyCollection:ProcessNodeJson(nodeJson)
	if (nodeJson ~= nil) then
		self.Name = nodeJson.Name;
		self:ProcessNodePropertiesJson(nodeJson.Properties);
		self:ProcessNodeChildrenJson(nodeJson.Children);
	end
end

function lib.PropertyCollection:ProcessNodePropertiesJson(nodePropertiesJson)
	self.Properties = {};
	if (nodePropertiesJson ~= nil) then
		-- Parse out all the NodeProperties.
		for name, value in pairs (nodePropertiesJson) do
    		local property = lib.TogetherProperty:New();
			property:ProcessNodePropertyJson(value);
			self.Properties[name] = property;
		end
	end
end

function lib.PropertyCollection:ProcessNodeChildrenJson(nodeChildrenJson)

	self.Children = {};
	
	if (nodeChildrenJson ~= nil) then
		-- Parse out all the NodeChildrens.
		for name, value in pairs (nodeChildrenJson) do
    		local children = lib.PropertyCollection:New();

			children:ProcessNodeJson(value);

			self.Children[name] = children;
		end
	end
end

function lib.PropertyCollection:EncodeJson()
	local selfEncoded = "";

	if (self.Name ~= "" or table.getn(self.Properties) > 0 or table.getn(self.Children) > 0) then
		selfEncoded = json.encode(self);
	end
	
	return selfEncoded;
end

function lib.PropertyCollection:ToString()
	local res = "Node:" ..
				"\n\tName = " .. self.Name;

	-- Dump all the Properties.
	local propsCount = 0;
	if (Properties ~= nil) then
		propsCount =  table.getn(self.Properties);
	end

	res = res .. "\n\tPropertiesCount = " .. propsCount;
			
    for i=1, propsCount do
		res = res .. "\n\t" .. self.Properties[i]:ToString();
	end
				
	
	-- Dump all the Children
	local childCount = 0;
	if (self.Children ~= nil) then
		childCount = table.getn(self.Children);
	end
				
	res = res .. "\n\tChildCount = " .. childCount;

	for j=1, childCount do
		res = res .. "\n\t" .. self.Children[j]:ToString();
	end
	
	return res;
end


function lib.PropertyCollection:Dump()
	self:DumpEx("");
end


function lib.PropertyCollection:DumpEx(spacing)
	local propsCount = table.getn(self.Properties);
	local childCount = table.getn(self.Children);

	print(spacing .. "PropertyCollection:");
	print(spacing .. "   Name               = " .. self.Name);

	print(spacing .. "   Properties:     " .. propsCount);
    for i=1, propsCount do
		self.Properties[i]:DumpEx(spacing .. "      ");
	end

	print(spacing .. "   Children:     " .. childCount);
    for j=1, childCount do
		self.Children[j]:DumpEx(spacing .. "      ");
	end
end


-- return PropertyCollection;

-------------------------------------------------------------------------------
-- ClientUserProfile.lua ------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherClientUserProfile = {};
lib.TogetherClientUserProfile.__index = lib.TogetherClientUserProfile;

-- @class TogetherClientUserProfile
-- The ClientUserProfile class contains a PropertyCollection stored for the user and associated 
-- to you, the developer, and is accessible from other games you have registered.
-- @member number ClientUserProfileID The ID of the ClientUserProfile.
-- @member number UserID The ID of the User associated with the ClientUserProfile.
-- @member number ClientID The ID of the Client associated with the ClientUserProfile.
-- @member PropertyCollection Properties A property collection containing all developer specific properties for the User. 


-----------------
-- Constructor --
-----------------

function lib.TogetherClientUserProfile.New()
	local self = {};
	setmetatable(self, lib.TogetherClientUserProfile);
	
	self.ClientUserProfileID	= 0;
	self.UserID					= 0;
	self.ClientID				= 0;
	self.Properties				= lib.PropertyCollection:New();

	return self;
end

function lib.TogetherClientUserProfile:ProcessClientUserProfileJson(clientUserProfileJson)
	self.ClientUserProfileID 	= clientUserProfileJson.ClientUserProfileID;
	self.UserID					= clientUserProfileJson.UserID;
	self.ClientID				= clientUserProfileJson.ClientID;

	self.Properties:ProcessNodeJson(clientUserProfileJson.Properties);
end

function lib.TogetherClientUserProfile:Dump()
	self:DumpEx("");
end

function lib.TogetherClientUserProfile:DumpEx(spacing)
	print(spacing .. "ClientUserProfile:");
	print(spacing .. "   ClientUserProfileID     = " .. self.ClientUserProfileID);
	print(spacing .. "   UserID                  = " .. self.UserID);
	print(spacing .. "   ClientID                = " .. self.ClientID);

	self.Properties:DumpEx(spacing .. "   ");
end


-- return TogetherClientUserProfile;

-------------------------------------------------------------------------------
-- GameUserProfile.lua --------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherGameUserProfile = {};
lib.TogetherGameUserProfile.__index = lib.TogetherGameUserProfile;


-- @class TogetherGameUserProfile
-- The GameUserProfile class contains a PropertyCollection stored for the user and 
-- associated to a particular game.
-- @member number GameUserProfileID The ID of the GameUserProfile.
-- @member number UserID The ID of the User associated with the GameUserProfile.
-- @member number GameID The ID of the Game associated with the GameUserProfile.
-- @member PropertyCollection Properties A property collection containing all game specific properties for the User. 


-----------------
-- Constructor --
-----------------

function lib.TogetherGameUserProfile.New()
	local self = {};
	setmetatable(self, lib.TogetherGameUserProfile);
	
	self.GameUserProfileID		= 0;
	self.UserID					= 0;
	self.GameID					= 0;
	self.Properties				= lib.PropertyCollection:New();

	return self;
end

function lib.TogetherGameUserProfile:ProcessGameUserProfileJson(gameUserProfileJson)
	self.GameUserProfileID 		= gameUserProfileJson.GameUserProfileID;
	self.UserID					= gameUserProfileJson.UserID;
	self.GameID					= gameUserProfileJson.GameID;

	self.Properties:ProcessNodeJson(gameUserProfileJson.Properties);
end

function lib.TogetherGameUserProfile:Dump()
	self:DumpEx("");
end

function lib.TogetherGameUserProfile:DumpEx(spacing)
	print(spacing .. "GameUserProfile:");
	print(spacing .. "   GameUserProfileID       = " .. self.GameUserProfileID);
	print(spacing .. "   UserID                  = " .. self.UserID);
	print(spacing .. "   GameID                  = " .. self.GameID);

	self.Properties:DumpEx(spacing .. "   ");
end


-- return TogetherGameUserProfile;

-------------------------------------------------------------------------------
-- UserGame.lua ---------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherUserGame = {};
lib.TogetherUserGame.__index = lib.TogetherUserGame;


-- @class TogetherUserGame
-- The UserGame class represents a game played by a User.
-- @member number GameID The ID of the Game the User has played.
-- @member string Name The Name of the Game the User has played.
-- @member string Description A textual description for the Game the User has played.


-----------------
-- Constructor --
-----------------

function lib.TogetherUserGame.New()
	local self = {};
	setmetatable(self, lib.TogetherUserGame);

	self.GameID							= 0;
	self.Name							= "";
	self.Description					= "";

	return self;
end

function lib.TogetherUserGame:ProcessUserAchievementJson(userGameJson)
	self.GameID							= userGameJson.GameID;
	self.Name							= userGameJson.Name;
	self.Description					= userGameJson.Description;
end

function lib.TogetherUserGame:Dump()
	self:DumpEx("");
end

function lib.TogetherUserGame:DumpEx(spacing)
	print(spacing .. "UserAchievement:");
	print(spacing .. "   GameID                        = " .. self.GameID);
	print(spacing .. "   Name                          = " .. self.Name);
	print(spacing .. "   Description                   = " .. self.Description);
end


-- return TogetherUserGame;

-------------------------------------------------------------------------------
-- UserGameManager.lua --------------------------------------------------------
-------------------------------------------------------------------------------
lib.UserGameManager = {};
lib.UserGameManager.__index = lib.UserGameManager;

-- @class UserGameManager
-- The UserGameManager class is for finding and fetching games played by the user.
-- @member table UserGames Stores all the UserGames contained in the Manager.

function lib.UserGameManager.New()
	local self = {};
	setmetatable(self, lib.UserGameManager);

	-- Contains all the UserGames.
	self.UserGames = {};

	return self;
end


-- @classmethod UserGameManager:FindByUserGameID()
-- Finds the UserGame with the specified UserGameID if it exists, otherwise returns nil.
-- @param number userGameID The ID of the UserGame to find  
-- @return UserGame
function lib.UserGameManager:FindByGameID(gameID)
	local indexOfUserGame = self:IndexOfByGameID(gameID);
	if (indexOfUserGame ~= -1) then
		return self:Get(indexOfUserGame);
	end
	return nil;
end

-- @classmethod UserGameManager:GetCount()
-- Gets the number of UserGames currently managed internally.
-- @return number
function lib.UserGameManager:GetCount()
	return table.getn(self.UserGames);
end

-- @classmethod UserGameManager:Get()
-- Gets the UserGame at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the UserGame to find
-- @return TogetherUserGame
function lib.UserGameManager:Get(index)
	return self.UserGames[index];
end

-- @classmethod UserGameManager:IndexOf()
-- Returns the index of the specified UserGame if it exists, otherwise returns nil.
-- @param TogetherUserGame userGame Instance of the UserGame to retrieve the index of.  
-- @return number
function lib.UserGameManager:IndexOf(userGame)
	return table.indexOf(self.UserGames, userGame);
end

-- @classmethod UserGameManager:IndexOfByGameID()
-- Returns the index of the UserGame with the specified GameID if it exists, otherwise returns -1.
-- @param number gameID The ID of the Game to find the index of.
-- @return number
function lib.UserGameManager:IndexOfByGameID(gameID)
	local userGameCount = self:GetCount();

   	for i=1, userGameCount do
    		if (self.UserGames[i].GameID == gameID) then
			return i;
		end
    end

    return -1;
end

-- @classmethod UserGameManager:Remove()
-- Removes a UserGame from the internally managed list. This does not delete the user game from the user's account persistently.
-- @boldnote This method is deprecated
-- @param number index The index of the UserGame to be removed.
function lib.UserGameManager:Remove(index)
	if (index ~= -1)	then
		table.remove(self.UserGames, index);
	end
end

function lib.UserGameManager:Dump()
	print("UserGames:");

	-- Dump all the UserGames as well.
	local userGameCount = table.getn(self.UserGames);
	print("   UserGameCount   = " .. userGameCount);

    for i=1, userGameCount do
    	self.UserGames[i]:DumpEx("   ");
    end
end

function lib.UserGameManager:ProcessUserGamesJson(userGamesJson)
	self.UserGames = {};

	-- Parse out all the UserAchievements.
	for name, value in pairs (userGamesJson) do
    	local userGame = lib.TogetherUserGame:New();
		userGame:ProcessUserGameJson(value);
		table.insert(self.UserGames, userGame);
    end

    lib.togetherPrint("   Processed " .. table.getn(self.UserGames) .. " user games.");
end




-------------------------------------------------------------------------------
--  Network methods.
-------------------------------------------------------------------------------

-- @classmessage UserGameManager:GetAll()
-- Gets all UserGames played by the User. Upon success, this will automatically update the internal list.
-- @param function callbackFunc The function to call upon completion.
function lib.UserGameManager:GetAll(callbackFunc)
	lib.togetherPrint("UserGameManager:GetAll()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


   		-- Process the response data.
		self:ProcessUserGamesJson(callback.ResponseObj.UserGames);

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


   	local parameters = "SessionToken=" .. g_Together:GetSessionToken();

   	lib.sendNetworkMessage("users", "getallusergames", parameters, networkListener);	
end


--return UserGameManager;

-------------------------------------------------------------------------------
-- Item.lua -------------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherItem = {};
lib.TogetherItem.__index = lib.TogetherItem;

-- @class TogetherItem
-- The TogetherItem class represents a together Item.
-- @member number ItemID The ID of the Item.
-- @member string ItemType The type of Item this is.
-- @member string Name The name of the Item.
-- @member string Description A textual description of the Item.
-- @member PropertyCollection Properties A property collection containing all custom properties for the Item.
-- @member PropertyCollection PriceProperties A property collection containing all the price related properties for the Item.


-----------------
-- Constructor --
-----------------

function lib.TogetherItem.New()
	local self = {};
	setmetatable(self, lib.TogetherItem);

	self.ItemID					= 0;
	self.ItemType				= "";
	self.Name					= "";
	self.Description			= "";
	self.Properties				= lib.PropertyCollection:New();
	self.PriceProperties		= lib.PropertyCollection:New();

	return self;
end

function lib.TogetherItem:ProcessItemJson(itemJson)
	self.ItemID					= itemJson.ItemID;	
	self.ItemType				= itemJson.ItemType;
	self.Name					= itemJson.Name;
	self.Description			= itemJson.Description;

	self.Properties:ProcessNodeJson(itemJson.Properties);
	self.PriceProperties:ProcessNodeJson(itemJson.PriceProperties);
end

function lib.TogetherItem:Dump()
	self:DumpEx("");
end

function lib.TogetherItem:DumpEx(spacing)
	print(spacing .. "Item:");
	print(spacing .. "   ItemID                 = " .. self.ItemID);
	print(spacing .. "   ItemType               = " .. self.ItemType);
	print(spacing .. "   Name                   = " .. self.Name);
	print(spacing .. "   Description            = " .. self.Description);

	self.Properties:DumpEx(spacing .. "   ");
	self.PriceProperties:DumpEx(spacing .. "   ");
end


-- return TogetherItem;

-------------------------------------------------------------------------------
-- UserItem.lua ---------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherUserItem = {};
lib.TogetherUserItem.__index = lib.TogetherUserItem;


-- @class TogetherUserItem
-- The UserItem class represents an Item belonging to the User's account.
-- @member number UserItemID The ID of the UserItem.
-- @member number RoomID The ID of the Room the UserItem was created in.  If equal to 0, then the UserItem wasn't created in a room.
-- @member TogetherItem Item The base Item that the UserItem is essentially an instance of.
-- @member PropertyCollection Properties A property collection containing all custom properties for the UserItem.


-----------------
-- Constructor --
-----------------

function lib.TogetherUserItem.New()
	local self = {};
	setmetatable(self, lib.TogetherUserItem);

	self.UserItemID				= 0;
	self.RoomID					= 0;
	self.Item					= lib.TogetherItem:New();
	self.Properties				= lib.PropertyCollection:New();

	return self;
end

function lib.TogetherUserItem:ProcessUserItemJson(userItemJson)
	self.UserItemID				= userItemJson.UserItemID;	
	self.RoomID					= userItemJson.RoomID;

	if (userItemJson["Item"] ~= nil) then
		self.Item:ProcessItemJson(userItemJson.Item);
	end
	if (userItemJson["Properties"] ~= nil) then
		self.Properties:ProcessNodeJson(userItemJson.Properties);
	end
end

function lib.TogetherUserItem:Dump()
	self:DumpEx("");
end

function lib.TogetherUserItem:DumpEx(spacing)
	print(spacing .. "UserItem:");
	print(spacing .. "   UserItemID             = " .. self.UserItemID);
	print(spacing .. "   RoomID                 = " .. self.RoomID);

	self.Item:DumpEx(spacing .. "   ");
	self.Properties:DumpEx(spacing .. "   ");
end


--------------------------------------------------------------------------------
--  Network methods.
--------------------------------------------------------------------------------

-- @classmessage TogetherUserItem:Modify()
-- Modifies the UserItem. Upon success, this will automatically update the internal data.
-- The UserItemID and Properties members are sent to the server when this method is called.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherUserItem:Modify(callbackFunc)
	lib.togetherPrint("TogetherUserItem:Modify()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Process the response data.
		self:ProcessUserItemJson(callback.ResponseObj.UserItem);

   		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&UserItemID=" .. self.UserItemID ..
    	"&UserItemProps=" .. self.Properties:EncodeJson();

	lib.sendNetworkMessage("users", "modifyuseritem", parameters, networkListener);
end


-- return TogetherUserItem;

-------------------------------------------------------------------------------
-- UserItemManager.lua --------------------------------------------------------
-------------------------------------------------------------------------------
lib.UserItemManager = {};
lib.UserItemManager.__index = lib.UserItemManager;

-- @class UserItemManager
-- The UserItemManager is used for fetching and finding items that exist for the current user.
-- @member table UserItems Stores all the UserItems contained in the Manager.

	
function lib.UserItemManager.New()
	local self = {};
	setmetatable(self, lib.UserItemManager);

	-- Contains all the Items.
	self.UserItems = {};

	return self;
end


-- @classmethod UserItemManager:Add()
-- Adds a UserItem to the internally managed list without persistence.
-- @boldnote This method is deprecated
-- @param TogetherUserItem userItem Instance of a UserItem to add internally
function lib.UserItemManager:Add(userItem)
	table.insert(self.UserItems, userItem);
end

-- @classmethod UserItemManager:FindByUserItemID()
-- Finds the UserItem with the specified UserItemID if it exists, otherwise returns nil.
-- @param number userItemID The ID of the UserItem to find  
-- @return TogetherUserItem
function lib.UserItemManager:FindByUserItemID(userItemID)
	local indexOfUserItem = self:IndexOfByUserItemID(userItemID);
	if (indexOfUserItem ~= -1) then
		return self:Get(indexOfUserItem);
	end
	return nil;
end

-- @classmethod UserItemManager:GetCount()
-- Gets the number of UserItems currently managed internally.
-- @return number
function lib.UserItemManager:GetCount()
	return table.getn(self.UserItems);
end

-- @classmethod UserItemManager:Get()
-- Gets the UserItem at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the UserItem to retrieve.  
-- @return TogetherUserItem
function lib.UserItemManager:Get(index)
	return self.UserItems[index];
end

-- @classmethod UserItemManager:IndexOf()
-- Returns the index of the specified UserItem if it exists, otherwise returns nil.
-- @param TogetherUserItem userItem Instance of the UserItem to find the index of
-- @return number
function lib.UserItemManager:IndexOf(userItem)
	return table.indexOf(self.UserItems, userItem);
end

-- @classmethod UserItemManager:IndexOfByUserItemID()
-- Returns the index of the UserItem with the specified UserItemID if it exists, otherwise returns -1.
-- @param number userItemID The ID of the UserItem to find the index of
-- @return number
function lib.UserItemManager:IndexOfByUserItemID(userItemID)
	local userItemCount = self:GetCount();

   	for i=1, userItemCount do
    	if (self.UserItems[i].UserItemID == userItemID) then
			return i;
		end
    end

    return -1;
end

-- @classmethod UserItemManager:Remove()
-- Removes a UserItem from the internally managed list. This does not delete the user item from the user's account persistently.
-- @boldnote This method is deprecated
-- @param number index The index of the UserItem to remove internally
function lib.UserItemManager:Remove(index)
	if (index ~= -1)	then
		table.remove(self.UserItems, index);
	end
end

function lib.UserItemManager:Dump()
	print("UserItems:");

	-- Dump all the UserItems as well.
	local userItemCount = table.getn(self.UserItems);
	print("   UserItemCount   = " .. userItemCount);

    for i=1, userItemCount do
   		self.UserItems[i]:DumpEx("   ");
    end
end

function lib.UserItemManager:ProcessUserItemsJson(userItemsJson)
	lib.togetherPrint("UserItemManager:ProcessUserItemsJson()");

	self.UserItems = {};

	-- Parse out all the UserItems.
	for name, value in pairs (userItemsJson) do
    	local userItem = lib.TogetherUserItem:New();
		userItem:ProcessUserItemJson(value);
		table.insert(self.UserItems, userItem);
    end

    lib.togetherPrint("   Processed " .. table.getn(self.UserItems) .. " user items.");
end




-------------------------------------------------------------------------------
--  Network methods.
-------------------------------------------------------------------------------

-- @classmessage UserItemManager:Award()
-- Awards a UserItem. Upon success, this automatically updates the internal list.
-- @param number itemID The ID of the Item to award.
-- @param number roomID The ID of the Room the UserItem is being awarded in. Pass 0.
-- @param PropertyCollection userItemProperties The properties to assign to the UserItem.  Pass nil to assign no properties.
-- @param function callbackFunc The function to call upon completion.
-- @boldnote Rooms are deprecated and the roomID has no effect at this time
function lib.UserItemManager:Award(itemID, roomID, userItemProperties, callbackFunc)
	lib.togetherPrint("UserItemManager:Award(" .. itemID .. ", " .. roomID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Create a new UserItem.
    	g_CurrentUserItem = lib.TogetherUserItem:New();

		-- Process the response data.
    	g_CurrentUserItem:ProcessUserItemJson(callback.ResponseObj.UserItem);
    	self:Add(g_CurrentUserItem);
    	callback.NewObject = g_CurrentUserItem;

    	callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&ItemID=" .. itemID ..
		"&RoomID=" .. roomID;
	if (userItemProperties ~= nil) then
		parameters = parameters .. "&UserItemProps=" .. userItemProperties:EncodeJson();
	end

	lib.sendNetworkMessage("users", "awarduseritem", parameters, networkListener);	
end

-- @classmessage UserItemManager:Create()
-- Creates a UserItem.
-- @param number itemID The ID of the Item to create a UserItem from.
-- @param number roomID The ID of the Room the UserItem is being awarded in. Pass 0.
-- @param PropertyCollection userItemProperties The properties to assign to the UserItem.  Pass nil to assign no properties.
-- @param function callbackFunc The function to call upon completion.
-- @boldnote Rooms are deprecated and the roomID has no effect at this time
function lib.UserItemManager:Create(itemID, roomID, userItemProperties, callbackFunc)
	lib.togetherPrint("UserItemManager:Create(" .. itemID .. ", " .. roomID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Create a new UserItem.
    	g_CurrentUserItem = lib.TogetherUserItem:New();

		-- Process the response data.
    	g_CurrentUserItem:ProcessUserItemJson(callback.ResponseObj.UserItem);
    	self:Add(g_CurrentUserItem);
    	callback.NewObject = g_CurrentUserItem;

	    callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&ItemID=" .. itemID ..
    	"&RoomID=" .. roomID;
	if (userItemProperties ~= nil) then
		parameters = parameters .. "&UserItemProps=" .. userItemProperties:EncodeJson();
	end

	lib.sendNetworkMessage("users", "createuseritem", parameters, networkListener);	
end

-- @classmessage UserItemManager:Delete()
-- Deletes a UserItem. Upon success, this automatically updates the internal list.
-- @param number userItemID The ID of the UserItem to delete.
-- @param function callbackFunc The function to call upon completion.
function lib.UserItemManager:Delete(userItemID, callbackFunc)
	lib.togetherPrint("UserItemManager:Delete(" .. userItemID .. "'");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


	    -- Now, remove the deleted UserItem.
    	self:Remove(self:IndexOfByUserItemID(userItemID));

	    callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&UserItemID=" .. userItemID;

	lib.sendNetworkMessage("users", "deleteuseritem", parameters, networkListener);
end

-- @classmessage UserItemManager:GetAll()
-- Gets all UserItems assigned to the User. Upon success, this automatically updates the internal list.
-- @param function callbackFunc The function to call upon completion.
function lib.UserItemManager:GetAll(callbackFunc)
	lib.togetherPrint("UserItemManager:GetAll()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


    	-- Now parse the json data.
		self:ProcessUserItemsJson(callback.ResponseObj.UserItems);

	    callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken();

    lib.sendNetworkMessage("users", "getalluseritems", parameters, networkListener);
end

-- @classmessage UserItemManager:Purchase()
-- Purchases a UserItem. Upon success, this automatically updates the internal list.
-- @param number itemID The ID of the Item to purchase.
-- @param number roomID The ID of the Room the UserItem is being awarded in. Pass 0.
-- @param PropertyCollection userItemProperties The properties to assign to the UserItem. Pass nil to assign no properties.
-- @param function callbackFunc The function to call upon completion.
-- @boldnote Rooms are deprecated and the roomID has no effect at this time
function lib.UserItemManager:Purchase(itemID, roomID, userItemProperties, useGameUserProfileProperties, callbackFunc)
	lib.togetherPrint("UserItemManager:Purchase(" .. itemID .. ", " .. roomID .. "'");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Create a new UserItem.
    	g_CurrentUserItem = lib.TogetherUserItem:New();

		-- Process the response data.
    	g_CurrentUserItem:ProcessUserItemJson(callback.ResponseObj.UserItem);
    	self:Add(g_CurrentUserItem);
    	callback.NewObject = g_CurrentUserItem;

	    callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&ItemID=" .. itemID ..
   		"&RoomID=" .. roomID ..
   		"&UseGameUserProfileProperties=" .. tostring(useGameUserProfileProperties);
	if (userItemProperties ~= nil) then
		parameters = parameters .. "&UserItemProps=" .. userItemProperties:EncodeJson();
	end

	lib.sendNetworkMessage("users", "purchaseuseritem", parameters, networkListener);	
end

-- @classmessage UserItemManager:Sell()
-- Sells a UserItem. Upon success, this automatically updates the internal list.
-- @param number userItemID The ID of the UserItem to sell.
-- @param function callbackFunc The function to call upon completion.
function lib.UserItemManager:Sell(userItemID, callbackFunc)
	lib.togetherPrint("UserItemManager:Sell(" .. userItemID .. "'");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end
    		

	    -- Now, remove the deleted UserItem.
    	self:Remove(self:IndexOfByUserItemID(userItemID));
    		
    	callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&UserItemID=" .. userItemID;

	lib.sendNetworkMessage("users", "selluseritem", parameters, networkListener);
end


--return UserItemManager;

-------------------------------------------------------------------------------
-- Achievement.lua ------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherAchievement = {};
lib.TogetherAchievement.__index = lib.TogetherAchievement;


-- @class TogetherAchievement
-- The Achievement class represents a together Achievement.
-- @member long AchievementID The ID of the Achievement.
-- @member string ActionName The name of the action signifying what needs to be accomplished in order to get the Achievement.
-- @member string Name The name of the Achievement.
-- @member string Description A textual description of the Achievement.
-- @member number RequiredCount The number of times the Achievement must be accomplished before it is completed.
-- @member boolean RequiredSequential A boolean indicating whether the Achievement actions must be performed sequentially in time.
-- @member number RequiredItemID The ID of the Item that is required in order to accomplish the Achievement.
-- @member number RequiredItemCount The number of Items that are required in order to accomplish the Achievement.
-- @member number AwardItemID The ID of the Item to award the User when they accomplish the Achievement.
-- @member number AwardItemCount The number of Items that are awarded to the User when they accomplish the Achievement.
-- @member PropertyCollection Properties A property collection containing all custom properties for the Achievement.
-- @member PropertyCollection PriceProperties A property collection containing all the price related properties for the Achievement.

-----------------
-- Constructor --
-----------------

function lib.TogetherAchievement.New()
	local self = {};
	setmetatable(self, lib.TogetherAchievement);

	self.AchievementID					= 0;
	self.ActionName						= "";
	self.Name							= "";
	self.Description					= "";
	self.RequiredCount					= 0;
	self.RequiredSequential				= false;
	self.RequiredItemID					= 0;
	self.RequiredItemCount				= 0;
	self.AwardItemID					= 0;
	self.AwardItemCount					= 0;
	self.Properties						= lib.PropertyCollection:New();
	self.PriceProperties				= lib.PropertyCollection:New();

	return self;
end

function lib.TogetherAchievement:ProcessAchievementJson(achievementJson)
	self.AchievementID			= achievementJson.AchievementID;	
	self.ActionName				= achievementJson.ActionName;
	self.Name					= achievementJson.Name;
	self.Description			= achievementJson.Description;
	self.RequiredCount			= tonumber(achievementJson.RequiredCount);
	self.RequiredSequential		= achievementJson.RequiredSequential;
	self.RequiredItemID  	   	= achievementJson.RequiredItemID;
	self.RequiredItemCount  	= tonumber(achievementJson.RequiredItemCount);
	self.AwardItemID			= achievementJson.AwardItemID;
	self.AwardItemCount			= tonumber(achievementJson.AwardItemCount);

	self.Properties:ProcessNodeJson(achievementJson.Properties);
	self.PriceProperties:ProcessNodeJson(achievementJson.PriceProperties);
end

function lib.TogetherAchievement:Dump()
	self:DumpEx("");
end

function lib.TogetherAchievement:DumpEx(spacing)
	print(spacing .. "Achievement:");
	print(spacing .. "   AchievementID          = " .. self.AchievementID);
	print(spacing .. "   ActionName             = " .. self.ActionName);
	print(spacing .. "   Name                   = " .. self.Name);
	print(spacing .. "   Description            = " .. self.Description);
	print(spacing .. "   RequiredCount          = " .. self.RequiredCount);
	print(spacing .. "   RequiredSequential     = " .. tostring(self.RequiredSequential));
	print(spacing .. "   RequiredItemID         = " .. self.RequiredItemID);
	print(spacing .. "   RequiredItemCount      = " .. self.RequiredItemCount);
	print(spacing .. "   AwardItemID            = " .. self.AwardItemID);
	print(spacing .. "   AwardItemCount         = " .. self.AwardItemCount);

	self.Properties:DumpEx(spacing .. "   ");
	self.PriceProperties:DumpEx(spacing .. "   ");	
end


-- return TogetherAchievement;

-------------------------------------------------------------------------------
-- UserAchievement.lua --------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherUserAchievement = {};
lib.TogetherUserAchievement.__index = lib.TogetherUserAchievement;


-- @class TogetherUserAchievement
-- The UserAchievement class represents a Achievement belonging to a User.
-- @member number UserAchievementID The ID of the UserAchievement.
-- @member number RoomID The ID of the Room the UserAchievement was awarded in.  If equal to 0, then the UserAchievement wasn't awarded in a room.
-- @member number RequiredCount The number of times the UserAchievement has been accomplished.  If this value is less than the base Achievement's RequiredCount, then the UserAchievement has only been partially accomplished.
-- @member boolean Completed A boolean indicating whether the UserAchievement has been fully accomplished.  Please see RequiredCount parameter description.
-- @member TogetherAchievement Achievement The base Achievement that the UserAchievement is essentially an instance of.
-- @member PropertyCollection Properties A property collection containing all custom properties for the UserAchievement.


-----------------
-- Constructor --
-----------------

function lib.TogetherUserAchievement.New()
	local self = {};
	setmetatable(self, lib.TogetherUserAchievement);

	self.UserAchievementID				= 0;
	self.RoomID							= 0;
	self.RequiredCount					= 0;
	self.Completed						= "";
	self.Achievement					= lib.TogetherAchievement:New();
	self.Properties						= lib.PropertyCollection:New();

	return self;
end

function lib.TogetherUserAchievement:ProcessUserAchievementJson(userAchievementJson)
	self.UserAchievementID				= userAchievementJson.UserAchievementID;	
	self.RoomID							= userAchievementJson.RoomID;
	self.RequiredCount					= tonumber(userAchievementJson.RequiredCount);
	self.Completed						= userAchievementJson.Completed;

	if (userAchievementJson["Achievement"] ~= nil) then
		self.Achievement:ProcessAchievementJson(userAchievementJson.Achievement);
	end
	self.Properties:ProcessNodeJson(userAchievementJson.Properties);
end

function lib.TogetherUserAchievement:Dump()
	self:DumpEx("");
end

function lib.TogetherUserAchievement:DumpEx(spacing)
	print(spacing .. "UserAchievement:");
	print(spacing .. "   UserAchievementID             = " .. self.UserAchievementID);
	print(spacing .. "   RoomID                        = " .. self.RoomID);
	print(spacing .. "   RequiredCount                 = " .. self.RequiredCount);
	print(spacing .. "   Completed                     = " .. tostring(self.Completed));

	self.Achievement:DumpEx(spacing .. "   ");
	self.Properties:DumpEx(spacing .. "   ");
end





--------------------------------------------------------------------------------
--  Network methods.
--------------------------------------------------------------------------------

-- @classmessage TogetherUserAchievement:Modify()
-- Modifies the UserAchievement. Upon success, this will automatically update the internal data.
-- The UserAchievementID, RoomID and Properties members are sent to the server when this method is called.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherUserAchievement:Modify(callbackFunc)
	lib.togetherPrint("TogetherUserAchievement:Modify()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Process the response data.
		self:ProcessUserAchievementJson(callback.ResponseObj.UserAchievement);

   		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&UserAchievementID=" .. self.UserAchievementID ..
    	"&RoomID=" .. self.RoomID ..
    	"&UserAchievementProps=" .. self.Properties:EncodeJson();

	lib.sendNetworkMessage("users", "modifyuserachievement", parameters, networkListener);
end


-- return TogetherUserAchievement;

-------------------------------------------------------------------------------
-- UserAchievementManager.lua -------------------------------------------------
-------------------------------------------------------------------------------
lib.UserAchievementManager = {};
lib.UserAchievementManager.__index = lib.UserAchievementManager;

-- @class UserAchievementManager
-- The UserAchievementManager is used for fetching and finding achievements that exist for the current user.
-- @member table UserAchievements Stores all the UserAchievements contained in the Manager.

	
function lib.UserAchievementManager.New()
	local self = {};
	setmetatable(self, lib.UserAchievementManager);

	-- Contains all the UserAchievements.
	self.UserAchievements = {};

	return self;
end

-- @classmethod UserAchievementManager:Add()
-- Adds a UserAchievement to the internally managed list without persistence.
-- @boldnote This method is deprecated
-- @param TogetherUserAchievement userAchievement Instance of a UserAchievement to add internally
function lib.UserAchievementManager:Add(userAchievement)
	table.insert(self.UserAchievements, userAchievement);
end

-- @classmethod UserAchievementManager:FindByUserAchievementID()
-- Finds the UserAchievement with the specified UserAchievementID if it exists, otherwise returns nil.
-- @param number userAchievementID The ID of the UserAchievement to find
-- @return TogetherUserAchievement
function lib.UserAchievementManager:FindByUserAchievementID(userAchievementID)
	local indexOfUserAchievement = self:IndexOfByUserAchievementID(userAchievementID);
	if (indexOfUserAchievement ~= -1) then
		return self:Get(indexOfUserAchievement);
	end
	return nil;
end

-- @classmethod UserAchievementManager:FindByAchievementID()
-- Finds the UserAchievement with the specified AchievementID if it exists, otherwise returns nil.
-- @param number achievementID The ID of the Achievement to find
-- @return TogetherUserAchievement
function lib.UserAchievementManager:FindByAchievementID(achievementID)
	local userAchievementCount = self:GetCount();
   	for i=1, userAchievementCount do
    		if (self.UserAchievements[i].Achievement.AchievementID == achievementID) then
			return self.UserAchievements[i];
		end
    end
    return nil;
end

-- @classmethod UserAchievementManager:GetCount()
-- Gets the number of UserAchievements currently managed internally.
-- @return number
function lib.UserAchievementManager:GetCount()
	return table.getn(self.UserAchievements);
end

-- @classmethod UserAchievementManager:Get()
-- Gets the UserAchievement at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the UserAchievement to find
-- @return TogetherUserAchievement
function lib.UserAchievementManager:Get(index)
	return self.UserAchievements[index];
end

-- @classmethod UserAchievementManager:IndexOf()
-- Returns the index of the specified UserAchievement if it exists, otherwise returns nil.
-- @param TogetherUserAchievement userAchievement Instance of the UserAchievement to find the index of
-- @return number
function lib.UserAchievementManager:IndexOf(userAchievement)
	return table.indexOf(self.UserAchievements, userAchievement);
end

-- @classmethod UserAchievementManager:IndexOfByUserAchievementID()
-- Returns the index of the UserAchievement with the specified UserAchievementID if it exists, otherwise returns -1.
-- @param number userAchievementID The ID of the UserAchievement to find the index of
-- @return number
function lib.UserAchievementManager:IndexOfByUserAchievementID(userAchievementID)
	local userAchievementCount = self:GetCount();

   	for i=1, userAchievementCount do
    		if (self.UserAchievements[i].UserAchievementID == userAchievementID) then
			return i;
		end
    end

    return -1;
end

-- @classmethod UserAchievementManager:Remove()
-- Removes a UserAchievement from the internally managed list. This does not delete the user achievement from the session's account persistently.
-- @boldnote This method is deprecated
-- @param number index The index of the UserAchievement to be removed.
function lib.UserAchievementManager:Remove(index)
	if (index ~= -1)	then
		table.remove(self.UserAchievements, index);
	end
end

function lib.UserAchievementManager:Dump()
	print("UserAchievements:");

	-- Dump all the UserAchievements as well.
	local userAchievementCount = table.getn(self.UserAchievements);
	print("   UserAchievementCount   = " .. userAchievementCount);

    for i=1, userAchievementCount do
    	self.UserAchievements[i]:DumpEx("   ");
    end
end

function lib.UserAchievementManager:ProcessUserAchievementsJson(userAchievementsJson)
	self.UserAchievements = {};

	-- Parse out all the UserAchievements.
	for name, value in pairs (userAchievementsJson) do
    	local userAchievement = lib.TogetherUserAchievement:New();
		userAchievement:ProcessUserAchievementJson(value);
		table.insert(self.UserAchievements, userAchievement);
    end

    lib.togetherPrint("   Processed " .. table.getn(self.UserAchievements) .. " user achievements.");
end




-------------------------------------------------------------------------------
--  Network methods.
-------------------------------------------------------------------------------

-- @classmessage UserAchievementManager:Award()
-- Awards a UserAchievement. Upon success, this will automatically update the internal list.
-- @param number achievementID The ID of the Achievement to award.
-- @param string actionName The Action of the Achievements to award.
-- @param number roomID The ID of the Room the UserAchievement is being awarded in.
-- @param PropertyCollection userAchievementProperties The properties to assign to the UserAchievement. Pass in nil to assign no properties.
-- @param string notificationMessage The notification message to send to the User. Pass in "" if no notification should be sent.
-- @param function callbackFunc The function to call upon completion.
function lib.UserAchievementManager:Award(achievementID, actionName, roomID, userAchievementProperties, notificationMessage, callbackFunc)
	lib.togetherPrint("UserAchievementManager:Award(" .. achievementID .. ", " .. actionName .. ", " ..
		roomID .. ", " .. notificationMessage .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Process the response data.
   		self:ProcessUserAchievementsJson(callback.ResponseObj.UserAchievements);

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


   	local parameters = "sessiontoken=" .. g_Together:GetSessionToken() ..
   		"&AchievementID=" .. achievementID ..
   		"&ActionName=" .. actionName ..
		"&RoomID=" .. roomID ..
		"&NotificationMessage=" .. notificationMessage;
	if (userAchievementProperties ~= nil) then
		parameters = parameters .. "&UserAchievementProps=" .. userAchievementProperties:EncodeJson();
	end

	lib.sendNetworkMessage("users", "awarduserachievement", parameters, networkListener);
end

-- @classmessage UserAchievementManager:Delete()
-- Deletes a UserAchievement. Upon success, this will automatically update the internal list.
-- @param number userAchievementID The ID of the UserAchievement to delete.
-- @param function callbackFunc The function to call upon completion.
function lib.UserAchievementManager:Delete(userAchievementID, callbackFunc)
	lib.togetherPrint("UserAchievementManager:Delete(" .. userAchievementID .. "'");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end

    		
   		-- Now, remove the deleted UserAchievement.
   		self:Remove(self:IndexOfByUserAchievementID(userAchievementID));

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&UserAchievementID=" .. userAchievementID;

	lib.sendNetworkMessage("users", "deleteuserachievement", parameters, networkListener);	
end

-- @classmessage UserAchievementManager:GetAll()
-- Gets all UserAchievements assigned to the User. Upon success, this will automatically update the internal list.
-- @param function callbackFunc The function to call upon completion.
function lib.UserAchievementManager:GetAll(callbackFunc)
	lib.togetherPrint("UserAchievementManager:GetAll()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


   		-- Process the response data.
		self:ProcessUserAchievementsJson(callback.ResponseObj.UserAchievements);

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


   	local parameters = "SessionToken=" .. g_Together:GetSessionToken();

	lib.sendNetworkMessage("users", "getalluserachievements", parameters, networkListener);	
end

-- @classmessage UserAchievementManager:Purchase()
-- Purchases a UserAchievement. Upon success, this will automatically update the internal list.
-- @boldnote This method is deprecated
-- @param number achievementID The ID of the Achievement to purchase.
-- @param number roomID The ID of the Room the UserAchievement is being purchased in.
-- @param PropertyCollection userAchievementProperties The properties to assign to the UserAchievement.  Pass in nil to assign no properties.
-- @param boolean useGameUserProfileProperties This has not effect, pass false.
-- @param function callbackFunc The function to call upon completion.
function lib.UserAchievementManager:Purchase(achievementID, roomID, userAchievementProperties, useGameUserProfileProperties, callbackFunc)
	lib.togetherPrint("AchievementManager:Purchase(" .. achievementID .. ", " .. roomID .. "'");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Create a new UserAchievement.
   		g_CurrentUserAchievement = lib.TogetherUserAchievement:New();

		-- Process the response data.
   		g_CurrentUserAchievement:ProcessUserAchievementJson(callback.ResponseObj.UserAchievement);
   		self:Add(g_CurrentUserAchievement);
   		callback.NewObject = g_CurrentUserAchievement;
    		
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
		"&AchievementID=" .. achievementID ..
		"&RoomID=" .. roomID ..
		"&UseGameUserProfileProperties=" .. tostring(useGameUserProfileProperties);
	if (userAchievementProperties ~= nil) then
		parameters = parameters .. "&UserAchievementProps=" .. userAchievementProperties:EncodeJson();
	end

	lib.sendNetworkMessage("users", "purchaseuserachievement", parameters, networkListener);
end

-- @classmessage UserAchievementManager:Sell()
-- Sells a UserAchievement. Upon success, this will automatically update the internal list.
-- @boldnote This method is deprecated
-- @param number userAchievementID The ID of the Achievement to sell.
-- @param function callbackFunc The function to call upon completion.
function lib.UserAchievementManager:Sell(userAchievementID, callbackFunc)
	lib.togetherPrint("UserAchievementManager:Sell(" .. userAchievementID .. "'");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


    	-- Now, remove the sold UserAchievement.
    	self:Remove(self:IndexOfByUserAchievementID(userAchievementID));

	   	callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


  	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&UserAchievementID=" .. userAchievementID;
	
	lib.sendNetworkMessage("users", "selluserachievement", parameters, networkListener);	
end


--return UserAchievementManager;

-------------------------------------------------------------------------------
-- User.lua -------------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherUser = {};
lib.TogetherUser.__index = lib.TogetherUser;


-- @class TogetherUser
-- The TogetherUser class represents a Together User.
-- @member number UserID The ID of the User.
-- @member string UserGuid The Guid assigned to the user that should be cached on the device.  When the UserGuid is passed
--						   while sending the 'loginuser' message to the server, the User assigned the UserGuid will be returned.
-- @member number ActiveUserAccountTypeID The type of account the User has.  This member represents the last registration performed
--							by the user.  0=Anonymous, 1=Facebook, 2=Twitter, 3=GooglePlus, 4=GameCenter, 5=Custom
-- @member string Name The name of the User.  For anonymous users, it will be in the format 'user_###' where ### equals the
--							UserID of the User.  For registered users, this will be equal to the Users name from some external
--							social network.  When a User registers via Facebook, Name will be set to their Facebook name.
-- @member string Username The username for the User.  It will be in the format 'user_###' where ### equals the UserID of the User.
--							This value is generated when a new User logs into a together game for the first.  This value can not
--							be changed at this time.
-- @member string Email The email of the User.
-- @member boolean Active A boolean indicating whether the User is active.
-- @member boolean Anonymous A boolean indicating whether the User has registered yet.
-- @member PropertyCollection Properties A property collection containing all custom properties for the User.
-- @member TogetherFacebookUser FacebookUser An instance of a FacebookUser object containing facebook user information.  If
--							FacebookUser is non nil, then the User has performed a Facebook registration at some time.
-- @member TogetherCustomUser CustomUser An instance of a CustomUser object containing custom user information.  If
--							CustomUser is non nil, then the User has performed a Custom registration at some time.
-- @member TogetherClientUserProfile ClientUserProfile An instance of a ClientUserProfile object containing client specific
--							properties for the User.
-- @member TogetherGameUserProfile GameUserProfile An instance of a GameUserProfile object containing game specific
--							properties for the User.
-- @member UserItemManager UserItemManager An instance of a UserItemManager object so developers can have quick access
--							to User's inventory of Items.
-- @member UserAchievementManager UserAchievementManager An instance of a UserAchievementManager object so developers
--							can have quick access to a User's UserAchievements.
-- @member UserGameManager UserGameManager An instance of a UserGameManager object so developers can have quick access
--							to the list of games a User has played.


-----------------
-- Constructor --
-----------------

function lib.TogetherUser.New()
	local self = {};
	setmetatable(self, lib.TogetherUser);

	self.UserID 					= 0;
	self.UserGuid					= "";
	self.ActiveUserAccountTypeID	= 0;
	self.Name						= "";
	self.Username					= "";
	self.Email					   	= "";
	self.Active				      	= true;
	self.Admin				       	= false;
	self.Anonymous				   	= true;
	self.Properties					= lib.PropertyCollection:New();

	self.FacebookUser				= nil;
	self.CustomUser		 		 	= nil;

	self.ClientUserProfile 			= nil;
	self.GameUserProfile 			= nil;
	
	self.UserItemManager			= lib.UserItemManager:New();
	self.UserAchievementManager		= lib.UserAchievementManager:New();

	self.UserGameManager			= nil;

	return self;
end

-- @classmethod TogetherUser:GetViewName()
-- Returns the visual display name for the User.
-- @return string
function lib.TogetherUser:GetViewName()
	local viewName = self.Username;
	if (self.Anonymous == false) then
		viewName = self.Name;
	end
	return viewName;
end

function lib.TogetherUser:ProcessUserJson(userJson)
	lib.togetherPrint("TogetherUser:ProcessUserJson()");
	self.UserID 					= userJson.UserID;
	self.UserGuid					= userJson.UserGuid;
	self.ActiveUserAccountTypeID	= userJson.ActiveUserAccountTypeID;
	self.Name						= userJson.Name;
	self.Username					= userJson.Username;
	self.Email						= userJson.Email;
	self.Active						= userJson.Active;
	self.Admin						= userJson.Admin;
	self.Anonymous					= userJson.Anonymous;

	if (userJson["Properties"] ~= nil) then
		self.Properties:ProcessNodeJson(userJson.Properties);
	end
	if (userJson["FacebookUser"] ~= nil) then
		self.FacebookUser = lib.TogetherFacebookUser:New();
		self.FacebookUser:ProcessFacebookUserJson(userJson.FacebookUser);
	end
	if (userJson["CustomUser"] ~= nil) then
		self.CustomUser = lib.TogetherCustomUser:New();
		self.CustomUser:ProcessCustomUserJson(userJson.CustomUser);
	end
	if (userJson["ClientUserProfile"] ~= nil) then
		self.ClientUserProfile = lib.TogetherClientUserProfile:New();
		self.ClientUserProfile:ProcessClientUserProfileJson(userJson.ClientUserProfile);
	end
	if (userJson["GameUserProfile"] ~= nil) then
		self.GameUserProfile = lib.TogetherGameUserProfile:New();
		self.GameUserProfile:ProcessGameUserProfileJson(userJson.GameUserProfile);
	end
	if (userJson["UserItems"] ~= nil) then
		self.UserItemManager = lib.UserItemsManager:New();
		self.UserItemManager:ProcessUserItemsJson(userJson.UserItems);
	end
	if (userJson["UserAchievements"] ~= nil) then
		self.UserAchievementManager = lib.UserAchievementsManager:New();
		self.UserAchievementManager:ProcessUserAchievementsJson(userJson.UserAchievements);
	end
	if (userJson["UserGames"] ~= nil) then
		self.UserGameManager = lib.UserGameManager:New();
		self.UserGameManager:ProcessUserGamesJson(userJson.UserGames);
	end
end

-- @classmethod TogetherUser:GetTogetherFacebookUser()
-- Gets the FacebookUser associated to this Together User if it exists, otherwise this 
-- will create and assign an empty FacebookUser, then return it
-- @return TogetherFacebookUser 
function lib.TogetherUser:GetTogetherFacebookUser()
	if (self.FacebookUser == nil) then
		self.FacebookUser = lib.TogetherFacebookUser:New();
	end
	return self.FacebookUser;
end

-- @classmethod TogetherUser:GetTogetherCustomUser()
-- Gets the CustomUSer associated to this Together User if it exists, otherwise this 
-- will create and assign an empty CustomUser, then return it
-- @return TogetherCustomUser 
function lib.TogetherUser:GetTogetherCustomUser()
	if (self.CustomUser == nil) then
		self.CustomUser = lib.TogetherCustomUser:New();
	end
	return self.CustomUser;
end

-- @classmethod TogetherUser:IsFacebookRegistered()
-- Returns a boolean indicating whether the User has registered via Facebook.
-- @return boolean 
function lib.TogetherUser:IsFacebookRegistered()
	local registeredViaFacebook = false;
	if (self.FacebookUser ~= nil) then
		if (self.FacebookUser.FacebookID ~= "0") then
			registeredViaFacebook = true;
		end
	end
	return registeredViaFacebook;
end

-- @classmethod TogetherUser:IsCustomRegistered()
-- Returns a boolean indicating whether the User has registered via Custom registration.
-- @return boolean 
function lib.TogetherUser:IsCustomRegistered()
	local registeredViaCustom = false;
	if (self.CustomUser ~= nil) then
		if (self.CustomUser.CustomUserID ~= 0) then
			registeredViaCustom = true;
		end
	end
	return registeredViaCustom;
end

function lib.TogetherUser:Dump()
	self:DumpEx("");
end

function lib.TogetherUser:DumpEx(spacing)
	print(spacing .. "User:");
	print(spacing .. "   UserID                   = " .. self.UserID);
	print(spacing .. "   UserGuid                 = " .. self.UserGuid);
	print(spacing .. "   ActiveUserAccountTypeID  = " .. self.ActiveUserAccountTypeID);
	print(spacing .. "   Name                     = " .. self.Name);
	print(spacing .. "   Username                 = " .. self.Username);
	print(spacing .. "   Email                    = " .. self.Email);
	print(spacing .. "   Active                   = " .. tostring(self.Active));
	print(spacing .. "   Admin                    = " .. tostring(self.Admin));
	print(spacing .. "   Anonymous                = " .. tostring(self.Anonymous));

	self.Properties:Dump(spacing .. "   ");

	if (self.FacebookUser == nil) then
		print(spacing .. "   FacebookUser             = (nil)");
	else
		self.FacebookUser:DumpEx(spacing .. "   ");
	end

	if (self.CustomUser == nil) then
		print(spacing .. "   CustomUser               = (nil)");
	else
		self.CustomUser:DumpEx(spacing .. "   ");
	end

	self.UserItemManager:Dump();
	self.UserAchievementManager:Dump();

	if (self.UserGameManager == nil) then
		print(spacing .. "   UserGames                = (nil)");
	else
		self.UserGameManager:DumpEx(spacing .. "   ");
	end
end


--------------------------------------------------------------------------------
--  Network methods.
--------------------------------------------------------------------------------

-- @classmessage TogetherUser:GetDetails()
-- Gets all the User's details. Upon success, this will automatically update the internal data.
-- The UserID member is passed along to the server when this method is called.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherUser:GetDetails(callbackFunc)
	lib.togetherPrint("TogetherUser:GetDetails()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end

		-- Process the response data.    		
		self:ProcessUserJson(callback.ResponseObj.User);

   		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&UserID=" .. self.UserID;

	lib.sendNetworkMessage("users", "getuser", parameters, networkListener);
end

-- @classmessage TogetherUser:Modify()
-- Modifies a User. Upon success, this will automatically update the internal data.
-- The Properties, ClientUserProfile properties, and GameUserProfile properties are sent to
-- the server when this method is called.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherUser:Modify(callbackFunc)
	lib.togetherPrint("TogetherUser:Modify()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end

		-- Process the response data.
		self:ProcessUserJson(callback.ResponseObj.User);

   		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&UserProps=" .. self.Properties:EncodeJson();
	if (self.ClientUserProfile ~= nil) then
		parameters = parameters .. "&ClientProfileProps=" .. self.ClientUserProfile.Properties:EncodeJson();
	end
	if (self.GameUserProfile ~= nil) then
		parameters = parameters .. "&GameProfileProps=" .. self.GameUserProfile.Properties:EncodeJson();
	end


	lib.sendNetworkMessage("users", "modifyuser", parameters, networkListener);
end


-- return TogetherUser;

-------------------------------------------------------------------------------
-- UserSession.lua ------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherUserSession = {};
lib.TogetherUserSession.__index = lib.TogetherUserSession;

-- @class TogetherUserSession
-- The UserSession class represents the together UserSession.  A UserSession is generated and
-- returned when the 'loginuser' message is sent to the server.  The SessionToken member is passed
-- along to the together server by all other subsequent messages.
-- @member number UserSessionID The ID of the UserSession.
-- @member number UserID The ID of the User associated with the UserSession.
-- @member number GameID The ID of the Game associated with the UserSession.
-- @member number PlatformID The ID of the Platform associated with the UserSession.
-- @member string SessionToken A tokenized string that represents this UserSession.  This is used by most network messages to the together server.

-----------------
-- Constructor --
-----------------

function lib.TogetherUserSession.New()
	local self = {};
	setmetatable(self, lib.TogetherUserSession);
	
	self.UserSessionID			= 0;
	self.UserID					= 0;
	self.GameID					= 0;
	self.PlatformID				= 0;
	self.SessionToken			= "";

	return self;
end

function lib.TogetherUserSession:ProcessUserSessionJson(userSessionJson)
	self.UserSessionID 			= userSessionJson.UserSessionID;
	self.UserID					= userSessionJson.UserID;
	self.GameID					= userSessionJson.GameID;
	self.PlatformID				= userSessionJson.PlatformID;
	self.SessionToken			= userSessionJson.SessionToken;
end

function lib.TogetherUserSession:Dump()
	self:DumpEx("");
end

function lib.TogetherUserSession:DumpEx(spacing)
	print(spacing .. "UserSession:");
	print(spacing .. "   UserSessionID           = " .. self.UserSessionID);
	print(spacing .. "   UserID                  = " .. self.UserID);
	print(spacing .. "   GameID                  = " .. self.GameID);
	print(spacing .. "   PlatformID              = " .. self.PlatformID);
	print(spacing .. "   SessionToken            = " .. self.SessionToken);
end


-- return TogetherUserSession;

-------------------------------------------------------------------------------
-- GameInstanceUser.lua -------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherGameInstanceUser = {};
lib.TogetherGameInstanceUser.__index = lib.TogetherGameInstanceUser;


-- @class TogetherGameInstanceUser
-- The GameInstanceUser class represents a User playing a together GameInstance or match.
-- @member number GameInstanceUserID The ID of the GameInstanceUser.
-- @member number GameInstanceID The ID of the GameInstance the GameInstanceUser belongs to.
-- @member number UserID The ID of the User playing a GameInstance.
-- @member string Username The Username assigned to the User.
-- @member string Name The Name assigned to the User.  This will be the same as Username unless the User had registered.
-- @member number TurnCount The number of moves the User has made.
-- @member boolean Active A boolean indicating whether the GameInstance is active.
-- @member string SocialType The type of social network the User is registered with.  Facebook="FB".
-- @member string SocialID The ID of the social user the User had registered as.  Facebook=[User's facebook ID].
-- @member number LastActivityInSeconds The number of seconds since the User has been active in the GameInstance.
-- @member number ClientID The ID of the Client the User has last played a Game with.
-- @member number GameID The ID of the Game the User has last played.
-- @member number PlatformID The ID of the Platform of the last played Game for the User. 
-- @member PropertyCollection Properties A property collection containing all custom properties for the GameInstanceUser.
 
-----------------
-- Constructor --
-----------------

function lib.TogetherGameInstanceUser.New()
	local self = {};
	setmetatable(self, lib.TogetherGameInstanceUser);
	
	self.GameInstanceUserID			= 0;
	self.GameInstanceID				= 0;
	self.UserID						= 0;
	self.Username					= "";
	self.Name						= "";
	self.TurnCount					= 0;
	self.Active						= 0;
	self.SocialType					= "";
	self.SocialID					= "";
	self.LastActivityInSeconds		= 0;
	self.ClientID					= 0;
	self.GameID						= 0;
	self.PlatformID					= 0;
	self.Properties					= lib.PropertyCollection:New();

	return self;
end

function lib.TogetherGameInstanceUser:ProcessGameInstanceUserJson(gameInstanceUserJson)
	self.GameInstanceUserID			= gameInstanceUserJson.GameInstanceUserID;	
	self.GameInstanceID 			= gameInstanceUserJson.GameInstanceID;
	self.UserID						= gameInstanceUserJson.UserID;
	self.Username					= gameInstanceUserJson.Username;
	self.TurnCount					= gameInstanceUserJson.TurnCount;
	self.Active						= gameInstanceUserJson.Active;
	self.SocialType					= gameInstanceUserJson.SocialType;
	self.SocialID					= gameInstanceUserJson.SocialID;
	self.LastActivityInSeconds		= gameInstanceUserJson.LastActivityInSeconds;
	self.ClientID					= gameInstanceUserJson.ClientID;
	self.GameID						= gameInstanceUserJson.GameID;
	self.PlatformID					= gameInstanceUserJson.PlatformID;

	if (gameInstanceUserJson["Properties"] ~= nil) then
		self.Properties:ProcessNodeJson(gameInstanceUserJson.Properties);
	end
end

function lib.TogetherGameInstanceUser:Dump()
	self:DumpEx("");
end

function lib.TogetherGameInstanceUser:DumpEx(spacing)
	print(spacing .. "GameInstanceUser:");
	print(spacing .. "   GameInstanceUserID     = " .. self.GameInstanceUserID);
	print(spacing .. "   GameInstanceID         = " .. self.GameInstanceID);
	print(spacing .. "   UserID                 = " .. self.UserID);
	print(spacing .. "   Username               = " .. self.Username);
	print(spacing .. "   Name                   = " .. self.Name);
	print(spacing .. "   TurnCount              = " .. self.TurnCount);
	print(spacing .. "   Active                 = " .. tostring(self.Active));
	print(spacing .. "   SocialType             = " .. self.SocialType);
	print(spacing .. "   SocialID               = " .. self.SocialID);
	print(spacing .. "   LastActivityInSeconds  = " .. self.LastActivityInSeconds);
	print(spacing .. "   ClientID               = " .. self.ClientID);
	print(spacing .. "   GameID                 = " .. self.GameID);
	print(spacing .. "   PlatformID             = " .. self.PlatformID);

	self.Properties:DumpEx(spacing .. "   ");
end

function lib.TogetherGameInstanceUser:PostProcessUsername()

	local togetherFriend = g_Together:FindTogetherFriendByUserID(self.UserID);
	local externalFriend = g_Together:FindFacebookFriendBySocialID(self.SocialID);

	self.Name = self.Username;

	-- Is this GameInstanceUser my User.
	if (self.UserID == g_Together:GetUserID()) then
		if (g_Together:GetNameOfUser() ~= "") then
			self.Name = g_Together:GetNameOfUser();
		else
			self.Name = g_Together:GetUsername();
	end

	-- Is this GameInstanceUser at least a TogetherUser.
	elseif (self.UserID ~= 0) then
		if (togetherFriend ~= nil) then
			self.Name = togetherFriend.Name;
		elseif (externalFriend ~= nil) then
			self.Name = externalFriend.Name;
		end
	
	elseif (tostring(self.SocialID) ~= "") then
		if (externalFriend ~= nil) then
			self.Name = externalFriend.Name;
		else
			self.Name = "######";
		end
	end
end


-- return TogetherGameInstanceUser;

-------------------------------------------------------------------------------
-- GameInstance.lua -----------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherGameInstance = {};
lib.TogetherGameInstance.__index = lib.TogetherGameInstance;


-- Various states a GameInstance can be in.
GAME_STATE_WAITING_FOR_PLAYERS	= 1;	-- Waiting for players to join the game.
GAME_STATE_IN_PROGRESS 			= 2;	-- Players are currently playing the game.
GAME_STATE_FINISHED				= 4;	-- Game has been finished and a leaderboard was generated.
GAME_STATE_POSSIBLE_REMATCH		= 8;	-- A rematched Game waiting for enough players to join.
GAME_STATE_FORFEIT				= 16;	-- Game was forfeited by a User.


-- @class TogetherGameInstance
-- The GameInstance class represents a Together GameInstance or individual match.
-- @member number GameInstanceID The ID of the GameInstance.
-- @member string GameInstanceType The type of GameInstance.  ie (Board 3x3, Board 6x6, Board 9x9)
-- @member number GameInstanceDuelID The ID of the duel the GameInstance belongs to. This is the ID of the first GameInstance in a line of rematches.
-- @member number CreatorUserID The ID of the User that created the GameInstance.
-- @member number RoomID The ID of the Room the GameInstance was created.  If equal to 0, then the GameInstance wasn't created in a room.
-- @member number ChatRoomID The ID of the ChatRoom associated with the GameInstance.
-- @member number SecondsSinceGameStarted The number of seconds since the GameInstance was started.
-- @member number SecondsSinceLastModified The number of seconds since the GameInstance was last modified.
-- @member number LastModifyTimestamp A timestamp for when the GameInstance was last modified.
-- @member number RoundCount The number of rounds the GameInstance has progressed through.
-- @member number TotalTurnCount The total number of moves made.
-- @member boolean Active A boolean indicating whether the GameInstance is active.
-- @member number State The State of the GameInstance.
-- @member number UserCount The number of users in the GameInstance.
-- @member number MaxUsers The max number of users in the GameInstance.
-- @member number TurnUserID The ID of the User whose turn it is.  When 0, it is no User's turn.  This will occur if first User makes their initial move and another possible User hasn't joined the GameInstance yet.
-- @member number TurnIndex The index of whose turn it is.
-- @member number PlayCount The number of times a GameInstance has been played in the duel.  This value will be 1 for the initial GameInstance. 2 for the second GameInstance in the duel.  3 for the third GameInstance in the duel.
-- @member number WinningUserID The ID of the User that has won the GameInstance.  When 0, there is no winner of the GameInstance.
-- @member boolean IsUserMemberOf A boolean indicating whether the logged in User is a member of the GameInstance.
-- @member number LeaderboardID The ID of the Leaderboard associated with the GameInstance.
-- @member PropertyCollection Properties A property collection containing all custom properties for the GameInstance.
-- @member table GameInstanceUsers Contains all the GameInstanceUsers that are playing the GameInstance.

-----------------
-- Constructor --
-----------------

function lib.TogetherGameInstance.New()
	local self = {};
	setmetatable(self, lib.TogetherGameInstance);

	self.GameInstanceID				= 0;
	self.GameInstanceType			= "";
	self.GameInstanceSubType 		= nil;
	self.GameInstanceDuelID			= 0;
	self.CreatorUserID				= 0;
	self.RoomID						= 0;
	self.ChatRoomID					= 0;
	self.SecondsSinceGameStarted	= 0;
	self.SecondsSinceLastModified	= 0;
	self.LastModifyTimestamp		= 0;
	self.RoundCount					= 0;
	self.TotalTurnCount				= 0;
	self.Active						= 1;
	self.State						= 0;
	self.UserCount					= 0;
	self.MaxUsers					= 2;
	self.TurnUserID					= 0;
	self.TurnIndex					= 0;
	self.PlayCount					= 0;
	self.WinningUserID				= 0;
	self.IsUserMemberOf				= 0;
	self.LeaderboardID				= 0;

	self.Properties					= lib.PropertyCollection:New();

	-- Contains all the Users in the GameInstance.
	self.GameInstanceUsers			= {};

	return self;
end


-- @classmethod TogetherGameInstance:AddGameInstanceUser()
-- Adds a GameInstanceUser to the manager internally without persistence.
-- @boldnote This method is deprecated
-- @param TogetherGameInstanceUser gameInstanceUser Instance of the GameInstanceUser to add to the internal list
function lib.TogetherGameInstance:AddGameInstanceUser(gameInstanceUser)
	table.insert(self.GameInstanceUsers, gameInstanceUser);
end

-- @classmethod TogetherGameInstance:FindGameInstanceUserByUserID()
-- Finds the GameInstanceUser with the specified UserID if it exists, otherwise returns nil.
-- @param number userID The ID of the User to find
-- @return TogetherGameInstanceUser
function lib.TogetherGameInstance:FindGameInstanceUserByUserID(userID)
	local indexOfGameInstanceUser = self:IndexOfGameInstanceUserByUserID(userID);
	if (indexOfGameInstanceUser ~= -1) then
		return self:GetGameInstanceUser(indexOfGameInstanceUser);
	end
	return nil;
end

-- @classmethod TogetherGameInstance:FindGameInstanceUserByGameInstanceUserID()
-- Finds the GameInstanceUser with the specified GameInstanceUserID if it exists, otherwise returns nil.
-- @param number gameInstanceUserID The ID of the GameInstanceUser to find
-- @return TogetherGameInstanceUser
function lib.TogetherGameInstance:FindGameInstanceUserByGameInstanceUserID(gameInstanceUserID)
	local indexOfGameInstance = self:IndexOfGameInstanceUserByGameInstanceUserID(gameInstanceUserID);
	if (indexOfGameInstanceUser ~= -1) then
		return self:GetGameInstanceUser(indexOfGameInstanceUser);
	end
	return nil;
end

-- @classmethod TogetherGameInstance:GetGameInstanceUserCount()
-- Gets the number of GameInstanceUsers currently managed internally.
-- @return number
function lib.TogetherGameInstance:GetGameInstanceUserCount()
	return table.getn(self.GameInstanceUsers);
end

-- @classmethod TogetherGameInstance:GetGameInstanceUser()
-- Gets the GameInstanceUser at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the GameInstanceUser to find
-- @return TogetherGameInstanceUser
function lib.TogetherGameInstance:GetGameInstanceUser(index)
	return self.GameInstanceUsers[index];
end

-- @classmethod TogetherGameInstance:GetTurnIndexForUser()
-- Gets the TurnIndex for a particular User. Turn indexes are base 0. Returns -1 if the user is not found.
-- @param number userID The ID of the User we're interested in getting the TurnIndex for 
-- @return number
function lib.TogetherGameInstance:GetTurnIndexForUser(userID)
	local gameInstanceUserCount = self:GetGameInstanceUserCount();
   	for i=1, gameInstanceUserCount do
    	if (self.GameInstanceUsers[i].UserID == userID) then
			return i - 1;
		end
    end
    return -1;
end

-- @classmethod TogetherGameInstance:IndexOfGameInstanceUser()
-- Returns the index of the specified GameInstanceUser if it exists, otherwise returns nil.
-- @param TogetherGameInstanceUser gameInstanceUser Instance of the GameInstanceUser to find the index of
-- @return number
function lib.TogetherGameInstance:IndexOfGameInstanceUser(gameInstanceUser)
	return table.indexOf(self.GameInstanceUsers, gameInstanceUser);
end

-- @classmethod TogetherGameInstance:IndexOfGameInstanceUserByUserID()
-- Returns the index of the GameInstanceUser with the specified UserID if it exists, otherwise returns -1.
-- @param number userID The ID of the User to find the index of
-- @return number
function lib.TogetherGameInstance:IndexOfGameInstanceUserByUserID(userID)
	local gameInstanceUserCount = self:GetGameInstanceUserCount();
   	for i=1, gameInstanceUserCount do
    	if (self.GameInstanceUsers[i].UserID == userID) then
			return i;
		end
    end
    return -1;
end

-- @classmethod TogetherGameInstance:IndexOfGameInstanceUserByGameInstanceUserID()
-- Returns the index of the GameInstanceUser with the specified GameInstanceUserID if it exists, otherwise returns -1.
-- @param number gameInstanceUserID The ID of the GameInstanceUser to find the index of
-- @return number
function lib.TogetherGameInstance:IndexOfGameInstanceUserByGameInstanceUserID(gameInstanceUserID)
	local gameInstanceUserCount = self:GetGameInstanceUserCount();
   	for i=1, gameInstanceUserCount do
    	if (self.GameInstanceUsers[i].GameInstanceUserID == gameInstanceUserID) then
			return i;
		end
    end
    return -1;
end

-- @classmethod TogetherGameInstance:RemoveGameInstanceUser()
-- Removes a GameInstanceUser from the internally managed list. This does not delete the user from the instance persistently.
-- @boldnote This method is deprecated
-- @param number index The index of the GameInstanceUser to be removed internally
function lib.TogetherGameInstance:RemoveGameInstanceUser(index)
	if (index ~= -1) then
		table.remove(self.GameInstanceUsers, index);
	end
end

function lib.TogetherGameInstance:Dump()
	self:DumpEx("");
end

function lib.TogetherGameInstance:DumpEx(spacing)
	print(spacing .. "GameInstance:");
	print(spacing .. "   GameInstanceID             = " .. self.GameInstanceID);
	print(spacing .. "   GameInstanceType           = " .. self.GameInstanceType);
	print(spacing .. "   GameInstanceDuelID         = " .. self.GameInstanceDuelID);
	print(spacing .. "   CreatorUserID              = " .. self.CreatorUserID);
	print(spacing .. "   RoomID                     = " .. self.RoomID);
	print(spacing .. "   ChatRoomID                 = " .. self.ChatRoomID);
	print(spacing .. "   SecondsSinceGameStarted    = " .. self.SecondsSinceGameStarted);
	print(spacing .. "   SecondsSinceLastModified   = " .. self.SecondsSinceLastModified);
	print(spacing .. "   LastModifyTimestamp        = " .. self.LastModifyTimestamp);
	print(spacing .. "   RoundCount                 = " .. self.RoundCount);
	print(spacing .. "   TotalTurnCount             = " .. self.TotalTurnCount);
	print(spacing .. "   Active                     = " .. tostring(self.Active));
	print(spacing .. "   State                      = " .. self.State);
	print(spacing .. "   UserCount                  = " .. self.UserCount);
	print(spacing .. "   MaxUsers                   = " .. self.MaxUsers);
	print(spacing .. "   TurnUserID                 = " .. self.TurnUserID);
	print(spacing .. "   TurnIndex                  = " .. self.TurnIndex);
	print(spacing .. "   PlayCount                  = " .. self.PlayCount);
	print(spacing .. "   WinningUserID              = " .. self.WinningUserID);
	print(spacing .. "   IsUserMemberOf             = " .. tostring(self.IsUserMemberOf));
	print(spacing .. "   LeaderboardID              = " .. self.LeaderboardID);

	self.Properties:DumpEx("   ");
	
	-- Dump all the GameInstanceUsers as well.
	local userCount = table.getn(self.GameInstanceUsers);
	print(spacing .. "   GameInstanceUserCount   = " .. userCount);

    for i=1, userCount do
    	self.GameInstanceUsers[i]:DumpEx(spacing .. "      ");
    end
end

function lib.TogetherGameInstance:ProcessGameInstanceJson(gameInstanceJson)
	self.GameInstanceID 			= gameInstanceJson.GameInstanceID;
	self.GameInstanceType			= gameInstanceJson.GameInstanceType;
	self.GameInstanceSubType		= gameInstanceJson.GameInstanceSubType;
	self.GameInstanceDuelID			= gameInstanceJson.GameInstanceDuelID;
	self.CreatorUserID				= gameInstanceJson.CreatorUserID;
	self.RoomID						= gameInstanceJson.RoomID;
	self.ChatRoomID					= gameInstanceJson.ChatRoomID;
	self.SecondsSinceGameStarted	= gameInstanceJson.SecondsSinceGameStarted;
	self.SecondsSinceLastModified	= gameInstanceJson.SecondsSinceLastModified;
	self.LastModifyTimestamp		= gameInstanceJson.LastModifyTimestamp;
	self.RoundCount					= gameInstanceJson.RoundCount;
	self.TotalTurnCount				= gameInstanceJson.TotalTurnCount;
	self.Active						= gameInstanceJson.Active;
	self.State						= tonumber(gameInstanceJson.State);
	self.UserCount					= gameInstanceJson.UserCount;
	self.MaxUsers					= tonumber(gameInstanceJson.MaxUsers);
	self.TurnUserID					= gameInstanceJson.TurnUserID;
	self.TurnIndex					= tonumber(gameInstanceJson.TurnIndex);
	self.PlayCount					= tonumber(gameInstanceJson.PlayCount);
	self.WinningUserID				= gameInstanceJson.WinningUserID;
	self.IsUserMemberOf				= gameInstanceJson.IsUserMemberOf;
	self.LeaderboardID				= gameInstanceJson.LeaderboardID;

	if (gameInstanceJson["Properties"] ~= nil) then
		self.Properties:ProcessNodeJson(gameInstanceJson.Properties);
	end

	if (gameInstanceJson["GameInstanceUsers"] ~= nil) then
		self:ProcessGameInstanceUsersJson(gameInstanceJson.GameInstanceUsers);
	end
end

function lib.TogetherGameInstance:ProcessGameInstanceUsersJson(gameInstanceUsersJson)
	self.GameInstanceUsers = {};

	-- Parse out all the GameInstanceUsers.
	for name, value in pairs (gameInstanceUsersJson) do
   		local gameInstanceUser = lib.TogetherGameInstanceUser:New();
		gameInstanceUser:ProcessGameInstanceUserJson(value);
		table.insert(self.GameInstanceUsers, gameInstanceUser);
    end
--    lib.togetherPrint("    Processed " .. table.getn(self.GameInstanceUsers) .. " GameInstanceUsers");
end

function lib.TogetherGameInstance:PostProcessUsernames()
	local gameInstanceUserCount = self:GetGameInstanceUserCount();
	for i=1, gameInstanceUserCount do
    	self.GameInstanceUsers[i]:PostProcessUsername();
    end
end

--------------------------------------------------------------------------------
--  Network methods.
--------------------------------------------------------------------------------

-- @classmessage TogetherGameInstance:GetDetails()
-- Gets the GameInstance's details.
-- This message should be called whenever it is necessary to get the latest state of a GameInstance.
-- Internally, this method passes the GameInstance's LastModifyTimestamp to the server.  If the
-- LastModifyTimestamp is the same value on the server, a "No Change" error will be returned.
-- If you do not wish this behavior, set LastModifyTimestamp on the GameInstance object to 0 before
-- calling this method and full details will always be returned. Upon success, this will automatically update
-- the internal data.
-- @param number gameInstanceID The ID of the GameInstance to retrieve details for
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherGameInstance:GetDetails(gameInstanceID, callbackFunc)
	lib.togetherPrint("TogetherGameInstance:GetDetails(" .. gameInstanceID .. ")");

	local function networkListener(callback)
   		print("TogetherGameInstance:GetDetails().networkListener()");
   		print("callback.Success = " .. tostring(callback.Success));
   		print("callback.Status = " .. callback.Status);
   		print("callback.Description = " .. callback.Description);
   		if (callback.Success == false) then
   			if (callback.Status == "1" and callback.Description == "No Change") then
   				callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   			else
   				callback:ExecuteCallbackFunc(callbackFunc);
   			end
   			return;
   		end


		if (callback.ResponseObj.GameInstance ~= nil) then
			-- Now parse the json data.
			self:ProcessGameInstanceJson(callback.ResponseObj.GameInstance);
			self:ProcessGameInstanceUsersJson(callback.ResponseObj.GameInstance.GameInstanceUsers);
		
			-- Post processes the GameInstanceUser's usernames.
			self:PostProcessUsernames();
		end

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end

	
   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
      	"&GameInstanceID=" .. gameInstanceID .. 
      	"&LastModifyTimestamp=" .. self.LastModifyTimestamp;

	lib.sendNetworkMessage("gameinstances", "getgamedetails", parameters, networkListener);		
end

-- @classmessage TogetherGameInstance:Finish()
-- Finishes a GameInstance.
-- This message should be called whenever a GameInstance is finished.  The State of the GameInstance
-- will change to (4 = GAME_STATE_FINISHED).  A Leaderboard will be generated for the GameInstance. Upon success 
-- this will automatically update the internal data.
-- @param number winningUserID The ID of the User that has won the GameInstance.  Pass in 0 if there was no winner.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherGameInstance:Finish(winningUserID, callbackFunc)
	lib.togetherPrint("TogetherGameInstance:Finish(" .. winningUserID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


   		-- Now parse the json data.
		self:ProcessGameInstanceJson(callback.ResponseObj.GameInstance);
		self:ProcessGameInstanceUsersJson(callback.ResponseObj.GameInstance.GameInstanceUsers);

		-- Post processes the GameInstanceUser's usernames.
		self:PostProcessUsernames();

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


    local gameUserProps = "";
	
	if (winningUserID ~= 0) then
		local winningGameInstanceUser = self:FindGameInstanceUserByUserID(winningUserID);
		gameUserProps = winningGameInstanceUser.Properties:EncodeJson();
   	end

    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
       	"&GameInstanceID=" .. self.GameInstanceID ..
   		"&WinningUserID=" .. winningUserID ..
   		"&GameProps=" .. self.Properties:EncodeJson() ..
   		"&GameUserProps=" .. gameUserProps;

	lib.sendNetworkMessage("gameinstances", "finishgame", parameters, networkListener);		
end

-- @classmessage TogetherGameInstance:Forfeit()
-- Forfeits a GameInstance.
-- This message should be called whenever a GameInstance is forfeited by a User.  The State of the
-- GameInstance will change to (16 = GAME_STATE_FORFEIT). Upon success, this will automatically update
-- the internal data.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherGameInstance:Forfeit(callbackFunc)
	lib.togetherPrint("TogetherGameInstance:Forfeit()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		if (callback.ResponseObj.GameInstance ~= nil) then
			-- Now parse the json data.
			self:ProcessGameInstanceJson(callback.ResponseObj.GameInstance);
			self:ProcessGameInstanceUsersJson(callback.ResponseObj.GameInstance.GameInstanceUsers);

			-- Post processes the GameInstanceUser's usernames.
			self:PostProcessUsernames();
		end

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
       	"&GameInstanceID=" .. self.GameInstanceID;

	lib.sendNetworkMessage("gameinstances", "forfeitgame", parameters, networkListener);		
end

-- @classmessage TogetherGameInstance:InviteUser()
-- Invites a User to a GameInstance. Upon success, this will automatically update the internal data.
-- @param number inviteeUserID The ID of the Together User to invite to the GameInstance.  Pass in 0 when inviting an external (Facebook) friend.
-- @param string inviteeSocialType The type of social network we're inviting a friend from.  Pass "FB" for Facebook.  Pass "" when passing a valid Together User.
-- @param string inviteeSocialID The ID of the external (Facebook) friend we're inviting.  For a Facebook friend, pass the friend's FacebookID.  Pass "" when passing a valid Together User.
-- @param PropertyCollection gameUserProperties A PropertyCollection to associate with the GameInstanceUser that gets created, or nil to attach no properties.
-- @param string notificationMessage The notification message to send to the Together User. Pass "" to prevent sending a notification.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherGameInstance:InviteUser(inviteeUserID, inviteeSocialType, inviteeSocialID, gameUserProperties, notificationMessage, callbackFunc)
	lib.togetherPrint("TogetherGameInstance:InviteUser(" .. inviteeUserID .. ", " .. inviteeSocialType .. ", " .. inviteeSocialID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		self:ProcessGameInstanceJson(callback.ResponseObj.GameInstance);
		self:ProcessGameInstanceUsersJson(callback.ResponseObj.GameInstance.GameInstanceUsers);

		-- Post processes the GameInstanceUser's usernames.
		self:PostProcessUsernames();

   		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&GameInstanceID=" .. self.GameInstanceID ..
    	"&InviteeUserID=" .. inviteeUserID ..
    	"&InviteeSocialType=" .. inviteeSocialType ..
    	"&InviteeSocialID=" .. inviteeSocialID ..
    	"&NotificationMessage=" .. notificationMessage;

    if (gameUserProperties ~= nil) then
    	parameters = parameters .. "&InviteeGameUserProps=" .. gameUserProperties:EncodeJson();
	end

	lib.sendNetworkMessage("gameinstances", "inviteusertogame", parameters, networkListener);
end

-- @classmessage TogetherGameInstance:Leave()
-- Leaves this GameInstance. Upon success, this will automatically update the internal data.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherGameInstance:Leave(callbackFunc)
	lib.togetherPrint("TogetherGameInstance:Leave()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end
 

   		-- Now parse the json data.
		self:ProcessGameInstanceJson(callback.ResponseObj.GameInstance);
		self:ProcessGameInstanceUsersJson(callback.ResponseObj.GameInstance.GameInstanceUsers);

		-- Post processes the GameInstanceUser's usernames.
		self:PostProcessUsernames();

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&GameInstanceID=" .. self.GameInstanceID;

	lib.sendNetworkMessage("gameinstances", "leavegame", parameters, networkListener);		
end

-- @classmessage TogetherGameInstance:MakeMove()
-- Makes a move in the GameInstance with optional turn index updates. Turn indexes are base 0. Upon success, this will
-- automatically update the internal data.
-- The following GameInstance members are sent to the server when this method is called.<br />
-- * <b>GameInstanceID:</b> The ID of the GameInstance we're making a move in.<br />
-- * <b>TurnIndex:</b> The current Index of which User whose turn it is.<br />
-- * <b>NewTurnUserID:</b> The UserID of the User whose turn it should be.  Pass in 0 to<br />
-- 						assign the next turn to no one.  The only time 0 should be passed<br />
-- 						is if another User can join the game and the game is waiting.  This<br />
-- 						is because whenever a User joins a game and the current TurnUserID is<br />
-- 						unassigned, turn is immediately assigned to the new user.<br />
-- * <b>NewTurnIndex:</b> The index of the next User to assign the turn to.  For a two player<br />
-- 						GameInstance, the TurnIndex should either be 0 or 1.<br />
-- * <b>GameInstanceUserID:</b> The current GameInstanceUserID whose turn it is.<br />
-- * <b>GameProps:</b> The GameInstance.Properties member representing the properties for the GameInstance.<br />
-- * <b>GameUserProps:</b> The Properties of the GameInstanceUser that is making the move.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherGameInstance:MakeMove(callbackFunc)

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end
 

   		-- Now parse the json data.
		self:ProcessGameInstanceJson(callback.ResponseObj.GameInstance);
		self:ProcessGameInstanceUsersJson(callback.ResponseObj.GameInstance.GameInstanceUsers);

		-- Post processes the GameInstanceUser's usernames.
		self:PostProcessUsernames();

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


	local userCount = self:GetGameInstanceUserCount();
    local newTurnIndex = self.TurnIndex + 1;
    if (newTurnIndex >= userCount) then
   		if (userCount > 1) then
   			newTurnIndex = 0;
   		end
    end

	local newTurnUserID = 0;
	local newGameInstanceUser = self:GetGameInstanceUser(newTurnIndex+1);
	if (newGameInstanceUser ~= nil) then
		newTurnUserID = newGameInstanceUser.UserID;
	end
	
	local myGameInstanceUser = self:FindGameInstanceUserByUserID(g_Together:GetUserID());
	
    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
       	"&GameInstanceID=" .. self.GameInstanceID ..
   		"&TurnIndex=" .. self.TurnIndex ..
   		"&NewTurnUserID=" .. newTurnUserID ..
   		"&NewTurnIndex=" .. newTurnIndex ..
   		"&GameInstanceUserID=" .. myGameInstanceUser.GameInstanceUserID ..
   		"&GameProps=" .. self.Properties:EncodeJson() ..
   		"&GameUserProps=" .. myGameInstanceUser.Properties:EncodeJson();

	lib.sendNetworkMessage("gameinstances", "makemoveingame", parameters, networkListener);		
end

-- @classmessage TogetherGameInstance:Modify()
-- Modifies the GameInstance. Upon success, this will automatically update the internal data.
-- The following GameInstance members are sent to the server when this method is called:<br />
-- * <b>GameInstanceID:</b> The ID of the GameInstance we're making a move in.<br />
-- * <b>Active:</b> The active boolean on the GameInstance.<br />
-- * <b>TurnUserID:</b> The UserID of the User whose turn it should be.  Pass in 0 to assign the next turn to no one.<br />
-- * <b>TurnIndex:</b> The Index of the User whose turn it is.<br />
-- * <b>GameProps:</b> The GameInstance.Properties member representing the properties for the GameInstance.<br />
-- * <b>State:</b> The State of the GameInstance.<br />
-- <table>
-- <tr><td><small>GAME_STATE_WAITING_FOR_PLAYERS</td><td><small>=1</td><td><small>Waiting for players to join the game.</td></tr>
-- <tr><td><small>GAME_STATE_IN_PROGRESS</td><td><small>=2</td><td><small>Players are currently playing the game.</td></tr>
-- <tr><td><small>GAME_STATE_FINISHED</td><td><small>=4</td><td><small>Game has been finished and a leaderboard was generated.</td></tr>
-- <tr><td><small>GAME_STATE_POSSIBLE_REMATCH</td><td><small>=8</td><td><small>A rematched Game waiting for enough players to join.</td></tr>
-- <tr><td><small>GAME_STATE_FORFEIT</td><td><small>=16</td><td><small>Game was forfeited by a User.<big></td></tr>
-- </table>
-- @param number indexOfUserToModify The index of the GameInstanceUser to modify as well.  Pass -1 to modify no GameInstanceUser.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherGameInstance:Modify(indexOfUserToModify, callbackFunc)
	lib.togetherPrint("TogetherGameInstance:Modify(" .. indexOfUserToModify .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		self:ProcessGameInstanceJson(callback.ResponseObj.GameInstance);
		self:ProcessGameInstanceUsersJson(callback.ResponseObj.GameInstance.GameInstanceUsers);

		-- Post processes the GameInstanceUser's usernames.
		self:PostProcessUsernames();

   		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&GameInstanceID=" .. self.GameInstanceID ..
    	"&Active=" .. tostring(self.Active) ..
    	"&State=" .. self.State ..
    	"&TurnUserID=" .. self.TurnUserID ..
    	"&TurnIndex=" .. self.TurnIndex ..
    	"&GameProps=" .. self.Properties:EncodeJson();

    if (indexOfUserToModify ~= -1) then
    	local gameInstanceUser = self:GetGameInstanceUser(indexOfUserToModify);
    	parameters = parameters .. "&ModifyUserID=" .. gameInstanceUser.UserID ..
    		"&GameUserProps=" .. gameInstanceUser.Properties:EncodeJson();
	end

	lib.sendNetworkMessage("gameinstances", "modifygame", parameters, networkListener);
end


-- return TogetherGameInstance;

-------------------------------------------------------------------------------
-- GameInstanceManager.lua ----------------------------------------------------
-------------------------------------------------------------------------------
lib.GameInstanceManager = {};
lib.GameInstanceManager.__index = lib.GameInstanceManager;

-- @class GameInstanceManager
-- The GameInstanceManager is used for fetching and finding matches that exist for the current game.
-- @member table GameInstances Stores all the GameInstances contained in the Manager.

function lib.GameInstanceManager.New()
	local self = {};
	setmetatable(self, lib.GameInstanceManager);
	
	self.GameInstances = {};

	return self;
end


-- @classmethod GameInstanceManager:Add()
-- Adds a GameInstance to the manager internally without persistence.
-- @boldnote This method is deprecated
-- @param TogetherGameInstance gameInstance Instance of a GameInstance to add internally
function lib.GameInstanceManager:Add(gameInstance)
	table.insert(self.GameInstances, gameInstance);
end

-- @classmethod GameInstanceManager:FindByGameInstanceID()
-- Finds the GameInstance with the specified GameInstanceID if it exists, otherwise returns nil.
-- @param number gameInstanceID The ID of the GameInstance to find  
-- @return TogetherGameInstance
function lib.GameInstanceManager:FindByGameInstanceID(gameInstanceID)
	local indexOfGameInstance = self:IndexOfByGameInstanceID(gameInstanceID);
	if (indexOfGameInstance ~= -1) then
		return self:Get(indexOfGameInstance);
	end
	return nil;
end

-- @classmethod GameInstanceManager:GetCount()
-- Gets the number of GameInstances currently managed internally.
-- @return number
function lib.GameInstanceManager:GetCount()
	return table.getn(self.GameInstances);
end

-- @classmethod GameInstanceManager:Get()
-- Gets the GameInstance at the specified index if it exists, otherwise return nil.
-- @param number index The index of the GameInstance to find
-- @return TogetherGameInstance
function lib.GameInstanceManager:Get(index)
	local gameInstance = self.GameInstances[index];
	return gameInstance;
end

-- @classmethod GameInstanceManager:IndexOf()
-- Returns the index of the specified GameInstance if it exists, otherwise returns nil.
-- @param TogetherGameInstance gameInstance Instance of the GameInstance to find the index of  
-- @return number
function lib.GameInstanceManager:IndexOf(gameInstance)
	return table.indexOf(self.GameInstances, gameInstance);
end

-- @classmethod GameInstanceManager:IndexOfByGameInstanceID()
-- Returns the index of the GameInstance with the specified GameInstanceID if it exists, otherwise returns -1.
-- @param number gameInstanceID The ID of the GameInstance to find the index of
-- @return number
function lib.GameInstanceManager:IndexOfByGameInstanceID(gameInstanceID)
	local gameInstanceCount = self:GetCount();
	for i=1, gameInstanceCount do
    		if (self.GameInstances[i].GameInstanceID == gameInstanceID) then
    			return i;
    		end
    end
    return -1;
end

-- @classmethod GameInstanceManager:Remove()
-- Removes a GameInstance from the internally managed list. This does not delete the GameInstance from the Game persistently.
-- @boldnote This method is deprecated
-- @param number index The index of the GameInstance to be removed internally
function lib.GameInstanceManager:Remove(index)
	table.remove(self.GameInstances, index);
end

function lib.GameInstanceManager:Dump()
	local gameInstanceCount = self:GetCount();

	print("GameInstanceManger:");
	print("   GameInstanceCount       = " .. gameInstanceCount);
	for i=1, gameInstanceCount do
    	self.GameInstances[i]:Dump();
    end
end

function lib.GameInstanceManager:ProcessGameInstancesJson(jsonObject, clearLastModifyTimestamp)
	self.GameInstances = {};
	
	if (jsonObject ~= nil) then
		-- Parse out all the GameInstances.
		for name, value in pairs (jsonObject) do
    		local gameInstance = lib.TogetherGameInstance:New();
			gameInstance:ProcessGameInstanceJson(value);
			table.insert(self.GameInstances, gameInstance);
			
			if (clearLastModifyTimestamp) then
				gameInstance.LastModifyTimestamp = 0;
			end
		end
	end
end

function lib.GameInstanceManager:PostProcessUsernames()
-- PostProcessUsername
	local gameInstanceCount = self:GetCount();
	for i=1, gameInstanceCount do
    	self.GameInstances[i]:PostProcessUsernames();
    end
end


-------------------------------------------------------------------------------
--  Network methods.
-------------------------------------------------------------------------------


-- @classmessage GameInstanceManager:Create()
-- Creates a new GameInstance. Upon success, this will automatically update the internal list.
-- @param string gameInstanceType The type of GameInstance to create. Potentially, a Game could have several types of GameInstance types within it. Type is limited to 16 characters.
-- @param string gameInstanceSubType The subtype of the GameInstance that will be created.  Potentially, a Game could have several sub types within it. SubType is limited to 16 characters.
-- @param number roomID The ID of the room the rematch GameInstance is created in. Pass 0 to bypass room creation.
-- @param number maxUsers The max number of users the GameInstance supports.  Pass in 2 for a two player game.
-- @param boolean passTurn A boolean indicating whether the turn should be passed immediately onto the next User. When true, the TurnUserID will actually be set to nil.  When the next User joins the GameInstance, the TurnUserID will be set to them.
-- @param PropertyCollection gameInstanceProperties The properties to assign to the GameInstance. Pass nil to assign no properties to the GameInstance.
-- @param PropertyCollection gameInstanceUserProperties The properties to assign to your GameInstanceUser. Pass nil to assign no properties to the GameInstanceUser.
-- @param function callbackFunc The function to call upon completion.
function lib.GameInstanceManager:Create(gameInstanceType, gameInstanceSubType, roomID, maxUsers,
		passTurn, gameInstanceProperties, gameInstanceUserProperties, callbackFunc)
	lib.togetherPrint("GameInstanceManager:Create()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end
    		
   		
    	-- Create the TogetherGameInstance object and let it parse it's json data.
		g_CurrentGameInstance = lib.TogetherGameInstance:New();
		g_CurrentGameInstance:ProcessGameInstanceJson(callback.ResponseObj.GameInstance);
		self:Add(g_CurrentGameInstance);
		callback.NewObject = g_CurrentGameInstance;

		-- Post processes the GameInstanceUser's usernames.
		g_CurrentGameInstance:PostProcessUsernames();

   		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end
	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
       	"&GameInstanceType=" .. gameInstanceType;
		
	if(nil ~= gameInstanceSubType) then
		parameters= parameters .. "&GameInstanceSubType=" .. gameInstanceSubType;
	end
		
	parameters = parameters .. "&RoomID=" .. roomID ..
		"&MaxUsers=" .. maxUsers ..
		"&PassTurn=" .. tostring(passTurn);
		
	if (gameInstanceProperties ~= nil) then
		parameters = parameters .. "&GameProps=" .. gameInstanceProperties:EncodeJson();
	end
	if (gameInstanceUserProperties ~= nil) then
		parameters = parameters .. "&GameUserProps=" .. gameInstanceUserProperties:EncodeJson();
	end

	lib.sendNetworkMessage("gameinstances", "creategame", parameters, networkListener);
end

-- @classmessage GameInstanceManager:CreateRematch()
-- Creates a rematch of a GameInstance. Upon success, this will automatically update the internal list. 
-- If the GameInstance is not already finished, it will be finished and a leaderboard will be generated.
-- @param number originalGameInstanceID The ID of the original GameInstance we're creating a rematch from. 
-- @param string gameInstanceType The type of GameInstance to create.  Potentially, a Game could have several types of GameInstance types within it. Type is limited to 16 characters.
-- @param string gameInstanceSubType The subtype of the GameInstance that will be created.  Potentially, a Game could have several subtypes within it. SubType is limited to 16 characters.
-- @param number roomID The ID of the room the rematch GameInstance is created in.  Pass in 0 for no room.
-- @param number maxUsers The max number of users the GameInstance supports.  Pass in 2 for a two player game.
-- @param number winningUserID The ID of the User that has won the GameInstance.
-- @param number turnUserID The ID of the User whose initial turn it is.
-- @param boolean includeLeftGameUsers A boolean dictating whether users that have left the original game should be included in the rematched GameInstance.
-- @param string rematchMessage The notification message to send to all other users that are a member of the rematched GameInstance. Pass "" to have no notification message sent.
-- @param PropertyCollection originalGameProps The final properties of the original GameInstance.
-- @param PropertyCollection origianlGameWinningUserProps The properties of the winning User of the original GameInstance.
-- @param PropertyCollection rematchGameProps The properties of the rematch GameInstance.  Pass in nil to assign no properties to the rematched GameInstance.
-- @param function callbackFunc The function to call upon completion.
function lib.GameInstanceManager:CreateRematch(originalGameInstanceID,
				gameInstanceType, gameInstanceSubType, roomID, maxUsers, winningUserID,
				turnUserID, includeLeftGameUsers, rematchMessage,
				originalGameProps, originalWinningGameUserProps,
				rematchGameProps,
				callbackFunc)

	lib.togetherPrint("TogetherGameInstance:CreateRematch()");
	lib.togetherPrint("   OriginalGameInstanceID = " .. originalGameInstanceID);
	lib.togetherPrint("   GameInstanceType = " .. gameInstanceType);
	lib.togetherPrint("   GameInstanceSubType = " .. gameInstanceSubType);
	lib.togetherPrint("   RoomID = " .. roomID);
	lib.togetherPrint("   MaxUsers = " .. maxUsers);
	lib.togetherPrint("   WinningUserID = " .. winningUserID);
	lib.togetherPrint("   TurnUserID = " .. turnUserID);
	lib.togetherPrint("   IncludeLeftGameUsers = " .. tostring(includeLeftGameUsers));
	lib.togetherPrint("   RematchMessage = " .. rematchMessage);

	if (originalGameProps ~= nil) then
		lib.togetherPrint("   OriginalGameProps = " .. originalGameProps:ToString());
	else
		lib.togetherPrint("   OriginalGameProps = nil");
	end

	if (originalWinningGameUserProps ~= nil) then
		lib.togetherPrint("   OriginalWinningGameUserProps = " .. originalWinningGameUserProps:ToString());
	else
		lib.togetherPrint("   OriginalWinningGameUserProps = nil");
	end

	if (rematchGameProps ~= nil) then
		lib.togetherPrint("   RematchGameProps = " .. rematchGameProps:ToString());
	else
		lib.togetherPrint("   RematchGameProps = nil");
	end


	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		g_CurrentGameInstance = lib.TogetherGameInstance:New();
		g_CurrentGameInstance:ProcessGameInstanceJson(callback.ResponseObj.GameInstance);
		g_CurrentGameInstance:ProcessGameInstanceUsersJson(callback.ResponseObj.GameInstance.GameInstanceUsers);
		self:Add(g_CurrentGameInstance);
		callback.NewObject = g_CurrentGameInstance;

		-- Post processes the GameInstanceUser's usernames.
		g_CurrentGameInstance:PostProcessUsernames();

   		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    		"&OriginalGameInstanceID=" .. originalGameInstanceID ..
    		"&GameInstanceType=" .. gameInstanceType ..
			"&GameInstanceSubType=" .. gameInstanceSubType ..
	    	"&RoomID=" .. roomID ..
	    	"&MaxUsers=" .. maxUsers ..
	    	"&WinningUserID=" .. winningUserID ..
	    	"&TurnUserID=" .. turnUserID ..
	    	"&IncludeLeftGameUsers=" .. tostring(includeLeftGameUsers) ..
	    	"&RematchMessage=" .. rematchMessage;
	    	
	if (originalGameProps ~= nil) then
		parameters = parameters .. "&OriginalGameProps=" .. json.encode(originalGameProps);
	end
	if (originalGameWinningUserProps ~= nil) then
		parameters = parameters .. "&OriginalWinningGameUserProps=" .. json.encode(originalGameWinningUserProps);
	end
	if (rematchGameProps ~= nil) then
		parameters = parameters .. "&RematchGameProps=" .. json.encode(rematchGameProps);
	end

	lib.sendNetworkMessage("gameinstances", "rematchgame", parameters, networkListener);	
end

-- @classmessage GameInstanceManager:Delete()
-- Deletes a GameInstance. Upon success, this will automatically update the internal list.
-- @param number gameInstanceID The ID of the GameInstance to delete.
-- @param function callbackFunc The function to call upon completion.
function lib.GameInstanceManager:Delete(gameInstanceID, callbackFunc)
	lib.togetherPrint("GameInstanceManager:Delete(" .. gameInstanceID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end

    	
    	-- Remove the GameInstance from the Manager.
    	self:Remove(self:IndexOfByGameInstanceID(gameInstanceID));
    	

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&GameInstanceID=" .. gameInstanceID;

	lib.sendNetworkMessage("gameinstances", "deletegame", parameters, networkListener);	
end

-- @classmessage GameInstanceManager:GetAll()
-- Gets all GameInstances. Upon success, this will automatically update the internal list.
-- @param number userID The ID of the User who must be a member of a GameInstance retrieved. Pass 0 to fetch all games regardless of membership within them.
-- @param table stateMask A table containing the GameInstance States to retrieve. The following stateMask table members are examined:
-- <table>
-- <tr><td><small>waitingForPlayers</td><td><small>Waiting for players to join the game.</td></tr>
-- <tr><td><small>inProgress</td><td><small>Players are currently playing the game.</td></tr>
-- <tr><td><small>finished</td><td><small>Game has been finished and a leaderboard was generated.</td></tr>
-- <tr><td><small>possibleRematch</td><td><small>A rematched Game waiting for enough players to join.</td></tr>
-- <tr><td><small>forfeit</td><td><small>Game was forfeited by a User.</td></tr>
-- </table>
-- Examples:
-- <pre>
-- -- To get all GameInstances that are playable.
-- local stateMasks = { waitingForPlayers=true, inProgress=true };
-- -- To get all GameInstances regardless of State.
-- local stateMasks = { waitingForPlayers=true, inProgress=true, finished=true, possibleRematch=true, forfeit=true };
-- </pre>
-- @param number maxCount The maximum number of GameInstance to retrieve.
-- @param boolean getGameInstanceProperties Set TRUE to retrieve the property collections of each game instance, FALSE to retrieve the instances without properties.
-- @param boolean friendsOnly Set TRUE to retrieve only gamesin which you and your friends are joined in
-- @param string gameInstanceType Set to retrieve only games with this type, pass nil to ignore.
-- @param string gameInstanceSubtype Set to retrieve only games with this subtype, pass nil to ignore.
-- @param function callbackFunc The function to call upon completion.
function lib.GameInstanceManager:GetAll(userID, stateMasks, maxCount, getGameInstanceProperties, friendsOnly, instanceType, instanceSubtype, callbackFunc)
	lib.togetherPrint("GameInstanceManager:GetAll()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


   		-- Now parse the json data.
		if (getGameInstanceProperties) then
			self:ProcessGameInstancesJson(callback.ResponseObj.GameInstances, false);
		else
   			-- Set each GameInstance's LastModifyTimestamp to 0 if getGameInstanceProperties = false.
			self:ProcessGameInstancesJson(callback.ResponseObj.GameInstances, true);
		end


		-- Post processes the GameInstanceUser's usernames.
		self:PostProcessUsernames();

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


	local stateMask = 0;
	
	if (stateMasks.waitingForPlayers ~= nil and stateMasks.waitingForPlayers == true) then
		stateMask = GAME_STATE_WAITING_FOR_PLAYERS;
	end

	if (stateMasks.inProgress ~= nil and stateMasks.inProgress == true) then
		stateMask = stateMask + GAME_STATE_IN_PROGRESS;
	end

	if (stateMasks.finished ~= nil and stateMasks.finished == true) then
		stateMask = stateMask + GAME_STATE_FINISHED;
	end

	if (stateMasks.possibleRematch ~= nil and stateMasks.possibleRematch == true) then
		stateMask = stateMask + GAME_STATE_POSSIBLE_REMATCH;
	end

	if (stateMasks.forfeit ~= nil and stateMasks.forfeit == true) then
		stateMask = stateMask + GAME_STATE_FORFEIT;
	end


--  State Values:
--		1 - Waiting for Players
--		2 - In Progress
--		4 - Finished
--		8 - Possible Rematch
   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&UserID=" .. userID ..
   		"&StateMask=" .. stateMask ..
   		"&MaxCount=" .. maxCount ..
		"&GetGameInstanceProperties=" .. tostring(getGameInstanceProperties) ..
		"&FriendsOnly=" .. tostring(friendsOnly);

	if(instanceType ~= nil) then
		parameters = parameters .. "&type=" .. instanceType;
	end
	
	if(instanceSubtype ~= nil) then
		parameters = parameters .. "&subtype=" .. instanceSubtype;
	end
		
	lib.sendNetworkMessage("gameinstances", "getallgames", parameters, networkListener);
end


-- @classmessage GameInstanceManager:GetAllInDuel()
-- Gets all the GameInstances in a duel. Upon success, this will automatically update the internal list.
-- @param number gameInstanceDuelID The ID of the duel to retrieve all GameInstances for.
-- @param function callbackFunc The function to call upon completion.
function lib.GameInstanceManager:GetAllInDuel(gameInstanceDuelID, callbackFunc)
	lib.togetherPrint("GameInstanceManager:GetAllInDuel(" .. gameInstanceDuelID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end
		
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&GameInstanceDuelID=" .. gameInstanceDuelID;

	lib.sendNetworkMessage("gameinstances", "getallgamesinduel", parameters, networkListener);	
end

-- @classmessage GameInstanceManager:Join()
-- Joins an existing GameInstance. Upon success, this will automatically update the internal list.
-- @param number gameInstanceID The ID of the specific GameInstance to join.
-- @param PropertyCollection gameInstanceUserProperties The properties to assign the User joining the GameInstance.
-- @param function callbackFunc The function to call upon completion.
function lib.GameInstanceManager:Join(gameInstanceID, gameInstanceUserProperties, callbackFunc)
	lib.togetherPrint("GameInstanceManager:Join(" .. gameInstanceID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


   		-- Find the GameInstance with the GameInstanceID or create a new GameInstance
   		-- if it's not already in the list.
     		g_CurrentGameInstance = self:FindByGameInstanceID(gameInstanceID);
		if (g_CurrentGameInstance == nil) then
			g_CurrentGameInstance = lib.TogetherGameInstance:New();
		end
 		-- Parse the GameInstance's data.
		g_CurrentGameInstance:ProcessGameInstanceJson(callback.ResponseObj.GameInstance);
		g_CurrentGameInstance:ProcessGameInstanceUsersJson(callback.ResponseObj.GameInstance.GameInstanceUsers);
		callback.NewObject = g_CurrentGameInstance;

		-- Post processes the GameInstanceUser's usernames.
		g_CurrentGameInstance:PostProcessUsernames();

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end
    

   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
		"&GameInstanceID=" .. gameInstanceID;
	if (gameInstanceUserProperties ~= nil) then
		parameters = parameters .. "&GameUserProps=" .. gameInstanceUserProperties:EncodeJson();
	end

	lib.sendNetworkMessage("gameinstances", "joingame", parameters, networkListener);
end

-- @classmessage GameInstanceManager:JoinRandom()
-- Joins a random existing GameInstance. Upon success, this will automatically update the internal list.
-- @param string gameInstanceType The type of GameInstance to join.
-- @param string gameInstanceSubType The sub-type (if any) of GameInstance to join.
-- @param TogetherPropertyCollection gameInstanceUserProperties The properties to assign the User joining the GameInstance.
-- @param function callbackFunc The function to call upon completion.
function lib.GameInstanceManager:JoinRandom(instanceType, instanceSubType, gameInstanceUserProperties, callbackFunc)
	lib.togetherPrint("GameInstanceManager:JoinRandom()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


   		-- Find the GameInstance with the GameInstanceID or create a new GameInstance
   		-- if it's not already in the list.
     		g_CurrentGameInstance = self:FindByGameInstanceID(gameInstanceID);
		if (g_CurrentGameInstance == nil) then
			g_CurrentGameInstance = lib.TogetherGameInstance:New();
		end

 		-- Parse the GameInstance's data.
		g_CurrentGameInstance:ProcessGameInstanceJson(callback.ResponseObj.GameInstance);
		g_CurrentGameInstance:ProcessGameInstanceUsersJson(callback.ResponseObj.GameInstance.GameInstanceUsers);
		callback.NewObject = g_CurrentGameInstance;

		-- Post processes the GameInstanceUser's usernames.
		g_CurrentGameInstance:PostProcessUsernames();

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end
    

   	local parameters = "SessionToken=" .. g_Together:GetSessionToken();
   	
	if(instanceType ~= nil) then
		parameters = parameters .. "&GameType=" .. instanceType;
	end
		
	if(instanceSubType ~= nil) then
   		parameters = parameters .. "&GameSubType=" .. instanceSubType;
	end
	
	if (gameInstanceUserProperties ~= nil) then
		parameters = parameters .. "&GameUserProps=" .. gameInstanceUserProperties:EncodeJson();
	end

	lib.sendNetworkMessage("gameinstances", "joinrandomgame", parameters, networkListener);	
end


--return GameInstanceManager;

-------------------------------------------------------------------------------
-- LeaderboardUser.lua --------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherLeaderboardUser = {};
lib.TogetherLeaderboardUser.__index = lib.TogetherLeaderboardUser;

-- @class TogetherLeaderboardUser
-- The Leaderboard class represents a User record within a Leaderboard.
-- @member number LeaderboardUserID The ID of the LeaderboardUser.
-- @member number UserID The ID of the User playing a original GameInstance.
-- @member string Username The Username assigned to the User.
-- @member boolean UserAnonymous A boolean indicating whether the User is anonymous.
-- @member number PlayDuration How long the User played the game for.
-- @member number SecondsSinceAwarded The number of seconds since the Leaderboard was awarded.
-- @member number LastActivityInSeconds The number of seconds since the User was last active in any game.
-- @member number ClientID The ID of the Client the User has last played a Game with.
-- @member number GameID The ID of the Game the User has last played.
-- @member number PlatformID The ID of the Platform of the last played Game for the User. 
-- @member PropertyCollection Properties A property collection containing all custom properties for the LeaderboardUser.


-----------------
-- Constructor --
-----------------

function lib.TogetherLeaderboardUser.New()
	local self = {};
	setmetatable(self, lib.TogetherLeaderboardUser);

	self.LeaderboardUserID			= 0;
	self.UserID						= 0;
	self.Username					= "";
	self.UserAnonymous				= true;
	self.PlayDuration				= 0;
	self.SecondsSinceAwarded		= 0;
	self.LastActivityInSeconds		= 0;
	self.ClientID					= 0;
	self.GameID						= 0;
	self.PlatformID					= 0;

	self.Properties					= lib.PropertyCollection:New();

	return self;
end

function lib.TogetherLeaderboardUser:ProcessLeaderboardUserJson(leaderboardUserJson)
	self.LeaderboardUserID 			= leaderboardUserJson.LeaderboardUserID;
	self.UserID						= leaderboardUserJson.UserID;
	self.Username					= leaderboardUserJson.Username;
	self.UserAnonymous				= leaderboardUserJson.UserAnonymous;
	self.PlayDuration				= leaderboardUserJson.PlayDuration;
	self.SecondsSinceAwarded		= leaderboardUserJson.SecondsSinceAwarded;
	self.LastActivityInSeconds		= leaderboardUserJson.LastActivityInSeconds;
	self.ClientID					= leaderboardUserJson.ClientID;
	self.GameID						= leaderboardUserJson.GameID;
	self.PlatformID					= leaderboardUserJson.PlatformID;

	self.Properties:ProcessNodeJson(leaderboardUserJson.Properties);
end

function lib.TogetherLeaderboardUser:Dump()
	self:DumpEx("");
end

function lib.TogetherLeaderboardUser:DumpEx(spacing)
	print(spacing .. "LeaderboardUser:");
	print(spacing .. "   LeaderboardUserID        = " .. self.LeaderboardUserID);
	print(spacing .. "   UserID                   = " .. self.UserID);
	print(spacing .. "   Username                 = " .. self.Username);
	print(spacing .. "   UserAnonymous            = " .. tostring(self.UserAnonymous));
	print(spacing .. "   PlayDuration             = " .. self.PlayDuration);
	print(spacing .. "   SecondsSinceAwarded      = " .. self.SecondsSinceAwarded);
	print(spacing .. "   LastActivityInSeconds    = " .. self.LastActivityInSeconds);
	print(spacing .. "   ClientID                 = " .. self.ClientID);
	print(spacing .. "   GameID                   = " .. self.GameID);
	print(spacing .. "   PlatformID               = " .. self.PlatformID);

	self.Properties:DumpEx(spacing .. "   ");
end


-- return TogetherLeaderboardUser;

-------------------------------------------------------------------------------
-- Leaderboard.lua ------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherLeaderboard = {};
lib.TogetherLeaderboard.__index = lib.TogetherLeaderboard;

-- @class TogetherLeaderboard
-- The Leaderboard class represents a together Leaderboard.
-- @member number LeaderboardID The ID of the Leaderboard.
-- @member number CreatorUserID The ID of the User that created the GameInstance the Leaderboard is based on.
-- @member number RoomID The ID of the Room the original GameInstance.
-- @member number SecondsSinceStart The number of seconds since the original GameInstance was started.
-- @member number SecondsSinceFinish The number of seconds since the original GameInstance was finished.
-- @member number MaxUsers The max number of users in the original GameInstance.
-- @member number TurnIndex The index of whose turn it last was.
-- @member number WinningUserID The ID of the User that won the original GameInstance.
-- @member table LeaderboardUsers Contains all the LeaderboardUsers that were playing the original GameInstance.

local leaderboard_SortByPropertyName = "";

function lib.TogetherLeaderboard:leaderboard_SortByCompareFunc(x, y)
	local xPropValue = x.Properties:Get(leaderboard_SortByPropertyName);
	local yPropValue = y.Properties:Get(leaderboard_SortByPropertyName);

	if (xPropValue == nil or yPropValue == nil) then
		return false;
	end

	xPropValue = tonumber(xPropValue);
	yPropValue = tonumber(yPropValue);

	return xPropValue < yPropValue;
end


-----------------
-- Constructor --
-----------------

function lib.TogetherLeaderboard.New()
	local self = {};
	setmetatable(self, lib.TogetherLeaderboard);

	self.LeaderboardID			= 0;
	self.CreatorUserID			= 0;
	self.RoomID					= 0;
	self.SecondsSinceStart		= 0;
	self.SecondsSinceFinish		= 0;
	self.MaxUsers				= 0;
	self.TurnIndex				= 0;
	self.WinningUserID			= 0;

	-- Contains all the LeaderboardUsers in the Leaderboard.
	self.LeaderboardUsers		= {};
    
	return self;
end


-- @classmethod TogetherLeaderboard:GetLeaderboardUserCount()
-- Gets the number of LeaderboardUsers currently managed internally.
-- @return number
function lib.TogetherLeaderboard:GetLeaderboardUserCount()
	return table.getn(self.LeaderboardUsers);
end

-- @classmethod TogetherLeaderboard:GetLeaderboardUser()
-- Gets the LeaderboardUser at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the LeaderboardUser to find
-- @return TogetherLeaderboardUser
function lib.TogetherLeaderboard:GetLeaderboardUser(index)
	return self.LeaderboardUsers[index];
end

-- @classmethod TogetherLeaderboard:SortBy()
-- Sorts the list of LeaderboardUsers by the specified property.
-- @param string propertyName The name of the property to sort the list of LeaderboardUsers by
function lib.TogetherLeaderboard:SortBy(propertyName)
	s_Leaderboard_SortByPropertyName = propertyName;
	table.sort(self.LeaderboardUsers, leaderboard_SortByCompareFunc);
end

-- @classmethod TogetherLeaderboard:GetWinningLeaderboardUser()
-- Gets the LeaderboardUser that had won the original GameInstance if it exists, otherwise returns nil.
-- @return TogetherLeaderboardUser
function lib.TogetherLeaderboard:GetWinningLeaderboardUser()
	local leaderboardUserCount = self:GetLeaderboardUserCount();
    for i=1, leaderboardUserCount do
   		if (self.LeaderboardUsers[i].UserID == self.WinningUserID) then
   			return self.LeaderboardUsers[i];		
   		end
    end
    return nil;
end

function lib.TogetherLeaderboard:Dump()
	self:DumpEx("");
end

function lib.TogetherLeaderboard:DumpEx(spacing)
	print(spacing .. "Leaderboard:");
	print(spacing .. "   LeaderboardID       = " .. self.LeaderboardID);
	print(spacing .. "   CreatorUserID       = " .. self.CreatorUserID);
	print(spacing .. "   RoomID              = " .. self.RoomID);
	print(spacing .. "   SecondsSinceStart   = " .. self.SecondsSinceStart);
	print(spacing .. "   SecondsSinceFinish  = " .. self.SecondsSinceFinish);
	print(spacing .. "   MaxUsers            = " .. self.MaxUsers);
	print(spacing .. "   TurnIndex           = " .. self.TurnIndex);
	print(spacing .. "   WinningUserID       = " .. self.WinningUserID);

	-- Dump all the LeaderboardUsers as well.
	local leaderboardUserCount = self:GetLeaderboardUserCount();
	print(spacing .. "   LeaderboardUserCount   = " .. leaderboardUserCount);

    for i=1, leaderboardUserCount do
   		self.LeaderboardUsers[i]:DumpEx("   ");	
    end
end


function lib.TogetherLeaderboard:ProcessLeaderboardJson(leaderboardJson)
	self.LeaderboardID 			= leaderboardJson.LeaderboardID;
	self.CreatorUserID			= leaderboardJson.CreatorUserID;
	self.RoomID					= leaderboardJson.RoomID;
	self.SecondsSinceStart		= leaderboardJson.SecondsSinceStart;
	self.SecondsSinceFinish		= leaderboardJson.SecondsSinceFinish;
	self.MaxUsers				= leaderboardJson.MaxUsers;
	self.TurnIndex				= leaderboardJson.TurnIndex;
	self.WinningUserID			= leaderboardJson.WinningUserID;
end

function lib.TogetherLeaderboard:ProcessLeaderboardUsersJson(leaderboardUsersJson)
	lib.togetherPrint("TogetherLeaderboard:ProcessLeaderboardUsersJson()");

	self.LeaderboardUsers = {};

	-- Parse out all the LeaderboardUsers.
	for name, value in pairs (leaderboardUsersJson) do
    	local leaderboardUser = lib.TogetherLeaderboardUser:New();

		leaderboardUser:ProcessLeaderboardUserJson(value);

		table.insert(self.LeaderboardUsers, leaderboardUser);
    end
end



--------------------------------------------------------------------------------
--  Network methods.
--------------------------------------------------------------------------------

-- @classmessage TogetherLeaderboard:GetDetails()
-- Gets the Leaderboard's details.
-- @param boolean friendsOnly A boolean indicating whether only Together friend Users should be retrieve.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherLeaderboard:GetDetails(friendsOnly, callbackFunc)
	lib.togetherPrint("TogetherLeaderboard:GetDetails()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


   		-- Now parse the data.
		self:ProcessLeaderboardJson(callback.ResponseObj.Leaderboard);
		self:ProcessLeaderboardUsersJson(callback.ResponseObj.LeaderboardUsers);

   		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&LeaderboardID=" .. self.LeaderboardID ..
   		"&FriendsOnly=" .. tostring(friendsOnly);

	lib.sendNetworkMessage("leaderboards", "getleaderboarddetails", parameters, networkListener);
end


--return TogetherLeaderboard;

-------------------------------------------------------------------------------
-- LeaderboardManager.lua -----------------------------------------------------
-------------------------------------------------------------------------------
lib.LeaderboardManager = {};
lib.LeaderboardManager.__index = lib.LeaderboardManager;

-- @class LeaderboardManager
-- The LeaderboardManager is used for fetching and finding leaderboards that exist for the current game.
-- @member table Leaderboards Stores all the Leaderboards contained in the Manager.

function lib.LeaderboardManager.New()
	local self = {};
	setmetatable(self, lib.LeaderboardManager);

	self.Leaderboards		= {};

	return self;
end


-- @classmethod LeaderboardManager:Add()
-- Adds a Leaderboard to the internally managed list without persistence.
-- @boldnote This method is deprecated
-- @param TogetherLeaderboard leaderboard Instance of a Leaderboard to add internally
function lib.LeaderboardManager:Add(leaderboard)
	table.insert(self.Leaderboards, leaderboard);
end

-- @classmethod LeaderboardManager:FindByLeaderboardID()
-- Finds the Leaderboard with the specified LeaderboardID if it exists, otherwise returns nil.
-- @param number leaderboardID The ID of the Leaderboard to find
-- @return TogetherLeaderboard
function lib.LeaderboardManager:FindByLeaderboardID(leaderboardID)
	local indexOfLeaderboard = self:IndexOfByLeaderboardID(leaderboardID);
	if (indexOfLeaderboard ~= -1) then
		return self:Get(indexOfLeaderboard);
	end
	return nil;
end

-- @classmethod LeaderboardManager:GetCount()
-- Gets the number of Leaderboards currently managed internally.
-- @return number
function lib.LeaderboardManager:GetCount()
	return table.getn(self.Leaderboards);
end

-- @classmethod LeaderboardManager:Get()
-- Gets the Leaderboard at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the Leaderboard to find
-- @return TogetherLeaderboard
function lib.LeaderboardManager:Get(index)
	return self.Leaderboards[index];
end

-- @classmethod LeaderboardManager:IndexOf()
-- Returns the index of the specified Leaderboard if it exists, otherwise returns nil.
-- @param TogetherLeaderboard leaderboard Instance of the Leaderboard to find the index of
-- @return number
function lib.LeaderboardManager:IndexOf(leaderboard)
	return table.indexOf(self.Leaderboards, leaderboard);
end

-- @classmethod LeaderboardManager:IndexOfByLeaderboardID()
-- Returns the index of the Leaderboard with the specified LeaderboardID if it exists, otherwise returns -1.
-- @param number leaderboardID The ID of the Leaderboard to find the index of
-- @return number
function lib.LeaderboardManager:IndexOfByLeaderboardID(leaderboardID)
	local leaderboardCount = self:GetCount();

   	for i=1, leaderboardCount do
    	if (self.Leaderboards[i].LeaderboardID == leaderboardID) then
			return i;
		end
    end

    return -1;
end

-- @classmethod LeaderboardManager:Remove()
-- Removes a Leaderboard from the internally managed list. This does not delete the leaderboard from the game persistently.
-- @boldnote This method is deprecated
-- @param number index	The index of the Leaderboard to be removed
function lib.LeaderboardManager:Remove(index)
	if (index ~= -1) then
		table.remove(self.Leaderboards, index);
	end
end

function lib.LeaderboardManager:Dump()
	local leaderboardCount = self:GetCount();

	print("TogetherLeaderboardManger:");
	print("   LeaderboardCount       = " .. leaderboardCount);

	for i=1, leaderboardCount do
    	self.Leaderboards[i]:Dump();
    end
end

function lib.LeaderboardManager:ProcessLeaderboardsJson(jsonObject)
	self.Leaderboards = {};

	-- Parse out all the Leaderboards.
	for name, value in pairs (jsonObject) do
    	local leaderboard = lib.TogetherLeaderboard:New();

		leaderboard:ProcessLeaderboardJson(value);

		table.insert(self.Leaderboards, leaderboard);
    end
end




-------------------------------------------------------------------------------
--  Network methods.
-------------------------------------------------------------------------------

-- @classmessage LeaderboardManager:Delete()
-- Deletes a Leaderboard. Upon success, this will automatically update the internal list.
-- @param number leaderboardID The ID of the Leaderboard to delete
-- @param function callbackFunc The function to call upon completion.
function lib.LeaderboardManager:Delete(leaderboardID, callbackFunc)
	lib.togetherPrint("LeaderboardManager:Delete(" .. leaderboardID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end

    		
   		-- Now remove the delete Leaderboard.
		self:Remove(self:IndexOfByLeaderboardID(leaderboardID));

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&LeaderboardID=" .. leaderboardID;

	lib.sendNetworkMessage("leaderboards", "deleteleaderboard", parameters, networkListener);
end

-- @classmessage LeaderboardManager:GetAll()
-- Gets all Leaderboards for the current session's Game or a particular User.
-- @param number getForUserID The ID of the User to retrieve Leaderboards for. Pass 0 to fetch all Leaderboards.
-- @param function callbackFunc The function to call upon completion.
function lib.LeaderboardManager:GetAll(getForUserID, callbackFunc)
	lib.togetherPrint("LeaderboardManager:GetAll(" .. getForUserID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end

    		
   		-- Now parse the data.
		self:ProcessLeaderboardsJson(callback.ResponseObj.Leaderboards);

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&GetForUserID=" .. getForUserID;

	lib.sendNetworkMessage("leaderboards", "getallleaderboards", parameters, networkListener);
end


--return LeaderboardManager;

-------------------------------------------------------------------------------
-- UserNotification.lua -------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherUserNotification = {};
lib.TogetherUserNotification.__index = lib.TogetherUserNotification;


-- @class TogetherUserNotification
-- The UserNotification class represents a together UserNotification.
-- @member number UserNotificationID The ID of the UserNotification.
-- @member string NotficationType The type of notification the UserNotification is.
-- @member string Purpose The purpose of the UserNotification.
-- @member string Message The textual (message) of the UserNotification.
-- @member number OriginalGameInstanceID The ID of the original GameInstance associated with the UserNotification.  This member is used for rematch invite notifications.
-- @member number GameInstanceID The ID of the GameInstance associated with the UserNotification.
-- @member number AchievementID The ID of the Achievement associated with the UserNotification.  If the User accepts the UserNotification, then they will be awarded this Achievement.
-- @member number ItemID The ID of the Item associated with the UserNotification.  If the User accepts the UserNotification, then they will be awarded this Item.
-- @member number ItemCount The number of Items to award the User when they accept the UserNotification.
-- @member string SocialType The type of social network the User is registered with.  Facebook="FB".
-- @member string SocialID The ID of the social user the User had registered as.  Facebook=[User's facebook ID].
-- @member number ChatRoomID The ID of the ChatRoom the UserNotification was sent from.
-- @member number FromUserID The ID of the User that sent the UserNotification.
-- @member string FromUsername The username of the User that sent the UserNotification.
-- @member boolean Processed A boolean indicating whether the UserNotification was processed.   
-- @member boolean Accepted A boolean indicating whether the UserNotification was accepted.
-- @member number SecondsSinceCreated The number of seconds since the UserNotification was created.
-- @member number FromUserLastActivityInSeconds The number of seconds since the User that sent the UserNotification has been active in any together Game.
-- @member number FromClientID The ID of the Client the User that sent the UserNotification has last played a Game with.
-- @member number FromGameID The ID of the Game the User that sent the UserNotification has last played.
-- @member number FromPlatformID The ID of the Platform of the last played Game for the User that sent the UserNotification.

-----------------
-- Constructor --
-----------------

function lib.TogetherUserNotification.New()
	local self = {};
	setmetatable(self, lib.TogetherUserNotification);

	self.UserNotificationID				= 0;
	self.NotificationType				= "";
	self.Purpose						= "";
	self.Message						= "";
	self.OriginalGameInstanceID			= 0;
	self.GameInstanceID					= 0;
	self.AchievementID					= 0;
	self.ItemID							= 0;
	self.ItemCount						= 0;
	self.SocialType						= "";
	self.SocialID						= "";
	self.ChatRoomID						= 0;
	self.FromUserID						= 0;
	self.FromUsername					= "";
	self.Processed						= false;
	self.Accepted						= false;
	self.SecondsSinceCreated			= 0;
	self.FromUserLastActivityInSeconds	= 0;
	self.FromClientID					= 0;
	self.FromGameID						= 0;
	self.FromPlatformID					= 0;

	return self;
end

function lib.TogetherUserNotification:ProcessUserNotificationJson(userNotificationJson)
	self.UserNotificationID				= userNotificationJson.UserNotificationID;	
	self.NotificationType				= userNotificationJson.NotificationType;
	self.Purpose						= userNotificationJson.Purpose;
	self.Message						= userNotificationJson.Message;
	self.OriginalGameInstanceID			= userNotificationJson.OriginalGameInstanceID;
	self.GameInstanceID					= userNotificationJson.GameInstanceID;
	self.AchievementID					= userNotificationJson.AchievementID;
	self.ItemID							= userNotificationJson.ItemID;
	self.ItemCount             		 	= userNotificationJson.ItemCount;
	self.SocialType						= userNotificationJson.SocialType;
	self.SocialID						= userNotificationJson.SocialID;
	self.ChatRoomID						= userNotificationJson.ChatRoomID;
	self.FromUserID						= userNotificationJson.FromUserID;
	self.FromUsername					= userNotificationJson.FromUsername;
	self.Processed          			= userNotificationJson.Processed;
	self.Accepted						= userNotificationJson.Accepted;
	self.SecondsSinceCreated			= userNotificationJson.SecondsSinceCreated;
	self.FromUserLastActivityInSeconds	= userNotificationJson.FromUserLastActivityInSeconds;
	self.FromClientID					= userNotificationJson.FromClientID;
	self.FromGameID						= userNotificationJson.FromGameID;
	self.FromPlatformID					= userNotificationJson.FromPlatformID;
end

function lib.TogetherUserNotification:Dump()
	self:DumpEx("");
end

function lib.TogetherUserNotification:DumpEx(spacing)
	print(spacing .. "UserNotification:");
	print(spacing .. "   UserNotificationID             = " .. self.UserNotificationID);
	print(spacing .. "   NotificationType               = " .. self.NotificationType);
	print(spacing .. "   Purpose                        = " .. self.Purpose);
	print(spacing .. "   Message                        = " .. self.Message);
	print(spacing .. "   OriginalGameInstanceID         = " .. self.OriginalGameInstanceID);
	print(spacing .. "   GameInstanceID                 = " .. self.GameInstanceID);
	print(spacing .. "   AchievementID                  = " .. self.AchievementID);
	print(spacing .. "   ItemID                         = " .. self.ItemID);
	print(spacing .. "   ItemCount                      = " .. self.ItemCount);
	print(spacing .. "   SocialType                     = " .. self.SocialType);
	print(spacing .. "   SocialID                       = " .. self.SocialID);
	print(spacing .. "   ChatRoomID                     = " .. self.ChatRoomID);
	print(spacing .. "   FromUserID                     = " .. self.FromUserID);
	print(spacing .. "   FromUsername                   = " .. self.FromUsername);
	print(spacing .. "   Processed                      = " .. tostring(self.Processed));
	print(spacing .. "   Accepted                       = " .. tostring(self.Accepted));
	print(spacing .. "   SecondsSinceCreated			= " .. self.SecondsSinceCreated);
	print(spacing .. "   FromUserLastActivityInSeconds	= " .. self.FromUserLastActivityInSeconds);
	print(spacing .. "   FromClientID					= " .. self.FromClientID);
	print(spacing .. "   FromGameID						= " .. self.FromGameID);
	print(spacing .. "   FromPlatformID					= " .. self.FromPlatformID);
end


-- return TogetherUserNotification;

-------------------------------------------------------------------------------
-- UserNotificationManager.lua ------------------------------------------------
-------------------------------------------------------------------------------
lib.UserNotificationManager = {};
lib.UserNotificationManager.__index = lib.UserNotificationManager;

-- @class UserNotificationManager
-- The UserNotificationManager class contains a collection UserNotifications.
-- With this class, a developer will be able to Create, Delete, Retrieve All, and Process UserNotifications.
-- @member table UserNotifications Stores all the UserNotifications contained in the Manager.
	
function lib.UserNotificationManager.New()
	local self = {};
	setmetatable(self, lib.UserNotificationManager);

	-- Contains all the UserNotifications for the User.
	self.UserNotifications = {};

	return self;
end


-- @classmethod UserNotificationManager:Add()
-- Adds a UserNotification to the internally managed list without persistence.
-- @boldnote This method is deprecated
-- @param TogetherUserNotification userNotification Instance of a UserNotification to add internally
function lib.UserNotificationManager:Add(userNotification)
	table.insert(self.UserNotifications, userNotification);
end

-- @classmethod UserNotificationManager:FindByUserNotificationID()
-- Finds the UserNotification with the specified UserNotificationID if it exists, otherwise returns nil.
-- @param number userNotificationID The ID of the UserNotification to find
-- @return TogetherUserNotification
function lib.UserNotificationManager:FindByUserNotificationID(userNotificationID)
	local indexOfUserNotification = self:IndexOfByUserNotificationID(userNotificationID);
	if (indexOfUserNotification ~= -1) then
		return self:Get(indexOfUserNotification);
	end
	return nil;
end

-- @classmethod UserNotificationManager:GetCount()
-- Gets the number of UserNotifications currently managed internally.
-- @return number
function lib.UserNotificationManager:GetCount()
	return table.getn(self.UserNotifications);
end

-- @classmethod UserNotificationManager:Get()
-- Gets the UserNotification at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the UserNotification to find
-- @return TogetherUserNotification
function lib.UserNotificationManager:Get(index)
	return self.UserNotifications[index];
end

-- @classmethod UserNotificationManager:IndexOf()
-- Returns the index of the specified UserNotification if it exists, otherwise returns nil.
-- @param TogetherUserNotification userNotification Instance of the UserNotification to find the index of
-- @return number
function lib.UserNotificationManager:IndexOf(userNotification)
	return table.indexOf(self.UserNotifications, userNotification);
end

-- @classmethod UserNotificationManager:IndexOfByUserNotificationID()
-- Returns the index of the UserNotification with the specified UserNotificationID if it exists, otherwise returns -1.
-- @param number userNotificationID The ID of the UserNotification to find the index of
-- @return number
function lib.UserNotificationManager:IndexOfByUserNotificationID(userNotificationID)
	local userNotificationCount = self:GetCount();

   	for i=1, userNotificationCount do
    	if (self.UserNotifications[i].UserNotificationID == userNotificationID) then
			return i;
		end
    end

    return -1;
end

-- @classmethod UserNotificationManager:Remove()
-- Removes a UserNotification from the internally managed list. This does not delete the notification from the user's account persistently.
-- @boldnote This method is deprecated
-- @param number index The index of the UserNotification to remove internally
function lib.UserNotificationManager:Remove(index)
	table.remove(self.UserNotifications, index);
end

function lib.UserNotificationManager:Dump()
	print("UserNotifications:");

	-- Dump all the UserNotifications as well.
	local userNotificationCount = table.getn(self.UserNotifications);
	print("   UserNotificationCount   = " .. userNotificationCount);

    for i=1, userNotificationCount do
    	self.UserNotifications[i]:Dump();
    end
end

function lib.UserNotificationManager:ProcessUserNotificationsJson(userNotificationsJson)
	self.UserNotifications = {};

	-- Parse out all the UserNotifications.
	for name, value in pairs (userNotificationsJson) do
    	local userNotification = lib.TogetherUserNotification:New();

		userNotification:ProcessUserNotificationJson(value);

		table.insert(self.UserNotifications, userNotification);
    end
end




-------------------------------------------------------------------------------
--  Network methods.
-------------------------------------------------------------------------------

-- @classmessage UserNotificationManager:Create()
-- Creates a new UserNotification. Upon success, this will automatically update the internal list.
-- @param number destUserID The ID of the User to send the UserNotification to.
-- @param string type The type of UserNotification being created.
-- @param string message The message of the UserNotification.
-- @param number originalGameInstanceID The original GameInstanceID played before creating a rematch.  Pass in 0 if this UserNotification does not pertain to a rematch.
-- @param number gameInstanceID The ID of the GameInstance assigned to the UserNotification.
-- @param number achievementID The ID of the Achievement assigned to the UserNotification.
-- @param number chatRoomID The ID of the ChatRoom assigned to the UserNotification.
-- @param number itemID The ID of the Item assigned to the UserNotification.
-- @param number itemCount The number of Items assigned to the UserNotification.
-- @param string socialType The type of social network which caused the UserNotification to be created. Pass in "FB" for Facebook.  Pass in "" if not specified.
-- @param string socialID The ID of the user on a social network.  Pass in the user's FacebookID for Facebook. Pass in "0" if not specified.
-- @param function callbackFunc The function to call upon completion.
function lib.UserNotificationManager:Create(destUserID, type, message, originalGameInstanceID, gameInstanceID, achievementID, chatRoomID, itemID, itemCount, socialType, socialID, callbackFunc)
	lib.togetherPrint("UserNotificationManager:Create()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Create a new UserNotification.
    	g_CurrentUserNotification = lib.TogetherUserNotification:New();

		-- Process the response data.
    	g_CurrentUserNotification:ProcessUserNotificationJson(callback.ResponseObj.UserNotification);
    	self:Add(g_CurrentUserNotification);
		callback.NewObject = g_CurrentUserNotification;

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end

    	
    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&DestUserID=" .. destUserID ..
    	"&Type=" .. type ..
    	"&Message=" .. message ..
		"&OriginalGameInstanceID=" .. originalGameInstanceID ..
		"&GameInstanceID=" .. gameInstanceID ..
		"&AchievementID=" .. achievementID ..
		"&ChatRoomID=" .. chatRoomID ..
		"&ItemID=" .. itemID ..
		"&ItemCount=" .. itemCount ..
		"&SocialType=" .. socialType ..
		"&SocialID=" .. socialID;

	lib.sendNetworkMessage("users", "createusernotification", parameters, networkListener);	
end

-- @classmessage UserNotificationManager:Delete()
-- Deletes a UserNotification. Upon success, this will automatically update the internal list.
-- @param number userNotificationID The ID of the UserNotification to delete
-- @param function callbackFunc The function to call upon completion.
function lib.UserNotificationManager:Delete(userNotificationID, callbackFunc)
	lib.togetherPrint("UserNotificationManager:Delete()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		local indexOfUserNotification = self:IndexOfByUserNotificationID(userNotificationID);
		if (indexOfUserNotification ~= -1) then
			self:Remove(indexOfUserNotification);
		end

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end

    	
    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&UserNotificationID=" .. userNotificationID;
	
	lib.sendNetworkMessage("users", "deleteusernotification", parameters, networkListener);	
end

-- @classmessage UserNotificationManager:GetAll()
-- Gets all UserNotifications for the User. Upon success, this will automatically update the internal list.
-- @param boolean processed A boolean indicating whether processed or unprocessed UserNotifications should be retrieved
-- @param function callbackFunc The function to call upon completion.
function lib.UserNotificationManager:GetAll(processed, callbackFunc)
	lib.togetherPrint("UserNotificationManager:GetAll()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


    	-- Process the response data.
		self:ProcessUserNotificationsJson(callback.ResponseObj.UserNotifications);

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end

  	
    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&Processed=" .. tostring(processed);

	lib.sendNetworkMessage("users", "getallusernotifications", parameters, networkListener);	
end

-- @classmessage UserNotificationManager:Process()
-- Processes a UserNotification. Upon success, this will automatically update the internal list.
-- @param number userNotificationID The ID of the UserNotification that is to be processed.
-- @param boolean accepted A boolean indicated whether the UserNotfication was accepted. Users must accept UserNotifications in order to create/join a rematch GameInstance or be awarded Achievements or Items.
-- @param function callbackFunc The function to call upon completion.
function lib.UserNotificationManager:Process(userNotificationID, accepted, callbackFunc)
	lib.togetherPrint("UserNotificationManager:Process(" .. userNotificationID .. ", " .. tostring(accepted) .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


    	local indexOfUserNotification = self:IndexOfByUserNotificationID(userNotificationID);
		if (indexOfUserNotification ~= -1) then
			self:Remove(indexOfUserNotification);
		end

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&UserNotificationID=" .. userNotificationID ..
    	"&Accept=" .. tostring(accepted);

	lib.sendNetworkMessage("users", "processusernotification", parameters, networkListener);	
end


--return UserNotificationManager;

-- ----------------------------------------------------------------------------
-- AchievementManager.lua ---------------------------------------------
-- ----------------------------------------------------------------------------
lib.AchievementManager = {};
lib.AchievementManager.__index = lib.AchievementManager;

-- @class AchievementManager
-- The AchievementManager is used for fetching and finding achievements that exist for the current game.
-- @member table Achievements Stores all the Achievements contained in the Manager.

function lib.AchievementManager.New()
	local self = {};
	setmetatable(self, lib.AchievementManager);
	
	-- Contains all the Achievements.
	self.Achievements = {};
    
	return self;
end

-- @classmethod AchievementManager:Add()
-- Adds an Achievement to the manager internally without persistence.
-- @boldnote This method is deprecated
-- @param TogetherAchievement achievement Instance of an Achievement to add internally
function lib.AchievementManager:Add(achievement)
	table.insert(self.Achievements, achievement);
end

-- @classmethod AchievementManager:FindByAchievementID()
-- Finds the Achievement with the specified AchievementID if it exists, otherwise returns nil.
-- @param number achievementID The ID of the Achievement to find
-- @return TogetherAchievement
function lib.AchievementManager:FindByAchievementID(achievementID)
	local indexOfAchievement = self:IndexOfByAchievementID(achievementID);
	if (indexOfAchievement ~= -1) then
		return self:Get(indexOfAchievement);
	end
	return nil;
end

-- @classmethod AchievementManager:GetCount()
-- Gets the number of Achievements currently managed internally.
-- @return number
function lib.AchievementManager:GetCount()
	return table.getn(self.Achievements);
end

-- @classmethod AchievementManager:Get()
-- Gets the Achievement at the specified index if it exists internally, otherwise returns nil.
-- @param number index The index of the Achievement to retrieve internally.
-- @return TogetherAchievement
function lib.AchievementManager:Get(index)
	return self.Achievements[index];
end

-- @classmethod AchievementManager:IndexOf()
-- Returns the index of the specified Achievement instance if it exists internally, otherwise returns nil.
-- @param TogetherAchievement achievement Instance of the Achievement to find the index of
-- @return number
function lib.AchievementManager:IndexOf(achievement)
	return table.indexOf(self.Achievements, achievement);
end

-- @classmethod AchievementManager:IndexOfByAchievementID()
-- Returns the index of the Achievement with the corresponding AchievementID if it exists internally, otherwise returns -1.
-- @param number achievementID The ID of the Achievement to find the index of
-- @return number
function lib.AchievementManager:IndexOfByAchievementID(achievementID)
	local achievementCount = self:GetCount();

   	for i=1, achievementCount do
    	if (self.Achievements[i].AchievementID == achievementID) then
			return i;
		end
    end

    return -1;
end

-- @classmethod AchievementManager:Remove()
-- Removes an Achievement from the internally managed list. This does not delete the Achievement from the game persistently.
-- @boldnote This method is deprecated
-- @param number index The index of the Achievement to be removed internally
function lib.AchievementManager:Remove(index)
	if (index ~= -1) then
		table.remove(self.Achievements, index);
	end
end

function lib.AchievementManager:Dump()
	print("AchievementManager:");

	-- Dump all the Achievements as well.
	local achievementCount = self:GetCount();
	print("   AchievementCount   = " .. achievementCount);

    for i=1, achievementCount do
    	self.Achievements[i]:Dump();
    end
end

function lib.AchievementManager:ProcessAchievementsJson(achievementsJson)
	lib.togetherPrint("AchievementManager:ProcessAchievementsJson()");

	self.Achievements = {};

	-- Parse out all the Achievements.
	for name, value in pairs (achievementsJson) do
    	local achievement = lib.TogetherAchievement:New();
    	achievement:ProcessAchievementJson(value);
		table.insert(self.Achievements, achievement);
    end
    	
    lib.togetherPrint("   Processed " .. table.getn(self.Achievements) .. " achievements.");
end




--------------------------------------------------------------------------------
--  Network methods.
--------------------------------------------------------------------------------

-- @classmessage AchievementManager:GetAll()
-- Requests a list of the Achievements configured for the current game.
-- @param function callbackFunc The function to call upon completion.
function lib.AchievementManager:GetAll(callbackFunc)
	lib.togetherPrint("AchievementManager:GetAll()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


   		-- Now parse the json data.
		self:ProcessAchievementsJson(callback.ResponseObj.Achievements);

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


   	local parameters = "SessionToken=" .. g_Together:GetSessionToken();

	lib.sendNetworkMessage("users", "getallachievements", parameters, networkListener);
end

--return AchievementManager;

-------------------------------------------------------------------------------
-- ItemManager.lua ------------------------------------------------------------
-------------------------------------------------------------------------------
lib.ItemManager = {};
lib.ItemManager.__index = lib.ItemManager;

-- @class ItemManager
-- The ItemManager is used for fetching and finding items that exist for the current game.
-- @member table Items Stores all the Items contained in the Manager.

function lib.ItemManager.New()
	local self = {};
	setmetatable(self, lib.ItemManager);

	-- Contains all the Items.
	self.Items = {};

	return self;
end


-- @classmethod ItemManager:Add()
-- Adds an Item to the manager internally without persistence.
-- @boldnote This method is deprecated
-- @param TogetherItem item Instance of an Item to add internally
function lib.ItemManager:Add(item)
	table.insert(self.Items, item);
end

-- @classmethod ItemManager:FindByItemID()
-- Finds the Item with the specified ItemID if it exists, otherwise returns nil.
-- @param number itemID The ID of the Item to find
-- @return TogetherItem
function lib.ItemManager:FindByItemID(itemID)
	local indexOfItem = self:IndexOfByItemID(itemID);
	if (indexOfItem ~= -1) then
		return self:Get(indexOfItem);
	end
	return nil;
end

-- @classmethod ItemManager:GetCount()
-- Gets the number of Items currently managed internally.
-- @return number
function lib.ItemManager:GetCount()
	return table.getn(self.Items);
end

-- @classmethod ItemManager:Get()
-- Gets the Item at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the Item to find
-- @return TogetherItem
function lib.ItemManager:Get(index)
	return self.Items[index];
end

-- @classmethod ItemManager:IndexOf()
-- Returns the index of the specified Item if it exists, otherwise returns nil.
-- @param TogetherItem item Instance of the Item to find the index of
-- @return number
function lib.ItemManager:IndexOf(item)
	return table.indexOf(self.Items, item);
end

-- @classmethod ItemManager:IndexOfByItemID()
-- Returns the index of the Item with the specified ItemID if it exists, otherwise returns -1.
-- @param number itemID The ID of the Item to find the index of
-- @return number
function lib.ItemManager:IndexOfByItemID(itemID)
	local itemCount = self:GetCount();

   	for i=1, itemCount do
    		if (self.Items[i].ItemID == itemID) then
			return i;
		end
    end

    return -1;
end

-- @classmethod ItemManager:Remove()
-- Removes an Item from the internally managed list. This does not delete the Item from the game persistently.
-- @boldnote This method is deprecated
-- @param number index The index of the Item to be removed
function lib.ItemManager:Remove(index)
	if (index ~= -1)	then
		table.remove(self.Items, index);
	end
end

function lib.ItemManager:Dump()
	print("Items:");

	-- Dump all the Items as well.
	local itemCount = table.getn(self.Items);
	print("   ItemCount   = " .. itemCount);

    for i=1, itemCount do
    		self.Items[i]:DumpEx("   ");
    end
end

function lib.ItemManager:ProcessItemsJson(itemsJson)
	lib.togetherPrint("ItemManager:ProcessItemsJson()");

	self.Items = {};

	-- Parse out all the Items.
	for name, value in pairs (itemsJson) do
    	local item = lib.TogetherItem:New();
		item:ProcessItemJson(value);
		table.insert(self.Items, item);
    end

    lib.togetherPrint("   Processed " .. table.getn(self.Items) .. " items.");
end



--------------------------------------------------------------------------------
--  Network methods.
--------------------------------------------------------------------------------

-- @classmessage ItemManager:GetAll()
-- Gets all Items configured in the Game. Upon success, this will automatically update the internal list.
-- @param function callbackFunc The function to call upon completion.
function lib.ItemManager:GetAll(callbackFunc)
	lib.togetherPrint("ItemManager:GetAll()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


    	-- Now parse the json data.
		self:ProcessItemsJson(callback.ResponseObj.Items);

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken();

	lib.sendNetworkMessage("users", "getallitems", parameters, networkListener);	
end


--return ItemManager;

-------------------------------------------------------------------------------
-- ChatRoomUser.lua -----------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherChatRoomUser = {};
lib.TogetherChatRoomUser.__index = lib.TogetherChatRoomUser;


-- @class TogetherChatRoomUser
-- The ChatRoomUser class represents a User that is a member of a ChatRoom.
-- @member number ChatRoomUserID The ID of the ChatRoomUser.
-- @member number UserID The ID of the User associated with the ChatRoomUser.
-- @member string Username The username assigned to the User.
-- @member string Name The Name assigned to the User.  This will be the same as Username unless the User had registered.
-- @member string SocialID The ID of the User on some social network.  For Facebook, this will be their FacebookID.
-- @member string SocialType The type of social network last used to register the User.  For Facebook, this will be "FB".
-- @member number SecondsSinceJoin The number of seconds since the user has joined the ChatRoom.
-- @member number LastActivityInSeconds The number of seconds since the user has been active in a Together game.
-- @member number ClientID The ID of the Client the User has last played a Game with.
-- @member number GameID The ID of the Game the User has last played.
-- @member number PlatformID The ID of the Platform of the last played Game for the User. 


-----------------
-- Constructor --
-----------------

function lib.TogetherChatRoomUser.New()
	local self = {};
	setmetatable(self, lib.TogetherChatRoomUser);
	
	self.ChatRoomUserID				= 0;
	self.UserID						= 0;
	self.Username					= "";
    self.Name						= "";
    self.SocialType					= "";
    self.SocialID					= "";
	self.SecondsSinceJoin			= 0;
	self.LastActivityInSeconds		= 0;
	self.ClientID					= 0;
	self.GameID						= 0;
	self.PlatformID					= 0;

	return self;
end

function lib.TogetherChatRoomUser:ProcessChatRoomUserJson(chatRoomUserJson)
	self.ChatRoomUserID 			= chatRoomUserJson.ChatRoomUserID;
	self.UserID						= chatRoomUserJson.UserID;
	self.Username					= chatRoomUserJson.Username;
    self.SocialType					= chatRoomUserJson.SocialType;
    self.SocialID					= chatRoomUserJson.SocialID;
	self.SecondsSinceJoin			= chatRoomUserJson.SecondsSinceJoin;
	self.LastActivityInSeconds		= chatRoomUserJson.LastActivityInSeconds;
	self.ClientID					= chatRoomUserJson.ClientID;
	self.GameID						= chatRoomUserJson.GameID;
	self.PlatformID					= chatRoomUserJson.PlatformID;
end

function lib.TogetherChatRoomUser:Dump()
	self:DumpEx("");
end

function lib.TogetherChatRoomUser:DumpEx(spacing)
	print(spacing .. "ChatRoomUser:")
	print(spacing .. "   ChatRoomUserID             = " .. self.ChatRoomUserID);
	print(spacing .. "   UserID                     = " .. self.UserID);
	print(spacing .. "   Username                   = " .. self.Username);
	print(spacing .. "   Name                       = " .. self.Name);
    print(spacing .. "   SocialType                 = " .. self.SocialType);
    print(spacing .. "   SocialID                   = " .. self.SocialID);
	print(spacing .. "   SecondsSinceJoin           = " .. self.SecondsSinceJoin);
	print(spacing .. "   LastActivityInSeconds      = " .. self.LastActivityInSeconds);
	print(spacing .. "   ClientID                   = " .. self.ClientID);
	print(spacing .. "   GameID                     = " .. self.GameID);
	print(spacing .. "   PlatformID                 = " .. self.PlatformID);
end

function lib.TogetherChatRoomUser:PostProcessUsername()

	local togetherFriend = g_Together:FindTogetherFriendByUserID(self.UserID);
	local externalFriend = g_Together:FindFacebookFriendBySocialID(self.SocialID);
		
	self.Name = self.Username;

	-- Is this GameInstanceUser my User.
	if (self.UserID == g_Together:GetUserID()) then
		if (g_Together:GetNameOfUser() ~= "") then
			self.Name = g_Together:GetNameOfUser();
		else
			self.Name = g_Together:GetUsername();
	end

	-- Is this GameInstanceUser at least a TogetherUser.
	elseif (self.UserID ~= 0) then
		if (togetherFriend ~= nil) then
			self.Name = togetherFriend.Name;
		elseif (externalFriend ~= nil) then
			self.Name = externalFriend.Name;
		end
	
	elseif (tostring(self.SocialID) ~= "") then
		if (externalFriend ~= nil) then
			self.Name = externalFriend.Name;
		else
			self.Name = "######";
		end
	end
end


-- return TogetherChatRoomUser;

-------------------------------------------------------------------------------
-- ChatMessage.lua ------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherChatMessage = {};
lib.TogetherChatMessage.__index = lib.TogetherChatMessage;

    
-- @class TogetherChatMessage
-- The ChatMessage class represents a single message in a chat room.
-- @member number ChatMessageID The ID of the ChatMessage.
-- @member number ParentChatMessageID The ID of the parent ChatMessage.
-- @member number UserID The ID of the User associated with the ChatMessage.
-- @member string Username The username assigned to the User.
-- @member string Name The Name assigned to the User.  This will be the same as Username unless the User had registered.
-- @member string Message The textual message for the ChatMessage.
-- @member boolean Read A boolean indicating whether the ChatMessage has been read.
-- @member number SecondsSinceCreated The number of seconds since the ChatMessage was created.
-- @member number SecondsLinceLastModified The number of seconds since the ChatMessage has been last modified.
-- @member number FromUserLastActivityInSeconds The number of seconds since the User who submitted the ChatMessage has been active in a Together game.
-- @member number FromClientID The ID of the Client the User has last played a Game with.
-- @member number FromGameID The ID of the Game the User has last played.
-- @member number FromPlatformID The ID of the Platform of the last played Game for the User. 


-----------------
-- Constructor --
-----------------

function lib.TogetherChatMessage.New()
	local self = {};
	setmetatable(self, lib.TogetherChatMessage);
	
	self.ChatMessageID					= 0;
	self.ParentChatMessageID			= 0;
	self.UserID							= 0;
	self.Username						= "";
	self.Name							= "";
	self.Message						= "";
	self.Read							= false;
	self.SecondsSinceCreated			= 0;
	self.SecondsSinceLastModified		= 0;
	self.FromUserLastActivityInSeconds	= 0;
	self.FromClientID					= 0;
	self.FromGameID						= 0;
	self.FromPlatformID					= 0;

	return self;
end

function lib.TogetherChatMessage:ProcessChatMessageJson(chatMessageJson)
	self.ChatMessageID 					= tonumber(chatMessageJson.ChatMessageID);
	self.ParentChatMessageID			= tonumber(chatMessageJson.ParentChatMessageID);
	self.UserID							= tonumber(chatMessageJson.UserID);
	self.Username						= chatMessageJson.Username;
	self.Message						= chatMessageJson.Message;
	self.Read							= chatMessageJson.Read;
	self.SecondsSinceCreated			= chatMessageJson.SecondsSinceCreated;
	self.SecondsSinceLastModified		= chatMessageJson.SecondsSinceLastModified;
	self.FromUserLastActivityInSeconds	= chatMessageJson.FromUserLastActivityInSeconds;
	self.FromClientID					= chatMessageJson.FromClientID;
	self.FromGameID						= chatMessageJson.FromGameID;
	self.FromPlatformID					= chatMessageJson.FromPlatformID;
end

function lib.TogetherChatMessage:Dump()
	self:DumpEx("");
end

function lib.TogetherChatMessage:DumpEx(spacing)
	print(spacing .. "ChatMessage:");
	print(spacing .. "   ChatMessageID                  = " .. self.ChatMessageID);
	print(spacing .. "   ParentChatMessageID            = " .. self.ParentChatMessageID);
	print(spacing .. "   UserID                         = " .. self.UserID);
	print(spacing .. "   Username                       = " .. self.Username);
	print(spacing .. "   Name                           = " .. self.Name);
	print(spacing .. "   Message                        = " .. self.Message);
	print(spacing .. "   Read                           = " .. tostring(self.Read));
	print(spacing .. "   SecondsSinceCreated            = " .. self.SecondsSinceCreated);
	print(spacing .. "   SecondsSinceLastModified       = " .. self.SecondsSinceLastModified);
	print(spacing .. "   FromUserLastActivityInSeconds  = " .. self.FromUserLastActivityInSeconds);
	print(spacing .. "   FromClientID                   = " .. self.FromClientID);
	print(spacing .. "   FromGameID                     = " .. self.FromGameID);
	print(spacing .. "   FromPlatformID                 = " .. self.FromPlatformID);
end

function lib.TogetherChatMessage:PostProcessUsername()
	local togetherFriend = g_Together:FindTogetherFriendByUserID(self.UserID);
	local externalFriend = g_Together:FindFacebookFriendBySocialID(self.SocialID);
		
	self.Name = self.Username;

	-- Is this GameInstanceUser my User.
	if (self.UserID == g_Together:GetUserID()) then
		if (g_Together:GetNameOfUser() ~= "") then
			self.Name = g_Together:GetNameOfUser();
		else
			self.Name = g_Together:GetUsername();
	end

	-- Is this GameInstanceUser at least a TogetherUser.
	elseif (self.UserID ~= 0) then
		if (togetherFriend ~= nil) then
			self.Name = togetherFriend.Name;
		elseif (externalFriend ~= nil) then
			self.Name = externalFriend.Name;
		end
	
	elseif (tostring(self.SocialID) ~= "") then
		if (externalFriend ~= nil) then
			self.Name = externalFriend.Name;
		else
			self.Name = "######";
		end
	end
end


-- return TogetherChatMessage;

-------------------------------------------------------------------------------
-- ChatRoom.lua ---------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherChatRoom = {};
lib.TogetherChatRoom.__index = lib.TogetherChatRoom;

-- @class TogetherChatRoom
-- The ChatRoom class represents a ChatRoom and manages a list internally of ChatRoomUsers and ChatMessages
-- @member number ChatRoomID The ID of the ChatRoom.
-- @member number RoomID The ID of the Room the ChatRoom is in.
-- @member number CreatorUserID The ID of the User that created the ChatRoom.
-- @member string CreatorUsername The username of the User that created the ChatRoom.
-- @member number SecondsSinceCreated The number of seconds since the ChatRoom was created.
-- @member number SecondsSinceModified The number of seconds since the ChatRoom was last modified.
-- @member string Name The name of the ChatRoom.
-- @member string Description A textual description for the ChatRoom.
-- @member PropertyCollection Properties A property collection containing all custom properties for the ChatRoom.
-- @member table ChatRoomUsers Contains all the ChatRoomUsers that are in the ChatRoom.
-- @member table ChatMessages Contains all the ChatMessages belonging to the ChatRoom.


-----------------
-- Constructor --
-----------------

function lib.TogetherChatRoom.New()
	local self = {};
	setmetatable(self, lib.TogetherChatRoom);

	self.ChatRoomID					= 0;
	self.RoomID						= 0;
	self.CreatorUserID				= 0;
	self.CreatorUsername			= "";
	self.SecondsSinceCreated		= 0;
	self.SecondsSinceModified		= 0;
	self.Name						= "";
	self.Description				= "";
	self.Properties					= lib.PropertyCollection:New();

	self.ChatRoomUsers 				= {};
	self.ChatMessages 				= {};

	return self;
end


-- @classmethod TogetherChatRoom:AddChatRoomUser()
-- Adds a ChatRoomUser to the internally managed list without persistence.
-- @boldnote This method is deprecated
-- @param TogetherChatRoomUser chatRoomUser Instance of the ChatRoomUser to add internally
function lib.TogetherChatRoom:AddChatRoomUser(chatRoomUser)
	table.insert(self.ChatRoomUsers, chatRoomUser);
end

-- @classmethod TogetherChatRoom:FindChatRoomUserByUserID()
-- Finds the ChatRoomUser with the specified UserID if it exists, otherwise returns nil.
-- @param number userID The ID of the User to find
-- @return TogetherChatRoomUser
function lib.TogetherChatRoom:FindChatRoomUserByUserID(userID)
	local indexOfChatRoomUser = self:IndexOfChatRoomUserByUserID(userID);
	if (indexOfChatRoomUser ~= -1) then
		return self:GetChatRoomUser(indexOfChatRoomUser);
	end
	return nil;
end

-- @classmethod TogetherChatRoom:FindChatRoomUserByChatRoomUserID()
-- Finds the ChatRoomUser with the specified ChatRoomUserID if it exists, otherwise returns nil.
-- @param number chatRoomUserID The ID of the ChatRoomUser to find
-- @return TogetherChatRoomUser
function lib.TogetherChatRoom:FindChatRoomUserByChatRoomUserID(chatRoomUserID)
	local indexOfChatRoomUser = self:IndexOfChatRoomUserByChatRoomUserID(chatRoomUserID);
	if (indexOfChatRoomUser ~= -1) then
		return self:GetChatRoomUser(indexOfChatRoomUser);
	end
	return nil;
end

-- @classmethod TogetherChatRoom:GetChatRoomUserCount()
-- Gets the number of ChatRoomUsers currently managed internally.
-- @return number
function lib.TogetherChatRoom:GetChatRoomUserCount()
	return table.getn(self.ChatRoomUsers);
end

-- @classmethod TogetherChatRoom:GetChatRoomUser()
-- Gets the ChatRoomUser at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the ChatRoomUser to retrieve internally
-- @return TogetherChatRoomUser
function lib.TogetherChatRoom:GetChatRoomUser(index)
	return self.ChatRoomUsers[index];
end

-- @classmethod TogetherChatRoom:IndexOfChatRoomUser()
-- Returns the index of the specified ChatRoomUser if it exists internally, otherwise returns nil.
-- @param TogetherChatRoomUser chatRoomUser Instance of the chatRoomUser to find the index of
-- @return number
function lib.TogetherChatRoom:IndexOfChatRoomUser(chatRoomUser)
	return self.ChatRoomUsers.indexOf(chatRoomUser);
end

-- @classmethod TogetherChatRoom:IndexOfChatRoomUserByUserID()
-- Returns the index of the ChatRoomUser with the specified UserID if it exists, otherwise returns -1.
-- @param number userID The ID of the User to find the index of
-- @return number
function lib.TogetherChatRoom:IndexOfChatRoomUserByUserID(userID)
	local chatRoomUserCount = self:GetChatRoomUserCount();
   	for i=1, chatRoomUserCount do
    	if (self.ChatRoomUsers[i].UserID == userID) then
			return i;
		end
    end
    return -1;
end

-- @classmethod TogetherChatRoom:IndexOfChatRoomUserByChatRoomUserID()
-- Returns the index of the ChatRoomUser with the specified ChatRoomUserID if it exists, otherwise returns -1.
-- @param number chatRoomUserID The ID of the ChatRoomUser to find the index of
-- @return number
function lib.TogetherChatRoom:IndexOfChatRoomUserByChatRoomUserID(chatRoomUserID)
	local chatRoomUserCount = self:GetChatRoomUserCount();
   	for i=1, chatRoomUserCount do
    	if (self.ChatRoomUsers[i].ChatRoomUserID == chatRoomUserID) then
			return i;
		end
    end
    return -1;
end

-- @classmethod TogetherChatRoom:RemoveChatRoomUser()
-- Removes a ChatRoomUser from the internal list without persistence.
-- @boldnote This method is deprecated
-- @param number index The index of the ChatRoomUser to remove
function lib.TogetherChatRoom:RemoveChatRoomUser(index)
	if (index ~= -1) then
		table.remove(self.ChatRoomUsers, index);
	end
end



-- @classmethod TogetherChatRoom:AddChatMessage()
-- Adds a ChatMessage to the internal list without persistence.
-- @boldnote This method is deprecated
-- @param TogetherChatMessage chatMessage Instance of a ChatMessage to add internally
function lib.TogetherChatRoom:AddChatMessage(chatMessage)
	table.insert(self.ChatMessages, chatMessage);
end

-- @classmethod TogetherChatRoom:FindChatMessageByChatMessageID()
-- Returns the ChatMessage with the specified ChatMessageID if it exists internally, otherwise returns nil.
-- @param number chatMessageID The ID of the ChatMessage to find
-- @return TogetherChatMessage
function lib.TogetherChatRoom:FindChatMessageByChatMessageID(chatMessageID)
	local indexOfChatMessage = self:IndexOfChatMessageByChatMessageID(chatMessageID);
	if (indexOfChatMessage ~= -1) then
		return self:GetChatMessage(indexOfChatMessage);
	end
	return nil;
end

-- @classmethod TogetherChatRoom:GetChatMessageCount()
-- Gets the number of ChatMessages currently managed in the internal list.
-- @return number
function lib.TogetherChatRoom:GetChatMessageCount()
	return table.getn(self.ChatMessages);
end

-- @classmethod TogetherChatRoom:GetChatMessage()
-- Gets the ChatMessage at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the ChatMessage to find
-- @return TogetherChatMessage
function lib.TogetherChatRoom:GetChatMessage(index)
	return self.ChatMessages[index];
end

-- @classmethod TogetherChatRoom:IndexOfChatMessage()
-- Returns the index of the specified ChatMessage if it exists, otherwise returns nil.
-- @param TogetherChatMessage chatMessage Instance of the ChatMessage to retrieve the index of
-- @return number
function lib.TogetherChatRoom:IndexOfChatMessage(chatMessage)
	return self.ChatMessages.indexOf(chatMessage);
end

-- @classmethod TogetherChatRoom:IndexOfChatMessageByChatMessageID()
-- Returns the index of the ChatMessage with the specified ChatMessageID if it exists, otherwise returns -1.
-- @param number chatMessageID The ID of the ChatMessage to find the index of
-- @return number
function lib.TogetherChatRoom:IndexOfChatMessageByChatMessageID(chatMessageID)
	local chatMessageCount = self:GetChatMessageCount();

   	for i=1, chatMessageCount do
    	if (self.ChatMessages[i].ChatMessageID == chatMessageID) then
			return i;
		end
    end

    return -1;
end

-- @classmethod TogetherChatRoom:RemoveChatMessage()
-- Removes a ChatMessage from the internal list without persistence.
-- @boldnote This method is deprecated
-- @param number index The index of the ChatMessage to remove
function lib.TogetherChatRoom:RemoveChatMessage(index)
	if (index ~= -1) then
		table.remove(self.ChatMessages, index);
	end
end

function lib.TogetherChatRoom:Dump()
	self:DumpEx("");
end

function lib.TogetherChatRoom:DumpEx(spacing)
	print(spacing .. "ChatRoom:");
	print(spacing .. "   ChatRoomID             = " .. self.ChatRoomID);
	print(spacing .. "   RoomID                 = " .. self.RoomID);
	print(spacing .. "   CreatorUserID          = " .. self.CreatorUserID);
	print(spacing .. "   CreatorUsername        = " .. self.CreatorUsername);
	print(spacing .. "   SecondsSinceCreated    = " .. self.SecondsSinceCreated);
	print(spacing .. "   SecondsSinceModified   = " .. self.SecondsSinceModified);
	print(spacing .. "   Name                   = " .. self.Name);
	print(spacing .. "   Description            = " .. self.Description);

	self.Properties:DumpEx(spacing .. "   ");

	-- Dump all the ChatRoomUsers.
	local chatRoomUserCount = table.getn(self.ChatRoomUsers);
	print(spacing .. "   ChatRoomUserCount   = " .. chatRoomUserCount);

    for i=1, chatRoomUserCount do
    	self.ChatRoomUsers[i]:DumpEx(spacing .. "   ");
    end

	-- Dump all the ChatMessages.
	local chatMessageCount = table.getn(self.ChatMessages);
	print(spacing .. "   ChatMessageCount   = " .. chatMessageCount);

    for i=1, chatMessageCount do
    	self.ChatMessages[i]:DumpEx(spacing .. "   ");
    end    
end

function lib.TogetherChatRoom:ProcessChatRoomJson(chatRoomJson)
	self.ChatRoomID 			= chatRoomJson.ChatRoomID;
	self.RoomID					= chatRoomJson.RoomID;
	self.CreatorUserID			= chatRoomJson.CreatorUserID;
	self.CreatorUsername		= chatRoomJson.CreatorUsername;
	self.SecondsSinceCreated    = chatRoomJson.SecondsSinceCreated;
	self.SecondsSinceModified   = chatRoomJson.SecondsSinceModified;
	self.Name					= chatRoomJson.Name;
	self.Description			= chatRoomJson.Description;

	if (chatRoomJson["Properties"] ~= nil) then
		self.Properties:ProcessNodeJson(chatRoomJson.Properties);
	end
end

function lib.TogetherChatRoom:ProcessChatRoomUsersJson(chatRoomUsersJson)
	self.ChatRoomUsers = {};
	for name, value in pairs (chatRoomUsersJson) do
    	local chatRoomUser = lib.TogetherChatRoomUser:New();
		chatRoomUser:ProcessChatRoomUserJson(value);
		table.insert(self.ChatRoomUsers, chatRoomUser);
    end
end

function lib.TogetherChatRoom:ProcessChatMessagesJson(chatMessagesJson)
	self.ChatMessages = {};
	for name, value in pairs (chatMessagesJson) do
    	local chatMessage = lib.TogetherChatMessage:New();
		chatMessage:ProcessChatMessageJson(value);
		table.insert(self.ChatMessages, chatMessage);
    end
end

function lib.TogetherChatRoom:PostProcessUsernames()
	local chatRoomUserCount = self:GetChatRoomUserCount();
	for i=1, chatRoomUserCount do
    	self.ChatRoomUsers[i]:PostProcessUsername();
    end

	local chatMessageCount = self:GetChatMessageCount();
	for i=1, chatMessageCount do
    	self.ChatMessages[i]:PostProcessUsername();
    end
end

 


--------------------------------------------------------------------------------
--  Network methods.
--------------------------------------------------------------------------------

-- @classmessage TogetherChatRoom:GetDetails()
-- Gets the details on a ChatRoom.
-- @param number chatRoomID The ID of the ChatRoom to get details on.
-- @param number startWithChatMessageID ID of the ChatMessage to start with when the server retrieves chat messages.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherChatRoom:GetDetails(chatRoomID, startWithChatMessageID, callbackFunc)
	lib.togetherPrint("TogetherChatRoom:GetDetails(" .. chatRoomID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   		   	if (callback.Status == "1" and callback.Description == "No Change") then
   				callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   			else
   				callback:ExecuteCallbackFunc(callbackFunc);
   			end
   			return;
   		end

    		
		self:ProcessChatRoomJson(callback.ResponseObj.ChatRoom);
		self:ProcessChatRoomUsersJson(callback.ResponseObj.ChatRoomUsers);
		self:ProcessChatMessagesJson(callback.ResponseObj.ChatMessages);
		self:PostProcessUsernames();
		
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&ChatRoomID=" .. chatRoomID ..
    	"&SecondsSinceModified=" .. self.SecondsSinceModified ..
    	"&StartWithChatMessageID=" .. startWithChatMessageID;

	lib.sendNetworkMessage("chatrooms", "getchatroomdetails", parameters, networkListener);
end

-- @classmessage TogetherChatRoom:Join()
-- Joins the current session and user to this ChatRoom. Upon success, this will automatically update the internal list.
-- @boldnote Be sure to set the class's ChatRoomID member to the ID of the ChatRoom you wish to join.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherChatRoom:Join(callbackFunc)
	lib.togetherPrint("TogetherChatRoom:Join()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


    	-- Now parse the json data.
    	if (callback.ResponseObj.ChatRoom == nil) then
    		callback.ResponseObj.ChatRoomUsers = {};
    		callback.ResponseObj.ChatMessages = {};
    		
    		callback:ExecuteCallbackFuncEx(callbackFunc, "Deleted", "");
    		return;	
    	end


    	-- Now parse the json data.
		self:ProcessChatRoomJson(callback.ResponseObj.ChatRoom);
		self:ProcessChatRoomUsersJson(callback.ResponseObj.ChatRoomUsers);
		self:ProcessChatMessagesJson(callback.ResponseObj.ChatMessages);
		self:PostProcessUsernames();

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&ChatRoomID=" .. self.ChatRoomID;

	lib.sendNetworkMessage("chatrooms", "joinchatroom", parameters, networkListener);
end

-- @classmessage TogetherChatRoom:Leave()
-- Disconnects the current session and user from this ChatRoom.
-- @boldnote Be sure to set the class's ChatRoomID member to the ID of the ChatRoom you wish to leave.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherChatRoom:Leave(callbackFunc)
	lib.togetherPrint("TogetherChatRoom:Leave()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Remove the appropriate ChatRoomUser from the ChatRoom.
		self:RemoveChatRoomUser(self:IndexOfChatRoomUserByUserID(userID));

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&ChatRoomID=" .. self.ChatRoomID ..
   		"&UserID=" .. g_Together:GetUserID();

	lib.sendNetworkMessage("chatrooms", "leavechatroom", parameters, networkListener);
end

-- @classmessage TogetherChatRoom:CreateMessage()
-- Creates a new ChatMessage and adds it to this ChatRoom. Upon success, this will automatically update the internal list.
-- @boldnote Be sure to set the class's ChatRoomID member to the ID of the ChatRoom you wish to join.
-- @param number parentChatMessageID The ID of the ChatMessage that is to be the parent of the newly created ChatMessage. Pass in 0 if the ChatMessage is not to have a parent.
-- @param string message The message to assign to the ChatMessage.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherChatRoom:CreateMessage(parentChatMessageID, message, callbackFunc)
	lib.togetherPrint("TogetherChatRoom:CreateMessage(" .. parentChatMessageID .. ", " .. message .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		g_CurrentChatMessage = lib.TogetherChatMessage:New();
    	g_CurrentChatMessage:ProcessChatMessageJson(callback.ResponseObj.ChatMessage);
		self:AddChatMessage(g_CurrentChatMessage);
		self:PostProcessUsernames();
		
		callback.NewObject = g_CurrentChatMessage;

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&ChatRoomID=" .. self.ChatRoomID ..
    	"&ParentChatMessageID=" .. parentChatMessageID ..
    	"&Message=" .. message;

	lib.sendNetworkMessage("chatrooms", "createchatmessage", parameters, networkListener);
end

-- @classmessage TogetherChatRoom:DeleteMessage()
-- Deletes a ChatMessage from the ChatRoom. Upon success, this will automatically update the internal list.
-- @boldnote Be sure to set the class's ChatRoomID member to the ID of the ChatRoom you wish to delete.
-- @param number chatMessageID The ID of the ChatMessage to delete
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherChatRoom:DeleteMessage(chatMessageID, callbackFunc)
	lib.togetherPrint("TogetherChatRoom:DeleteMessage(" .. chatMessageID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Remove the appropriate ChatMessage from the ChatRoom.
		self:RemoveChatMessage(self:IndexOfChatMessageByChatMessageID(chatMessageID));

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
	end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&ChatRoomID=" .. self.ChatRoomID ..
    	"&ChatMessageID=" .. chatMessageID;

	lib.sendNetworkMessage("chatrooms", "deletechatmessage", parameters, networkListener);
end

-- @classmessage TogetherChatRoom:MarkMessageAsRead()
-- Marks a Message as Read. Upon success, this will automatically update the ChatMessage internally.
-- @param number chatMessageID The ID of the ChatMessage to mark as read
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherChatRoom:MarkMessageAsRead(chatMessageID, callbackFunc)
	lib.togetherPrint("TogetherChatRoom:MarkMessageAsRead(" .. chatMessageID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		local chatMessage = self:FindChatMessageByChatMessageID(chatMessageID);
		if (chatMessage ~= nil) then
			chatMessage:ProcessChatMessageJson(callback.ResponseObj.ChatMessage);		
		end

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
	end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&ChatRoomID=" .. self.ChatRoomID ..
    	"&ChatMessageID=" .. chatMessageID;

	lib.sendNetworkMessage("chatrooms", "markchatmessageasread", parameters, networkListener);	
end

-- @classmessage TogetherChatRoom:Modify()
-- Modifies the ChatRoom. Upon success, this will automatically update the ChatRoom internally.
-- With this method, you can modify the following parameters of the ChatRoom:
-- RoomID, Name, Description, ChatRoomProps.
-- @boldnote Be sure to set the class's ChatRoomID member to the ID of the ChatRoom you wish to modify.		
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherChatRoom:Modify(callbackFunc)
	lib.togetherPrint("TogetherChatRoom:Modify()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		self:ProcessChatRoomJson(callback.ResponseObj.ChatRoom);
		self:PostProcessUsernames();

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&ChatRoomID=" .. self.ChatRoomID ..
    	"&RoomID=" .. self.RoomID ..
    	"&Name=" .. self.Name ..
    	"&Description=" .. self.Description ..
    	"&ChatRoomProps=" .. self.Properties:EncodeJson();

	lib.sendNetworkMessage("chatrooms", "modifychatroom", parameters, networkListener);
end

-- @classmessage TogetherChatRoom:InviteUser()
-- Invites a User to this ChatRoom. You must either specify a valid inviteeUserID or valid inviteeSocialType
-- and inviteeSocialID. For Facebook, pass in "FB" for inviteeSocialType and the friend's FacebookID for inviteeSocialID.
-- @boldnote Be sure to set the class's ChatRoomID member to the ID of the ChatRoom you wish the User to be invited to.
-- @param number inviteeUserID The ID of the User to invite.  Pass in 0 if not specified.
-- @param string inviteeSocialType The type of social network.  Pass in "" if not specified.  "FB" for Facebook.
-- @param string inviteeSocialID The ID of the social friend.  Pass in "" if not specified.  Friends's FacebookID otherwise.
-- @param string notificationMessage The message to use when creating a UserNotification for the User being invite. Pass in "" if no notification is to be sent.
-- @param function callbackFunc The function to call upon completion.
function lib.TogetherChatRoom:InviteUser(inviteeUserID, inviteeSocialType, inviteeSocialID, notificationMessage, callbackFunc)
	lib.togetherPrint("TogetherChatRoom:InviteUser(" .. inviteeUserID .. ", " .. inviteeSocialType .. ", " .. inviteeSocialID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		self:ProcessChatRoomJson(callback.ResponseObj.ChatRoom);
		self:ProcessChatRoomUsersJson(callback.ResponseObj.ChatRoomUsers);
		self:PostProcessUsernames();

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&ChatRoomID=" .. self.ChatRoomID ..
    	"&InviteeUserID=" .. inviteeUserID ..
    	"&InviteeSocialType=" .. inviteeSocialType ..
    	"&InviteeSocialID=" .. inviteeSocialID ..
    	"&NotificationMessage=" .. notificationMessage ..
    	"&ChatRoomProps=" .. self.Properties:EncodeJson();

	lib.sendNetworkMessage("chatrooms", "inviteusertochatroom", parameters, networkListener);
end


-- return TogetherChatRoom;

-------------------------------------------------------------------------------
-- ChatRoomManager.lua --------------------------------------------------------
-------------------------------------------------------------------------------
lib.ChatRoomManager = {};
lib.ChatRoomManager.__index = lib.ChatRoomManager;

-- @class ChatRoomManager
-- The ChatRoomManager is used for fetching and finding chatrooms that exist for the current game.
-- @member table ChatRooms Stores all the ChatRooms contained in the Manager.
	
function lib.ChatRoomManager.New()
	local self = {};
	setmetatable(self, lib.ChatRoomManager);
	
	-- Contains all the ChatRooms.
	self.ChatRooms = {};
    
	return self;
end


-- @classmethod ChatRoomManager:Add()
-- Adds a ChatRoom to the manager internally without persistence.
-- @boldnote This method is deprecated
-- @param TogetherChatRoom chatRoom Instance of a ChatRoom to add internally
function lib.ChatRoomManager:Add(chatRoom)
	table.insert(self.ChatRooms, chatRoom);
end

-- @classmethod ChatRoomManager:FindByChatRoomID()
-- Finds the ChatRoom with the specified ChatRoomID if it exists, otherwise returns nil.
-- @param number chatRoomID The ID of the ChatRoom to find
-- @return TogetherChatRoom
function lib.ChatRoomManager:FindByChatRoomID(chatRoomID)
	local indexOfChatRoom = self:IndexOfByChatRoomID(chatRoomID);
	if (indexOfChatRoom ~= -1) then
		return self:Get(indexOfChatRoom);
	end
	return nil;
end

-- @classmethod ChatRoomManager:GetCount()
-- Gets the number of ChatRooms currently managed by the internal list
-- @return number
function lib.ChatRoomManager:GetCount()
	return table.getn(self.ChatRooms);
end

-- @classmethod ChatRoomManager:Get()
-- Gets the ChatRoom at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the ChatRoom to retrieve
-- @return TogetherChatRoom
function lib.ChatRoomManager:Get(index)
	return self.ChatRooms[index];
end

-- @classmethod ChatRoomManager:IndexOf()
-- Returns the index of the specified ChatRoom if it exists, otherwise returns nil.
-- @param TogetherChatRoom chatRoom Instance of the ChatRoom to retrieve the index of
-- @return number
function lib.ChatRoomManager:IndexOf(chatRoom)
	return table.indexOf(self.ChatRooms, chatRoom);
end

-- @classmethod ChatRoomManager:IndexOfByChatRoomID()
-- Returns the index of the ChatRoom with the specified ChatRoomID if it exists, otherwise returns -1.
-- @param number chatRoomID The ID of the ChatRoom to find the index of
-- @return number
function lib.ChatRoomManager:IndexOfByChatRoomID(chatRoomID)
	local chatRoomCount = self:GetCount();

   	for i=1, chatRoomCount do
    	if (self.ChatRooms[i].ChatRoomID == chatRoomID) then
			return i;
		end
    end

    return -1;
end

-- @classmethod ChatRoomManager:Remove()
-- Removes a ChatRoom from the managed list without persistence.
-- @boldnote This method is deprecated
-- @param number index The index of the ChatRoom to be removed if it exists
function lib.ChatRoomManager:Remove(index)
	if (index ~= -1) then
		table.remove(self.ChatRooms, index);
	end
end

function lib.ChatRoomManager:Dump()
	print("ChatRoomManager:");

	-- Dump all the ChatRooms as well.
	local chatRoomCount = table.getn(self.ChatRooms);
	print("   ChatRoomCount   = " .. chatRoomCount);

    for i=1, chatRoomCount do
    	self.ChatRooms[i]:Dump();
    end
end

function lib.ChatRoomManager:ProcessChatRoomsJson(chatRoomsJson)
	lib.togetherPrint("ChatRoomManager:ProcessChatRoomsJson()");

	self.ChatRooms = {};

	-- Parse out all the ChatRooms.
	for name, value in pairs (chatRoomsJson) do
    	local chatRoom = lib.TogetherChatRoom:New();

		chatRoom:ProcessChatRoomJson(value);

		table.insert(self.ChatRooms, chatRoom);
    end
end

function lib.ChatRoomManager:PostProcessUsernames()
	local chatRoomCount = self:GetCount();
	for i=1, chatRoomCount do
    	self.ChatRooms[i]:PostProcessUsernames();
    end
end



-------------------------------------------------------------------------------
--  Network methods.
-------------------------------------------------------------------------------

-- @classmessage ChatRoomManager:Create()
-- Creates a ChatRoom that can be associated to a Game Instance and optionally joined immediately.
-- @param string name The name of the new ChatRoom.
-- @param string description The description for the new ChatRoom.
-- @param number roomID The ID of the room the ChatRoom is in.  Pass in 0 for no room.
-- @param number gameInstanceID The ID of the GameInstance the ChatRoom is associated with. GameInstances associated with ChatRooms will retrieved when GameInstanceManager:GetAll() is called.
-- @param PropertyCollection chatRoomProperties The properties to associate with the ChatRoom.  Pass in null if no properties should be associated.  
-- @param function callbackFunc The function to call upon completion.
function lib.ChatRoomManager:Create(name, description, roomID, gameInstanceID, joinChatRoom, chatRoomProperties, callbackFunc)
	lib.togetherPrint("ChatRoomManager:Create()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end

    		
		g_TogetherChatRoom = lib.TogetherChatRoom:New();
    	g_TogetherChatRoom:ProcessChatRoomJson(callback.ResponseObj.ChatRoom);
    	self:Add(g_TogetherChatRoom);
		self:PostProcessUsernames();

		callback.NetObject = g_TogetherChatRoom;

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&Name=" .. name ..
    	"&Description=" .. description ..
    	"&RoomID=" .. roomID ..
    	"&GameInstanceID=" .. gameInstanceID ..
    	"&JoinChatRoom=" .. tostring(joinChatRoom);
    if (chatRoomProperties ~= nil) then
    	parameters = parameters .. "&ChatRoomProps=" .. chatRoomProperties:EncodeJson();
    end

	lib.sendNetworkMessage("chatrooms", "createchatroom", parameters, networkListener);
end

-- @classmessage ChatRoomManager:Delete()
-- Deletes a ChatRoom with the specified ID.
-- @param number chatRoomID The ID of the ChatRoom to delete
-- @param function callbackFunc The function to call upon completion
function lib.ChatRoomManager:Delete(chatRoomID, callbackFunc)
	lib.togetherPrint("ChatRoomManager:Delete(" .. chatRoomID .. "'");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end

	    -- Now, remove the deleted ChatRoom.
    	self:Remove(self:IndexOfByChatRoomID(chatRoomID));

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&ChatRoomID=" .. chatRoomID;

	lib.sendNetworkMessage("chatrooms", "deletechatroom", parameters, networkListener);
end

-- @classmessage ChatRoomManager:GetAll()
-- Gets all ChatRooms or optionally all a specific user is a member of.
-- @param number getForUserID The ID of the User to get ChatRooms for. When specified, only the ChatRooms the User is a member of will be retrieved. Pass in 0 to retrieve all ChatRooms.
-- @param function callbackFunc The function to call upon completion.
function lib.ChatRoomManager:GetAll(getForUserID, callbackFunc)
	lib.togetherPrint("ChatRoomManager:GetAll()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end
   		

   		-- Now parse the json data.
		self:ProcessChatRoomsJson(callback.ResponseObj.ChatRooms);
		self:PostProcessUsernames();

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"GetForUserID=" .. getForUserID;

	lib.sendNetworkMessage("chatrooms", "getallchatrooms", parameters, networkListener);
end

--return ChatRoomManager;

-------------------------------------------------------------------------------
-- Friend.lua -----------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherFriend = {};
lib.TogetherFriend.__index = lib.TogetherFriend;


-- @class TogetherFriend
-- The Friend class represents a together Friend.
-- @member number UserID The ID of the User that is a Friend.
-- @member string Name The name of the Friend.  This is filled out when they register via some social network.  (Facebook)
-- @member string Username The username of the Friend.
-- @member string SocialID The ID of the User on some social network.  For Facebook, this will be their FacebookID.
-- @member string SocialType The type of social network last used to register the User.  For Facebook, this will be "FB". 
-- @member boolean PlaysThisGame A boolean indicating whether the User has played the current game the logged in User is playing.


-----------------
-- Constructor --
-----------------

function lib.TogetherFriend.New()
	local self = {};
	setmetatable(self, lib.TogetherFriend);

	self.UserID					= 0;
	self.Name					= "";
	self.Username				= "";
	self.SocialID				= "";
	self.SocialType				= "";
	self.PlaysThisGame			= false;

	return self;
end

function lib.TogetherFriend:ProcessFriendJson(friendJson)
	self.UserID					= friendJson.UserID;	
	self.Name					= friendJson.Name;
	self.Username				= friendJson.Username;
	self.SocialID				= friendJson.SocialID;
	self.SocialType				= friendJson.SocialType;
	self.PlaysThisGame			= friendJson.PlaysThisGame;
end

function lib.TogetherFriend:Dump()
	self:DumpEx("");
end

function lib.TogetherFriend:DumpEx(spacing)
	print(spacing .. "Friend:");
	print(spacing .. "   UserID             = " .. self.UserID);
	print(spacing .. "   Name               = " .. self.Name);
	print(spacing .. "   Username           = " .. self.Username);
	print(spacing .. "   SocialID           = " .. self.SocialID);
	print(spacing .. "   SocialType         = " .. self.SocialType);
	print(spacing .. "   PlaysThisGame      = " .. tostring(self.PlaysThisGame));
end


-- return TogetherFriend;

-------------------------------------------------------------------------------
-- ExternalFriend.lua ---------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherExternalFriend = {};
lib.TogetherExternalFriend.__index = lib.TogetherExternalFriend;

-- @class TogetherExternalFriend
-- The ExternalFriend class represents a together ExternalFriend.
-- This class is used to represent a friend from some external social network.  (Facebook, Twitter, GooglePlus, etc...)
-- @member string FriendType The type of social network the friend relationship originated from.  ("FB" for Facebook)
-- @member string FriendID The ID of the friend on some social network.  (FacebookID for Facebook)
-- @member string Name The name of the friend on some social network.

-----------------
-- Constructor --
-----------------

function lib.TogetherExternalFriend.New()
	local self = {};
	setmetatable(self, lib.TogetherExternalFriend);

	self.FriendType				= "";
	self.FriendID				= "";
	self.Name					= "";

	return self;
end

function lib.TogetherExternalFriend:Dump()
	self:DumpEx("");
end

function lib.TogetherExternalFriend:DumpEx(spacing)
	print(spacing .. "ExternalFriend:");
	print(spacing .. "   FriendType         = " .. self.FriendType);
	print(spacing .. "   FriendID           = " .. self.FriendID);
	print(spacing .. "   Name               = " .. self.Name);
end


-- return TogetherExternalFriend;

-------------------------------------------------------------------------------
-- FriendManager.lua ----------------------------------------------------------
-------------------------------------------------------------------------------
lib.FriendManager = {};
lib.FriendManager.__index = lib.FriendManager;

-- @class FriendManager
-- The FriendManager class contains a collection of Friends.
-- @member table Friends Stores all the Friends contained in the Manager.
-- @member table FriendsDictionaryByUserID A table used to store all together friends in a dictionary form by their UserID.
-- @member table FriendsDictionaryBySocialID A table used to store all together friends in a dictionary form by their SocialID.
	
function lib.FriendManager.New()
	local self = {};
	setmetatable(self, lib.FriendManager);

	-- Contains all the Friends.
	self.Friends = {};
	self.FriendsDictionaryBySocialID = {};
	self.FriendsDictionaryByUserID = {};

	return self;
end


-- @classmethod FriendManager:Add()
-- Adds a TogetherFriend to the manager internally without persistence.
-- @boldnote This method is deprecated
-- @param TogetherFriend friend Instance of the TogetherFriend to add
function lib.FriendManager:Add(friend)
	table.insert(self.Friends, friend);
end

-- @classmethod FriendManager:FindByUserID()
-- Finds a TogetherFriend by UserID if it exists, otherwise returns nil.
-- @param number userID The ID of the User to find
-- @return TogetherFriend
function lib.FriendManager:FindByUserID(userID)
	lib.togetherPrint("FriendManager:FindByUserID(" .. userID .. ")");
	return self.FriendsDictionaryByUserID[tostring(userID)];
end

-- @classmethod FriendManager:FindBySocialID()
-- Finds the TogetherFriend by SocialID if it exists, otherwise returns nil.
-- @param number socialID The SocialID of the User to find  
-- @return TogetherFriend
function lib.FriendManager:FindBySocialID(socialID)
	if FriendsDictionaryBySocialID ~= nil then
		return self.FriendsDictionaryBySocialID[tostring(socialID)];
	else
		return nil;
	end
end

-- @classmethod FriendManager:GetCount()
-- Gets the number of TogetherFriends currently managed internally.
-- @return number
function lib.FriendManager:GetCount()
	return table.getn(self.Friends);
end

-- @classmethod FriendManager:Get()
-- Gets the TogetherFriend at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the Friend to find
-- @return TogetherFriend
function lib.FriendManager:Get(index)
	return self.Friends[index];
end

-- @classmethod FriendManager:IndexOf()
-- Gets the Index of the specified Friend if it exists, otherwise returns nil.
-- @param TogetherFriend friend Instance of the Friend to get the index of  
-- @return number
function lib.FriendManager:IndexOf(friend)
	return table.indexOf(self.Friends, friend);
end

-- @classmethod FriendManager:IndexOfByUserID()
-- Returns the index of the TogetherFriend with the specified UserID if it exists, otherwise returns -1.
-- @param number userID The ID of the User to get the index of
-- @return number
function lib.FriendManager:IndexOfByUserID(userID)
	local friendCount = self:GetCount();

   	for i=1, friendCount do
    	if (self.Friends[i].UserID == userID) then
			return i;
		end
    end

    return -1;
end

-- @classmethod FriendManager:Remove()
-- Removes a TogetherFriend from the internally managed list. This does not delete the Friend from the user's list persistently.
-- @boldnote This method is deprecated
-- @param number index The index of the FriendUse to be removed internally 
function lib.FriendManager:Remove(index)
	if (index ~= -1)	then
		table.remove(self.Friends, index);
	end
end

function lib.FriendManager:Dump()
	print("TogetherFriends:");

	-- Dump all the Friends as well.
	local friendCount = table.getn(self.Friends);
	print("   FriendCount   = " .. friendCount);

    for i=1, friendCount do
    	self.Friends[i]:DumpEx("   ");
    end
end

function lib.FriendManager:ProcessFriendsJson(friendsJson)

	lib.togetherPrint("FriendManager:ProcessFriendsJson()");

	self.Friends = {};
	self.FriendsDictionaryByUserID = {};
	self.FriendsDictionaryBySocialID = {};

	-- Parse out all the Friends.
	for name, value in pairs (friendsJson) do
    	local friend = lib.TogetherFriend:New();

		friend:ProcessFriendJson(value);

		table.insert(self.Friends, friend);
		self.FriendsDictionaryByUserID[tostring(friend.UserID)] = friend;
		self.FriendsDictionaryBySocialID[tostring(friend.SocialID)] = friend;
    end

    lib.togetherPrint("   Processed " .. table.getn(self.Friends) .. " friends.");
end

function lib.FriendManager:TrimExternalFriends(externalFriends)

	-- Dump all the Friends as well.
	local externalFriendCount = 0;
	local externalFriend = nil;
	local friendCount = self:GetCount();
	local friend = nil;

	lib.togetherPrint("   FriendCount   = " .. friendCount);
    for i=1, friendCount do
 		friend = self:Get(i);
 
 		externalFriendCount = table.getn(externalFriends);
 
 		for j=1, externalFriendCount do
 			externalFriend = externalFriends[j];

 			-- Remove all TogetherFriends from the ExternalFriends list.	
 			if (friend.SocialID == externalFriend.FriendID) then
 				table.remove(externalFriends, j);
 				break; 			
 			end
 		end
    end
end


		

-------------------------------------------------------------------------------
--  Network methods.
-------------------------------------------------------------------------------

-- @classmessage FriendManager:AddFriend()
-- Adds a new friend to the current session's User account. Upon success, this will automatically update the internal list.
-- @param number friendUserID The ID of the User to add as a friend
-- @param function callbackFunc The function to call upon completion.
function lib.FriendManager:AddFriend(friendUserID, callbackFunc)
	lib.togetherPrint("FriendManager:AddFriend(" .. friendUserID .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Create a new Friend.
    	g_CurrentFriend = lib.TogetherFriend:New();

		-- Process the response data.
    	g_CurrentFriend:ProcessFriendJson(callback.ResponseObj.Friend);
    	self:Add(g_CurrentFriend);
    	callback.NewObject = g_CurrentFriend;
    	
	    callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&FriendUserID=" .. friendUserID;

	lib.sendNetworkMessage("users", "addfriend", parameters, networkListener);	
end

-- @classmessage FriendManager:GetAll()
-- Gets all Friends from the current session's User account. Upon success, this will automatically update the internal list.
-- @param function callbackFunc The function to call upon completion.
function lib.FriendManager:GetAll(callbackFunc)
	lib.togetherPrint("FriendManager:GetAll()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


    	-- Now parse the json data.
		self:ProcessFriendsJson(callback.ResponseObj.Friends);

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken();

	lib.sendNetworkMessage("users", "getfriends", parameters, networkListener);	
end

-- @classmessage FriendManager:RemoveFriend()
-- Removes a Friend from the current session's User account. Upon success, this will automatically update the internal list.
-- @param number friendUserID The ID of a User to remove as a friend
-- @param function callbackFunc The function to call upon completion.
function lib.FriendManager:RemoveFriend(friendUserID, callbackFunc)
	lib.togetherPrint("FriendManager:Delete(" .. friendUserID .. "'");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


	    -- Now, remove the removed Friend.
    	self:Remove(self:IndexOfByUserID(friendUserID));

	    callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&FriendUserID=" .. friendUserID;

	lib.sendNetworkMessage("users", "removefriend", parameters, networkListener);
end

-- @classmessage FriendManager:SynchFriends()
-- Synchronizes the Friend list. This method is called whenever you initially log into Facebook.  For each Facebook friend,
-- if they are also a registered Together User, they become a Together friend on the User account. Upon success, this 
-- will automatically update the internal list.
-- @param string The type of synchronization to be done. Pass "FB" for Facebook. This parameter exists for future expandability to other social networks.
-- @param table externalFriends The array full of external (Facebook) friends.
-- @param function callbackFunc The function to call upon completion.
function lib.FriendManager:SynchFriends(syncType, externalFriends, callbackFunc)
	lib.togetherPrint("---------------------------  FriendManager:SynchFriends(" .. syncType .. "'");

	local function networkListener(callback)
   		lib.togetherPrint("---------------------------  FriendManager.networklistener()");
   		
   		
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end

    	-- Now parse the json data.
		self:ProcessFriendsJson(callback.ResponseObj.Friends);

		self:TrimExternalFriends(externalFriends);

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end

	local encodedExternalFriends = json.encode(externalFriends);

    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&SyncType=" .. syncType;-- ..

	lib.togetherPrint("About to call sendLargeNetworkMessage()");
	lib.sendLargeNetworkMessage("users", "syncfriends", parameters, encodedExternalFriends, networkListener);
end


--return FriendManager;

-------------------------------------------------------------------------------
-- UserMessage.lua ------------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherUserMessage = {}
lib.TogetherUserMessage.__index = lib.TogetherUserMessage;

-- @class TogetherUserMessage
-- The UserMessage class represents a message sent directly to a User's account.
-- @member number UserMessageID The ID of the UserMessage.
-- @member number SourceUserID The ID of the User that sent the UserMessage.  If 0, the UserMessage should be treated as a system message.
-- @member number DestinationUserID The ID of the User the UserMessage was sent to.
-- @member string SourceUsername The Name of the User that sent the UserMessage.
-- @member string DestinationUsername The Name of the User that the UserMessage was sent to.
-- @member boolean IsGameIndependent A boolean indicating whether the UserMessage is not meant for a specific Game only.
-- @member string Title The title of the UserMessage.
-- @member string Message The textual (message) of the UserMessage.
-- @member boolean WasRead A boolean indicating whether the UserMessage was read.
-- @member number SecondsSinceCreated The number of seconds since the UserMessage was created.
-- @member number SecondsSinceModified The number of seconds since the UserMessage was last modified.
-- @member number DestinationLastActivityInSeconds The number of seconds since the User the UserMessage was sent to has been active in a together Game.
-- @member number DestinationClientID The ID of the Client the User the UserMessage was sent to has last played a Game with.
-- @member number DestinationGameID The ID of the Game the User the UserMessage was sent to has last played.
-- @member number DestinationPlatformID The ID of the Platform of the last played Game for the User the UserMessage was sent to.   
-- @member number SourceLastActivityInSeconds The number of seconds since the User that sent the UserMessage has been active in a together Game.
-- @member number SourceClientID The ID of the Client the User that sent the UserMessage has last played a Game with.
-- @member number SourceGameID The ID of the Game the User that sent the UserMessage has last played.
-- @member number SourcePlatformID The ID of the Platform of the last played Game for the User that sent the UserMessage.   
-- @member PropertyCollection Properties A property collection containing all custom properties for the UserMessage.

-----------------
-- Constructor --
-----------------

function lib.TogetherUserMessage.New()
	local self = {};
	setmetatable(self, lib.TogetherUserMessage);
	
	self.UserMessageID						= 0;
	self.SourceUserID						= 0;
	self.DestinationUserID					= 0;
	self.SourceUsername						= "";
	self.DestinationUsername				= "";
	self.IsGameIndependent					= false;
	self.Title								= "";
	self.Message							= "";
	self.WasRead							= false;
	self.SecondsSinceCreated				= 0;
	self.SecondsSinceModified				= 0;
	self.DestinationLastActivityInSeconds	= 0;
	self.DestinationClientID				= 0;
	self.DestinationGameID					= 0;
	self.DestinationPlatformID				= 0;
	self.SourceLastActivityInSeconds		= 0;
	self.SourceClientID						= 0;
	self.SourceGameID						= 0;
	self.SourcePlatformID					= 0;
	self.Properties							= lib.PropertyCollection:New();

	return self;
end

function lib.TogetherUserMessage:ProcessUserMessageJson(userMessageJson)
	self.UserMessageID						= tonumber(userMessageJson.UserMessageID);
	self.SourceUserID						= tonumber(userMessageJson.SourceUserID);
	self.DestinationUserID					= tonumber(userMessageJson.DestinationUserID);
	self.SourceUsername						= userMessageJson.SourceUsername;
	self.DestinationUsername				= userMessageJson.DestinationUsername;
	self.IsGameIndependent					= userMessageJson.IsGameIndependent;
	self.Title								= userMessageJson.Title;
	self.Message							= userMessageJson.Message;
	self.WasRead							= userMessageJson.WasRead;
	self.SecondsSinceCreated				= userMessageJson.SecondsSinceCreated;
	self.SecondsSinceModified				= userMessageJson.SecondsSinceModified;
	self.DestinationLastActivityInSeconds	= userMessageJson.DestinationLastActivityInSeconds;
	self.DestinationClientID				= userMessageJson.DestinationClientID;
	self.DestinationGameID					= userMessageJson.DestinationGameID;
	self.DestinationPlatformID				= userMessageJson.DestinationPlatformID;
	self.SourceLastActivityInSeconds		= userMessageJson.SourceLastActivityInSeconds;
	self.SourceClientID						= userMessageJson.SourceClientID;
	self.SourceGameID						= userMessageJson.SourceGameID;
	self.SourcePlatformID					= userMessageJson.SourcePlatformID;

	if (userMessageJson["Properties"] ~= nil) then
		self.Properties:ProcessNodeJson(userMessageJson.Properties);
	end
end

function lib.TogetherUserMessage:Dump()
	self:DumpEx("");
end

function lib.TogetherUserMessage:DumpEx(spacing)
	print(spacing .. "UserMessage:");
	print(spacing .. "   UserMessageID                      = " .. self.UserMessageID);
	print(spacing .. "   SourceUserID                       = " .. self.SourceUserID);
	print(spacing .. "   DestinationUserID                  = " .. self.DestinationUserID);
	print(spacing .. "   SourceUsername                     = " .. self.SourceUsername);
	print(spacing .. "   DestinationUsername                = " .. self.DestinationUsername);
	print(spacing .. "   IsGameIndependent                  = " .. tostring(self.IsGameIndependent));
	print(spacing .. "   Title                              = " .. self.Title);
	print(spacing .. "   Message                            = " .. self.Message);
	print(spacing .. "   WasRead                            = " .. tostring(self.WasRead));
	print(spacing .. "   SecondsSinceCreated                = " .. self.SecondsSinceCreated);
	print(spacing .. "   SecondsSinceModified               = " .. self.SecondsSinceModified);
	print(spacing .. "   DestinationLastActivityInSeconds   = " .. self.DestinationLastActivityInSeconds);
	print(spacing .. "   DestinationClientID                = " .. self.DestinationClientID);
	print(spacing .. "   DestinationGameID                  = " .. self.DestinationGameID);
	print(spacing .. "   DestinationPlatformID              = " .. self.DestinationPlatformID);
	print(spacing .. "   SourceLastActivityInSeconds        = " .. self.SourceLastActivityInSeconds);
	print(spacing .. "   SourceClientID                     = " .. self.SourceClientID);
	print(spacing .. "   SourceGameID                       = " .. self.SourceGameID);
	print(spacing .. "   SourcePlatformID                   = " .. self.SourcePlatformID);

	self.Properties:DumpEx(spacing .. "   ");
end


-- return TogetherUserMessage;

-------------------------------------------------------------------------------
-- UserMessageManager.lua -----------------------------------------------------
-------------------------------------------------------------------------------
lib.UserMessageManager = {};
lib.UserMessageManager.__index = lib.UserMessageManager;

-- @class UserMessageManager
-- The UserMessageManager class is used to find and fetch messages directly sent to the current session's User account. 
-- With this class, a developer will be able to create a message, delete a message,
-- get all messages, and mark a message as read.  A Developer can use UserMessages as in-game email.
-- @member table UserMessages Stores all the UserMessages contained in the Manager.

function lib.UserMessageManager.New()
	local self = {};
	setmetatable(self, lib.UserMessageManager);

	-- Contains all the UserMessages.
	self.UserMessages = {};

	return self;
end


-- @classmethod UserMessageManager:Add()
-- Adds a UserMessage to the internally managed list without persistence.
-- @boldnote This method is deprecated
-- @param TogetherUserMessage userMessage Instance of a UserMessage to add internally
function lib.UserMessageManager:Add(userMessage)
	table.insert(self.UserMessages, userMessage);
end

-- @classmethod UserMessageManager:FindByUserMessageID()
-- Finds the UserMessage with the specified UserMessageID if it exists, otherwise returns nil.
-- @param number userMessageID The ID of the UserMessage to find
-- @return TogetherUserMessage
function lib.UserMessageManager:FindByUserMessageID(userMessageID)
	local indexOfMessage = self:IndexOfByUserMessageID(userMessageID);
	if (indexOfMessage ~= -1) then
		return self:Get(indexOfMessage);
	end
	return nil;
end

-- @classmethod UserMessageManager:GetCount()
-- Gets the number of UserMessages currently managed internally.
-- @return number
function lib.UserMessageManager:GetCount()
	return table.getn(self.UserMessages);
end

-- @classmethod UserMessageManager:Get()
-- Gets the UserMessage at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the UserMessage to find
-- @return TogetherUserMessage
function lib.UserMessageManager:Get(index)
	return self.UserMessages[index];
end

-- @classmethod UserMessageManager:IndexOf()
-- Returns the index of the specified UserMessage if it exists, otherwise returns nil.
-- @param TogetherUserMessage userMessage Instance of the UserMessage to find the index of  
-- @return number
function lib.UserMessageManager:IndexOf(userMessage)
	return table.indexOf(self.UserMessages, userMessage);
end

-- @classmethod UserMessageManager:IndexOfByUserMessageID()
-- Returns the index of the UserMessage with the specified UserMessageID if it exists, otherwise returns -1.
-- @param number userMessageID The ID of the UserMessage to find the index of
-- @return number
function lib.UserMessageManager:IndexOfByUserMessageID(userMessageID)
	local messageCount = self:GetCount();

   	for i=1, messageCount do
    	if (self.UserMessages[i].UserMessageID == userMessageID) then
			return i;
		end
    end

    return -1;
end

-- @classmethod UserMessageManager:Remove()
-- Removes a UserMessage from the internally managed list. This does not delete the message from the user's mailbox persistently.
-- @boldnote This method is deprecated
-- @param number index The index of the UserMessage to remove internally
function lib.UserMessageManager:Remove(index)
	if (index ~= -1)	then
		table.remove(self.UserMessages, index);
	end
end

function lib.UserMessageManager:Dump()
	print("UserMessages:");

	-- Dump all the Messages as well.
	local messageCount = table.getn(self.UserMessages);
	print("   MessageCount   = " .. messageCount);

    for i=1, messageCount do
    		self.UserMessages[i]:DumpEx("   ");
    end
end

function lib.UserMessageManager:ProcessMessagesJson(messagesJson)

	lib.togetherPrint("UserMessageManager:ProcessMessagesJson()");

	self.UserMessages = {};

	-- Parse out all the Messages.
	for name, value in pairs (messagesJson) do
    	local message = lib.TogetherUserMessage:New();
		message:ProcessUserMessageJson(value);
		table.insert(self.UserMessages, message);
    end

    lib.togetherPrint("   Processed " .. table.getn(self.UserMessages) .. " messages.");
end



-------------------------------------------------------------------------------
--  Network methods.
-------------------------------------------------------------------------------

-- @classmessage UserMessageManager:GetAll()
-- Gets all UserMessages assigned to the User. Upon success, this will automatically update the internal mailbox.
-- @param boolean unreadOnly A Boolean indicating whether only unread messages should be retrieved.
-- @param number startID The ID of the UserMessage to start with when returning UserMessages.
-- @param number count The max number of UserMessages to return.
-- @param function callbackFunc The function to call upon completion.
function lib.UserMessageManager:GetAll(unreadOnly, startID, count, callbackFunc)
	lib.togetherPrint("UserMessageManager:GetAll()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


    	-- Now parse the json data.
		self:ProcessMessagesJson(callback.ResponseObj.Messages);

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&UnreadOnly=" .. tostring(unreadOnly) ..
    	"&StartID=" .. startID ..
    	"&Count=" .. count;

	lib.sendNetworkMessage("users", "getallusermessages", parameters, networkListener);	
end

-- @classmessage UserMessageManager:CreateMessage()
-- Sends a message to a specific User. Upon success, this will automatically update the internal mailbox.
-- @param number destinationUserID The ID of the User to send the UserMessage to.
-- @param string title The title of the UserMessage.
-- @param string message The message of the UserMessage.
-- @param boolean isGameIndependent A boolean indicating whether the generated UserMessage is
--							assigned to the Game being played.
-- @param PropertyCollection messageProperties The properties to assign to the UserMessage.  Pass in
--							nil to assign no properties.
-- @param function callbackFunc The function to call upon completion.
function lib.UserMessageManager:CreateMessage(destinationUserID, title, message, isGameIndependent, messageProperties, callbackFunc)
	lib.togetherPrint("UserMessageManager:CreateMessage()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


    	-- Now parse the json data.
		--self:ProcessMessagesJson(callback.ResponseObj.Message);

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end

    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&DestUserID=" .. destinationUserID ..
    	"&Title=" .. title ..
    	"&Message=" .. message ..
    	"&IsGameIndependent=" .. tostring(isGameIndependent);
    	
    if (messageProperties ~= nil) then
		parameters = parameters .. "&Properties=" .. messageProperties:EncodeJson();
	end

	lib.sendNetworkMessage("users", "createusermessage", parameters, networkListener);	
end

-- @classmessage UserMessageManager:MarkMessageAsRead()
-- Marks a UserMessage as read. Upon success, this will automatically update the internal mailbox.
-- @param number userMessageID The ID of the UserMessage to mark as read.
-- @param function callbackFunc The function to call upon completion.
function lib.UserMessageManager:MarkMessageAsRead(userMessageID, callbackFunc)
	lib.togetherPrint("UserMessageManager:MarkMessageAsRead()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


    	-- Now parse the json data.
		local userMessage = self:FindByUserMessageID(userMessageID);
		if (userMessage ~= nil) then
			userMessage:ProcessUserMessageJson(callback.ResponseObj.Message);
		end

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end

    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&UserMessageID=" .. userMessageID;

	lib.sendNetworkMessage("users", "markusermessageasread", parameters, networkListener);	
end

-- @classmessage UserMessageManager:DeleteMessage()
-- Deletes a UserMessage. Upon success, this will automatically update the internal mailbox.
-- @param number userMessageID The ID of the UserMessage to delete.
-- @param function callbackFunc The function to call upon completion.
function lib.UserMessageManager:DeleteMessage(userMessageID, callbackFunc)
	lib.togetherPrint("UserMessageManager:DeleteMessage()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		self:Remove(self:IndexOfByUserMessageID(userMessageID));

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end

    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&UserMessageID=" .. userMessageID;

	lib.sendNetworkMessage("users", "deleteusermessage", parameters, networkListener);	
end


--return UserMessageManager;

-------------------------------------------------------------------------------
-- UserPurchase.lua -----------------------------------------------------------
-------------------------------------------------------------------------------
lib.TogetherUserPurchase = {};
lib.TogetherUserPurchase.__index = lib.TogetherUserPurchase;

-- @class TogetherUserPurchase
-- The UserPurchase class represents a User's purchase.
-- @member number UserPurchaseID The ID of the UserPurchase.
-- @member number RoomID The ID of the Room the Purchase was done in.
-- @member number AchievementID The ID of the Achievement that was purchased.
-- @member number ItemID The ID of the Item that was purchased.
-- @member string Description A textual description for the purchase.
-- @member number Count The number of things that were purchased.
-- @member number SecondsSinceCreated The number of seconds since the purchase occurred.
-- @member number SecondsSinceLastModified The number of seconds since purchase was last modified.
-- @member PropertyCollection Properties A property collection containing all custom properties for the UserPurchase.


-----------------
-- Constructor --
-----------------

function lib.TogetherUserPurchase.New()
	local self = {};
	setmetatable(self, lib.TogetherUserPurchase);

	self.UserPurchaseID				= 0;
	self.RoomID						= 0;
	self.AchievementID				= 0;
	self.ItemID						= 0;
	self.Description				= "";
	self.Count						= 0;
	self.SecondsSinceCreated		= 0;
	self.SecondsSinceLastModified	= 0;

	self.Properties					= lib.PropertyCollection:New();

	return self;
end

function lib.TogetherUserPurchase:ProcessUserPurchaseJson(userPurchaseJson)
	self.UserPurchaseID				= userPurchaseJson.UserPurchaseID;
	self.RoomID						= userPurchaseJson.RoomID;
	self.AchievementID				= userPurchaseJson.AchievementID;
	self.ItemID						= userPurchaseJson.ItemID;
	self.Description				= userPurchaseJson.Description;
	self.Count						= userPurchaseJson.Count;
	self.SecondsSinceCreated		= userPurchaseJson.SecondsSinceCreated;
	self.SecondsSinceLastModified	= userPurchaseJson.SecondsSinceLastModified;

	if (userPurchaseJson["Properties"] ~= nil) then
		self.Properties:ProcessNodeJson(userPurchaseJson.Properties);
	end
end

function lib.TogetherUserPurchase:Dump()
	self:DumpEx("");
end

function lib.TogetherUserPurchase:DumpEx(spacing)
	print(spacing .. "UserPurchase:");
	print(spacing .. "   UserPurchaseID             = " .. self.UserPurchaseID);
	print(spacing .. "   RoomID                     = " .. self.RoomID);
	print(spacing .. "   AchievementID              = " .. self.AchievementID);
	print(spacing .. "   ItemID                     = " .. self.ItemID);
	print(spacing .. "   Description                = " .. self.Description);
	print(spacing .. "   Count                      = " .. self.Count);
	print(spacing .. "   SecondsSinceCreated        = " .. self.SecondsSinceCreated);
	print(spacing .. "   SecondsSinceLastModified   = " .. self.SecondsSinceLastModified);

	self.Properties:DumpEx(spacing .. "   ");
end


-- return TogetherUserPurchase;

-------------------------------------------------------------------------------
-- UserPurchaseManager.lua ----------------------------------------------------
-------------------------------------------------------------------------------
lib.UserPurchaseManager = {};
lib.UserPurchaseManager.__index = lib.UserPurchaseManager;

-- @class UserPurchaseManager
-- The UserPurchaseManager class contains a collection UserPurchases.
-- With this class, a developer will be able to Create and Retrieve All their UserPurchases.
-- @member table UserPurchases Stores all the UserPurchases contained in the Manager.
	
function lib.UserPurchaseManager:New()
	local self = {};
	setmetatable(self, lib.UserPurchaseManager);

	-- Contains all the UserPurchases.
	self.UserPurchases = {};

	return self;
end


-- @classmethod UserPurchaseManager:Add()
-- Adds a UserPurchase to the internally managed list without persistence.
-- @boldnote This method is deprecated
-- @param TogetherUserPurchase userPurchase Instance of a UserPurchase to add internally
function lib.UserPurchaseManager:Add(userPurchase)
	table.insert(self.UserPurchases, userPurchase);
end

-- @classmethod UserPurchaseManager:FindByUserPurchaseID()
-- Finds the UserPurchase with the specified UserPurchaseID if it exists, otherwise returns nil
-- @param number userPurchaseID The ID of the UserPurchase to find
-- @return TogetherUserPurchase
function lib.UserPurchaseManager:FindByUserPurchaseID(userPurchaseID)
	local indexOfUserPurchase = self:IndexOfByUserPurchaseID(userPurchaseID);
	if (indexOfUserPurchase ~= -1) then
		return self:Get(indexOfUserPurchase);
	end
	return nil;
end

-- @classmethod UserPurchaseManager:GetCount()
-- Gets the number of UserPurchases currently managed internally.
-- @return number
function lib.UserPurchaseManager:GetCount()
	return table.getn(self.UserPurchases);
end

-- @classmethod UserPurchaseManager:Get()
-- Gets the UserPurchase at the specified index if it exists, otherwise returns nil.
-- @param number index The index of the UserPurchase to find
-- @return TogetherUserPurchase
function lib.UserPurchaseManager:Get(index)
	return self.UserPurchases[index];
end

-- @classmethod UserPurchaseManager:IndexOf()
-- Returns the index of the specified UserPurchase if it exists, otherwise returns nil.
-- @param TogetherUserPurchase userItem Instance of the UserPurchase to find the index of  
-- @return number
function lib.UserPurchaseManager:IndexOf(userPurchase)
	return table.indexOf(self.UserPurchases, userPurchase);
end

-- @classmethod UserPurchaseManager:IndexOfByUserPurchaseID()
-- Returns the index of the UserPurchase with the specified UserPurchaseID if it exists, otherwise returns -1.
-- @param number userPurchaseID The ID of the UserPurchase to find the index of
-- @return number
function lib.UserPurchaseManager:IndexOfByUserPurchaseID(userPurchaseID)
	local userPurchaseCount = self:GetCount();

   	for i=1, userPurchaseCount do
    	if (self.UserPurchases[i].UserPurchaseID == userPurchaseID) then
			return i;
		end
    end

    return -1;
end

-- @classmethod UserPurchaseManager:Remove()
-- Removes a UserPurchase from the internally managed list. This does not delete the purchase from the user's account persistently.
-- @boldnote This method is deprecated
-- @param number index The index of the UserPurchase to remove internally
function lib.UserPurchaseManager:Remove(index)
	if (index ~= -1)	then
		table.remove(self.UserPurchases, index);
	end
end

function lib.UserPurchaseManager:Dump()
	print("UserPurchases:");

	-- Dump all the UserPurchases as well.
	local userPurchaseCount = table.getn(self.UserPurchases);
	print("   UserPurchaseCount   = " .. userPurchaseCount);

    for i=1, userPurchaseCount do
   		self.UserPurchases[i]:DumpEx("   ");
    end
end

function lib.UserPurchaseManager:ProcessUserPurchasesJson(userPurchasesJson)
	lib.togetherPrint("UserPurchaseManager:ProcessUserPurchasesJson()");

	self.UserPurchases = {};

	-- Parse out all the UserPurchases.
	for name, value in pairs (userPurchasesJson) do
    	local userPurchase = lib.TogetherUserPurchase:New();
		userPurchase:ProcessUserPurchaseJson(value);
		table.insert(self.UserPurchases, userPurchase);
    end

    lib.togetherPrint("   Processed " .. table.getn(self.UserPurchases) .. " user purchases.");
end




-------------------------------------------------------------------------------
--  Network methods.
-------------------------------------------------------------------------------

-- @classmessage UserPurchaseManager:Create()
-- Creates a new UserPurchase record. Upon success, this will automatically update the internal list.
-- @param number roomID The ID of the room where the purchase occurred.  Pass in 0 for no room.
-- @param number achievementID The ID of the achievement that was purchase.
-- @param number itemID The ID of the item that was purchased.
-- @param string description A textual description of the purchase.
-- @param number count the Number of (Achievements, Items, things) purchased.
-- @param PropertyCollection userPurchaseProperties The properties to assign to the UserPurchase record. Pass an instance to link properties. Pass nil to assign no properties.
-- @param function callbackFunc The function to call upon completion.
function lib.UserPurchaseManager:Create(roomID, achievementID, itemID, description, count, userPurchaseProperties, callbackFunc)
	lib.togetherPrint("UserPurchaseManager:Create(" .. roomID .. ", " .. achievementID .. ", " .. itemID .. ", " ..
		description .. ", " .. count .. ")");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Create a new UserPurchase.
    	g_CurrentUserPurchase = lib.TogetherUserPurchase:New();

		-- Process the response data.
    	g_CurrentUserPurchase:ProcessUserPurchaseJson(callback.ResponseObj.UserPurchase);
    	self:Add(g_CurrentUserPurchase);
    	callback.NewObject = g_CurrentUserPurchase;

	    callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&RoomID=" .. roomID ..
    	"&AchievementID=" .. achievementID ..
    	"&ItemID=" .. itemID ..
    	"&Description=" .. description ..
    	"&Count=" .. count;
	if (userPurchaseProperties ~= nil) then
		parameters = parameters .. "&UserPurchaseProps=" .. userPurchaseProperties:EncodeJson();
	end

	lib.sendNetworkMessage("users", "createuserpurchase", parameters, networkListener);	
end

-- @classmessage UserPurchaseManager:GetAll()
-- Gets all UserPurchases done by a User. Upon success, this will automatically update the internal list.
-- @param function callbackFunc The function to call upon completion.
function lib.UserPurchaseManager:GetAll(callbackFunc)
	lib.togetherPrint("UserPurchaseManager:GetAll()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


    	-- Now parse the json data.
		self:ProcessUserPurchasesJson(callback.ResponseObj.UserPurchases);

	    callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken();

	lib.sendNetworkMessage("users", "getalluserpurchases", parameters, networkListener);
end


--return UserPurchaseManager;

-------------------------------------------------------------------------------
-- END INCLUDES ---------------------------------------------------------------
-------------------------------------------------------------------------------


-------------------------------------------------------------------------------
-- Globals --------------------------------------------------------------------
-------------------------------------------------------------------------------

-- @classmessage Together:GetInstance()
-- Gets or creates the instance of global 'g_Together'
-- @return Together
lib.GetInstance = function()
	if(g_Together ~= nil) then
		return g_Together;
	end
	
	g_Together = lib.Together:New();
	return g_Together;
end


-- Sends a network message to the server.
lib.sendNetworkMessage = function(namespace, action, parameters, networkListener)
	lib.SendNetworkMessage(namespace, action, parameters, networkListener);
end

lib.sendLargeNetworkMessage = function(namespace, action, parameters, fileData, callbackFunc)
	lib.SendLargeNetworkMessage(namespace, action, parameters, fileData, callbackFunc);
end

lib.togetherPrint = function(message)
	if(g_TogetherPrintEnabled == true) then
		print(message);
	end
end

lib.urlencode = function(str)
	if (str) then
		str = string.gsub(str, "\n", "\r\n")
		str = string.gsub(str, "([^%w ])",
        function (c) return string.format("%%%02X", string.byte(c)) end)
		str = string.gsub(str, " ", "+")
	end

	return str
end
 
lib.urldecode = function(str)
	str = string.gsub(str, "+", " ")
	str = string.gsub(str, "%%(%x%x)",
    function(h) return string.char(tonumber(h,16)) end)
	str = string.gsub(str, "\r\n", "\n")

	return str
end

lib.pingTimer = function()
	g_Together:Ping(nil);
	timer.performWithDelay(g_Together.PingInterval * 1000, pingTimer);
end

lib.SendNetworkMessage = function(namespace, action, parameters, callbackFunc)
	lib.togetherPrint("Together:SendNetworkMessage(" .. namespace .. ", " .. action .. ", " .. parameters .. ")");

	local function networkListener(event)
		local callback = lib.TogetherCallback:New(namespace, action, parameters);
   		
   		if (event.isError) then
   			lib.DumpNetworkError(event);
   			callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Unable to communicate with playstogether servers at this time");
   			return;
   		end

   		lib.togetherPrint(event.response);
   		callback.ResponseObj = json.decode(event.response);

		if (callback.ResponseObj.Status ~= "Success") then
			callback:ExecuteCallbackFuncEx(callbackFunc, "Error", callback.ResponseObj.Error.ErrorDescription);
			return;
		end

    	callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


	local parametersUrlEncoded = lib.urlencode(parameters);

	local timestamp = os.clock();
	local stringToHash = parameters .. "-" .. timestamp .. "-" .. g_Together.ClientPrivateKey;
	local signature = crypto.digest(crypto.md5, stringToHash);


	local postData = "cpk=" .. g_Together.ClientPublicKey ..
		"&ts=" .. timestamp ..
		"&sig=" .. signature ..
		"&rspf=" .. g_Together.Rspf ..
		"&params=" .. parametersUrlEncoded;

	local postUrl = g_Together.TogetherServerIP .. "/" .. namespace .. "/" .. action;

   	lib.togetherPrint("parameters = " .. parameters);
	lib.togetherPrint("postUrl = " .. postUrl);
   	lib.togetherPrint("postData = " .. postData);

	g_Together.LastPingTime = os.time();

 	local params = {};
	params.body = postData;
	network.request(postUrl, "POST", networkListener, params);
end

lib.SendLargeNetworkMessage = function(namespace, action, parameters, fileData, callbackFunc)
	lib.togetherPrint("***  Together:SendLargeNetworkMessage(" .. namespace .. ", " .. action .. ", " .. parameters .. ")");

	local function networkListener(event)
		lib.togetherPrint("***  Got response.");
		local callback = lib.TogetherCallback:New(namespace, action, parameters);
   		
   		if (event.isError) then
   			lib.DumpNetworkError(event);
			callback:ExecuteCallbackFuncEx(callbackFunc, "Error", "Unable to communicate with playstogether servers at this time");
   			return;
   		end

   		lib.togetherPrint(event.response);
   		callback.ResponseObj = json.decode(event.response);

		if (callback.ResponseObj.Status ~= "Success") then
			callback:ExecuteCallbackFuncEx(callbackFunc, "Error", callback.ResponseObj.Error.ErrorDescription);
			return;
		end

    	callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


	local parametersUrlEncoded = lib.urlencode(parameters);

	local timestamp = os.clock();
	local stringToHash = parameters .. "-" .. timestamp .. "-" .. g_Together.ClientPrivateKey;
	local signature = crypto.digest(crypto.md5, stringToHash);

 	lib.togetherPrint("***   self.ClientPrivateKey = " ..  g_Together.ClientPrivateKey); 
	lib.togetherPrint("***   timestamp = " .. timestamp);
	lib.togetherPrint("***   stringToHash = " .. stringToHash);
	lib.togetherPrint("***   signature = " .. signature);
	lib.togetherPrint("***   parameters = " .. parametersUrlEncoded);

	lib.togetherPrint("***About to start building the MultipartFormData");
	
	local multipartFormData = lib.MultipartFormData.New();

	multipartFormData:addHeader("Customer-Header", "Custom Header Value");
	multipartFormData:addField("cpk", g_Together.ClientPublicKey);
	multipartFormData:addField("ts", tostring(timestamp));
	multipartFormData:addField("sig", signature);
	multipartFormData:addField("rspf", g_Together.Rspf);
	multipartFormData:addField("params", parametersUrlEncoded);
	multipartFormData:addLargeData("filedata", fileData);

 	lib.togetherPrint("***MultipartFormData populated.");

	local params = {}
	params.body = multipartFormData:getBody() 			-- Must call getBody() first!
	params.headers = multipartFormData:getHeaders() 	-- Headers not valid until getBody() is called.

	local postUrl = g_Together.TogetherServerIP .. "/" .. namespace .. "/" .. action;
	--local postUrl = g_Together.TogetherServerIP .. "/api/v1/" .. namespace .. "/" .. action;

	LastPingTime = os.time();

 	network.request(postUrl, "POST", networkListener, params);
end

lib.DumpNetworkError = function(event)
	print("***** Together:DumpNetworkError:");
	if (event.isError ~= nil) then
		print("*****   event.isError = " .. tostring(event.isError));
	end
	if (event.name ~= nil) then
		print("*****   event.name = " .. tostring(event.name));
	end
	if (event.response ~= nil) then
		print("*****   event.response = " .. tostring(event.response));
	end
	if (event.status ~= nil) then
		print("*****   event.status = " .. tostring(event.status));
	end
	if (event.url ~= nil) then
		print("*****   event.url = " .. tostring(event.url));
	end
end

lib.CalculateSignature = function(postData)
	local encryptedPostData = crypto.hmac(crypto.md5, g_Together.ClientPrivateKey, postData);
	return encryptedPostData;
end

-------------------------------------------------------------------------------
-- Together.lua ---------------------------------------------------------------
-------------------------------------------------------------------------------
lib.Together = {};
lib.Together.__index = lib.Together;


-- @class Together
-- The Together class is the root class in the Together api.
-- It contains essential configuration settings, an object representing the logged in User, and 
-- various Managers for creating, deleting, and retrieving various Together objects.
-- @member number PingInterval How often the ping message is sent to the server.
-- @member number LastPingTime The last time a ping message was sent to the server.
-- @member string ApnsDeviceToken The DeviceToken for Apple push notifications.
-- @member boolean RegisteredPushEnabledDevice A boolean indicates whether the push enabled Device has been registered with the server.
-- @member string CacheUserGuid The cached UserGuid of the last logged in User.
-- @member TogetherCache TogetherCache A TogetherCache class instance used to Load and Save the together cache on the Device.
-- @member string TogetherServerIP The IP address of the together server.
-- @member string ClientPublicKey The PublicKey of the Together Client the Game belongs to.
-- @member string ClientPrivateKey The PrivateKey of the Together Client that Game belongs to.
-- @member string GameKey The Key of the Together Game.
-- @member string PlatformName The name of the platform the Game is running on.
-- 								(IOS, Android, Mac OS, Unity, HTML5/JS)
-- @member string FacebookAppID The ApplicationID of the Facebook application.
-- @member string FacebookPrivileges The Facebook privileges to ask for when logging into Facebook.
-- @member TogetherSocial Social A TogetherSocial class instance containing various social apis.
-- @member TogetherUser TogetherUser A TogetherUser class instance representing the logged in User.
-- @member TogetherUserSession TogetherUserSession A TogetherUserSession class instance representing the logged in UserSession.
-- @member GameInstanceManager GameInstanceManager A GameInstanceManager class instance useful for storing GameInstances
-- 										the logged in User is a member of.
-- @member LeaderboardManager LeaderboardManager A LeaderboardManager class instance useful for storing Leaderboards.
-- @member UserMessageManager UserMessageManager A UserMessageManager class instance for sending and receiving in game messages or emails
-- @member UserNotificationManager UserNotificationManager A UserNotificationManager class instance useful for storing UserNotifications.
-- @member AchievementManager AchievementManager A AchievementManager class instance useful for storing Achievements.
-- @member ItemManager ItemManager A ItemManager class instance useful for storing Items.
-- @member ChatRoomManager ChatRoomManager A ChatRoomManager class instance useful for storing ChatRooms.
-- @member FriendManager FriendManager A FriendManager class instance useful for storing together Friends.
-- @member UserPurchaseManager UserPurchaseManager A UserPurchaseManager class instance useful for storing UserPurchases.

-----------------
-- Constructor --
-----------------

function lib.Together.New()
	local self = {};
	setmetatable(self, lib.Together);
	
	self.PingInterval					= 60;	-- 60 seconds.
	self.LastPingTime					= os.time();

	self.ApnsDeviceToken				= "";
	self.GCMDeviceToken					= "";
	self.RegisteredPushEnabledDevice	= false;

	self.CacheUserGuid					= "";
	self.TogetherCache 					= lib.TogetherCache:New();
	
	self.TogetherServerIP				= "http://api.v1.playstogether.com";

	-- Client Keys.
    self.ClientPublicKey 				= "";
    self.ClientPrivateKey				= "";

	-- Game Key.
    self.GameKey						= "";

    -- The name of the Platform we're running on.
    self.PlatformName					= "";

	-- The Facebook AppID used when logging into and submiting wall posts.
	self.FacebookAppID					= "";
	self.FacebookPrivileges				= nil;

	self.Social							= nil;

	self.TogetherUser					= nil;
	self.TogetherUserSession			= nil;

	self.GameInstanceManager			= nil;
	self.LeaderboardManager				= nil;
	self.UserNotificationManager		= nil;
	self.AchievementManager				= nil;
	self.ItemManager					= nil;
	self.ChatRoomManager				= nil;
	self.FriendManager					= nil;
	self.UserPurchaseManager			= nil;

	self.Rspf							= "json";

	self.Callback						= lib.TogetherCallback:New();

	return self;
end

-- @classmethod Together:GetUserID()
-- Shorthand for fetching the TogetherUser.UserID property.
-- @return number
function lib.Together:GetUserID()
	return self.TogetherUser.UserID;
end

-- @classmethod Together:GetUsername()
-- Shorthand for fetching the TogetherUser.Username property.
-- @return string
function lib.Together:GetUsername()
	return self.TogetherUser.Username;
end

-- @classmethod Together:GetNameOfUser()
-- Shorthand for fetching the TogetherUser.Name property.
-- @return string
function lib.Together:GetNameOfUser()
	return self.TogetherUser.Name;
end

-- @classmethod Together:GetUserViewName()
-- Shorthand for calling the TogetherUser:GetViewName method.
-- @return string
function lib.Together:GetUserViewName()
	return self.TogetherUser:GetViewName();
end

-- @classmethod Together:IsUserFacebookRegistered()
-- Checks to see if the User is registered via Facebook.
-- @return boolean
function lib.Together:IsUserFacebookRegistered()
	return self.TogetherUser:IsFacebookRegistered();
end

-- @classmethod Together:IsUserCustomRegistered()
-- Checks to see if the User is registered via Custom.
-- @return boolean
function lib.Together:IsUserCustomRegistered()
	return self.TogetherUser:IsCustomRegistered();
end

-- @classmethod Together:FindTogetherFriendByUserID()
-- Finds the TogetherFriend with the specified UserID.
-- @param number userID The ID of User to retrieve.
-- @return TogetherFriend
function lib.Together:FindTogetherFriendByUserID(userID)
	return self.FriendManager:FindByUserID(userID);
end

-- @classmethod Together:FindTogetherFriendBySocialID()
-- Finds the TogetherFriend with the specified SocialID (FacebookID).
-- @param number userID The ID of User to retrieve.
-- @return TogetherFriend
function lib.Together:FindTogetherFriendBySocialID(socialID)
	return self.FriendManager:FindToSocialID(socialID);
end

-- @classmethod Together:FindTogetherFriendBySocialID()
-- Finds the FacebookFriend with the specified SocialID (FacebookID).
-- @param number userID The ID of User to retrieve.
-- @return TogetherFriend
function lib.Together:FindFacebookFriendBySocialID(socialID)
	return self.Social.Facebook:FindBySocialID(socialID);
end

function lib.Together:DumpTogetherFriends()
	self.FriendManager:Dump();
end

function lib.Together:DumpFacebookFriends()
	self.Social.Facebook:DumpFriends();
end

-- @classmethod Together:GetSessionToken()
-- Gets the session token returned when the User logged in.
-- @return string
function lib.Together:GetSessionToken()
	return self.TogetherUserSession.SessionToken;
end

-- @classmethod Together:Initialize()
-- Initializes the Together class so it's ready to make API requests.
-- @param string clientPublicKey The PublicKey assigned to your account. This is accessible from the [playstogether developer portal](https://developer.playstogether.com).
-- @param string clientPrivateKey The PrivateKey assigned to your account.  This is accessible from the [playstogether developer portal](https://developer.playstogether.com).
-- @param string gameKey The GameKey of the game you are connecting to. This is accessible from the [playstogether developer portal](https://developer.playstogether.com).
-- @param string platformName The Name of the Platform the game is running on.  Supported Platforms are:<br>("IOS", "Android", "Mac OS", "Unity", "HTML5/JS")
function lib.Together:Initialize(clientPublicKey, clientPrivateKey, gameKey, platformName)
    self.ClientPublicKey 	= clientPublicKey;
    self.ClientPrivateKey	= clientPrivateKey;
    self.GameKey			= gameKey;
    self.PlatformName		= platformName;

	-- Load the TogetherCache.
	self:LoadTogetherCache();

	-- Wait 2 seconds before calling function
	timer.performWithDelay(self.PingInterval * 1000, pingTimer);
end

-- @classmethod Together:SetApnsDeviceToken()
-- Sets the ApnsDeviceToken that will be used when registering the device for push notifications.
-- @param string apnsDeviceToken The device token.
function lib.Together:SetApnsDeviceToken(apnsDeviceToken)
	self.ApnsDeviceToken = apnsDeviceToken;
end

-- @classmethod Together:SetServerAddress()
-- Sets the ServerAddress all network messages will be sent to when talking to the together servers.
-- This defaults to the primary Together servers and does not need to be called unless you are working 
-- with a form of private/local server instance. If you are interested in private hosting and want 
-- more information, contact [sales@playstogether.com](mailto:sales@playstogether.com).
-- @param string serverAddress The server address of the together server.
function lib.Together:SetServerAddress(serverAddress)
	self.TogetherServerIP = serverAddress;
end

-- @classmethod Together:GetServerAddress()
-- Gets the ServerAddress all requests are being sent to.
-- @return string
function lib.Together:GetServerAddress()
	return self.TogetherServerIP;
end

-- @classmethod Together:SetFacebookAppID()
-- Sets the Facebook ApplicationID all Facebook related calls will use.
-- @param string facebookAppID The ApplicationID of the Facebook application.
-- @param table facebookPrivileges A table full of Facebook privileges to ask for when logging into Facebook.
function lib.Together:SetFacebookAppID(facebookAppID, facebookPrivileges)
	self.FacebookAppID = facebookAppID;
	self.FacebookPrivileges = facebookPrivileges;
end

-- @classmethod Together:GetCacheUserGuid()
-- Gets the cached UserGuid.
-- @return string
function lib.Together:GetCacheUserGuid()
	return self.TogetherCache.UserGuid;
end

-- @classmethod Together:LoadTogetherCache()
-- Loads the Together Cache from the Device.  The only thing stored in the TogetherCache currently
-- is the UserGuid of the last logged in user for the application.
function lib.Together:LoadTogetherCache()
	-- Let the TogetherCache object load the Cache.	
	if (self.TogetherCache:Load() == true) then
		self.CacheUserGuid = self.TogetherCache.UserGuid;
	end
end

-- @classmethod Together:SaveTogetherCache()
-- Saves the Together Cache to the Device.  The only thing stored in the TogetherCache currently
-- is the UserGuid of the last logged in user for the application.
function lib.Together:SaveTogetherCache()
	-- Let the TogetherCache object save the Cache.	
	if (self.TogetherCache:Save() == true) then
		self.CacheUserGuid = self.TogetherCache.UserGuid;
	end
end

-- @classmethod Together:EraseTogetherCache()
-- Erases the Together Cache from the Device.  The only thing stored in the TogetherCache currently
-- is the UserGuid of the last logged in user for the application.
function lib.Together:EraseTogetherCache()
	self.TogetherCache:Erase();
end

function lib.Together:Dump()
	lib.togetherPrint("Together Dump:");
	
	-- Dump the TogetherUser.
	if (self.TogetherUser ~= nil) then
		self.TogetherUser:Dump();
	else
		lib.togetherPrint("   TogetherUser is nil.");
	end

	-- Dump the TogetherUserSession.
	if (self.TogetherUserSession ~= nil) then
		self.TogetherUserSession:Dump();
	else
		lib.togetherPrint("   TogetherUserSession is nil.");
	end
end




--------------------------------------------------------------------------------
--  Network methods.
--------------------------------------------------------------------------------

-- @classmessage Together:LoginUser()
-- Logs in the User. This should always be the first Together network message called. If no User GUID is provided, 
-- a new user account will be created anonymously and assigned a GUID which can be used to log the user in again 
-- later or register them with Facebook or via Custom form.
-- @boldnote Currently anonymous users will NOT be deleted. However it is possible that a user cleansing system will be implemented in the future that removes <i>unregistered</i> accounts after 3 to 6 months of <i>inactivity</i>.
-- @param function callbackFunc The function to call upon completion.
function lib.Together:LoginUser(callbackFunc)
	lib.togetherPrint("Together.LoginUser()");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		self.Social = lib.TogetherSocial:New();
		self.Social.Facebook:Initialize(self.FacebookAppID, self.FacebookPrivileges);

   		self.TogetherUserSession = lib.TogetherUserSession:New();
   		self.TogetherUserSession:ProcessUserSessionJson(callback.ResponseObj.UserSession);

   		self.TogetherUser = lib.TogetherUser:New();
   		self.TogetherUser:ProcessUserJson(callback.ResponseObj.User);
		
		-- Create the GameInstanceManager.
		self.GameInstanceManager = lib.GameInstanceManager:New();

		-- Create the LeaderboardManager.
		self.LeaderboardManager = lib.LeaderboardManager:New();

		-- Create the UserNotificationManager.
		self.UserNotificationManager = lib.UserNotificationManager:New();
		
		-- Create the AchievementManager.
		self.AchievementManager = lib.AchievementManager:New();

		-- Create the ItemManager.
		self.ItemManager = lib.ItemManager:New();

		-- Create the ChatRoomManager.
		self.ChatRoomManager = lib.ChatRoomManager:New();

		-- Create the FriendManager.
		self.FriendManager = lib.FriendManager:New();
		self.Social.Facebook.FriendManager = self.FriendManager;
		
		-- Create the UserMessageManager.
		self.UserMessageManager = lib.UserMessageManager:New();

		-- Create the UserPurchaseManager.
		self.UserPurchaseManager = lib.UserPurchaseManager:New();

		
		self.CacheUserGuid = self.TogetherUser.UserGuid;
			
		-- If this is the first time we've logged in, then save out the
		-- TogetherCache so the same user will be used upon future logins.
		-- Not doing so will cause a new user to be created each time they
		-- login in.
		self.TogetherCache.UserGuid = self.TogetherUser.UserGuid;
		self:SaveTogetherCache();
		
		self:AddAnalytic("Info", "JustLoggedIn", self.TogetherCache.UserGuid);
		
   		lib.togetherPrint("Just logged in successfully.");

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
 	end


   	if (self.CacheUserGuid == nil) then
   		lib.togetherPrint("self.CacheUserGuid=nil");
   	end

	local parameters = "GameKey=" .. self.GameKey ..
		"&PlatformName=" .. self.PlatformName ..
		"&UserGuid=" .. self.CacheUserGuid;
		
	lib.sendNetworkMessage("users", "loginuser", parameters, networkListener);
end

-- @classmessage Together:GetServerTimeUTC()
-- Gets the Server Timestamp(UTC+0). The timestamp will be returned in the data member of the callback as a long.
-- @param function callbackFunc The function to call upon completion.
function lib.Together:GetServerTimeUTC(callbackFunc)
	local function networkListener(callback)
		if(callback.Success == false) then
			callback:ExecuteCallbackFunc(callbackFunc);
			return;
		end
		
		-- Process the response
		--local response = {};
		--response.Timestamp = callback.ResponseObj.Timestamp;
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
	end
	
    local parameters = "SessionToken=" .. g_Together:GetSessionToken();
	lib.sendNetworkMessage("utility", "getservertime", parameters, networkListener);
end

-- @classmessage Together:GetGlobalProfile()
-- Fetches your developer global profile of data set through the portal or by atomic operations. 
-- The callback object will contain the profile in the data member as a PropertyCollection type.
-- @param function callbackFunc The function to call upon completion.
function lib.Together:GetGlobalProfile(callbackFunc)
	local function networkListener(callback)
		if(callback.Success == false) then
			callback:ExecuteCallbackFunc(callbackFunc);
			return;
		end
		
		-- Process the response
		self.GlobalProfile = TogetherPropertyCollection:New();
		self.GlobalProfile:ProcessNodeJson(callback.ResponseObj.Profile);
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
	end
	
    local parameters = "SessionToken=" .. g_Together:GetSessionToken();
	lib.sendNetworkMessage("profiles", "getdeveloperprofile", parameters, networkListener);
end

-- @classmessage Together:GetGameProfile()
-- Fetches the game's profile of data set through the portal or by atomic operations. 
-- The callback object will contain the profile in the data member as a PropertyCollection type.
-- @param function callbackFunc The function to call upon completion.
function lib.Together:GetGameProfile(callbackFunc)
	local function networkListener(callback)
		if(callback.Success == false) then
			callback:ExecuteCallbackFunc(callbackFunc);
			return;
		end
		
		-- Process the response
		self.GameProfile = TogetherPropertyCollection:New();
		self.GameProfile:ProcessNodeJson(callback.ResponseObj.Profile);
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
	end
	
    local parameters = "SessionToken=" .. g_Together:GetSessionToken();
	lib.sendNetworkMessage("profiles", "getgameprofile", parameters, networkListener);
end

-- @classmessage Together:GetUserProfile()
-- Fetches the current, logged in user's profile for the game. The callback object will 
-- contain the profile in the data member as a PropertyCollection type. This is also retrieved 
-- when the User object for the local player is fetched and can be modified with 
-- the User.Modify() call.
-- @param function callbackFunc The function to call upon completion.
function lib.Together:GetUserProfile(callbackFunc)
	local function networkListener(callback)
		if(callback.Success == false) then
			callback:ExecuteCallbackFunc(callbackFunc);
			return;
		end
		
		-- Process the response
		self.UserProfile = TogetherPropertyCollection:New();
		self.UserProfile:ProcessNodeJson(callback.ResponseObj.Profile);
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
	end
	
    local parameters = "SessionToken=" .. g_Together:GetSessionToken();
	lib.sendNetworkMessage("profiles", "getuserprofile", parameters, networkListener);
end

-- @classmessage Together:AddAtomic()
-- Adds an atomic field to either the game profile or the global profile. The callback object will
-- contain a Property type in the data field.
-- @param boolean global Pass TRUE to add the atomic entry to the global profile, FALSE to add it to the game profile
-- @param string parentName The name of an existing parent collection in which to add the atomic entry to
-- @param string propertyName The name of the atomic field to add
-- @param string propertyValue The value of the atomic entry to apply
-- @param function callbackFunc The function to call upon completion.
function lib.Together:AddAtomic(global, parentName, propertyName, propertyValue, callbackFunc)
	local function networkListener(callback)
		if(callback.Success == false) then
			callback:ExecuteCallbackFunc(callbackFunc);
			return;
		end
		
		-- Process the response
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
	end
	
    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
		"&global=" .. tostring(global) ..
		"&parent=" .. parentName ..
		"&name=" .. propertyName ..
		"&value=" .. propertyValue;
	
	lib.sendNetworkMessage("utility", "addatomic", parameters, networkListener);
end

-- @classmessage Together:IncrementAtomic()
-- Increments an existing atomic property in either the game profile or global profile without an 
-- upper limit. The callback object will contain a Property type in the data field.
-- @param boolean global Pass TRUE to increment an entry in the global profile, FALSE to increment an entry in the game profile
-- @param string parentName The name of an existing parent collection containing the property
-- @param string propertyName The name of the property to increment
-- @param function callbackFunc The function to call upon completion.
function lib.Together:IncrementAtomic(global, parentName, propertyName, callbackFunc)
	local function networkListener(callback)
		if(callback.Success == false) then
			callback:ExecuteCallbackFunc(callbackFunc);
			return;
		end
		
		-- Process the response
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
	end
	
    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
		"&global=" .. tostring(global) ..
		"&parent=" .. parentName ..
		"&name=" .. propertyName;
	
	lib.sendNetworkMessage("utility", "incrementatomic", parameters, networkListener);
end

-- @classmessage Together:IncrementAtomicWithLimit()
-- Increments an existing atomic property in either the game profile or global profile with a 
-- passed upper limit. The callback object will contain a Property type in the data field.
-- @param boolean global Pass TRUE to increment an entry in the global profile, FALSE to increment an entry in the game profile
-- @param string parentName The name of an existing parent collection containing the property
-- @param string propertyName The name of the property to increment
-- @param number limit The upper limit of the atomic operation as an integer
-- @param function callbackFunc The function to call upon completion.
function lib.Together:IncrementAtomicWithLimit(global, parentName, propertyName, limit, callbackFunc)
	local function networkListener(callback)
		if(callback.Success == false) then
			callback:ExecuteCallbackFunc(callbackFunc);
			return;
		end
		
		-- Process the response
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
	end
	
    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
		"&global=" .. tostring(global) ..
		"&parent=" .. parentName ..
		"&name=" .. propertyName ..
		"&limit=" .. limit;
	
	lib.sendNetworkMessage("utility", "incrementatomic", parameters, networkListener);
end

-- @classmessage Together:IncrementAtomicWithLimitRef()
-- Increments an existing atomic property in either the game profile or global profile with a reference 
-- to a limit elsewhere in the profile. The callback object will contain a Property type in the data field.
-- @param boolean global Pass TRUE to increment an entry in the global profile, FALSE to increment an entry in the game profile
-- @param string parentName The name of an existing parent collection containing the property
-- @param string propertyName The name of the property to increment
-- @param string refParent The name of the parent collection containing the property to be used as the limit
-- @param string refProperty The name of the property in the referenced parent to be used as the limit
-- @param function callbackFunc The function to call upon completion.
function lib.Together:IncrementAtomicWithLimitRef(global, parentName, propertyName, refParent, refProperty, callbackFunc)
	local function networkListener(callback)
		if(callback.Success == false) then
			callback:ExecuteCallbackFunc(callbackFunc);
			return;
		end
		
		-- Process the response
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
	end
	
    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
		"&global=" .. tostring(global) ..
		"&parent=" .. parentName ..
		"&name=" .. propertyName ..
		"&limitParent=" .. refParent ..
		"&limitName=" .. refProperty;
	
	lib.sendNetworkMessage("utility", "incrementatomic", parameters, networkListener);
end

-- @classmessage Together:RegisterFacebook()
-- Registers the User with Facebook.
-- TogetherSocialFacebook:Login() calls this method upon successfully logging into facebook.
-- @param string facebookID The FacebookID of the facebook user.
-- @param string name The name of the facebook user.
-- @param string firstName The first name of the facebook user.
-- @param string lastName The last name of the facebook user.
-- @param string link The link to the facebook user.
-- @param string username The username of the facebook user.
-- @param string gender The gender of the facebook user.
-- @param string locale The locale of the facebook user.
-- @param function callbackFunc The function to call upon completion.
function lib.Together:RegisterFacebookUser(facebookUser, callbackFunc)
	-- Overload
	self:RegisterFacebook(facebookUser.FacebookID,
								facebookUser.Name,
								facebookUser.FirstName,
								facebookUser.LastName,
								facebookUser.Link,
								facebookUser.Username,
								facebookUser.Gender,
								facebookUser.Locale,
								callbackFunc);
end

function lib.Together:RegisterFacebook(facebookID, name, firstName, lastName, link, username, gender, locale, callbackFunc)

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Process the response data.
    	self.TogetherUserSession:ProcessUserSessionJson(callback.ResponseObj.UserSession);
   		self.TogetherUser:ProcessUserJson(callback.ResponseObj.User);

		self.CacheUserGuid = self.TogetherUser.UserGuid;
			
		-- If this is the first time we've logged in, then save out the
		-- TogetherCache so the same user will be used upon future logins.
		-- Not doing so will cause a new user to be created each time they
		-- login in.
		self.TogetherCache.UserGuid = self.TogetherUser.UserGuid;
		self:SaveTogetherCache();


		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
    	"&FacebookID=" .. facebookID;
	if (name ~= nil) then
    	parameters = parameters .. "&Name=" .. tostring(name);
    end
    if (firstName ~= nil) then
    	parameters = parameters .. "&FirstName=" .. tostring(firstName);
    end
    if (lastName ~= nil) then
    	parameters = parameters .. "&LastName=" .. tostring(lastName);
    end
    if (link ~= nil) then
    	parameters = parameters .. "&Link=" .. tostring(link);
    end
    if (username ~= nil) then
    	parameters = parameters .. "&Username=" .. tostring(username);
    end
    if (gender ~= nil) then
    	parameters = parameters .. "&Gender=" .. tostring(gender);
    end
   	if (locale ~= nil) then
   		parameters = parameters .. "&Locale=" .. tostring(locale);
   	end
   		
	lib.sendNetworkMessage("users", "registerfacebookuser", parameters, networkListener);
end

-- @classmessage Together:RegisterCustom()
-- Registers the User with the custom registration system.
-- @param string email The email of the Custom user.
-- @param string password The password of the Custom user.
-- @param string name The name of the Custom user.
-- @param function callbackFunc The function to call upon completion.
function lib.Together:RegisterCustom(email, password, name, callbackFunc)

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end
    		

		-- Process the response data.
    	self.TogetherUserSession:ProcessUserSessionJson(callback.ResponseObj.UserSession);
   		self.TogetherUser:ProcessUserJson(callback.ResponseObj.User);

		self.CacheUserGuid = self.TogetherUser.UserGuid;
			
		-- If this is the first time we've logged in, then save out the
		-- TogetherCache so the same user will be used upon future logins.
		-- Not doing so will cause a new user to be created each time they
		-- login in.
		self.TogetherCache.UserGuid = self.TogetherUser.UserGuid;
		self:SaveTogetherCache();


		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end

	local hashedPassword = crypto.digest(crypto.md5, password);

   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&Email=" .. email ..
   		"&Password=" .. hashedPassword ..
   		"&Name=" .. name;

	lib.sendNetworkMessage("users", "registercustomuser", parameters, networkListener);
end

-- @classmessage Together:Logout()
-- Logs out the User. If the user did not registered, this will mark the account inactive but is reactivated
-- at the next login with the same user GUID.
-- @boldnote Currently anonymous users will NOT be deleted. However it is possible that a user cleansing system will be implemented in the future that removes <i>unregistered</i> accounts after 3 to 6 months of <i>inactivity</i>.
-- @param function callbackFunc The function to call upon completion.
function lib.Together:Logout(callbackFunc)

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end


		-- Process the response data.
    	self.TogetherUserSession:ProcessUserSessionJson(callback.ResponseObj.UserSession);
   		self.TogetherUser:ProcessUserJson(callback.ResponseObj.User);

		self.CacheUserGuid = '';

		-- If this is the first time we've logged in, then save out the
		-- TogetherCache so the same user will be used upon future logins.
		-- Not doing so will cause a new user to be created each time they
		-- login in.
		self.TogetherCache.UserGuid = '';

		-- Erase the TogetherCache object file.
		self:EraseTogetherCache();


		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
    end


    local parameters = "SessionToken=" .. g_Together:GetSessionToken();

	lib.sendNetworkMessage("users", "logoutuser", parameters, networkListener);
end

-- @classmessage Together:RegisterPushEnabledDevice()
-- Registers a push enabled Device. Use by setting ApnsDeviceToken and/or GcmDeviceToken 
-- and/or WnsDeviceToken first then calling.
-- @param function callbackFunc The function to call upon completion.
function lib.Together:RegisterPushEnabledDevice(callbackFunc)

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end

    	self.RegisteredPushEnabledDevice = true;

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end
	local deviceToken = "&";
	if(self.ApnsDeviceToken ~= "") then
		deviceToken = deviceToken .. "APNS_DeviceToken=" .. self.ApnsDeviceToken;
	elseif(self.GCMDeviceToken ~= "") then
		deviceToken = deviceToken .. "GCM_DeviceToken=" .. self.GCMDeviceToken;
	end
	
   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() .. deviceToken;

	lib.sendNetworkMessage("users", "registerpushenableddevice", parameters, networkListener);
end


-- @classmessage Together:SendPushNotification()
-- Sends a push notification message.
-- @boldnote This counts towards Push Notifications on your developer account and does not count as a System Request.
-- @param number destUserID The ID of the User to send the push notification to.
-- @param string notificationMessage The message to send.
-- @param string platform the platform that the message is being sent to: ios or android
-- @param TogetherNotification data the TogetherNotification to be sent to the server
-- @param function callbackFunc The function to call upon completion.
function lib.Together:SendPushNotification(destUserID, notificationMessage, platform, data, callbackFunc)

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end
    		
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end
	
   	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&DestinationUserID=" .. destUserID ..
		"&Platform=" .. platform;
		
	if(nil ~= data) then
		parameters = parameters .. "&Data=" .. json.encode(data);
	end
	
	if(notificationMessage ~= nil) then
		parameters = parameters .. "&AlertMessage=" .. notificationMessage;
	end

	lib.sendNetworkMessage("users", "sendnotification", parameters, networkListener);
end

-- @classmessage Together:Ping()
-- Pings the Server for the User as a keep-alive.
-- @param function callbackFunc The function to call upon completion.
function lib.Together:Ping(callbackFunc)

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end
    		
		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end


	-- Make sure we are at least logged in.
	if (TogetherUserSession == nil) then
		lib.togetherPrint("   Not logged in.  Not pinging...");
		return;
	end


	local pingTime = os.time();

	local pingTime = os.time();
	local pingDelta = os.difftime(pingTime, self.LastPingTime);

	lib.togetherPrint("**********  pingDelta = " .. pingDelta);

	-- Don't want to ping the server toooooooo frequently.
	if (pingDelta <= self.PingInterval) then
		lib.togetherPrint("   Not pinging...");
		return;
	end
	
	
	lib.togetherPrint("   Pinging Server.");

	self.LastPingTime = pingTime;	

	local parameters = "SessionToken=" .. g_Together:GetSessionToken();

	lib.sendNetworkMessage("users", "pinguser", parameters, networkListener);
end

-- @classmessage Together:AddAnalytic()
-- Adds an Analytic event for the User with simple options.
-- @param string eventName The name of the event to assign to the analytic record.
-- @param string propName The name of the property to assign to the analytic record.
-- @param string propValue The value of the property to assign to the analytic record.
-- @param function callbackFunc The function to call upon completion.
function lib.Together:AddAnalytic(eventName, propName, propValue, callbackFunc)
	lib.togetherPrint("Together:AddAnalytic(" .. eventName .. ", " .. propName .. ", " .. tostring(propValue) .. ")");

	local propertyCollection = lib.PropertyCollection:New();
	propertyCollection:Set(propName, propValue);

	self:AddAnalyticEx(eventName, propertyCollection, callbackFunc);
end

-- @classmessage Together:AddAnalyticEx()
-- Adds an Analytic event for the User with extended options.
-- @param string eventName The name of the event to assign to the analytic record.
-- @param PropertyCollection propertyCollection Collection of data to add to the event record
-- @param function callbackFunc The function to call upon completion.
function lib.Together:AddAnalyticEx(eventName, propertyCollection, callbackFunc)
	lib.togetherPrint("Together:AddAnalytic(" .. eventName .. ", properties)");

	local function networkListener(callback)
   		if (callback.Success == false) then
   			callback:ExecuteCallbackFunc(callbackFunc);
   			return;
   		end

		callback:ExecuteCallbackFuncEx(callbackFunc, "Success", "");
   	end
	
	if(g_Together:GetSessionToken() == nil) then
		lib.togetherPrint("session nil");
	end
	if(eventName == nil) then
		lib.togetherPrint("event nil");
	end
		
	local parameters = "SessionToken=" .. g_Together:GetSessionToken() ..
   		"&EventName=" .. eventName ..
   		"&Properties=" .. propertyCollection:EncodeJson();

	lib.sendNetworkMessage("users", "addanalytic", parameters, networkListener);
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib;
