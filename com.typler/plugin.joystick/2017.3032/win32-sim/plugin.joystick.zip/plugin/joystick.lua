local Library = require("CoronaLibrary")
local lib = Library:new({name = "plugin.joystick", publisherId = "com.typler"})

function lib.newJoystick(properties)
	local private = {}
		private.group = display.newGroup()
		if properties.group then
			properties.group:insert(private.group)
		end
		private.radius = properties.backgroundRadius

	local public = {}
		public.background = display.newCircle(private.group, properties.x, properties.y, properties.backgroundRadius)
		public.movedStick = display.newCircle(private.group, properties.x, properties.y, properties.movedStickRadius)

		function public:isActivated()
			return private.activated
		end

		function public:setCoords(x, y)
			private.group.x = x
			private.group.y = y
		end

		function public:getCoords()
			return {x = private.group.x, y = private.group.y}
		end

		function public:getVector()
			return {x = (public.movedStick.x - public.background.x) / private.radius, y = (public.movedStick.y - public.background.y) / private.radius}
		end

	function touchListener(event)
		if(event.phase == "moved") then
			if(math.sqrt(math.pow(event.x - public.background.x, 2) + math.pow(event.y - public.background.y, 2)) <= private.radius) then -- If touch coordinates in range of private
				public.movedStick.x = event.x -- Move movedStick part
				public.movedStick.y = event.y
				private.activated = true
			else if(private.activated) then 
					if(public.background.x - event.x < 0) then -- Else if touch in left side of private
						local tan = (-(public.background.y - event.y) / public.background.width) / (-(public.background.x - event.x) / public.background.width) -- Calculate tan
						local rads = math.atan(tan) -- Converting to radians
						public.movedStick.x = public.background.x + (math.cos(rads) * private.radius) -- Set coordinates
						public.movedStick.y = public.background.y + (math.sin(rads) * private.radius)
					else -- If in right side
						local tan = (-(public.background.y - event.y) / public.background.width) / (-(public.background.x - event.x) / public.background.width)
						local rads = math.atan(tan)
						public.movedStick.x = public.background.x + (-math.cos(rads) * private.radius)
						public.movedStick.y = public.background.y + (-math.sin(rads) * private.radius)
					end	
				end
			end
		end
		if(event.phase == "ended") then -- When touch finish, move movedStick part to default position
			public.movedStick.x = public.background.x
			public.movedStick.y = public.background.y
			private.activated = false
		end
	end

	Runtime:addEventListener("touch", touchListener)

	return public
end

return lib