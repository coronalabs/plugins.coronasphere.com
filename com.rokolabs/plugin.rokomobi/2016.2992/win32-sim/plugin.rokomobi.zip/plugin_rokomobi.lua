local Library = require "CoronaLibrary"

-- Create library
lib = Library:new{ name='plugin.rokomobi', publisherId='com.rokolabs', version=1 }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local PLUGIN_NAME = require "plugin_PLUGIN_NAME"
--    PLUGIN_NAME.test()
--    
local function showWarning(functionName)
     print( functionName .. " WARNING: The RokoMobi plugin is only supported on Android & iOS devices. Please build for device")
end

lib.init = function()
	showWarning( 'rokomobi.init()' )
end

lib.setUser = function()
	showWarning( 'rokomobi.setUser()' )
end

lib.addEvent = function()
	showWarning( 'rokomobi.addEvent()' )
end

lib.registerPush = function()
	showWarning( 'rokomobi.registerPush()' )
end

lib.print = function()
	showWarning( 'rokomobi.print()' )
end

lib.getUserInfo = function()
	showWarning( 'rokomobi.getUserInfo()' )
end

lib.promoCodeFromNotification = function()
	showWarning( 'rokomobi.promoCodeFromNotification()' )
end

lib.loadPromo = function()
	showWarning( 'rokomobi.loadPromo()' )
end

lib.loadUserPromoCodes = function()
	showWarning( 'rokomobi.loadUserPromoCodes()' )
end

lib.markPromoCodeAsUsed = function()
	showWarning( 'rokomobi.markPromoCodeAsUsed()' )
end

lib.loadReferralDiscountsList = function()
	showWarning( 'rokomobi.loadReferralDiscountsList()' )
end

lib.markReferralDiscountAsUsed = function()
	showWarning( 'rokomobi.markReferralDiscountAsUsed()' )
end

lib.loadDiscountInfoWithCode = function()
	showWarning( 'rokomobi.loadDiscountInfoWithCode()' )
end

lib.activateDiscountWithCode = function()
	showWarning( 'rokomobi.activateDiscountWithCode()' )
end

lib.completeDiscountWithCode = function()
	showWarning( 'rokomobi.completeDiscountWithCode()' )
end

lib.createLink = function()
	showWarning( 'rokomobi.createLink()' )
end

lib.inviteFriends = function()
	showWarning( 'rokomobi.inviteFriends()' )
end

lib.shareWithUi = function()
	showWarning( 'rokomobi.shareWithUi()' )
end

lib.shareCompleteForChannel = function()
	showWarning( 'rokomobi.shareCompleteForChannel()' )
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
