local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='goprezzo', publisherId='com.goprezzo' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local goprezzo = require "plugin_goprezzo"
--    goprezzo.test()
--    
lib.init = function()
	native.showAlert( 'Sorry!', 'goprezzo plugin is not supported on this platform', { 'OK' } )
	print( 'goprezzo plugin is not supported on this platform' )
end

lib.submitScoreAsync = function()
	native.showAlert( 'Sorry!', 'goprezzo plugin is not supported on this platform', { 'OK' } )
	print( 'goprezzo plugin is not supported on this platform' )
end

lib.checkIn = function()
	native.showAlert( 'Sorry!', 'goprezzo plugin is not supported on this platform', { 'OK' } )
	print( 'goprezzo plugin is not supported on this platform' )
end

lib.claimScore = function()
	native.showAlert( 'Sorry!', 'goprezzo plugin is not supported on this platform', { 'OK' } )
	print( 'goprezzo plugin is not supported on this platform' )
end

lib.sessionCreated = function()
	native.showAlert( 'Sorry!', 'goprezzo plugin is not supported on this platform', { 'OK' } )
	print( 'goprezzo plugin is not supported on this platform' )
end

lib.expireSession = function()
	native.showAlert( 'Sorry!', 'goprezzo plugin is not supported on this platform', { 'OK' } )
	print( 'goprezzo plugin is not supported on this platform' )
end
-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
