local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='goprezzo', publisherId='com.goprezzo' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--   local goprezzo = require "plugin_goprezzo"
--   goprezzo.test()
--    
--local testLib = require "DLLTEST"
local initCalled=false
local checkIn=false
local isSessionCreated=false
local submitScoreAsync=false
local claimScore=false


lib.init = function(gameid,value1,value2,listener)
	initCalled = true
	isSessionCreated = true
	print( 'Init called.' )
	print( 'Set sessionCreated to true.' )
	print(gameid)
	print(value1)
	print(value2)
	return initCalled
end

lib.submitScoreAsync = function()
	-- The values passed in
	print( 'submitScoreAsync called with values:' )
	-- check if init has been called
	if initCalled then
		submitScoreAsync = true
		return submitScoreAsync
	else	
		native.showAlert( 'Sorry!' , 'Plugin not initiated!' , { 'OK' })
	end
end

lib.checkIn = function(value1,value2,value3)
	print( 'checkIn called with values:' )
	print(value1)
	print(value2)
	print(value3)

	if initCalled then
		checkIn = true
		return checkIn
	else	
		native.showAlert( 'Sorry!' , 'Plugin not initiated!' , { 'OK' })
	end
end

lib.claimScore = function()

	if initCalled and checkIn then
		native.showAlert( 'Claim Score Success!' , 'Claim score completed, however the Windows Simulator does not support the WebView to display goprezzo...' , { 'OK' })
		claimScore = true
		return claimScore
	else
		if initCalled==false then	
			native.showAlert( 'Sorry!' , 'Plugin not initiated!' , { 'OK' })
		end	
		if checkIn==false then
			native.showAlert( 'Sorry!' , 'Score have not been checked in, please call checkIn method!' , { 'OK' })
		end
	end
end

lib.sessionCreated = function()
	return isSessionCreated
end

lib.expireSession = function()
	print( 'expireSession called.' )
end
-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
