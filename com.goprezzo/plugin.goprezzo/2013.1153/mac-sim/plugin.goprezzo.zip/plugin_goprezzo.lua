local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='goprezzo', publisherId='com.goprezzo' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--   local goprezzo = require "plugin_goprezzo"
--   goprezzo.test()
--    
--local testLib = require "DLLTEST"

-- URL of the spoof GoPrezzo page
local url = "http://goprezzo.com/mock/"

-- Variables to simulate whether methods are called
local initCalled=false
local checkIn=false
local isSessionCreated=false
local submitScoreAsync=false
local claimScore=false


lib.init = function(gameid,value1,value2,listener)
	initCalled = true
	isSessionCreated = true
	print( 'Init called.' )
	print( 'Set sessionCreated to true.' )
	print(gameid)
	print(value1)
	print(value2)
	return initCalled
end

lib.submitScoreAsync = function()
	-- check if init has been called
	if initCalled then
		submitScoreAsync = true
		return submitScoreAsync
	else	
		native.showAlert( 'Sorry!' , 'Plugin not initiated!' , { 'OK' })
	end
end

lib.checkIn = function()
	if initCalled then
		checkIn = true
		return checkIn
	else	
		native.showAlert( 'Sorry!' , 'Plugin not initiated!' , { 'OK' })
	end
end

-- Listener to close webView when close button is hit
-- Also Handles when an error occurs within the webView
local function listener( event )
    local shouldLoad = true

    local url = event.url
    if 1 == string.find( url, "corona:close" ) then
        -- Close the web popup
        shouldLoad = false
    end

    if event.errorCode then
        -- Error loading page
        print( "Error: " .. tostring( event.errorMessage ) )
        shouldLoad = false
    end

    return shouldLoad
end

local options =
	{
    	hasBackground=false,
    	baseUrl=system.DocumentsDirectory,
    	urlRequest=listener
	}
-- Loads the webView with the URL and adds an event listener for closing webView
local function loadWebPage()
	native.showWebPopup(url,options)
end

-- NetworkListener for errors connecting to server 
-- and when HTTP request was unsuccessful
local function networkListener(event)
	if(event.isError) then
		--error
		native.showAlert( 'Sorry!' , 'Error Connecting to Server' , { 'OK' } )
	else
		if event.status == 200 then
			print("Loading Webpage...")
			loadWebPage()
		else
			native.showAlert( 'Sorry!' , 'Status Code:' .. event.status, { 'OK' } )
		end
	end	
end		

lib.claimScore = function()

	if initCalled and checkIn then

		network.request(url,"GET",networkListener)

		claimScore = true
		return claimScore
	else
		if initCalled==false then	
			native.showAlert( 'Sorry!' , 'Plugin not initiated!' , { 'OK' })
		end	
		if checkIn==false then
			native.showAlert( 'Sorry!' , 'Score have not been checked in, please call checkIn method!' , { 'OK' })
		end
	end
end

lib.sessionCreated = function()
	return isSessionCreated
end

lib.expireSession = function()
	print( 'expireSession called.' )
end
-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
