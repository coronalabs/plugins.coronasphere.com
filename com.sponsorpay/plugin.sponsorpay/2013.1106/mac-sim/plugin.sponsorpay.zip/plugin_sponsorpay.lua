local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.sponsorpay', publisherId='com.sponsorpay' }

lib.start= function()
	print( "WARNING: The 'plugin.sponsorpay' library is not available on this platform." )
	print( "WARNING: sponsorpay.start() will not return a valid token" )

	return "not-a-token"
end

lib.launchOfferWall = function()
	print( "WARNING: The 'plugin.sponsorpay' library is not available on this platform." )
	print( "WARNING: sponsorpay.launchOfferWall() does not do anything" )
end

lib.requestNewCoins = function()
	print( "WARNING: The 'plugin.sponsorpay' library is not available on this platform." )
	print( "WARNING: sponsorpay.requestNewCoins() does not do anything" )
end

lib.reportActionCompletion = function()
	print( "WARNING: The 'plugin.sponsorpay' library is not available on this platform." )
	print( "WARNING: sponsorpay.reportActionCompletion() does not do anything" )
end

lib.shouldShowVCSRewardNotification = function()
	print( "WARNING: The 'plugin.sponsorpay' library is not available on this platform." )
	print( "WARNING: sponsorpay.shouldShowVCSRewardNotification() does not do anything" )
end

lib.requestMBEOffers= function()
	print( "WARNING: The 'plugin.sponsorpay' library is not available on this platform." )
	print( "WARNING: sponsorpay.requestMBEOffers() will always return false" )

	return false
end

lib.startMBEEngagement= function()
	print( "WARNING: The 'plugin.sponsorpay' library is not available on this platform." )
	print( "WARNING: sponsorpay.startMBEEngagement() will always return false" )

	return false
end

lib.setShowMBERewardNotification = function()
	print( "WARNING: The 'plugin.sponsorpay' library is not available on this platform." )
	print( "WARNING: sponsorpay.setShowMBERewardNotification() does not do anything" )
end

lib.errorEventHandler = function()
	print( "WARNING: The 'plugin.sponsorpay' library is not available on this platform." )
	print( "WARNING: sponsorpay.errorEventHandler() does not do anything" )
end

lib.getPluginVersion = function()
	print( "WARNING: The 'plugin.sponsorpay' library is not available on this platform." )
	print( "WARNING: sponsorpay.getPluginVersion() will not return a version string" )

	return "not-a-version-string"
end

lib.enableLogging = function()
	print( "WARNING: The 'plugin.sponsorpay' library is not available on this platform." )
	print( "WARNING: sponsorpay.enableLogging() does not do anything" )
end


-- Return an instance
return lib
