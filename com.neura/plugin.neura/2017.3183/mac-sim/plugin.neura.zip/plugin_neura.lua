local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='neura', publisherId='com.neura' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------

local function unavailible()
	print("WARNING: plugin.neura is not availible for this platform.")
end

local function unavailibleReturnEmptyString()
	print("WARNING: plugin.neura is not availible for this platform.")
	return ""
end

local function unavailibleReturnEmptyArray()
	print("WARNING: plugin.neura is not availible for this platform.")
	return {}
end

local function unavailibleReturnFalse()
	print("WARNING: plugin.neura is not availible for this platform.")
	return false
end

lib.addDevice = unavailible
lib.addPlace = unavailible
lib.authenticate = unavailible
lib.connect = unavailible
lib.disconnect = unavailible
lib.enableAutomaticallySyncLogs = unavailible
lib.enableNeuraHandingStateAlertMessages = unavailible
lib.forgetMe = unavailible
lib.getAppPermissions = unavailible
lib.getDailySummary = unavailible
lib.getKnownCapabilities = unavailibleReturnEmptyArray
lib.getKnownDevices = unavailible
lib.getLocationBasedEvents = unavailibleReturnEmptyArray
lib.getMissingDataForEvent = unavailible
lib.getPermissionStatus = unavailible
lib.getSdkVersion = unavailibleReturnEmptyString
lib.getSleepProfile = unavailible
lib.getSubscriptions = unavailible
lib.getUserDetails = unavailible
lib.getUserPhone = unavailible
lib.getUserPlaceByLabelType = unavailibleReturnEmptyArray
lib.getUserSituation = unavailible
lib.hasDeviceWithCapability = unavailibleReturnFalse
lib.isLoggedIn = unavailibleReturnFalse
lib.isMissingDataForEvent = unavailibleReturnFalse
lib.registerFirebaseToken = unavailible
lib.removeSubscription = unavailible
lib.sendFeedbackOnEvent = unavailible
lib.shouldSubscribeToEvent = unavailibleReturnFalse
lib.simulateAnEvent = unavailible
lib.subscribeToEvent = unavailible

lib.setReminder = unavailible
lib.cancelReminder = unavailible
lib.snoozeReminder = unavailible
lib.clearNotification = unavailible
lib.getPluginVersion = function()
	return "1.0.40"
end
-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
