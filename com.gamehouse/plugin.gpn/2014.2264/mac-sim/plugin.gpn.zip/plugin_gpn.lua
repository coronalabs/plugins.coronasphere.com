local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='gpn', publisherId='com.gamehouse' }

-- gpn.init( listener, options )
lib.init = function( listener, options )
	return false
end

-- gpn.startRequestingInterstitials( )
lib.startRequestingInterstitials = function( )
	return false
end

-- gpn.presentInterstitial( options )
lib.presentInterstitial = function( options )
	return "not_presented"
end

-- gpn.stopRequestingInterstitials( )
lib.stopRequestingInterstitials = function()
	return false
end

-- gpn.setShouldKillOnLowMemory( flag )
lib.setShouldKillOnLowMemory = function( flag )
	return false
end

-- gpn.debugSetAppId( appId )
lib.debugSetAppId = function( appId )
	return false
end

-- gpn.debugGetBaseURL( baseURL )
lib.debugGetBaseURL = function( baseURL )
	return false
end

return lib
