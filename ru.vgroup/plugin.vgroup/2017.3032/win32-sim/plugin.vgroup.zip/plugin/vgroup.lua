local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='vgroup', publisherId='ru.vgroup' }

local defaults = require "plugin.vgroup.defaults"

------ INFO ------
-- version : 1.0Beta;
-- release : 21.09.2019
------------------


--globals
	_main = display.newGroup()

--FUNCTIONS

	function A( obj,name,dad )
		--test
		if( type(obj)=="table" ) then
			--add name to <obj>
			if( name ) then
				obj.name = name
			else
				obj.name = '<NOUN>'
			end

			--присваивание к dad
			if( dad ) then
				if( dad.numChildren ) then
					dad:insert( obj )
				else
					print("vgroup: arg #3 is not a group")
				end
			else
				_main:insert( obj )
			end

			return obj
		else
			print("vgroup: please insert object as arg #1")
		end

	end

	function F( ... )

		local chName = ""
		local chGroup = _main
		local chObj = nil
		local b = 0

		if( type(arg[1])=='table' ) then
			chGroup = arg[1]
			b = 1
		end
		
		--search obj in layer
		for i=1+b,#arg do
			chName = arg[i]
			if( type(chName)=='string' ) then
				for a=1,chGroup.numChildren do
					if( chGroup[a].name==chName ) then
						chObj = chGroup[a]
						break;
					end
				end
			elseif( type(chName)=='number' ) then
				chObj = chGroup[chName]
			end


			if( not(i<#arg and chObj.numChildren ) ) then
				break;
			else
				chGroup = chObj
				chObj = nil
			end
		end

		return chObj
	end


--[[
	DOCUMENTATION
	doc-A( <obj>,"name",<dad> ) - create object <obj> with name "name" in object <dad>
	doc-F( [<dad>,]arg1... ) - found file using names in object <dad>. args can be numbers or strings
	default <dad> is group _main
]]--