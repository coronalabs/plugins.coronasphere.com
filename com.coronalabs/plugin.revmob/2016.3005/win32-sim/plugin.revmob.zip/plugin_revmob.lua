local library = require("CoronaLibrary")

-- Create library
local lib = library:new{name = "plugin.revmob", publisherId = "com.coronalabs", version = 1.0}

-- Default implementations
local function defaultFunction()
	print("WARNING: The '" .. lib.name .. "' library is not available on this platform.")
end

-- Stub functions
lib.init = defaultFunction
lib.startSession = defaultFunction
lib.setUserDetails = defaultFunction
lib.load = defaultFunction
lib.isLoaded = defaultFunction
lib.show = defaultFunction
lib.hide = defaultFunction

return lib
