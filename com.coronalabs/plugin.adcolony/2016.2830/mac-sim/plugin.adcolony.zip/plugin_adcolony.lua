-- AdColony plugin

local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name="plugin.adcolony", publisherId="com.coronalabs" }

-------------------------------------------------------------------------------
-- BEGIN
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local adcolony = require "plugin.adcolony"
--    adcolony.init()
--    

local function showWarning(functionName)
    print( functionName .. " WARNING: The AdColony plugin is only supported on Android & iOS devices. Please build for device")
end

function lib.init()
    showWarning("adcolony.init()")
end

function lib.isLoaded()
    showWarning("adcolony.isLoaded()")
end

function lib.isAdVisible()
    showWarning("adcolony.isAdVisible()")
end

function lib.show()
    showWarning("adcolony.show()")
end

function lib.hide()
    showWarning("adcolony.hide()")
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
