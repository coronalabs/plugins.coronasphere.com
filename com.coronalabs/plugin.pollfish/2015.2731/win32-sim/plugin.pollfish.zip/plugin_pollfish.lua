-- Pollfish plugin

local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.pollfish', publisherId='com.coronalabs' }

-------------------------------------------------------------------------------
-- BEGIN
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local PLUGIN_NAME = require "plugin_PLUGIN_NAME"
--    PLUGIN_NAME:showPopup()
--    

local function showWarning()
    print( 'WARNING: The Pollfish plugin is only supported on Android & iOS devices. Please build for device' );
end

function lib.init()
    showWarning()
end

function lib.isLoaded()
    showWarning()
end

function lib.load()
    showWarning()
end

function lib.show()
    showWarning()
end

function lib.hide()
    showWarning()
end

function lib.setUserDetails()
    showWarning()
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
