-- Appodeal plugin

local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name="plugin.appodeal", publisherId="com.coronalabs", version=3 }

-------------------------------------------------------------------------------
-- BEGIN
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local appodeal = require "plugin.appodeal"
--    appodeal.init()
--    

local function showWarning(functionName)
    print( functionName .. " WARNING: The Appodeal plugin is only supported on Android, iOS and tvOS devices. Please build for device")
end

function lib.init()
    showWarning("appodeal.init()")
end

function lib.show()
    showWarning("appodeal.show()")
end

function lib.hide()
    showWarning("appodeal.hide()")
end

function lib.load()
    showWarning("appodeal.load()")
end

function lib.isLoaded()
    showWarning("appodeal.isLoaded()")
end

function lib.setUserDetails()
    showWarning("appodeal.setUserDetails()")
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
