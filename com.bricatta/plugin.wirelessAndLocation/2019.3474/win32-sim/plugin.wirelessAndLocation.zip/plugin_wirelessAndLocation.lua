local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.wirelessAndLocation', publisherId='com.bricatta' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local PLUGIN_NAME = require "plugin_PLUGIN_NAME"
--    PLUGIN_NAME.test()
--    
local function defaultFunction()
--	native.showAlert( 'Hello, World!', 'PLUGIN_NAME.test() invoked', { 'OK' } )
	print( 'Warning : This function is only available on Android devices.' )
end


lib.getLocationProviders = defaultFunction
lib.openGpsSettings = defaultFunction
lib.equestTurnOnGps = defaultFunction		-- ( gpsListenerPermission )
lib.startGpsListener = defaultFunction		-- ( gpsListener , {gpsMinTime = "500", gpsMinDistance = "2" })
lib.openBluetoothSettings = defaultFunction
lib.openWifiSettings = defaultFunction
lib.setupNewWifi = defaultFunction			-- ( { ssid = 'testssid' , password = 'nonessid' } )
lib.getWifiConnectionInfo = defaultFunction
lib.getWifiScanInfo = defaultFunction		-- ( scanResultsListener )
lib.getWifiDhcpAndConfiguredNetworksInfo = defaultFunction









-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
