local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='inmobi', publisherId='com.inmobi' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation startine here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
-- local inmobi = require "plugin_inmobi"
-- inmobi.initWithParams( appId [, listener] [, optionalParams] )
-- local banner = inmobi.createBannerAd("adSize" [, optionalParams])
-- 		 banner.show()
-- local interstial = inmobi.createInterstitialAd( options )
-- 		 interstitial.load()
-- 		 interstitial.show()
-- local analytics = inmobi.getAnalytics()
-- 		 analytics.startSessionManually()
--    	 analytics.stopSessionManually()
--    	 analytics.beginSection("sectionName" [, params])
--    	 analytics.endSection("sectionName" [, params])
--    	 analytics.tagEvent("eventName" [, params])
-- 
lib.initWithParams = function(...)
        native.showAlert( 'InMobi Plugin!', 'inmobi.initWithParams() invoked', { 'OK' } )
        print( 'initWithParams method will initialize InMobi with __appId__ provided' )
end

lib.createBannerAd = function(...)
        native.showAlert( 'InMobi Plugin!', 'inmobi.createBannerAd() invoked', { 'OK' } )
        print( 'createBannerAd method will display banner ad with specified size.' )
        return {
	        show = function()
	        	print('will display banner ad.')
	        end,
	        hide = function()
	        	print('will hide banner ad.')
	        end
	    }
end

lib.createInterstitialAd = function(...)
        native.showAlert( 'InMobi Plugin!', 'inmobi.createInterstitialAd() invoked', { 'OK' } )
        print( 'createInterstitialAd method will display interstitial ad.' )
        return {
	        load = function()
	        	print('will load interstitial ad. load method will not display interstitial ad.')
	        end,
	        show = function()
	        	print('will display interstitial ad.')
	        end
	    }
end

lib.getAnalytics = function()
        native.showAlert( 'InMobi Plugin!', 'inmobi.getAnalytics() invoked', { 'OK' } )
        print( 'getAnalytics method will return the analytics related methods.' )
        return {
	        startSessionManually = function( ... )
	        	print('analytics - startSessionManually is called ')
	        end,
	        stopSessionManually = function( ... )
	        	print('analytics - stopSessionManually is called ')
	        end,
	        beginSection = function( ... )
	        	print('analytics - beginSection is called ')
	        end,
	        endSection = function( ... )
	        	print('analytics - endSection is called ')
	        end,
	        tagEvent = function( ... )
	        	print('analytics - tagEvent is called ')
	        end
	    }
end

lib.CONSTANTS = {
	
}

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib