
local Library = require "CoronaLibrary"
local lib = Library:new{ name = "fortumo", publisherId = "com.fortumo" }

lib.VERSION = "9.2"
lib.BILLING_STATUS_NOT_SENT = 0
lib.BILLING_STATUS_PENDING = 1
lib.BILLING_STATUS_BILLED = 2
lib.BILLING_STATUS_FAILED = 3
lib.BILLING_STATUS_USE_ALTERNATIVE_METHOD = 4
lib.SERVICE_STATUS_UNKNOWN = 0
lib.SERVICE_STATUS_AVAILABLE = 1
lib.SERVICE_STATUS_UNAVAILABLE = 2
lib.PRODUCT_TYPE_CONSUMABLE = 0
lib.PRODUCT_TYPE_NON_CONSUMABLE = 1
lib.PRODUCT_TYPE_SUBSCRIPTION = 2

lib.newPaymentRequest = function()
	local request = { consumable = true, type = 0, creditsMultiplier = 1.0, icon = -1 }
	
	function request:setService(serviceId, appSecret)
		self.serviceId = serviceId
		self.appSecret = appSecret
	end
	
	function request:setConsumable(flag)
		print("WARNING: fortumo.setConsumable() is deprecated. Use setType()")
		self.consumable = flag
		
		if flag then
			self.type = 0
		else
			self.type = 1
		end
	end
	
	function request:setType(value)
		self.type = value
		
		if value == 1 then
			self.consumable = false
		else
			self.consumable = true
		end
	end
	
	function request:setCreditsMultiplier(value)
		self.creditsMultiplier = value
	end
	
	function request:setDisplayString(value)
		self.displayString = value
	end
	
	function request:setIcon(value)
		self.icon = value
	end
	
	function request:setPriceAmount(value)
		self.priceAmount = value
	end
	
	function request:setPriceCurrency(value)
		self.priceCurrency = value
	end
	
	function request:setProductName(value)
		self.productName = value
	end
	
	return request
end

lib.setLoggingEnabled = function(flag)
	print("WARNING: The 'plugin.fortumo' library is not available on this platform.")
	print("WARNING: fortumo.setLoggingEnabled() does not do anything")
end

lib.setStatusChangeListener = function(listener)
	print("WARNING: The 'plugin.fortumo' library is not available on this platform.")
	print("WARNING: fortumo.setStatusChangeListener() does not do anything")
end

lib.findService = function(request, listener)
	print("WARNING: The 'plugin.fortumo' library is not available on this platform.")
	print("WARNING: fortumo.findService() does not do anything")
	
	local function cb(event)
    	local response = { serviceStatus = 0, serviceId = request.serviceId }
		
    	listener(response)
	end
	
	timer.performWithDelay(1000, cb)
end

lib.findPaymentHistory = function(request, listener)
	print("WARNING: The 'plugin.fortumo' library is not available on this platform.")
	print("WARNING: fortumo.findPaymentHistory() does not do anything")
	
	if listener ~= nil then
		local function cb(event)
			local response = { serviceStatus = 0, serviceId = request.serviceId, payments = { } }
			
    		listener(response)
		end
		
		timer.performWithDelay(1000, cb)
	end
end

lib.makePayment = function(request, listener)
	print("WARNING: The 'plugin.fortumo' library is not available on this platform.")
	print("WARNING: fortumo.makePayment() does not do anything")
	
	if listener ~= nil then
		local function cb(event)
    		local response = { billingStatus = 0, serviceId = request.serviceId, productName = request.productName }
			
    		listener(response)
		end
		
		timer.performWithDelay(1000, cb)
	end
end

lib.findPayment = function(request, listener)
	print("WARNING: The 'plugin.fortumo' library is not available on this platform.")
	print("WARNING: fortumo.findPayment() does not do anything")
	
	if listener ~= nil then
		local function cb(event)
			local response = { billingStatus = 0, serviceId = request.serviceId, productName = request.productName }
			
    		listener(response)
		end
		
		timer.performWithDelay(1000, cb)
	end
end

return lib