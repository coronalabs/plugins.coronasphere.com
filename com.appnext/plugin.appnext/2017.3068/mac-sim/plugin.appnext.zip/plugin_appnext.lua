local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.appnext', publisherId='com.appnext' }

-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local appnext = require "plugin.appnext"
--    appnext.init()
--    

lib.init = defaultFunction
lib.getApiVersion = defaultFunction
lib.createAd = defaultFunction
lib.loadAd = defaultFunction
lib.showAd = defaultFunction

lib.adIsLoaded = defaultFunction
lib.setCategories = defaultFunction
lib.getCategories = defaultFunction
lib.setPostback = defaultFunction
lib.getPostback = defaultFunction
lib.setButtonText = defaultFunction
lib.getButtonText = defaultFunction
lib.setButtonColor = defaultFunction
lib.getButtonColor = defaultFunction
lib.setBackButtonCanClose = defaultFunction
lib.getBackButtonCanClose = defaultFunction
lib.setCreativeType = defaultFunction
lib.getCreativeType = defaultFunction
lib.setSkipText = defaultFunction
lib.getSkipText = defaultFunction
lib.setAutoPlay = defaultFunction
lib.getAutoPlay = defaultFunction
lib.setProgressType = defaultFunction
lib.getProgressType = defaultFunction
lib.setProgressColor = defaultFunction
lib.getProgressColor = defaultFunction
lib.setVideoLength = defaultFunction
lib.getVideoLength = defaultFunction
lib.setCloseDelay = defaultFunction
lib.getCloseDelay = defaultFunction
lib.setShowClose = defaultFunction
lib.getShowClose = defaultFunction
lib.setMute = defaultFunction
lib.getMute = defaultFunction
lib.setPreferredOrientation = defaultFunction
lib.getPreferredOrientation = defaultFunction
lib.setRewardsTransactionId = defaultFunction
lib.getRewardsTransactionId = defaultFunction
lib.setRewardsUserId = defaultFunction
lib.getRewardsUserId = defaultFunction
lib.setRewardsRewardTypeCurrency = defaultFunction
lib.getRewardsRewardTypeCurrency = defaultFunction
lib.setRewardsAmountRewarded = defaultFunction
lib.getRewardsAmountRewarded = defaultFunction
lib.setRewardsCustomParameter = defaultFunction
lib.getRewardsCustomParameter = defaultFunction

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
