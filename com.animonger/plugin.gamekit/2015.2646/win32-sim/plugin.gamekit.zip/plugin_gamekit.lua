local Library = require('CoronaLibrary')

-- Create sub library for simulator
local lib = Library:new{ name='plugin.gamekit', publisherId='com.animonger' }

local function default()
	native.showAlert( 'GameKit Plugin Warning', 'The GameKit plugin is not supported in the simulator, please use iOS device only.', { 'OK' } )
    print("WARNING: The GameKit plugin is not supported in the simulator, please use iOS device only.")
end

-- assign gamekit functions to default function
lib.init = default
lib.show = default
lib.request = default
lib.send = default
lib.get = default
lib.sendRealTimeDataToAllPlayers = default
lib.submit = default

return lib