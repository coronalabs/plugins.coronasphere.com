-- to use: local greenthrottle = require "plugin.greenthrottle"
--greenthrottle stub file for simulator

-- Create library
local Library = require "CoronaLibrary"
local lib = Library:new{ name='plugin.greenthrottle', publisherId='com.greenthrottle' }

lib.BUTTON_A = 0
lib.BUTTON_B = 1
lib.BUTTON_Y = 2
lib.BUTTON_X = 3
lib.BUTTON_DOWN = 4
lib.BUTTON_UP = 5
lib.BUTTON_LEFT = 6
lib.BUTTON_RIGHT = 7
lib.BUTTON_L1 = 8
lib.BUTTON_L2 = 9
lib.BUTTON_L3 = 10
lib.BUTTON_R1 = 11
lib.BUTTON_R2 = 12
lib.BUTTON_R3 = 13
lib.BUTTON_ANALOG_LEFT_UP = 14
lib.BUTTON_ANALOG_LEFT_DOWN = 15
lib.BUTTON_ANALOG_LEFT_LEFT = 16
lib.BUTTON_ANALOG_LEFT_RIGHT = 17
lib.BUTTON_ANALOG_RIGHT_UP = 18
lib.BUTTON_ANALOG_RIGHT_DOWN = 19
lib.BUTTON_ANALOG_RIGHT_LEFT = 20
lib.BUTTON_ANALOG_RIGHT_RIGHT = 21
lib.BUTTON_BACK = 22
lib.BUTTON_START = 23
lib.BUTTON_GTHOME = 24

lib.CONTROLLER_1 = 0
lib.CONTROLLER_2 = 1
lib.CONTROLLER_3 = 2
lib.CONTROLLER_4 = 3

lib.BUTTON_STATE_HELD = 0
lib.BUTTON_STATE_DOWN = 1
lib.BUTTON_STATE_UP = 2

lib.ANALOG_LEFT = 0
lib.ANALOG_RIGHT = 1
lib.ANALOG_L2 = 2
lib.ANALOG_R2 = 3

lib.ANALOG_AXIS_X = 0
lib.ANALOG_AXIS_Y = 0

notWritten = true

function stub()
	if notWritten then
		print( "GreenThrottle Stub called, all functions do nothing")
		notWritten = false
	end

end

-- Create a function for the library
lib.getButtonState = function(state, controllerId, button)
	stub()
	return 0
end

lib.getAnalogState = function(axis, controllerId, control)
	stub()
	return 0
end

lib.getAnalogChanged = function(controllerId, control)
	stub()
	return false
end

lib.getConnectedState = function(controllerId)
	stub()
	return false
end

lib.getServiceConnected = function()
	stub()
	return false
end

lib.clearControllerState = function(controllerId)
	stub()
end

lib.addLeftButtonRemap = function()
	stub()
end

lib.removeLeftButtonRemap = function()
	stub()
end

lib.addRightButtonRemap = function()
	stub()
end

lib.removeRightButtonRemap = function()
	stub()
end

lib.hideAndroidSystemUI = function()
	stub()
end

lib.startFrame = function()
	stub()
end

-- Return lib instead of using 'module()' which pollutes the global namespace
return lib
