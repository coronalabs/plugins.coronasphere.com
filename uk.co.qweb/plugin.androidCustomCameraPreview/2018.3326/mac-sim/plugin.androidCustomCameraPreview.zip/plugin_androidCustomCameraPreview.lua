local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='androidCustomCameraPreview', publisherId='uk.co.qweb' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------

lib.start = function()
	print( 'On Android, start() would be invoked now.' )
	return true
end

lib.stop = function()
	print( 'On Android, stop() would be invoked now.' )
	return true
end

lib.status = function()
	print( 'On Android, status() would be invoked now.' )
	return "waiting"
end

lib.text = function(position, message)
	print( 'On Android, text() would be invoked now.' )
end

lib.image = function(filename)
	print( 'On Android, image() would be invoked now.' )
end

lib.photo = function()
	print( 'On Android, photo() would be invoked now.' )
	return ""
end

lib.photoStatus = function()
	print( 'On Android, photoStatus() would be invoked now.' )
	return "waiting"
end

lib.cameras = function()
	print( 'On Android, cameras() would be invoked now.' )
	return {}
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
