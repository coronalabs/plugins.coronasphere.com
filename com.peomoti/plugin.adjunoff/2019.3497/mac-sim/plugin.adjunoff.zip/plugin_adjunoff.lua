local Library = require "CoronaLibrary"

-- Create stub library for simulator
local adjust = Library:new{ name='plugin.adjunoff', publisherId='com.peomoti' }

-- Default implementations
local function defaultFunction(...)
print( "WARNING: The '" .. adjust.name .. "' library is not available on this platform." )
end

adjust.init = defaultFunction
adjust.signIn = defaultFunction
adjust.silentSignIn = defaultFunction
adjust.signOut = defaultFunction

adjust.trackEvent = defaultFunction
adjust.setOfflineMode = defaultFunction
adjust.setEnabled = defaultFunction
adjust.isEnabled = defaultFunction
adjust.getAdid = defaultFunction
adjust.getGoogleAdId = defaultFunction
adjust.getAmazonAdId = defaultFunction
adjust.getIdfa = defaultFunction
adjust.getAttribution = defaultFunction
adjust.setAttributionListener = defaultFunction
adjust.setAttributionListener = defaultFunction
adjust.setEventTrackingSuccessListener = defaultFunction
adjust.setEventTrackingFailureListener = defaultFunction
adjust.setSessionTrackingSuccessListener = defaultFunction
adjust.setSessionTrackingFailureListener = defaultFunction
adjust.setDeferredDeeplinkListener = defaultFunction
adjust.addSessionCallbackParameter = defaultFunction
adjust.removeSessionCallbackParameter = defaultFunction
adjust.resetSessionCallbackParameters = defaultFunction
adjust.addSessionPartnerParameter = defaultFunction
adjust.removeSessionPartnerParameter = defaultFunction
adjust.resetSessionPartnerParameters = defaultFunction
adjust.create = defaultFunction




-- Return an instance
return adjust