print('WARNING: Plugin should not be imported directly. Use `system.getPreference( "app", "install_referrer", "string" )` to retrieve referrer')
return {}
