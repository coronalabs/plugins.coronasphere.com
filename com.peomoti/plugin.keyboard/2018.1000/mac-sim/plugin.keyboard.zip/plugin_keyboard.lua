local Library = require "CoronaLibrary"

-- Create stub library for simulator
local keyboard = Library:new{ name='plugin.keyboard', publisherId='com.peomoti' }

-- Default implementations
local function defaultFunction(...)
print( "WARNING: The '" .. keyboard.name .. "' library is not available on this platform." )
end

keyboard.getHeight = defaultFunction




-- Return an instance
return keyboard