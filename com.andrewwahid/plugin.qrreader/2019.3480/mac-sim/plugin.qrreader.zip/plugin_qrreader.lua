local lib = require('CoronaLibrary'):new{name = 'plugin.qrreader', publisherId = 'com.andrewwahid'}

lib.startScan = function()
	print('WARNING plugin.qrreader: startScan() is not supported on this platform.')
end

return lib