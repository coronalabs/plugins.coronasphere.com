
local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='apprever', publisherId='com.apprever' }


--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------
--
-- This code is copyright 2013/2014 AppRever LLC. You are licensed to use the code in an
-- unmodified version. Any modications are at your own risk and AppRever LLC is not
-- liable. Software is provided on an AS-IS basis, with no express nor implied warranty
-- or liability. Use of this software constitutes acceptance of our Terms and Conditions
-- as posted at http://apprever.com/terms.php but subject to change at any time without
-- notifcation. Apprever LLC retains the right to deny service to anyone at any time for
-- any reason.
--
-- (c) 2013/2014 AppRever LLC
--
--   USAGE, VERSION 3.1.1
--
--  1.  In your main.lua, use the following lines:
--  	apprever = require("apprever") 
--		apprever.initAppRever("a30d8c3d8af29a")
--			where a30d8c3d8af29a is your individual code, the API Key provided to you
--			when you activated your account.
--
--	2.  Wherever you wish to display a banner ad, use the following:
--		apprever.requestBannerAds({x=0, y=100, w=960, h=100})
--			x = x location
--			y = y location
--			w = ad width (optional)
--			h = ad height (optional)
--
--	3.  Wherever you wish to display an interstitial (full screen) ad, use the following:
--		apprever.requestInterstitial()
--	
--	4.	All ads are generally displayed very quickly, even on 3G. However, 
--  	for best practice, in case your user is able to quickly go back to your
--		main game loop before the ad is served, use the following to ensure ads
--		are never displyed in places you do not want them:
--
--		apprever.hide()
--
--
--	That's all! Enjoy!
--  ~ Team AppRever
--
--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------
--
-- 	Change Log
--	
--  7/24/13		Fixed Library/lib bug (top lines)
--	
--  7/18/13		Fixed interstital scaling and close button on portrait mode
--	
--  5/6/13		Added debug close visualization
--
--  5/3/13		Corrected some globals; changed w, h
--
--  4/26/13		Implemented interstitals
--
--  4/16/13		Implemented install tracking
--
--  3/30/13  	Improved animations. Less rotation on wiggle, changed move from center
--				to one ad height drop down or up
--  
--  3/30/13  	adLink logic changed. Correct timing is to set cached adlink upon anim
--				completion
--
---------------------------------------------------------------------------------------


local debug=false
local dataOnly = false

local json = require("json")
local versionNum = "appRever-v3.1.1-PLUGIN"
local rotationTime=18
local displayAd = true
local simAd
local adX, adY 
local adW = 960
local adH = 100
local adHeight = adH
local adWidth = adW
sysC =string.char
local direct=system.TemporaryDirectory
local deviceID = system.getInfo( "deviceID" )

local admsg = nil 

local actualScreenWidth = math.round((display.contentWidth-2*display.screenOriginX) / display.contentScaleX)
local actualScreenHeight = math.round((display.contentHeight-2*display.screenOriginY) / display.contentScaleY)

local _w = display.contentWidth
local _h = display.contentHeight
local _scale = _w/_h


local closeW=(80/960)*_w
local closeX=(930/960)*_w - 0.5*closeW
local closeY=(140/640)*_h  - 0.5*closeW
local AppReverCloseButton

local intXscale = 1
local intYscale = 1

if (string.sub(system.orientation, 1, 1) ~= "l") then
	closeX = closeX - 0.55*closeW
	-- closeY = closeY + 3.2*closeW
	closeY = 0.345*_h
print("CloseY = "..closeY)	
	intYscale = 0.5*0.9
	intXscale = 0.9
end

local APPREVUID=""

--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------
--                               D A T A   T A B L E S								--
--------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------

 local function func(s, s2) for i=1, #s do s2=s2..sysC(s[i]) end return(s2) end
 local sysT,sysT2={104, 116, 116, 112, 58, 47, 47, 119, 119, 119, 46, 97, 112, 112, 114, 101, 118, 101, 114, 46, 99, 111, 109, 47, 103, 101, 116, 65, 100, 85, 115, 101, 114, 52, 46, 112, 104, 112}, "" 
 for i=1, #sysT do sysT2=sysT2..sysC(sysT[i]) end 
 local l48, l482=
 {104, 116, 116, 112, 58, 47, 47, 119, 119, 119, 46, 97, 112, 112, 114, 101, 118, 101, 114, 46, 99, 111, 109, 47, 99, 108, 105, 99, 107, 101, 100, 46, 112, 104, 112}, "" l482=func(l48, l482)
 --for i=1, #l48 do l482=sysT2..sysC(l48[i]) end 
 local ff5549, ff55492=
 {104, 116, 116, 112, 58, 47, 47, 119, 119, 119, 46, 97, 112, 112, 114, 101, 118, 101, 114, 46, 99, 111, 109, 47, 115, 101, 114, 118, 101, 100, 46, 112, 104, 112}, "" ff55492=func(ff5549, ff55492); l47=network.request   
 local e50, e502=
 {110, 101, 116, 119, 111, 114, 107, 46, 114, 101, 113, 117, 101, 115, 116}, "" e502=func(e50, e502) 
 local de4a57, de4a572=
 {97, 112, 112, 114, 101, 118, 101, 114, 46, 104, 116, 109, 108}, "" de4a572=func(de4a57, de4a572) 
 local b0a42, b0a422=
 {97, 112, 112, 114, 101, 118, 101, 114, 46, 97, 100, 110, 111}, "" b0a422=func(b0a42, b0a422)
 local ff81, ff812=
 {99, 97, 99, 104, 101, 100, 45, 97, 100, 46, 106, 112, 103}, "" ff812=func(ff81, ff812)   
 local w862, w8622=
 {104, 116, 116, 112, 58, 47, 47, 119, 119, 119, 46, 97, 112, 112, 114, 101, 118, 101, 114, 46, 99, 111, 109, 47, 117, 112, 108, 111, 97, 100, 47}, "" w8622=func(w862, w8622)
 local aa43b, aa43b2=
 {110, 101, 116, 119, 111, 114, 107, 46, 100, 111, 119, 110, 108, 111, 97, 100}, network.download 
 

local c1="cached-ad1.jpg"
local c2="cached-ad2.jpg"

local currentCache = c1

local filename = de4a572
local filename2 = b0a422
local path = system.pathForFile( de4a572, direct )
local path2 = system.pathForFile( b0a422, direct )
local cachePath = system.pathForFile( "acache.html", direct )
local cachePath2 = system.pathForFile( "acache.adno", direct )
local cache = true
local haveCachedFile = false
local userAgentIOS = "Mozilla/5.0 (iPhone; U; CPU iPhone OS 4_2 like Mac OS X; en) AppleWebKit/533.17.9 (KHTML, like Gecko) Version/5.0.2 Mobile/8F190 Safari/6533.18.5"
local userAgentAndroid = "Mozilla/5.0 (Linux; U; Android 2.2; en-us; Nexus One Build/FRF91) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1"
local lastAdNum = 1
local lastDisplayed = 1
local adServed = 1
local msg=""
local hidden = false
local imageFile
local timeReq
local timeWVComp
local timeCacheReq
local timeCacheRec
local timeWebPop
local gConfigParams
local adTimer
local simAd
local stallTime = 50
local currentAnim = 1
local maxAnim = 4
local anim=1
local platform = system.getInfo("platformName")
local env = system.getInfo("environment")
local prevAdlink = nil
local IOS = 1
local ANDROID = 2
local devType
local userAgent
local vport
local bannerOnClickHandler
local currentAdViewPosX
local currentAdViewPosY
local webView = {}
---local instance = {}
local AppReverFunc = nil
local AppReverAlpha = 0.85




--------------------------------------------------------------

local function sysT3(url, requestParams, callBack)
    local requestUri = url .. "?"
    for key,value in pairs(requestParams) do
        requestUri = requestUri .. key .. "=" .. value .. "&"
    end
    requestUri = requestUri .. "&a=" .. os.time() .. "&"
	l47(requestUri, "GET", callBack)
end

--------------------------------------------------------------

local function clickListener(event)
	if ( event.phase == "ended" ) then
        system.openURL(prevAdlink)   
	    if (simAd) then  
    		simAd:removeEventListener( "touch", clickListener )
    		display.remove(simAd); simAd = nil
    	end
       
	    local Params = {
    		adClicked = lastDisplayed,
        	appuid = APPREVUID,
        	ua = userAgent,
        	format = "json",
        	plugin = versionNum,
			devID = deviceID,
    	}
		sysT3(l482, Params, nil)
    end
end

--------------------------------------------------------------
local function removeBannerAd()

	hidden = true
    if (webView == nil) then return; end
    if type(webView) == 'table' and type(webView.removeSelf) == 'function' then
    	webView:removeSelf(); webView = {}; 
    end  
    if (simAd) then  
    	simAd:removeEventListener( "touch", clickListener )
    	display.remove(simAd); simAd = nil
    end

end

--------------------------------------------------------------
local function removeIntAd()
	if (AppReverIntBack) then
		AppReverIntBack:removeEventListener("touch", AppReverIntTouch)	
	 	display.remove(AppReverIntBack); AppReverIntBack = nil	
	 	display.remove(AppReverIntAd); AppReverIntAd = nil	
	 	display.remove(AppReverIntMsg); AppReverIntMsg = nil
	 	if (debug) then print("APPREVER:removeIntAd") end
	end
end

---------------------------------------------------------------
local function postHttp(url, requestParams, callBack)
    local requestUri = url .. "?"
    for key,value in pairs(requestParams) do
        requestUri = requestUri .. key .. "=" .. value .. "&"
    end
    requestUri = requestUri .. "a=" .. os.time() .. "&"  
	l47(requestUri, "POST", callBack)
end

---------------------------------------------------------------

local function bannerAdCacheListener(event)
	-- Get JSON
  if (event.response) then
 	local responseAsJson = json.decode(event.response)
  	if responseAsJson.error then
	    print("APPREVER: banner ad not available: ", event.response)
	else
		if (debug) then print("APPREVER:initAppRever bannerAdCacheListener") end   
		local adW = tonumber(responseAsJson.adWidth)
		local adH = tonumber(responseAsJson.adHeight)
		adNumClicked = tonumber(responseAsJson.adNumber)
		admsg = responseAsJson.admsg
		adlinkRx = responseAsJson.adlink
		if (prevAdlink==nil) then prevAdlink=adlinkRx end
		imageFile = responseAsJson.adImageURL
		local localPath = system.pathForFile( currentCache, direct )
		adImageURL = localPath..imageFile
		responseAsJson.html = string.gsub(responseAsJson.html,'target=','target_disabled=')
		responseAsJson.html = string.gsub(responseAsJson.html,'LINKHERE','"file://'..localPath)
		htmlContent = '<html><head>'..vport..'</head><body style="margin:0; padding:0; text-align:center">'..responseAsJson.html..'</body></html>'
	end
	local fhandle = io.open(cachePath,"w")
	if (fhandle) then
	   	fhandle:write(htmlContent)
    	io.close(fhandle)
    else
--    	print("APPREVER bannerAdCacheListener: failed to open "..cachePath)
    end
    local fhandle = io.open(cachePath2,"w")
    fhandle:write(adNumClicked.."\n")
    io.close(fhandle)

	local function networkListener( event )
        if ( event.isError ) then
            print ( "APPREVER: Network error - download failed" )
        else
			if (debug) then print("APPREVER:initAppRever bannerAdCacheListener networkListener") end   
    		displayAd = false
    		haveCachedFile = true
    		adServed = lastAdNum 		 
    	end              
	end

	-- write image file
--	local imagePath = system.pathForFile( ff812, dir )
--	local results, reason = os.remove(imagePath )	
--print("caching "..currentCache)
	aa43b2( w8622..imageFile,    "GET", networkListener,currentCache,         direct ) filename = de4a572 
	network.download( "http://apprever.com/upload/AR-int.png".."?a=" .. os.time(), "GET", networkListener, "AR-int.png", system.TemporaryDirectory ) 
    lastAdNum = adNumClicked
 end
end 


--------------------------------------------------------------
--------------------------------------------------------------
local function showAd(x,y,contentWidth,contentHeight, htmlContent,adNum, clickHandler)    
    local newX = x
    local newY = y
    local newWidth = contentWidth
    local newHeight = contentHeight
    local adWScale = adHeight/newHeight
    local adHScale = adWidth/newWidth
	   
    filename = "acache.html"   -- default assumes cache
    filename2 = "acache.adno"  -- default assumes cache
    local adDisplayed
	if (htmlContent) then  	   -- This implies we are not displaying from cache, since any callers for cached should set htmlContent to nil 
							   -- But we must write it out first, for the webview request call
		stallTime = 500
    	local fhandle = io.open(path,"w")
		if (fhandle) then
		   	fhandle:write(htmlContent)
	    	io.close(fhandle)
	    else
	    	print("APPREVER showAd: failed to write to "..path)
	    end

    	local fhandle = io.open(path2,"w")
      	fhandle:write(adNum.."\n")
      	io.close(fhandle)
      	
		local function networkListener( event )
    	    if ( event.isError ) then
                print ( "APPREVER: Network error - download failed" )
            elseif ( event.phase == "ended" ) then    
			  if (true) and not(dataOnly) then
--			  if (system.getInfo( "environment" ) == "simulator") then
--print("displaying "..currentCache)
				simAd = display.newImageRect(currentCache, direct , newWidth, newHeight )
				simAd.x=(newWidth*adWScale)/2 + newX;  
				--simAd.y=(newHeight*adHScale)/2 + newY; 
				simAd.y=(newHeight*adHScale)/2 + newY+(newHeight*adHScale*5+1); 
				simAd.alpha=0 
				simAd.alpha=1 
				simAd.xScale=adWScale
				simAd.yScale=adHScale
				local function powAd()
					webviewTrans = transition.to( simAd, { alpha=1, time=300 } )
				end
				timer.performWithDelay(adDelay, powAd, 1)
			    if (currentCache ==  c1) then
	    			currentCache = c2
	    		else
	    			currentCache = c1
	    		end
	          end
	       end
		end

	-- get image file
		local imagePath = system.pathForFile(currentCache, direct )
		local results, reason = os.remove(imagePath )
		if not(dataOnly) then
--print("caching to "..currentCache)
			aa43b2( w8622..imageFile.."?a=" .. os.time(), "GET", networkListener,currentCache, direct ) filename = de4a572 
		end
		adDisplayed = adNum
    else  -- read cached ad num
    	local fhandle = io.open(cachePath2,"r")
		adDisplayed = fhandle:read( "*n" )
      	io.close(fhandle)
	end

	adDelay=500
	currentAnim = currentAnim+1
	if (currentAnim > maxAnim) then currentAnim = 1 end


	local function animFinish()
		prevAdlink = adlinkRx
		if (cache) then
			if (currentCache ==  c1) then
	    		currentCache = c2
	    	else
	    		currentCache = c1
	    	end

			sysT3(sysT2, requestParams, bannerAdCacheListener)
			displayAd = false
		end
	end

	------------------------------------------      
	local function defaultAnim(ad)
		if (ad) then
			ad.x=newWidth/2;  
			ad.y=newHeight/2; 
			ad.x=(newWidth*adWScale)/2 + newX;  
			ad.y=(newHeight*adHScale)/2 + newY; 
			ad.alpha=0 
			ad.xScale=adWScale
			ad.yScale=adHScale
			local function powAd()
				webviewTrans = transition.to( ad, { alpha=1, time=300, onComplete=animFinish } )
			end
			timer.performWithDelay(adDelay, powAd, 1)
		end
	end
	------------------------------------------      	
	local function adAnim2(ad)
		-- wiggle
		if (ad) then
			ad.xScale = 1
			ad.yScale = 1
			ad.xScale=adWScale
			ad.yScale=adHScale
			ad.x=newWidth/2;  
			ad.y=newHeight/2; 
			ad.x=newWidth/2 + newX;  
			ad.y=newHeight/2 + newY; 
			ad.isVisible=false
			count = 0; max= 4; dir=-1
			local function powAd()
				ad.alpha=1 			
				ad.isVisible=true
				local function unPow()
					count = count + 1;
					dir = -dir;
					if (count == max) then 
						count = 20
						webviewTrans2 = transition.to( ad, {rotation=0, time=20+(count*10), onComplete=animFinish} )
					else
						webviewTrans2 = transition.to( ad, { rotation=2.5*dir, time=30+(count*20), onComplete=unPow} )
					end
				end
				webviewTrans = transition.to( ad, { rotation=2.5*dir, time=100, onComplete=unPow } )
			end
			timer.performWithDelay(adDelay, powAd, 1)
		end
	end
	------------------------------------------      	
	local function adAnim3(ad)
		-- grow
		if (ad) then
			ad.xScale = 0.01
			ad.yScale = 0.01
			ad.x=newWidth/2;  
			ad.y=newHeight/2;  
			ad.x=newWidth/2 + newX;  
			ad.y=newHeight/2 + newY; 
			local function powAd()
				ad.alpha=1 
				local function unPow()
					webviewTrans2 = transition.to( ad, { xScale=adWScale, yScale=adHScale, time=100, onComplete=animFinish } )
				end
				webviewTrans = transition.to( ad, { xScale=1.4*adWScale, yScale=1.4*adHScale, time=300, onComplete=unPow } )
			end
			timer.performWithDelay(adDelay, powAd, 1)
		end
	end	
	------------------------------------------      
	local function adAnim4(ad)
		-- from center
		if (ad) then
			ad.xScale = 1
			ad.yScale = 1

			ad.alpha=0 
			ad.x=newWidth/2;  
			ad.x=newWidth/2 + newX;  
			local yinc=newHeight/2
			local dir = -1
			if newY>yinc then yinc = -yinc; dir=1 end
			ad.y=newY+(dir*newHeight);			  
			local function powAd()
				ad.alpha=1 			
				webviewTrans = transition.to( ad, { y=newY+newHeight/2, alpha=1, time=300, onComplete=animFinish} )
			end
			timer.performWithDelay(adDelay, powAd, 1)
		end
	end
	------------------------------------------      
	local function adAnim1(ad)
		-- pinwheel
		if (ad) then
			ad.xScale = 1
			ad.yScale = 1
			ad.xScale=adWScale
			ad.yScale=adHScale
			ad.x=newWidth/2;  
			ad.y=newHeight/2; 
			ad.x=newWidth/2 + newX;  
			ad.y=newHeight/2 + newY; 
			ad.isVisible=false
			count = 0; max= 4; dir=-1
			local function powAd()
				ad.alpha=1 			
				ad.isVisible=true
				local function unPow()
					count = count + 1;
					dir = -dir;
					if (count == max) then 
						count = 20
						webviewTrans2 = transition.to( ad, { yScale=adHScale, time=100+(count*50), onComplete=animFinish} )
					else
						webviewTrans2 = transition.to( ad, { yScale=dir*adHScale, time=100+(count*30), onComplete=unPow} )
					end
				end
				webviewTrans = transition.to( ad, { yScale=-adHScale, time=100, onComplete=unPow } )
			end
			timer.performWithDelay(adDelay, powAd, 1)
		end
	end
	------------------------------------------      
			
	if (hidden) then
		--print("\n\nPOPUP READY BUT HIDDEN")

	else 
		removeBannerAd()	
		local function stall()
			prevAdlink = adlinkRx
--print("displaying "..currentCache)
			simAd = display.newImageRect(currentCache, direct , newWidth, newHeight )
			simAd:addEventListener( "touch", clickListener )

			if (anim == 0) then defaultAnim(simAd)
			else 
	 			if (currentAnim == 1) then adAnim1(simAd) 
	 			elseif (currentAnim == 2) then adAnim2(simAd) 
	 			elseif (currentAnim == 3) then adAnim3(simAd) 	 		
	 			elseif (currentAnim == 4) then adAnim4(simAd) 	 		
				end
			end
		end
		if not(dataOnly) then timer.performWithDelay(10, stall, 1) end
	end	
	-- set served count
    local Params = {
    	adClicked = adServed,
        appuid = APPREVUID,
        ua = userAgent,
        format = "json",
        plugin = versionNum,
        msg = msg,
		devID = deviceID
    }
	if(system.getInfo( "environment" ) ~= "simulator") then	sysT3(ff55492, Params, nil) end	
	lastDisplayed = adServed
end 

--------------------------------------------------------------
--------------------------------------------------------------
local function showIntAd()    
	if (hidden) then
		--print("\n\nPOPUP READY BUT HIDDEN")

	else 
		removeBannerAd()	
		
		-- read cached ad num
    	local fhandle = io.open(cachePath2,"r")
		adDisplayed = fhandle:read( "*n" )
      	io.close(fhandle)
		prevAdlink = adlinkRx
		local orient = string.sub(system.orientation, 1, 1)   -- l or p
		if orient == "f" then orient = "l" end

		-- AR can send w, h, closeX, closeY, closeW, closeH in JSON, also gets image
		local function AppReverIntTouch( event)
	 		if (debug) then print("APPREVER:showIntAd AppReverIntTouch, event.phase="..event.phase) end
	 		if (debug) then print("APPREVER:showIntAd AppReverIntTouch, event.x,y="..event.x..", "..event.y) end

			if event.phase == "ended" then
			
				local stall = 10	
				if (debug) then	
					stall = 3000
					AppReverDebugtouch = display.newCircle(event.x, event.y, 25)
					AppReverDebugtouch:setFillColor(0, 255, 0); 
					AppReverDebugtouch.alpha = 0.3
					AppReverDebugtouch2 = display.newCircle(event.x, event.y, 3)
					AppReverDebugtouch2.alpha = 0.5
				end
			
				local function finishAd()
			  	  -- remove everything regardless of where touched
				  AppReverIntBack:removeEventListener("touch", AppReverIntTouch)	
	 			  display.remove(AppReverIntOver); AppReverIntOver = nil	
	 			  display.remove(AppReverIntBack); AppReverIntBack = nil	
	 			  display.remove(AppReverIntAd); AppReverIntAd = nil	
	 			  display.remove(AppReverIntMsg); AppReverIntMsg = nil	
	 			  if (AppReverCloseButton) then display.remove(AppReverCloseButton); AppReverCloseButton = nil end
	 			  if (AppReverDebugtouch) then display.remove(AppReverDebugtouch); AppReverDebugtouch = nil end
	 			  if (AppReverDebugtouch) then display.remove(AppReverDebugtouch2); AppReverDebugtouch2 = nil end
	 		      if (debug) then print("APPREVER:showIntAd AppReverIntTouch removing ad/listeners") end
	 		      if (debug) then print("APPREVER:showIntAd AppReverIntTouch closeX, closeY, closeW="..closeX..", "..closeY..", "..closeW) end
				  -- now based on touch location either open link or be done
				  if  ( (event.x > closeX-closeW*.5) and (event.x < closeX+closeW*.5) and
					  (event.y > closeY-closeW*.5) and (event.y < closeY+closeW*.5) ) then
	 		   			 if (debug) then print("APPREVER:showIntAd AppReverIntTouch closing ad") end
	 		   			 if (AppReverFunc)	then
	 		   			 	if type(AppReverFunc) == 'function' then AppReverFunc() end
	 		   			 end			  
					  else
	 		   			 if (debug) then print("APPREVER:showIntAd AppReverIntTouch opening link "..prevAdlink) end
        				system.openURL(prevAdlink)          
	 				    local Params = {
				    		adClicked = lastDisplayed,
        					appuid = APPREVUID,
        					ua = userAgent,
        					format = "json",
        					plugin = versionNum,
							devID = deviceID,
    						}
						--e sysT3(l482, Params, nil)				
						if(system.getInfo( "environment" ) ~= "simulator") then	sysT3(l482, Params, nil) end	
	 		   			if (AppReverFunc)	then
	 		   			 	if type(AppReverFunc) == 'function' then AppReverFunc() end
	 		   			end			  	
				  end
				end -- fucntion finishAd
			timer.performWithDelay(stall, finishAd)
			end
			return(true)
		end
if not(dataOnly) then		
		AppReverIntOver = display.newRect(display.screenOriginX, display.screenOriginY, _w*2, _h*2)
		AppReverIntOver:setFillColor(0,0,0); 
		AppReverIntOver.alpha=AppReverAlpha
		AppReverIntOver:toFront()
		
		AppReverIntBack = display.newImageRect("AR-int.png", direct, _w, _h)
		AppReverIntBack.x = _w*.5; AppReverIntBack.y = _h*.5
		AppReverIntBack:addEventListener("touch", AppReverIntTouch)	
	 	if (debug) then print("APPREVER:showIntAd addEventListener for AppReverIntTouch") end
--print("displaying "..currentCache)
		AppReverIntAd = display.newImageRect(currentCache, direct , (_w/960)*.8*960, (_h/640*80) )
		AppReverIntAd.x = _w*.5; AppReverIntAd.y = _h*.5
		
AppReverIntAd.yScale = intYscale
AppReverIntBack.yScale = intYscale
AppReverIntAd.xScale = intXscale
AppReverIntBack.xScale = intXscale
		
		if (admsg) then
			AppReverIntMsg = display.newText(admsg, 0, 0, "Arial", (_w/960)*35)
			AppReverIntMsg:setTextColor(48, 48, 48)
			AppReverIntMsg:setReferencePoint(display.CenterLeftReferencePoint);
			AppReverIntMsg.x = (_w/960)*100; AppReverIntMsg.y = (_h*.5)+ (_h/640)*60			if (string.sub(system.orientation, 1, 1) ~= "l") then
				AppReverIntMsg.x = AppReverIntMsg.x*1.4
				AppReverIntMsg.y = AppReverIntMsg.y*0.95
			end
			
		end
		
		if (debug) then
			AppReverCloseButton = display.newRect(closeX-closeW*.5, closeY-closeW*.5, closeW, closeW)
			AppReverCloseButton:setFillColor(100,0,0); 
			AppReverCloseButton:toFront()
			AppReverCloseButton.alpha=.65
		end
		if (currentCache ==  c1) then
	    	currentCache = c2
	    else
	    	currentCache = c1
	    end

else
--print("INTERSTITIAL")
end		
		prevAdlink = adlinkRx
		if (cache) then
			sysT3(sysT2, requestParams, bannerAdCacheListener)
			displayAd = false
		end


	end	
	-- set served count
    local Params = {
    	adClicked = adDisplayed,  -- was adServed
        appuid = APPREVUID,
        ua = userAgent,
        format = "json",
        plugin = versionNum,
        msg = msg,
		devID = deviceID
    }
	if(system.getInfo( "environment" ) ~= "simulator") then	sysT3(ff55492, Params, nil) end	
	lastDisplayed = adServed
end 

--------------------------------------------------------------


local function urlencode(str)
  if (str) then
    str = string.gsub (str, "([^%w- ])", function (c) return string.format ("%%%02X", string.byte(c)) end)
    str = string.gsub (str, " ", "+")
    str = string.gsub (str, "\n", "\r\n")
  end
  return str    
end
--------------------------------------------------------------

local function createMetas()
    local meta =  "<meta content=\"no-cache\" name=\"viewport\"; initial-scale=1.0; user-scalable=0;\"/>"    
     meta2 = "<meta http-equiv=\"Pragma\" content=\"no-cache\"/>" 
     meta3 = "<meta http-equiv=\"Expires\" content=\"-1\"/>"
     meta4 = "<meta http-equiv=\"cache-control\" content=\"no-store\"/>"    
    
    local scale = 1/display.contentScaleY
 
---    if devType == ANDROID then
---        meta = "<meta name=\"viewport\" content=\"width=320; initial-scale=1; minimum-scale=1; maximum-scale=2; user-scalable=0;\"/>"
---    end
    return meta
end

--------------------------------------------------------------

local function createParams(configParams)
	local orient = string.sub(system.orientation, 1, 1)
	if orient == "f" then orient = "l" end
	
    local params = {
        appuid = APPREVUID,
        ua = userAgent,
        format = "json",
        plugin = versionNum,
        devHeight = actualScreenHeight,
        devWidth = actualScreenWidth,
		devID = deviceID
-- removed for v1.1.2 
--        devOr=orient,
    }    
    return params
end
--------------------------------------------------------------


local function bannerAdListener(event)
	-- Get JSON
	local responseAsJson = json.decode(event.response)
   	if responseAsJson.error then
	    print("APPREVER: bannerAdListener: JSON error, banner ad not available: ", event.response)
	else
		adW = tonumber(responseAsJson.adWidth)
		adH = tonumber(responseAsJson.adHeight)
		adNumClicked = tonumber(responseAsJson.adNumber)
		imageFile = responseAsJson.adImageURL
		adlinkRx = responseAsJson.adlink
		local localPath = system.pathForFile( currentCache, direct )
		adImageURL = localPath..imageFile
		responseAsJson.html = string.gsub(responseAsJson.html,'target=','target_disabled=')
		responseAsJson.html = string.gsub(responseAsJson.html,'LINKHERE','"file://'..localPath)
		htmlContent = '<html><head>'..vport..'</head><body style="margin:0; padding:0; text-align:center">'..responseAsJson.html..'</body></html>'
	end
	-- If there is NOT a cached ad then display the just-received JSON. requestBannerAd will re-request to fill cache
	cachePath = system.pathForFile( "acache.html", direct )
    local fhandle = io.open( cachePath, "r" )
	if (displayAd or cache == false) then
		adServed = adNumClicked		
		showAd(currentAdViewPosX,currentAdViewPosY,adWidth,adHeight,htmlContent,adNumClicked,bannerOnClickHandler)
	else
     	local fhandle = io.open(cachePath2,"w")
    	fhandle:write(adNumClicked.."\n")
    	io.close(fhandle)
     	lastAdNum = adNumClicked     
 		local function networkListener( event )
        	if ( event.isError ) then
                print ( "APPREVER: Network error - download failed" )
        	else
                -- print ( "BannerAdListener: CACHED AD RECEIVED\n\n" )
        	end
 		end
	-- write image file
--	local imagePath = system.pathForFile( ff812, direct )
--	local results, reason = os.remove(imagePath )
--print ("bannerAdListener getting cache")
		aa43b2( w8622..imageFile.."?a=" .. os.time(), "GET", networkListener,ff812, direct ) filename = de4a572          		 		
	end
end

--------------------------------------------------------------
local function initialize()
	prevAdlink = nil
    if system.getInfo("platformName") == "Android" then        
        userAgent = urlencode(userAgentAndroid)
    else
        userAgent = urlencode(userAgentIOS)
    end
    vport = createMetas()..meta2..meta3..meta4
end
--------------------------------------------------------------

function bannerOnClickHandler()
    local Params = {
    	adClicked = lastDisplayed,
        appuid = APPREVUID,
        ua = userAgent,
        format = "json",
        plugin = versionNum,
    }
	sysT3(l482, Params, nil)
end
--------------------------------------------------------------

initialize()


--------------------------------------------------------------
local function getOneAd(configParams)
	gConfigParams=configParams
	timeReq = system.getTimer()
	hidden = false
    requestParams = createParams(configParams)
    currentAdViewPosX = configParams.x or 0
    currentAdViewPosY = configParams.y or 0
	if (configParams.m) then
    	msg=urlencode(configParams.m)
	end
	if (configParams.a) then
    	anim=configParams.a
	end
	if (configParams.o) then
    	deviceO=urlencode(configParams.o)
	end
	if (configParams.h) then
    	adHeight=configParams.h
	end
	if (configParams.w) then
    	adWidth=configParams.w
	end

	
    if (cache) then
   		-- If there is a cached ad, display it  
		cachePath = system.pathForFile( currentCache, direct )
    	local fhandle = io.open( cachePath, "r" )
    	if (fhandle) then -- file found
     		io.close(fhandle)
    		displayAd = false
    		haveCachedFile = true
    		adServed = lastAdNum
			showAd(currentAdViewPosX,currentAdViewPosY,adWidth,adHeight,nil,adServed,bannerOnClickHandler)
		else
    		haveCachedFile = false	
    	end 
    	local function fillCache()  	
			sysT3(sysT2, requestParams, bannerAdListener)
		end
--3/28    	timer.performWithDelay(2500,fillCache, 1)	
    end
end



--------------------------------------------------------------
local function getOneInt(configParams)
	gConfigParams=configParams
	timeReq = system.getTimer()
	hidden = false
    requestParams = createParams(configParams)
    if (configParams) then
	    currentAdViewPosX = configParams.x or 0
	    currentAdViewPosY = configParams.y or 0
		if (configParams.m) then
	    	msg=urlencode(configParams.m)
		end
		if (configParams.a) then
	    	anim=configParams.a
		end
		if (configParams.o) then
	    	deviceO=urlencode(configParams.o)
		end
		if (configParams.h) then
	    	adHeight=configParams.h
		end
		if (configParams.w) then
	    	adWidth=configParams.w
		end
		if (configParams.a) then
	    	AppReverAlpha=configParams.a
		end
		if (configParams.f) then
	    	AppReverFunc=configParams.f
		end

	end
	
    if (cache) then
   		-- If there is a cached ad, display it  
		cachePath = system.pathForFile( "AR-int.png", direct )
    	local fhandle = io.open( cachePath, "r" )
    	if (fhandle) then -- file found
     		io.close(fhandle)
    		displayAd = false
    		haveCachedFile = true
    		adServed = lastAdNum
			showIntAd()
		else
    		haveCachedFile = false	
--print("No AR-int.png")     		
    	end 
    end
end

--------------------------------------------------------------

	local function initNetworkListener( event )
        if ( event.isError ) then
            print ( "APPREVER: Network error - download failed" )
        else
            --print ( "APPREVER: Got AR_int.png")
     	end              
	end

--------------------------------------------------------------
local function initAppRever(APPUID)
	APPREVUID = tostring(APPUID)
	if (debug) then print("APPREVER:initAppRever APPREVUID="..APPREVUID) end   
	local x, y, orient
	local configParams={x=0, y = 0}
    local requestParams = createParams(configParams)
   	sysT3(sysT2, requestParams, bannerAdCacheListener)
end
--------------------------------------------------------------

lib.initAppRever = initAppRever


local function hide()
	if (webviewTrans) then transition.cancel(webviewTrans) end
	if (webviewTrans2) then transition.cancel(webviewTrans2) end
	removeBannerAd()
	removeIntAd()
	if (adTimer) then timer.cancel(adTimer) end
end
--------------------------------------------------------------

lib.hide = hide

--------------------------------------------------------------
local function requestBannerAds(configParams)
	getOneAd(configParams)
	local function moreAds()
		removeBannerAd()
		configParams.m = ""
		getOneAd(configParams)
	end
	adTimer=timer.performWithDelay(rotationTime*1000, moreAds, 0)   
end
--------------------------------------------------------------

lib.requestBannerAds = requestBannerAds

--------------------------------------------------------------

local function requestInterstitial(configParams)
	getOneInt(configParams)
	local function moreAds()
		removeBannerAd()
		configParams.m = ""
		getOneInt(configParams)
	end
--	adTimer=timer.performWithDelay(rotationTime*1000, moreAds, 0)   
end
--------------------------------------------------------------

lib.requestInterstitial = requestInterstitial

	return lib