local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.dolbyPlugin', publisherId='com.dolby' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation startine here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local PLUGIN_NAME = require "plugin_PLUGIN_NAME"
--    PLUGIN_NAME:showPopup()
--    
local function showWarning()
	native.showAlert( 'Not Supported', 'The Dolby plugin is only supported on Android devices.', { 'OK' } )
end

function lib.init()
	showWarning()
end

function lib.getProfile()
	showWarning()
end

function lib.isEnabled()
	showWarning()
end

function lib.setEnabled()
	showWarning()
end

function lib.setProfile()
	showWarning()
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib