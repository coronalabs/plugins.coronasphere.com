-- local demoLibrary = require "plugin.demoLibrary"
native.showAlert(
	"ERROR",
	"Platform Nor supported",
	{ "OK" } )
