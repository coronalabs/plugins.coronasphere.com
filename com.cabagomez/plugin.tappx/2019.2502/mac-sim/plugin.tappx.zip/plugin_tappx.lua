local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name="plugin.tappx", publisherId="com.cabagomez", version=1}

local function showWarning()
    print("WARNING: plugin.tappx is only supported on Android devices.")
end

showWarning()

return lib