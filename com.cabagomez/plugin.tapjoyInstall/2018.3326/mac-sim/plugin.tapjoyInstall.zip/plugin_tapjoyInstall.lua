local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name="plugin.tapjoyInstall", publisherId="com.cabagomez", version=1}

local function showWarning(functionName)
    print( functionName .. " WARNING: tapjoyInstall plugin is only supported on iOS devices.")
end

function lib.init(listerner, options )
    showWarning("tapjoyInstall.init(listerner, {options})")
end
-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
