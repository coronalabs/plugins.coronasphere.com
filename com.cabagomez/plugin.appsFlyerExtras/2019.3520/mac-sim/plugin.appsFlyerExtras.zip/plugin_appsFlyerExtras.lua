local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name="plugin.appsFlyerExtras", publisherId="com.cabagomez", version=1}

local function showWarning(functionName)
    print( functionName .. " WARNING: appsFlyerExtras plugin is only supported on iOS devices.")
end

function lib.setUseReceiptValidationSandbox(bool)
    showWarning("appsFlyerExtras:setUseReceiptValidationSandbox(bool)")
end

function lib.setUseUninstallSandbox(bool)
    showWarning("appsFlyerExtras:setUseUninstallSandbox(bool)")
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
