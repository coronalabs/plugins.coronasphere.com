local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.AmazonAds', publisherId='com.deleurapps' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local PLUGIN_NAME = require "plugin_PLUGIN_NAME"
--    PLUGIN_NAME.test()
--    
lib.init = function()
	print( 'Amazon Ads are not supported on this platform. plugin.AmazonAds.init() invoked' )
end

lib.show = function()
	print( 'Amazon Ads are not supported on this platform. plugin.AmazonAds.show() invoked' )
end

lib.hide = function()
	print( 'Amazon Ads are not supported on this platform. plugin.AmazonAds.hide() invoked' )
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
