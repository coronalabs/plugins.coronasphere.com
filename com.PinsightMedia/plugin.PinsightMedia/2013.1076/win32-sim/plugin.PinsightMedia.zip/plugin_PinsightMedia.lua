local Library = require "CoronaLibrary"

local lib = Library:new{ name='plugin.PinsightMedia', publisherId='com.PinsightMedia' }

lib.init = function(ProductName,Version,listener)
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.enableDiagnostics = function()
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.enableTestMode = function()
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.setEmail = function(email)
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.setTwitterId = function(twitterId)
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.setPhoneNo = function(phoneNo)
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.showInterstitial = function(placement)
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.showBanner = function(placement)
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.hideBanner = function()
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.removeBanner = function()
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.resumeBanner = function(apiKey)
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.showSquareAd = function()
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.removeSquareAd = function()
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

lib.enableLocationService = function()
    print( "WARNING: The 'plugin.PinsightMedia' library is not available on this platform." )
end

return lib
