local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.replayKit', publisherId='com.scottrules44' }

-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.record = defaultFunction
lib.stopRecording = defaultFunction
lib.cancelRecording = defaultFunction
lib.availbleToRecord = defaultFunction
lib.recordingScreen = defaultFunction
lib.usingMicrophoneForRecoding = defaultFunction
lib.startBroadcasting = defaultFunction
lib.stopBroadcasting = defaultFunction
lib.pauseBroadcasting = defaultFunction
lib.resumeBroadcasting = defaultFunction
lib.setBroadcastingOptions = defaultFunction
lib.broadcasting = defaultFunction
lib.broadcastIsPaused = defaultFunction
lib.getBroadcastingUrl = defaultFunction
lib.accessCameraRoll = defaultFunction
lib.canAccessCameraRoll = defaultFunction

-- Return an instance
return lib