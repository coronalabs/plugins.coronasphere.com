local Library = require "CoronaLibrary"

-- Create stub library for simulator
local lib = Library:new{ name='plugin.moreInfo', publisherId='com.scottrules44' }

-- Default implementations
local function defaultFunction()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

lib.getBatteryLevel = defaultFunction
lib.getBatteryState = defaultFunction
lib.getTotalSpace = defaultFunction
lib.getTotalFreeSpace = defaultFunction
lib.getNetworkStatus = getNetworkStatus
lib.getPlaform = getPlaform

-- Return an instance
return lib