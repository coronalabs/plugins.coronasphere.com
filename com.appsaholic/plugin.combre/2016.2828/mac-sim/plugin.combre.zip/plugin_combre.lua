local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.combre', publisherId='com.appsaholic' }

local function defaultFunction()
    print("Commercial Break SDK is not available on simulator")
end

lib.init = defaultFunction
lib.showVideoAd = defaultFunction
lib.isCommercialBreakAvailable = defaultFunction
lib.setEventListener = defaultFunction

return lib
