local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='adlooper', publisherId='com.adlooper' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation startine here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local adlooper = require "plugin_adlooper"
--    adlooper.init()
--    

lib.init = function()
        native.showAlert( 'init', 'adlooper.inti() invoked', { 'OK' } )
        print( 'init' )
end
lib.onBackPressed = function()
        native.showAlert( 'onBackPressed', 'adlooper.onBackPressed() invoked', { 'OK' } )
        print( 'onBackPressed' )
end
lib.showAd = function()
        native.showAlert( 'showAd', 'adlooper.showAd() invoked', { 'OK' } )
        print( 'showAd' )
end
lib.showBanner = function()
        native.showAlert( 'showBanner', 'adlooper.showBanner() invoked', { 'OK' } )
        print( 'showBanner' )
end
lib.showSquareAd = function()
        native.showAlert( 'showSquareAd', 'adlooper.showSquareAd() invoked', { 'OK' } )
        print( 'showSquareAd' )
end
lib.locateBanner = function()
        native.showAlert( 'locateBanner', 'adlooper.locateBanner() invoked', { 'OK' } )
        print( 'locateBanner' )
end
lib.locateSquare = function()
        native.showAlert( 'locateSquare', 'adlooper.locateSquare() invoked', { 'OK' } )
        print( 'locateSquare' )
end
lib.resizeBanner = function()
        native.showAlert( 'resizeBanner', 'adlooper.resizeBanner() invoked', { 'OK' } )
        print( 'resizeBanner' )
end
lib.resizeSquare = function()
        native.showAlert( 'resizeSquare', 'adlooper.resizeSquare() invoked', { 'OK' } )
        print( 'resizeSquare' )
end
lib.allignSquare = function()
        native.showAlert( 'allignSquare', 'adlooper.allignSquare() invoked', { 'OK' } )
        print( 'allignSquare' )
end
lib.allignBanner = function()
        native.showAlert( 'allignBanner', 'adlooper.allignBanner() invoked', { 'OK' } )
        print( 'allignBanner' )
end
lib.hideAd = function()
        native.showAlert( 'hideAd', 'adlooper.hideAd() invoked', { 'OK' } )
        print( 'hideAd' )
end
-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
