local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='mohound', publisherId='com.mohound' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation startine here)
-------------------------------------------------------------------------------

lib.init = function(key, secret)
	print('Hello, World!')
end

lib.ping = function()
end

lib.setdebugmode = function()
end

lib.trackpurchase = function(amount, item)
end

lib.trackaction = function(name)
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
