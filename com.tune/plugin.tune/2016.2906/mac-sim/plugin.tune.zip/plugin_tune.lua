local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.tune', publisherId='com.tune' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
--
--    local tune = require "plugin_tune"
--    tune.test()
--

local function showWarning(functionName)
    print( functionName .. " WARNING: The Tune plugin is only supported on Android & iOS devices. Please build for device.")
end

lib.init = function()
	showWarning( "tune.init()" )
end

lib.measureSession = function()
	showWarning( "tune.measureSession()" )
end

lib.measureEvent = function()
	showWarning( "tune.measureEvent()" )
end

lib.setDebugMode = function()
	showWarning( "tune.setDebugMode()" )
end

lib.setDeepLink = function()
	showWarning( "tune.setDeepLink()" )
end

lib.setExistingUser = function()
	showWarning( "tune.setExistingUser()" )
end

lib.setListener = function()
	showWarning( "tune.setListener()" )
end

lib.setPackageName = function()
	showWarning( "tune.setPackageName()" )
end

lib.setShouldAutoCollectDeviceLocation = function()
	showWarning( "tune.setShouldAutoCollectDeviceLocation()" )
end

lib.setUserId = function()
	showWarning( "tune.setUserId()" )
end

lib.checkForDeferredDeeplink = function()
	showWarning( "tune.checkForDeferredDeeplink()" )
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
