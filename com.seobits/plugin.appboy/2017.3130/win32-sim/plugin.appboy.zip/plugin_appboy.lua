local Library = require "CoronaLibrary"

function showAppboyMessage(functionName)
	print("Appboy "..functionName.." is not available in Simulator")
end

-- Create library
local lib = Library:new{ name='plugin.appboy', publisherId='com.seobits' }

lib.init = function()
	showAppboyMessage("init");
end

lib.getDeviceId = function()
	showAppboyMessage("getDeviceId");
	return "";
end

lib.changeUser = function()
	showAppboyMessage("changeUser");
end

lib.flushDataAndProcessRequestQueue = function()
	showAppboyMessage("flushDataAndProcessRequestQueue");
end

lib.logCustomEvent = function()
	showAppboyMessage("logCustomEvent");
end

lib.logPurchase = function()
	showAppboyMessage("logPurchase");
end

lib.registerPushToken = function()
	showAppboyMessage("registerPushToken");
end

lib.setUserInfo = function()
	showAppboyMessage("setUserInfo");
end

lib.setCustomAttribute = function()
	showAppboyMessage("setCustomAttribute");
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
