local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.osUtilities', publisherId='com.gremlininteractive' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation startine here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local PLUGIN_NAME = require "plugin_PLUGIN_NAME"
--    PLUGIN_NAME:showPopup()
--    

local function showWarning()
	print( 'The OS Utilities plugin is only supported on an iOS & Android devices. Please build for device' );
end

function lib.getPluginVersion()
	showWarning()
end

function lib.init()
	showWarning()
end

function lib.saveString()
	showWarning()
end

function lib.getString()
	showWarning()
end

function lib.removeString()
	showWarning()
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
