local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='ui_framework', publisherId='com.skyjoy' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation starting here)
-------------------------------------------------------------------------------
--require("controls.init")
local config = require("plugin.ui_framework.config")
local colors = require("plugin.ui_framework.css.colors")

lib.config = {}
lib.isActive = false

function lib:init(a) -- {primaryColor, secondaryColor, os}
	if not 	a then a = {} end
	config:setOs(a.os)
	config:setScreenScale(a.screenScale)

	lib.colors = colors
	lib.fonts = require("plugin.ui_framework.css.fonts")
	lib.screen = require("plugin.ui_framework.utils.screen_util")
	lib.downloadImage = require("plugin.ui_framework.utils.download_image_util")
	lib.device = require("plugin.ui_framework.utils.device_util")

	if a.primaryColor == nil then
		a.primaryColor = "blue"
	end

	if a.secondaryColor == nil then
		a.secondaryColor = "white"	
	end
	
	if a.accentColor == nil then
		if a.secondaryColor then
			a.accentColor = a.secondaryColor
		else
			a.accentColor = "white"	
		end
	end

	config:setThemeColor({
		primary = lib.colors[a.primaryColor], 
		primaryLite = lib.colors[a.primaryColor.."Lite"] or lib.colors[a.primaryColor], 
		primaryExtraLite = lib.colors[a.primaryColor.."ExtraLite"] or lib.colors[a.primaryColor], 
		primaryDark = lib.colors[a.primaryColor.."Dark"] or lib.colors[a.primaryColor],
		secondary = lib.colors[a.secondaryColor], 
		secondaryLite = lib.colors[a.secondaryColor.."Lite"] or lib.colors[a.secondaryColor], 
		secondaryDark = lib.colors[a.secondaryColor.."Dark"] or lib.colors[a.secondaryColor],
		accent = lib.colors[a.accentColor]
	})


	if a.plugins then
		if a.plugins.utf8 then
			config.plugins.utf8 = require( "plugin.utf8" )
		end
	end

	require("plugin.ui_framework.ui.panel")
	lib.newGridPanel = require("plugin.ui_framework.ui.grid_panel")
	lib.newStackPanel = require("plugin.ui_framework.ui.stack_panel")

	lib.newButton = require("plugin.ui_framework.ui.button").new
	lib.getButtonSettings = require("plugin.ui_framework.ui.button").getSetting

	lib.newButtonLegacy = require("plugin.ui_framework.ui.button_legacy")
	lib.newSwitch = require("plugin.ui_framework.ui.switch")
	lib.newSlider = require("plugin.ui_framework.ui.slider")
	lib.newProgressBar = require("plugin.ui_framework.ui.progress_bar").new
	lib.setProgressBar = require("plugin.ui_framework.ui.progress_bar").set

	lib.newFrame = require("plugin.ui_framework.ui.frame")
	lib.newCard = require("plugin.ui_framework.ui.card")
	lib.newShadow = require("plugin.ui_framework.ui.shadow")

	lib.newToastLegacy = require("plugin.ui_framework.ui.toast_legacy")
	
	lib.newToast = require("plugin.ui_framework.ui.toast").new

	-- lib.newRow = require("plugin.ui_framework.ui.tableview_row")
	lib.newNavbar = require("plugin.ui_framework.ui.navbar")
	lib.newNavbarLegacy = require("plugin.ui_framework.ui.navbar_legacy")
	lib.newTabMenu = require("plugin.ui_framework.ui.tab_menu")
	lib.newTabMenuLegacy = require("plugin.ui_framework.ui.tab_menu_legacy")

	lib.newInput = require("plugin.ui_framework.ui.input")
	lib.newSearchbar = require("plugin.ui_framework.ui.search_bar")

	if a.enable then
		if a.enable.scrollView then
			local myWidget = require("plugin.ui_framework.libs.widget")
			lib.newScrollView = myWidget.newScrollView
		end

		if a.enable.loader then
			lib.newLoader = require("plugin.ui_framework.ui.loader").new
			lib.removeLoader = require("plugin.ui_framework.ui.loader").remove
		end

		if a.enable.noData then
			lib.newNoData = require("plugin.ui_framework.ui.no_data").new
			lib.removeNoData = require("plugin.ui_framework.ui.no_data").remove	
		end

		if a.enable.statusbar then
			lib.newStatusbar = require("plugin.ui_framework.ui.statusbar").new
			lib.setStatusbarMode = require("plugin.ui_framework.ui.statusbar").setMode
			lib.statusbarIsVisible = require("plugin.ui_framework.ui.statusbar").isVisible
		end

		if a.enable.row then
			lib.newRow = require("plugin.ui_framework.ui.row").new
			lib.getRowSettings = require("plugin.ui_framework.ui.row").getSetting

		end

		if a.enable.tile then
			lib.newTile = require("plugin.ui_framework.ui.tile").new
			lib.getTileSettings = require("plugin.ui_framework.ui.tile").getSetting
			lib.extendTile = require("plugin.ui_framework.ui.tile").extend
		end

		if a.enable.info then
			lib.newInfo = require("plugin.ui_framework.ui.info").new
			lib.removeInfo = require("plugin.ui_framework.ui.info").remove	
		end

		if a.enable.sideMenu then
			lib.newSideMenu = require("plugin.ui_framework.ui.side_menu").new
			lib.getSideMenuSettings = require("plugin.ui_framework.ui.side_menu").getSetting
		end
	end

	lib.helper = require("plugin.ui_framework.libs.helper")


	lib.config = config
	lib.isActive = true
end

function lib:addColor(key, color_table)
	colors[key] = color_table
end


-- Return library instance
return lib
