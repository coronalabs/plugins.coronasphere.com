local deviceUtils = omf.DeviceUtil
local whatOs = deviceUtils:get("os")
local color = app.Color


local ui = {
	-- status bar
	statusbar = {
		height = display.topStatusBarContentHeight,
		color = color.black,
		isActive = true
	},
	-- navbar

	navbar = {
		height = 56,
		color = color.white
	},

	tab_menu = {
		height = 50,
		color = color.white
	},

	side_menu = {
		height = 50,
		color = color.white
	},
    
    card = {
		header_color = color.white,
		body_color = color.white
	},
    
    image_two_line = {
        image_path = "framework/graphics/list_placeholder.png"
    }
}

app:update("UiCss", ui, "framework.css.ui")

if whatOs == "ios" then

else

end
