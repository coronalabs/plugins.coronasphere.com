local isAndroid = require("plugin.ui_framework.utils.device_util").isAndroid
local textCss = {}
textCss.regular = "Roboto-Regular"
textCss.medium = "Roboto-Medium"
textCss.light = "Roboto-Light"
textCss.condensed = "RobotoCondensed-Regular"
textCss.icons = "ionicons"

-- http://ionicons.com/cheatsheet.html

if isAndroid then

else
	textCss.regular = native.systemFont
	textCss.medium = native.systemFontBold
end

textCss.back = { 
	font = textCss.regular,
	fontSize = 17,
	iconFont = textCss.icons,
	iconFontSize = 26
}



textCss.button = { 
	font = textCss.regular,
	fontSize = 14,
}

textCss.body1 = {
	font = textCss.regural,
	fontSize = 14
}

textCss.body2 = {
	font = textCss.medium,
	fontSize = 14
}

textCss.subheading = {
	font = textCss.regural,
	fontSize = 16
}
  
textCss.title = {
	font = textCss.medium,
	fontSize = 20
}
  
textCss.headline = {
	font = textCss.regural,
	fontSize = 24
}
  
textCss.display1 = {
	font = textCss.regural,
	fontSize = 34
}

textCss.icon = {}
textCss.icon.more = ""
textCss.icon.share = ""
textCss.icon.camera = ""
textCss.icon.link = ""

if isAndroid then
	textCss.back.icon = ""
	textCss.icon.back = ""
	textCss.icon.arrow_right = ""
	textCss.icon.menu = ""
	textCss.icon.home = ""
	textCss.icon.list = ""
	textCss.icon.search = ""
	textCss.icon.options = ""
	textCss.icon.account = ""
	textCss.icon.people = ""
	textCss.icon.bolt = ""
	textCss.icon.body = ""
	textCss.icon.info = ""
	textCss.icon.settings = ""

	textCss.icon.loader = ""
	textCss.icon.plus = ""
	textCss.icon.puls = ""

	textCss.icon.message = ""
	textCss.icon.logout = ""
else
	textCss.back.icon = ""
	textCss.icon.back = ""
	textCss.icon.arrow_right = ""
	textCss.icon.menu = ""
	textCss.icon.home = { default = "", outline = "" }
	textCss.icon.list = { default = "", outline = ""}
	textCss.icon.search = ""
	textCss.icon.options = {default = "", outline = ""}
	textCss.icon.account = {default = "", outline = ""}
	textCss.icon.people = {default = "", outline = ""}
	textCss.icon.bolt = {default = "", outline = ""}
	textCss.icon.body = {default = "", outline = ""}
	textCss.icon.info = {default = "", outline = ""}
	textCss.icon.puls = { default = "" , outline = "" }

	textCss.icon.settings = ""

	textCss.icon.loader = ""
	textCss.icon.plus = ""
	
	textCss.icon.message = { default = "", outline = "" }
	textCss.icon.logout = ""
	
	textCss.back.iconFontSize = 32
	textCss.back.fontSize = 16
	textCss.subheading.fontSize = 16
	textCss.subheading.font = textCss.medium
end


return textCss