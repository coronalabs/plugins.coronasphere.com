local config = require("plugin.ui_framework.config")


local colors = { }

colors.transparent = {0, 0, 0, 0}

if config.isIos then
	colors.red = {255, 59, 47}

	colors.blueExtraLite = {168, 222, 251, 255}
	colors.blueLite = {66, 165, 245, 255}
	colors.blue = {0, 122, 255, 255}
	colors.blueDark = {21, 101, 192, 255}
	
	colors.grayLite = {247, 247, 248, 255}
	colors.gray = {239, 239, 244, 255}
	colors.grayDark = {200, 200, 204, 255}
	colors.grayDarkExtra = {120, 120, 120, 255}	

	colors.redLite = {255, 205, 210, 255}
	colors.red = {244, 67, 54, 255}
	colors.redDark = {183, 28, 28, 255}
	
	colors.white = {255, 255, 255, 255}
	
	colors.yellow = {255, 204, 0, 255}
	
	colors.orange = {255, 149, 1, 255}
	
	colors.pink = {255, 44, 85, 255}
	
	colors.greenExtraLite = {200, 230, 201, 255}
	colors.greenLite = {92, 168, 95, 255}
	colors.green = {76, 218, 100, 255}
	colors.greenDark = {46, 123, 49, 255}

	colors.black = {0,0,0, 255}
	colors.blackDark = {15,15,15, 255}
	colors.blackLite = {35, 35, 35, 255}


else
	colors.red = {244, 67, 54, 255}
	
	colors.blueExtraLite = {168, 222, 251, 255}
	colors.blueLite = {90, 200, 251, 255}
	colors.blue = {33, 150, 243, 255}
	colors.blueDark = {21, 101, 192, 255}
	
	colors.grayLite = {224, 224, 224, 255}
	colors.gray = {189, 189, 189, 255}
	colors.grayDark = {158, 158, 158, 255}
	colors.grayDarkExtra = {120, 120, 120, 255}	

	colors.redLite = {252, 102, 93, 255}
	colors.red = {255, 59, 47, 255}
	colors.redDark = {255, 15, 0, 255}
	
	colors.white = {255, 255, 255, 255}
	
	colors.yellow = {255, 204, 0, 255}
	
	colors.orange = {255, 149, 1, 255}
	
	colors.pink = {233, 30, 99, 255}
	
	colors.greenExtraLite = {200, 230, 201, 255}
	colors.greenLite = {92, 168, 95, 255}
	colors.green = {76, 175, 80, 255}
	colors.greenDark = {46, 123, 49, 255}

	colors.black = {0,0,0, 255}
	colors.blackDark = {15,15,15, 255}
	colors.blackLite = {35, 35, 35, 255}

end


for k,v in pairs(colors) do
	colors[k][1] = v[1]/255
	colors[k][2] = v[2]/255
	colors[k][3] = v[3]/255
	if colors[k][4] then
		colors[k][4] = v[4]/255
	end
end

return colors