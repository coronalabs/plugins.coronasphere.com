local Config = require("plugin.ui_framework.config")

local _ = {}



local architectureInfo = system.getInfo( "architectureInfo" )
local function whatIosDevice() 
	if architectureInfo == "iPod7,1" then
		return "iPod Touch 5"
	elseif architectureInfo == "iPod7,1" then
		return "iPod Touch 6"
	elseif architectureInfo == "iPhone3,1" or architectureInfo == "iPhone3,2" or architectureInfo == "iPhone3,3" then
		return "iPhone 4"
	elseif architectureInfo == "iPhone4,1" then
		return "iPhone 4s"
	elseif architectureInfo == "iPhone5,1" or architectureInfo == "iPhone5,2" then
		return "iPhone 5"
	elseif architectureInfo == "iPhone5,3" or architectureInfo == "iPhone5,4" then
		return "iPhone 5c"
	elseif architectureInfo == "iPhone6,1" or architectureInfo == "iPhone6,2" then
		return "iPhone 5s"
	elseif architectureInfo == "iPhone7,2" then
		return "iPhone 6"
	elseif architectureInfo == "iPhone7,1" then
		return "iPhone 6 Plus"
	elseif architectureInfo == "iPhone8,1" then
		return "iPhone 6s"
	elseif architectureInfo == "iPhone8,2" then 
		return "iPhone 6s Plus"
	elseif architectureInfo == "iPhone9,1" or architectureInfo ==  "iPhone9,3" then 
		return "iPhone 7"
	elseif architectureInfo == "iPhone9,2" or architectureInfo ==  "iPhone9,4" then 
		return "iPhone 7 Plus"
	elseif architectureInfo == "iPhone8,4" then
		return "iPhone SE"
	elseif architectureInfo == "iPhone10,1" and architectureInfo == "iPhone10,4" then
		return "iPhone 8"
	elseif architectureInfo == "iPhone10,2" and architectureInfo == "iPhone10,5" then
		return "iPhone 8 Plus"
	elseif architectureInfo == "iPhone10,3" and architectureInfo == "iPhone10,6" then
		return "iPhone X"
	elseif architectureInfo == "iPhone11,8" then
		return "iPhone XR"
	elseif architectureInfo == "iPhone11,6" then
		return "iPhone XS"
	elseif architectureInfo == "iPhone11,2" and architectureInfo == "iPhone11,4" then
		return "iPhone XS Max"
	elseif architectureInfo == "iPhone12,1" then
		return "iPhone 11"
	elseif architectureInfo == "iPhone12,3" then
		return "iPhone 11 Pro"
	elseif architectureInfo == "iPhone12,5" then
		return "iPhone 11 Pro Max"
	elseif architectureInfo == "iPad2,1" or architectureInfo == "iPad2,2" or architectureInfo == "iPad2,3" or architectureInfo == "iPad2,4" then
		return "iPad 2"
	elseif architectureInfo == "iPad3,1" or architectureInfo == "iPad3,2" or architectureInfo == "iPad3,3" then
		return "iPad 3"
	elseif architectureInfo == "iPad3,4" or architectureInfo == "iPad3,5" or architectureInfo == "iPad3,6" then
		return "iPad 4"
	elseif architectureInfo == "iPad4,1" or architectureInfo == "iPad4,2" or architectureInfo == "iPad4,3" then
		return "iPad Air"
	elseif architectureInfo == "iPad5,3" or architectureInfo == "iPad5,4" then
		return "iPad Air 2"
	elseif architectureInfo == "iPad2,5" or architectureInfo == "iPad2,6" or architectureInfo == "iPad2,7" then
		return "iPad Mini"
	elseif architectureInfo == "iPad4,4" or architectureInfo == "iPad4,5" or architectureInfo == "iPad4,6" then
		return "iPad Mini 2"
	elseif architectureInfo == "iPad4,7" or architectureInfo == "iPad4,8" or architectureInfo == "iPad4,9" then
		return "iPad Mini 3"
	elseif architectureInfo == "iPad5,1" or architectureInfo == "iPad5,2" then
		return "iPad Mini 4"
	elseif architectureInfo == "iPad6,3" or architectureInfo == "iPad6,4" or architectureInfo == "iPad6,7" or architectureInfo == "iPad6,8" then
		return "iPad Pro"
	else
		return "iPhone 6"
	end
end

local function whatIosDensity(iosDeviceName)
	if iosDeviceName == "iPhone 4" or iosDeviceName == "iPhone 4s" or
		iosDeviceName == "iPhone 5" or iosDeviceName == "iPhone 5c" or
	 	iosDeviceName == "iPhone 5s" or iosDeviceName == "iPhone 6" or 
	 	iosDeviceName == "iPhone 6s" or iosDeviceName == "iPhone 7" or 
	 	iosDeviceName == "iPod Touch 6" or iosDeviceName == "iPod Touch 5" or
	 	iosDeviceName == "iPhone XR" or iosDeviceName == "iPhone 11" then

	 	return 326
	elseif iosDeviceName == "iPhone 6 Plus" or iosDeviceName == "iPhone 6s Plus"
		or iosDeviceName == "iPhone 7 Plus" then

		return 401
	elseif iosDeviceName == "iPhone X" or iosDeviceName == "iPhone XS" or 
		iosDeviceName == "iPhone XS Max" or iosDeviceName == "iPhone 11 Pro" or 
		iosDeviceName == "iPhone 11 Pro Max" then

		return 462
	elseif iosDeviceName == "iPad Mini" then

		return 163
	elseif iosDeviceName == "iPad Mini 2" or iosDeviceName == "iPad Mini 3"
		or iosDeviceName == "iPad Mini 4" then

		return 326
	elseif iosDeviceName == "iPad 3" or iosDeviceName == "iPad 4" 
		or iosDeviceName == "iPad Air" or iosDeviceName == "iPad Air 2" 
		or iosDeviceName == "iPad Pro" then

		return 264
	end
end



local mathRound = math.round

-- ldpi = 0.75
-- mdpi = 1
-- hdpi = 1.5
-- xhdpi = 2
-- xxhdpi = 3
-- xxxhdpi = 4
local scale = 1
local dpi = system.getInfo("androidDisplayApproximateDpi")
if dpi == nil then
	local iosDeviceName = whatIosDevice()
	local dpi = whatIosDensity(iosDeviceName)
	scale = mathRound(dpi / 160)
else
	scale = mathRound(dpi / 160)
end

function _.setScale(_scale)
	scale = _scale
end

function _.toPx(points)
	if Config.screenScale == "auto" then
		return mathRound(points)
	else
		return mathRound(points*scale) 
	end
end

-- return device screen dpi
function _.getDpi()
	return dpi
end

-- return screen scale
function _.getscreenScale()
	return scale
end

if Config.screenScale == "auto" then
	_.contentWidth = display.contentWidth
	_.contentMiddle = display.contentWidth*.5
else
	_.contentWidth = display.contentWidth
	_.contentMiddle = (display.contentWidth*.5)/scale
end

return _