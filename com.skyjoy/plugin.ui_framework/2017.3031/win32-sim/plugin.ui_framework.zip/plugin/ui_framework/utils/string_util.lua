local abs = math.abs
local StringUtil = {}

local function _initializeTrim(self)
	local cutChars = {" ", ",", "."} -- gdy string konczy sie na jeden z tych znakow to ucinamy go

	for i=1, #cutChars do
		local char = cutChars[i]
		local byte = string.byte(char:sub(1,1))
		self.var.cutCharBytes[byte] = true -- dla tych bitow ucinamy ostatni znak
	end
end

function StringUtil:init()
	self.var = {
		cutCharBytes = {} 
	}
	_initializeTrim(self)
end

function StringUtil:upper(string)
	-- Contract:requiresType(string, "string")
	return string.upper(string)
end

function StringUtil:lower(string)
	-- Contract:requiresType(string, "string")
	return string.lower(string)
end

function StringUtil:upperFirst(string)
	-- Contract:requiresType(string, "string")
	if string.len(string) < 2 then 
		return string.upper(string)
	else
		return string.upper((string.sub(string, 1, 1))) .. string.sub(string, 2, string.len(string))
	end
end


function StringUtil:trim(target, width, endString)
	-- Contract:requiresNotNil(target, "target")
	-- Contract:requiresType(width, "number")

	if isNil(endString) then endString = "..." end -- tymi znakami ma sie konczyc strimowany string
	if isNil(self.var) then self:initialize() end
	
	local originalText = target.text
	local min, max = 0, utf8.len(target.text)
	local loopCounter = 0

	if width <= 0 or target.width < width then 
		return 
	else
		target.text = target.text .. endString
	end

	local function checkLastChar()
		local lastChar = utf8.sub(originalText, min, min)
		local lastCharCode = utf8.byte(lastChar)
		if self.var.cutCharBytes[lastCharCode] then
			target.text = utf8.sub(originalText, 1, min - 1) .. endString -- obcinamy 1 znak
			if self.var.cutCharBytes[utf8.byte(utf8.sub(originalText, min - 1, min - 1))] then -- odcinanie przedostatniej litery
				target.text = utf8.sub(originalText, 1, min - 2) .. endString -- obcinamy 2 znaki
			end
		else
			target.text = utf8.sub(originalText, 1, min) .. endString
		end
	end
	
	local function checkEnd()
		if abs(min - max) <= 1 or loopCounter > 12 then 
			checkLastChar()
			return true
		end
		return false
	end

	local function crop()
		loopCounter = loopCounter + 1
		if target.width > width then 
			max = utf8.len(target.text) - 3
			if checkEnd() then return end
			target.text = utf8.sub(originalText, 1, math.floor(min + (max - min)*.5)) .. endString
			crop()
		else
			min = utf8.len(target.text) - 3
			if checkEnd() then return end
			target.text = utf8.sub(originalText, 1, math.floor(min + (max - min)*.5)) .. endString
			crop()
		end 
	end 
	crop()
end


return StringUtil