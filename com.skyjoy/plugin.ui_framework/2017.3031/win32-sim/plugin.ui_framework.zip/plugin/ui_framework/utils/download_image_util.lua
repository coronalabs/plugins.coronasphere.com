-- 27.08.2014
-- Placeholder is displayed when image is downloading or download ends with error -- using placeholder isn't necessary
-- If you want to use placeholder just set it's path by "_.setDefaultImage(imgFilename)" eg.
-- download.setDefaultImage("Graphics/photo_default.png")


-- 22.10.2015
-- Dodano zabezpieczenie sprawdzające czy cache sie sam nie wyczyscił

-- 11.12.2015
-- dodano radius aby zaokrąglać rogi
-- dodano autoSize zwraca obrazek w rozdziałce w jakiej jest pobrany. czyli newImage zamiast newImageRect

-- If you want to download many of the same image (with the same id), there is only one network request
-- cacheArray stores info about images in temporary folder - it allows to don't call "io.open()" every time you use "_.image()"
-- 
-- "fade" - enables fadeIn effect while replacing placeholder with image (default false); "fadeTime" (default 1400ms)
-- images with the same imageId have to have the same "fade" param
--
-- example of use: 
-- download.image({group = contentGroup, url = "http://www.geemzo.com/images/geemzo-logo.jpg", params = { id = "picture1", x = 80, y = 80, w = 100, h = 100, fade = true, fadeTime = 1000}, callback = onImageDownloaded})
-- necessary parameters to display image are: "group", "url" and "id" 

-- 12.01.2016
-- dodano flage która umożliwia zapisanie obrazka bez jego rozdzielczości.

local json = require("json")

local headers = {}; headers["Content-Type"] = "application/x-www-form-urlencoded"
local params = {}; params.headers = headers

local _h = display.contentHeight
local _w = display.contentWidth

local DownloadImage = {}

local networkArray = {}
local cacheArray = {}

function DownloadImage.cancel(id)
	if id then
		if networkArray[id] then
			network.cancel( networkArray[id] )
			networkArray[id] = nil

			local Index
			for i=1, #cacheArray do
				if cacheArray[i].id == id then
					Index = i
					break
				end
			end
			if Index and cacheArray[Index] and cacheArray[Index].isDownloading then
				cacheArray[Index].isError = true -- setting image error, when cancel while downloading
				cacheArray[Index].isDownloading = false
			end

			-- print("Cancel: "..id)
		end
	else
		for k,v in pairs(networkArray) do
	   		network.cancel( networkArray[k] )
	   		-- print("ACancel: "..k)
	   		networkArray[k] = nil

	   		local Index
			for i=1, #cacheArray do
				if cacheArray[i].id == k then
					Index = i
					break
				end
			end

	   		if Index and cacheArray[Index] and cacheArray[Index].isDownloading then
	   			cacheArray[Index].isError = true
	   			cacheArray[Index].isDownloading = false
	   		end
		end
	end
end

function DownloadImage.setDefaultImage(imgFilename)
	DownloadImage.placeholder = imgFilename
end

local function returnPlaceholder(array)
	-- print ("return placeholder")
	local callback = array[1].callback
	local placeholder = array[2]
	if type(callback) == "function" then
		callback({img = placeholder})
	end
end

local function destroyPlaceholder(imgGroup)
	if imgGroup and imgGroup.anchorX then
		for i = imgGroup.numChildren, 1, -1 do

			if imgGroup[i].whatType == "placeholder" then
				display.remove( imgGroup[i] )
				break
			end
		end
	end
end

function DownloadImage:get(a, dontTouchThisParams)
	local group, url, params, callback = a.group, a.url, a.params, a.callback

	if not url then url = "" end

	local w = params.width or _w
	local h = params.height or _h
	local x = params.x or 0
	local y = params.y or 0
	local autoSize = params.autoSize or false
	local radius = params.radius or false
	if not a.id then error("image ID i required. It's a unique name for this image!") end
	local _id = a.id
	local placeholder
	local fade, fadeTime = params.fade or false, params.fadeTime or 1400
	local isPlaceholderDisplayed = false
	 		
	if params.placeholder then
		placeholder = params.placeholder
	elseif DownloadImage.placeholder then
		placeholder = DownloadImage.placeholder
	end

	local fileFormat = ""

	if url and string.match(url:lower(), "jpg") then 
		fileFormat = "jpg"
	elseif url and string.match(url:lower(), "png") then 
		fileFormat = "png" 
	elseif url and string.match(url:lower(), "jpeg") then 
		fileFormat = "jpg"
	end 

	local imgGroup = display.newGroup( )
	if group and group.insert then 
		group:insert( imgGroup )
	end 

	local function finalizeListener( self, event )
		-- TODO
		-- to niedziała i nie wiadomo dlaczego. tran sie nie kasuje.
		if _id then
			transition.cancel( _id )
		end
		DownloadImage.cancel(_id)
    end
    imgGroup.finalize = finalizeListener
    if not imgGroup.addEventListener then return false end 
	imgGroup:addEventListener( "finalize" )


	if fileFormat == "" or not url:find("http") then 
		if placeholder and not params.dontShowPlaceholder then

			local image = display.newImageRect( imgGroup, placeholder, w, h )

			image.whatType = "placeholder"
			imgGroup.x = x
			imgGroup.y = y

			if params.anchorX then
				image.anchorX = params.anchorX
			end
			if params.anchorY then
				image.anchorY = params.anchorY
			end
			if type(callback) == "function" then
				callback({img = imgGroup})
			end

			return imgGroup
		end
		return false 
	end

	local photo = tostring(_id) .. "."..fileFormat
	imgGroup.fileName = photo
	imgGroup.fileFormat = fileFormat

	local path = system.pathForFile( photo, system.TemporaryDirectory)
	local imageExistInCache = false -- if image exists in cacheArray
	local imageExistInTemp = false-- if image exists in temporary directory but no in cacheArray yet
	local isError = false -- image download error
	local index = 0 -- index of image in cacheArray

	for i=1, #cacheArray do
		if cacheArray[i].id == _id then -- searching
			--_printTable(cacheArray[i])
			imageExistInCache = true
			index = i
			if cacheArray[i].isError then
				isError = true
			end
		end
	end

	-- if cache for this id doesn't exist then create it
	if not imageExistInCache then 
		index = #cacheArray
		cacheArray[index] = {}
	end

	if not imageExistInCache and not isError then
		imageExistInTemp = io.open( path )
	end

	-- print("photo", photo)
	if (imageExistInCache or imageExistInTemp) and not isError and not cacheArray[index].isDownloading then -- wyswietlanie pobranego juz obrazka

		local image
		if radius then
			image = display.newRoundedRect(imgGroup, 0, 0, w, h, radius )

		-- Set the fill (paint) to use the bitmap image
			local paint = {
			    type = "image",
			    filename = photo,
			    baseDir = system.TemporaryDirectory
			}
			image.fill = paint
		else

			if autoSize then
				image = display.newImage( imgGroup, photo, system.TemporaryDirectory, 0, 0 )
			else
				image = display.newImageRect(imgGroup, photo, system.TemporaryDirectory, w, h)
			end
		end

		if not image or ( image and not image.anchorY) then 
			table.remove( cacheArray, index )
		else 
			if cacheArray[index].a_params and fade and dontTouchThisParams then -- nie katywna funkcja. Dla pobranego już obrazka nie odpala się FADE
				image.alpha = 0
				transition.to( image, {alpha = 1, delay = 2000, time = fadeTime, transition = easing.outQuad, onComplete = function () 
					
					if cacheArray[index].a_params[dontTouchThisParams] then -- zabezpieczenie przed ?dziwnym? bledem
						display.remove( cacheArray[index].a_params[dontTouchThisParams][2] )
						cacheArray[index].a_params[dontTouchThisParams] = nil
					end
				end, tag = "download_fade"} )
			end

			if type(a.fadeCallback) == "function" then -- że jako nie odpala się fade dla już pobranego obrazka to robimy fake callback.
				a.fadeCallback()
			end

			if imageExistInTemp then 
				cacheArray[index].id = _id
				cacheArray[index].isError = false
				io.close( imageExistInTemp ) 
				--print("IO CLOSE")
			end

			if type(callback) == "function" then
				callback({img = imgGroup})
			end

			if params.anchorX then
				image.anchorX = params.anchorX
			end
			if params.anchorY then
				image.anchorY = params.anchorY
			end

			imgGroup.x = x
			imgGroup.y = y
		end
	else -- if is error or file not exists
		--local defaultImage = {}
		if placeholder and not params.dontShowPlaceholder then
			-- print("--------------",placeholder)
			isPlaceholderDisplayed = true

			--imgGroup = display.newGroup( )
			--group:insert( imgGroup )
			local image = display.newImageRect( imgGroup, placeholder, w, h )
			image.whatType = "placeholder"
			imgGroup.x = x
			imgGroup.y = y

			if params.anchorX then
				image.anchorX = params.anchorX
			end
			if params.anchorY then
				image.anchorY = params.anchorY
			end
		end

		if cacheArray[index].isDownloading then -- if image with this id is downloading
			--print("save params to array")
			if not cacheArray[index].a_params then
				cacheArray[index].a_params = {}
			end
			cacheArray[index].a_params[#cacheArray[index].a_params+1]={a,imgGroup}
			-- waiting for download and then relanuch _.image with a
		
		elseif type(url) == "string" and string.len(url) > 0 then -- tu wchodzi tylko raz (dla pierwszego obrazka)

			cacheArray[index].id = _id
			cacheArray[index].isDownloading = true

			networkArray[_id] = network.download( url, 
			"GET", function(e) 
			--print(e)
				cacheArray[index].isDownloading = false
				if imgGroup then
					if e.isError or e.response.filename ~= photo then 
						print("++ Warrning! Error photo!", url)
						if type(callback) == "function" and not params.dontShowPlaceholder then
							callback({isError = true, img = imgGroup})
						end
						--timer.performWithDelay( 20, function() -- timer for safety
						if cacheArray[index].a_params then
							for i=1, #cacheArray[index].a_params do
								print ("CALLBACK after ERROR ", i);
								returnPlaceholder(cacheArray[index].a_params[i]);
								cacheArray[index].a_params[i] = nil -- deleting callbacks and references to placeholders
							end;
						end;
						--end)

						cacheArray[index].isError = true
					else
						if not fade then display.remove( imgGroup[1] ) end -- pierwszy pobierany obrazek nie jest w cacheArray dlatego trzeba recznie usunac placeholder
						
						local image
						if radius then
							image = display.newRoundedRect(imgGroup, 0, 0, w, h, radius )

						-- Set the fill (paint) to use the bitmap image
							local paint = {
							    type = "image",
							    filename = photo,
							    baseDir = system.TemporaryDirectory
							}
							image.fill = paint
						else
							if autoSize then
								image = display.newImage( imgGroup, photo, system.TemporaryDirectory, 0, 0 )
							else
								image = display.newImageRect(imgGroup, photo, system.TemporaryDirectory, w, h)
							end 
						end
						
						if fade then
							image.alpha = 0
							transition.to( 
								image, 
								{
									alpha = 1, 
									time = fadeTime, 
									onComplete = function ()
									--print(imgGroup)
										if type(a.fadeCallback) == "function" then
											a.fadeCallback()
										end
										if imgGroup and imgGroup.numChildren then
											destroyPlaceholder(imgGroup)
										end
									end,
									transition = easing.outQuad,
									tag = _id
								} )

							--print(imgGroup.fadeTransition)
						end

						if params.anchorX then
							image.anchorX = params.anchorX
						end
						if params.anchorY then
							image.anchorY = params.anchorY
						end	
						imgGroup.x = x
						imgGroup.y = y	

						if type(callback) == "function" then
							callback({img = imgGroup})
						end
					end 

					cacheArray[index].isError = false

					if cacheArray[index].a_params then
						for i=1, #cacheArray[index].a_params do
							DownloadImage:get(cacheArray[index].a_params[i][1], i)
							if not fade then
								display.remove( cacheArray[index].a_params[i][2] ) -- removing placeholder
								cacheArray[index].a_params[i] = nil -- deleting callbacks and references to placeholders
							end
						end
					end
				end
				networkArray[_id] = nil
			end, photo, system.TemporaryDirectory )
		end
	end
	return imgGroup
end

return DownloadImage