local Class = {}

-- ldpi = 0.75
-- mdpi = 1
-- hdpi = 1.5
-- xhdpi = 2
-- xxhdpi = 3
-- xxxhdpi = 4
local scale = 1
local dpi = system.getInfo("androidDisplayDensityName")
if dpi == nil then
	scale = 2
elseif dpi == "ldpi" then
	scale = .75
elseif dpi == "mdpi" then
	scale = 1
elseif dpi == "hdpi" then
	scale = 1.5
elseif dpi == "xhdpi" then
	scale = 2
elseif dpi == "xxhdpi" then
	scale = 3
elseif dpi == "xxxhdpi" then
	scale = 4
else
	scale = 2
end

local mathRound = math.round
function Class.toPoints(px)
	print(mathRound(px*scale))
	return mathRound(px*scale)
end
------------------------------
-- Set what platform are we on
------------------------------

function Class.getOrientation()
	local orientation = "portrait"
	if display.contentWidth > display.contentHeight then
		orientation = "landscape"
	end
	return orientation
end

Class.isSimulator = false
Class.isIos = false
Class.isAndroid = false
Class.isPhone = false
Class.isTablet = false
Class.isTv = false

Class.deviceId = system.getInfo("deviceID")
Class.platformVersion = system.getInfo( "platformVersion" )
Class.deviceModel = system.getInfo("model")
Class.whatLanguage = system.getPreference( "ui", "language" )
Class.appVersion = system.getInfo( "appVersionString" )
Class.architecture = system.getInfo( "architectureInfo" )
Class.resolutionWidth = display.pixelWidth
Class.resolutionHeight = display.pixelHeight
Class.screenSize = 0

------------------------------
-- Set what platform are we on
------------------------------
local platformName = system.getInfo( "platform" )

if system.getInfo( "environment" ) == "simulator" then
	Class.isSimulator = true
	Class.appVersion = 1

	local name = system.getInfo("model")
	print("name", name)
	if name == "Galaxy Tab" or name == "KFTT"  then
		Class.isAndroid = true
		Class.isTablet = true
	elseif name == "GT-I9300" or name == "Sensation" or name == "GenericAndroidDevice" or name == "SM-G900S" then
		Class.isAndroid = true
		Class.isPhone = true
	elseif name == "iPhone" then
		Class.isIos = true
		Class.isPhone = true
	elseif name == "iPad" then
		Class.isIos = true
		Class.isTablet = true
	elseif name == "AFTV" then
		Class.isAndroid = true
		Class.isTv = true
	else
		Class.isIos = true
		Class.isPhone = true
	end

elseif platformName == "android" then
	Class.isAndroid = true

	local approximateDpi = system.getInfo("androidDisplayApproximateDpi")
	local widthInInches = display.pixelWidth / approximateDpi
	local heightInInches = display.pixelHeight / approximateDpi
	local diagonal = widthInInches*widthInInches + heightInInches*heightInInches

	diagonal = math.round(math.sqrt(diagonal) )
	Class.screenSize = diagonal

	if diagonal > 6 then
		Class.isTablet = true
	else
		Class.isPhone = true
	end

-- elseif platformName == "Win" then
-- 	DeviceUtils.whatOs = "android"
-- 	DeviceUtils.deviceType = "tablet"
else
	if string.sub(system.getInfo("model"),1,4) == "iPad" then
		Class.isTablet = true
		Class.screenSize = 10
	else
		Class.isPhone = true
		Class.screenSize = 4
	end

	-- local openudid = require("plugin.openudid")

	-- DeviceUtils.deviceId = openudid.getValue()
	Class.isIos = true
end

return Class