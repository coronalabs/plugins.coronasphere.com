-- dorobic cancel

local class = {}
local transitions = {}

function class.new(displayObj, a)
	if (a and a.startColor and a.endColor) then
		if not a.tag then a.tag = "default" end

	    local length = a.time or 300
	    
	    local startTime = system.getTimer()
	    
	    local easingFunc = a.transition or easing.linear
	    local function colorInterpolate(a,b,i,t)
	        local colourTable = {
				easingFunc(i,t,a[1],b[1]-a[1]),
				easingFunc(i,t,a[2],b[2]-a[2]),
				easingFunc(i,t,a[3],b[3]-a[3]),
			}
			if (b[4] and a[4]) then
				colourTable[#colourTable+1] = easingFunc(i,t,a[4],b[4]-a[4])
			end
			
			return colourTable
	    end

	    local function runFunc(event)
			local runTime = system.getTimer()

	        if (startTime + length > runTime) then
	            displayObj:setFillColor(unpack(colorInterpolate(a.startColor, a.endColor, runTime-startTime, length)))
	        else
	            -- do it one last time to make sure we have the correct final color
	            displayObj:setFillColor(unpack(a.endColor))
	            class.cancel(a.tag)
	        end
	    end
	    
	    transitions[#transitions+1] = {
	    	runFunc = runFunc,
		    tag = a.tag
	    }
	    
	    Runtime:addEventListener("enterFrame", runFunc)
	end
end

function class.cancel(tag)
	for i = #transitions, 1, -1 do
		if transitions[i].tag == tag then
			Runtime:removeEventListener("enterFrame", transitions[i].runFunc)
			table.remove(transitions, i)
		end
	end
end

return class