local _ = {}
local _speed = 1
local function queBuilder(self)
	if #self.queOrder > 0 then
		--buildItem(que[ queOrder[1] ])

		self.que[ self.queOrder[1] ].callback( self.que[ self.queOrder[1] ].data ) -- return itself so it can be build

		self.que[ self.queOrder[1] ] = nil
		table.remove(self.queOrder, 1)
	else
		--print("nothing to build class")
	end
end

function _:new( o )
 
	local o = o or {}

	setmetatable( o, self )
	self.__index = self

	o.que = {}
	o.queOrder = {}

	o.timer = timer.performWithDelay( _speed, function() queBuilder(o)  end, 0 )
 
  return o
 
end


function _:add(data, key, callback)

	if self.que[key] then
		self:cancel(key)
	end

	if not self.que[key] then
		self.que[key] = {data = data, callback = callback }
		self.queOrder[#self.queOrder+1] = key
	else
		print("Already in Que: ", key)
	end
end

function _:cancel(key)

	if self.que[key] then
		self.que[key] = nil
		for i = #self.queOrder, 1, -1 do
			if self.queOrder[i] == key then
				table.remove(self.queOrder, i)
				break
			end
		end
	end
end

function _:reset()
	for i = #self.queOrder, 1, -1 do
		self.que[ self.queOrder[i] ] = nil
		self.queOrder[i] = nil
	end
end

function _:finalize( o )
	if self.timer then timer.cancel(self.timer) end
	self:reset()
end


function _.setSpeed(speed)
	_speed = speed
end


return _