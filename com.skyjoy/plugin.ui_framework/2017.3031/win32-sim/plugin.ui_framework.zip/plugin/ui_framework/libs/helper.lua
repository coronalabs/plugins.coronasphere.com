local class = {}

function class.ratio(a)-- {ratio = "16:9", w = "300", perfect}
	local h
	local w
	if a.ratio == "16:9" then
		if a.width then
			w = math.round(a.width)
			h = math.ceil(w*0.5625)
		elseif a.height then
			h = math.round(a.height)
			w = math.ceil(h*1.7777)
		end
	elseif a.ratio == "4:3" then
		if a.width then
			w = math.round(a.width or 1)
			h = math.ceil(w*0.75)
		elseif a.height then
			h = math.round(a.height)
			w = math.ceil(h*1.33)
		end	
	elseif a.ratio == "9:16" then
		if a.width then
			w = math.round(a.width)
			h = math.ceil(w*1.7777)
		elseif a.height then
			h = math.round(a.height)
			w = math.ceil(h*0.5625)
		end
	else
		w = math.round(a.width or 1)
		h = math.round(a.height or 1)

		local ratio = (a.height/w)
		local localH = math.ceil(display.contentWidth*ratio)

		if localH < display.contentHeight then
			local ratio = (w/a.height)
			h = display.contentHeight
			w = math.ceil(display.contentHeight*ratio)
		else
			h = localH
			w = display.contentWidth
		end
	end

	if not a.perfect then
		if h % 2 == 0 then -- even
		else
			h = h + 1
		end


		if w % 2 == 0 then -- even
		else
			w = w + 1
		end
	end

	return {width = w, height = h}
end


------------------------------------------------------------------------------------
-- os functions
------------------------------------------------------------------------------------
-- return string that says if first value is equal, lower or higher compared to second value
-- print(os.compareVersions("4.0.4", "4.0.4") )  -> isEqual	
-- print(os.compareVersions("4.0.4", "4.0.5") )  -> isLower	
-- print(os.compareVersions("4.0.4", "4.0.3") )  -> isHigher	
-- print(os.compareVersions("1.0.0", "1.0") )  -> isEqual	
-- print(os.compareVersions("1.0.0", "1.0.0.1") )  -> isLower	
-- print(os.compareVersions("1.0.0.0.2", "1.0.0.1.2") )  -> isLower	
-- view.changeToStart()
function class.compareVersions(v1, v2) 
	local a_v1, a_v2 = class.splitString(v1,  "%." ), class.splitString(v2,  "%." )
	local maxLength = #a_v1 > #a_v2 and #a_v1 or #a_v2

	local iterations = 0
	for i = 1, maxLength do 
		if (tonumber(a_v1[i]) or 0) == (tonumber(a_v2[i]) or 0) then 
			iterations = iterations + 1
			if iterations == maxLength then 
				return "isEqual"
			end 
		elseif (tonumber(a_v1[i]) or 0) > (tonumber(a_v2[i]) or 0) then 
			return "isHigher"
		elseif (tonumber(a_v1[i]) or 0) < (tonumber(a_v2[i]) or 0) then 
			return "isLower"
		end 
	end 
end 

	
function class.splitString( text, inSplitPattern, outResults )
	if not text then return {} end

	if not outResults then
		outResults = { }
	end
	local theStart = 1
	local theSplitStart, theSplitEnd = string.find( text, inSplitPattern, theStart )
	while theSplitStart do
		table.insert( outResults, string.sub( text, theStart, theSplitStart-1 ) )
		theStart = theSplitEnd + 1
		theSplitStart, theSplitEnd = string.find( text, inSplitPattern, theStart )
	end
	table.insert( outResults, string.sub( text, theStart ) )
	return outResults
end

function class.crypt(string, key, mode)
	if not key then key = "ajomb" end
	
	local new_string = ""
	local pass = 0 
	for c_key = 1, #key do 
	pass = pass + string.byte(string.sub(key,c_key,c_key))
	end 
	if pass > 255 then
		pass =  math.floor(pass / (pass/255 +1))
	end
	if mode == 0 then -- encrypt
		for encrypt = 1,#string do 
			add_byte = string.byte(string.sub(string,encrypt,encrypt)) 
			if add_byte + pass > 255 then 
					add_byte = add_byte + pass - 255
			else
					add_byte = add_byte + pass
			end

			add_string = string.char(add_byte) 
			new_string = new_string..add_string
		end 
	elseif mode == 1 then -- uncrypt
		for decrypt = 1,#string do 
			add_byte = string.byte(string.sub(string,decrypt,decrypt)) 
			if add_byte - pass  < 0 then 
					add_byte = 255 + add_byte-pass 
			else
					add_byte = add_byte - pass
			end

			add_string = string.char(add_byte) 
			new_string = new_string..add_string
		end 
	end 
	string = nil
	return new_string
end

return class