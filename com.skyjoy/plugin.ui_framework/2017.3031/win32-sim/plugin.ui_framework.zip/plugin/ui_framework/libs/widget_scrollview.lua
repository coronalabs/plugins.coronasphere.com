
-- Abstract: widget.newScrollView()
-- Code is MIT licensed; see https://www.coronalabs.com/links/code/license
---------------------------------------------------------------------------------------

local M = 
{
	_options = {},
	_widgetName = "widget.newScrollView",
}

-- Require needed widget files
local _widget = require( "plugin.ui_framework.libs.widget" )
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local queManager = require("plugin.ui_framework.libs.que_manager")
local config = require("plugin.ui_framework.config")

-- Localize math functions
local mAbs = math.abs

local _margin = toPx(8)
local _margin_touch_offset = toPx(10)
local _w = display.contentWidth
local _h = display.contentHeight

-- Creates a new scrollView
local function createScrollView( scrollView, options )

	-- Create a local reference to our options table
	local opt = options

	if options.renderSpeed then
		queManager.setSpeed(options.renderSpeed)
	end
	local q = queManager:new() -- elements builder, by item

	
	-- Forward references
	local view, viewFixed, viewBackground, viewMask
	
	-- Create the view
	view = display.newGroup()
	--

	-- TODO: this has to be replaced by correct behavior. Right now, it's a temporary group in which we place objects inserted in the scrollview
	-- in graphics2.0
	local collectorGroup = display.newGroup()
	collectorGroup.x = - opt.width * 0.5
	collectorGroup.y = - opt.height * 0.5
	view:insert( collectorGroup )
	scrollView._collectorGroup = collectorGroup


	viewFixed = display.newGroup()
		
	-- Create the view's background
	viewBackground = display.newRect( scrollView, 0, 0, opt.width, opt.height )
	viewBackground.x = 0
	viewBackground.y = 0

	----------------------------------
	-- Properties
	----------------------------------
	
	-- Background
	viewBackground.isVisible = not opt.shouldHideBackground
	viewBackground.isHitTestable = true
	viewBackground:setFillColor( unpack( opt.backgroundColor ) )
	
	-- Set the view's initial position ( to account for top padding )
	view.y = view.y + opt.topPadding
	-- Set the platform
	view._isPlatformAndroid = "Android" == system.getInfo( "platformName" )

	-- make sure is divisible by 2
	if opt.height % 2 ~= 0 then
        opt.height = opt.height + 1
    end
	
	-------------------------------------------------------
	-- Assign properties to the view
	-------------------------------------------------------
	
	-- We need to assign these properties to the object
	view._background = viewBackground
	view._mask = viewMask
	view._startXPos = 0
	view._startYPos = 0
	view._prevXPos = 0
	view._prevYPos = 0
	view._prevX = 0
	view._prevY = 0
	view._delta = 0
	view._velocity = 0
	view._prevTime = 0
	view._lastTime = 0
	view._tween = nil
	view._left = opt.left
	view._top = opt.top
	view._width = opt.width
	view._height = opt.height
	view._topPadding = opt.topPadding
	view._bottomPadding = opt.bottomPadding
	view._leftPadding = opt.leftPadding
	view._rightPadding = opt.rightPadding
	view._moveDirection = nil
	view._isHorizontalScrollingDisabled = opt.isHorizontalScrollingDisabled
	view._isVerticalScrollingDisabled = opt.isVerticalScrollingDisabled
	view._listener = opt.listener
	view._friction = opt.friction
	view._maxVelocity = opt.maxVelocity
	view._timeHeld = 0
	view._isLocked = opt.isLocked
	view._scrollWidth = opt.scrollWidth
	view._scrollHeight = opt.scrollHeight
	view._trackVelocity = false	
	view._updateRuntime = false
	view._rows = {}
	view._numberOfRows = 0
	view._onRowRender = opt.onRowRender
	view._onRowRemoved = opt.onRowRemoved
	view._onRowTouch = opt.onRowTouch
	view._onTakeFocus = opt.onTakeFocus
	view._columns = opt.columns
	view._columnsPos = {}
	view._columnXIndex = 1
	view._columnYPos = 0
	view._verticalSpacing = opt.verticalSpacing
	view._referenceIndex = {} -- atv referenc table
	view._navigateYOffset = opt.navigateYOffset
	view._itemWidth = opt.itemWidth
	view._topMargin = opt.topMargin
	

	-- calculate item width to place items on grid properly
	local _columnWidth = opt.itemWidth + opt.horizontalSpacing
	local _columnXPos = _columnWidth*.5


	for i = 1, view._columns do
		if opt.itemXOffset then
			view._columnsPos[i] = _columnXPos + opt.itemXOffset
		else
			view._columnsPos[i] = _columnXPos
		end
		  -- view._width*.5
		_columnXPos = _columnXPos + _columnWidth
	end
	for i = 1, view._columns do
		view._columnsPos[i] = view._columnsPos[i] - opt.width *.5
	end

	-- assign the threshold values to the momentum
	view.scrollStopThreshold = opt.scrollStopThreshold
	view.isBounceEnabled = opt.isBounceEnabled
	view.autoHideScrollBar = opt.autoHideScrollBar
	view._widgetType = "scrollView"

	-------------------------------------------------------
	-- Assign properties/objects to the scrollView
	-------------------------------------------------------

	-- Assign objects to the view
	view._fixedGroup = viewFixed

	-- Assign objects to the scrollView
	scrollView._view = view	
	scrollView:insert( view )
	scrollView:insert( viewFixed )
	
	-- assign the momentum variable to the scrollview
	scrollView._momentumScrolling = require( "plugin.ui_framework.libs.widget_momentumScrolling" ):new()
	-- TODO: this is temporary, because the tableview view height is calculated wrong. we need to pass in the widget type to know how to position the scrollbar
	scrollView._momentumScrolling.widgetType = "scrollView"
	
	----------------------------------------------------------
	--	PUBLIC METHODS	
	----------------------------------------------------------
	-- Function to insert a row into a tableView
	function scrollView:insertItem( options )
		return self._view:_insertItem( options )
	end

	function scrollView:insertListItem( id, items )
		return self._view:_insertListItem( id, items )
	end

	-- Function to remove all items in table view
	function scrollView:removeAllItems()
		return self._view:_removeAllItems( )
	end

	-- Function to remove specyfic row at index
	function scrollView:removeItem(index)
		return self._view:_removeItem(index)
	end

	-- Function to retrieve the number of rows in a tableView
	function scrollView:getNumRows()
		return self._view._numberOfRows
	end

	-- Function to retrieve the x/y position of the scrollView's content
	function scrollView:getContentPosition()
		return self._view:_getContentPosition()
	end
	
	-- Function to set the frame of the widget post creation
	function scrollView:setSize( newWidth, newHeight )
		-- resize the widget
		self.width = newWidth
		self.height = newHeight
		--resize the widget's view
		self._view._width = newWidth
		self._view._height = newHeight
		--resize the widget's background
		self._view._background.width = newWidth
		self._view._background.height = newHeight
		-- reposition the collector group if graphics 2.0
		self._collectorGroup.x = - newWidth * 0.5
		self._collectorGroup.y = - newHeight * 0.5

		-- Update the scrollWidth
		self._view._scrollWidth = self._view.width

		-- Update the scrollHeight
		self._view._scrollHeight = self._view.height
				
		-- after the contentWidth / Height updates are complete, scroll the view to the position it was at before inserting the new object
		self:scrollToPosition( { x = self._view.x, y = self._view.y, time = 0 } )
		
		-- Create the scrollBar
		if not opt.hideScrollBar then
			if not self._view._isLocked then
				-- Need a delay here also..
				timer.performWithDelay( 2, function()
					-- because this is performed with a delay, we have to check if we still have the scrollHeight property. This prevents
					-- issues when removing the scrollview after creation in the same frame.
					if self._view._scrollHeight then	
						if not self._view._isVerticalScrollingDisabled and self._view._scrollHeight > self._view._height then							
							display.remove( self._view._scrollBar )
							self._view._scrollBar = nil
							self._view._scrollBar = self._momentumScrolling.createScrollBar( self._view, opt.scrollBarOptions )
						end
					end
				end)
			end
		end	
	end
	
	-- Function to scroll the view to a specific position
	function scrollView:scrollToPosition( options )
		-- check if any scrolling is going on, and cancel the transition
		transition.cancel( "_widgetScrollTransition" )

		local newX = options.x or self._view.x
		local newY = options.y or self._view.y
		local transitionTime = options.time or 400
		local onTransitionComplete = options.onComplete
		
		-- Stop updating Runtime & tracking velocity
		self._view._updateRuntime = false
		self._view._trackVelocity = false
		-- Reset velocity back to 0
		self._view._velocity = 0		
	
		-- Transition the view to the new position
		transition.to( self._view, { 
			tag = "_widgetScrollTransition", 
			x = newX,
			y = newY, 
			time = transitionTime, 
			transition = easing.inOutQuad, 
			onComplete = onTransitionComplete } )
	end
	
	-- Function to scroll the view to a specified position from a list of constants ( i.e. top/bottom/left/right )
	function scrollView:scrollTo( position, options )
		
		-- check if any scrolling is going on, and cancel the transition
		transition.cancel( "_widgetScrollTransition" )
	
		local newPosition = position or "top"
		local newX = self._view.x
		local newY = self._view.y
		local transitionTime = options.time or 400
		local onTransitionComplete = options.onComplete
		
		-- Set the target x/y positions
		if "top" == newPosition then
			newY = self._view._topPadding
		elseif "bottom" == newPosition then
			--newY = self._view._background.y - ( self._view.contentHeight ) + ( self._view._background.contentHeight * 0.5 ) - self._view._bottomPadding
			-- bottom is the scrollHeight ( the view's content height ) minus padding and the actual widget height
			newY = - self._view.contentHeight + self._view._bottomPadding + self.contentHeight
		elseif "left" == newPosition then
			newX = self._view._leftPadding
		elseif "right" == newPosition then
			--newX = self._view._background.x - ( self._view.contentWidth ) + ( self._view._background.contentWidth * 0.5 ) - self._view._rightPadding
			-- right is the scrollWidth ( the view's content width ) minus padding and the actual widget width
			newX = - self._view.contentWidth + self._view._rightPadding + self.contentWidth
		end
		
		-- Transition the view to the new position
		transition.to( self._view, { 
			tag = "_widgetScrollTransition", 
			x = newX, 
			y = newY, 
			time = transitionTime, 
			transition = easing.inOutQuad, 
			onComplete = function()
		
			if "function" == type( onTransitionComplete ) then
				onTransitionComplete()
			end
			-- Stop updating Runtime & tracking velocity
			self._view._updateRuntime = false
			self._view._trackVelocity = false
			-- Reset velocity back to 0
			self._view._velocity = 0
		
		end
		 } )
	end

	function scrollView:getPosition()
		return self._view.x, self._view.y
	end
	
	function scrollView:takeFocus( event )
		local target = event.target
		
		-- Remove focus from the object
		display.getCurrentStage():setFocus( target, nil )
		
		-- Handle turning widget buttons back to their default state (visually, ie their default button images & labels)
		if "table" == type( target ) then
			if "string" == type( target._widgetType ) then
				-- Remove focus from the widget. From parent if the scrollview is in another scrollview, from self otherwise
				if "scrollView" == target.parent._widgetType then
					target.parent:_loseFocus()
				else
					target:_loseFocus()
				end
			end
		end
		
		-- Create our new event table
		local newEvent = {}
		
		-- Copy the event table's keys/values into our newEvent table
		for k, v in pairs( event ) do
			newEvent[k] = v
		end

		-- Set our new event's phase to began, and it's target to the view
		newEvent.phase = "began"
		newEvent.target = self._view
		
		-- Send a touch event to the view
		self._view:touch( newEvent )
	end
		
	function scrollView:setScrollWidth( newValue )
		
		-- adjust the scrollview scroll width
		timer.performWithDelay( 2, function()
			self._view._scrollWidth = newValue or self._view._scrollWidth
		end )
				
	end

	function scrollView:setScrollHeight( newValue )
		
		-- adjust the scrollview scroll height
		timer.performWithDelay( 2, function()
			self._view._scrollHeight = newValue or self._view._scrollHeight
		end )
				
		-- Recreate the scrollBar
		if not opt.hideScrollBar then
			if self._view._scrollBar then
				display.remove( self._view._scrollBar )
				self._view._scrollBar = nil
			end
			
			if not self._view._isLocked then
				-- Need a delay here also..
				timer.performWithDelay( 2, function()
					--[[
					Currently only vertical scrollBar's are provided, so don't show it if they can't scroll vertically
					--]]								
					if not self._view._scrollBar and not self._view._isVerticalScrollingDisabled and self._view._scrollHeight > self._view._height then
						self._view._scrollBar = self._momentumScrolling.createScrollBar( self._view, opt.scrollBarOptions )
					end
				end)
			end
		end	
	end
	
	-- getter for the widget's view
	function scrollView:getView()
		return self._view
	end

	-- getter for the scrollview's velocity
	function scrollView:getVelocity()
		return self._view._velocity
	end

	function scrollView:navigate(state)
		return self._view:_navigate(state)
	end

	function scrollView.remote(direction)
		return scrollView._view:_remote(direction)
	end
	
	----------------------------------------------------------
	--	PRIVATE METHODS	
	----------------------------------------------------------	

	-- Handle touch events on any inserted widget buttons
	local function _handleButtonTouch( event )
		local _targetButton = event.target
		
		-- If the target exists and is not active
		if _targetButton then
			if not _targetButton._isActive then
				local phase = event.phase
				
				view:touch( event )

				return true
			end
		end
	end

	-- Override scale function as scrollView's don't support it
	function scrollView:scale()
		print( "WARNING: " .. M._widgetName .. " does not support scaling" )
	end

	-- Override the insert method for scrollView to insert into the view instead
    scrollView._cachedInsert = scrollView.insert

	function scrollView:updateScrollAreaSize()
				
		-- we store the original coordinates
		local origY = self._view.y
		local origX = self._view.x
		
		-- Update the scroll content area size (NOTE: Seems to need a 1ms delay for the group to reflect it's new content size? ) odd ...
		timer.performWithDelay( 1, function()
			-- Update the scrollWidth
			self._view._scrollWidth = self._view.width

			-- Update the scrollHeight
			self._view._scrollHeight = self._view.height

			local groupXPadding = 0
			local groupYPadding = 0
			-- for v2. we have to compute the left padding to the first object into the dimensions
			-- of the scrollview scroll area
		
				if self._collectorGroup.numChildren and self._collectorGroup.numChildren > 0 then
					local leftPadding = self._collectorGroup[ 1 ].x - ( self._collectorGroup[ 1 ].width * 0.5 )
					local topPadding = self._collectorGroup[ 1 ].y - (self._collectorGroup[ 1 ].height * 0.5 )
					if leftPadding > 0 then
						groupXPadding = groupXPadding + leftPadding
					end
					if topPadding > 0 then
						groupYPadding = groupYPadding + topPadding
					end
				end
				if self._view._scrollWidth then
					self._view._scrollWidth = self._view._scrollWidth + groupXPadding
				end
				if self._view._scrollHeight then
					self._view._scrollHeight = self._view._scrollHeight + groupYPadding
				end
			

			-- Override the scroll height if it is less than the height of the window
			if "number" == type( self._view._scrollHeight ) and "number" == type( self._view._height ) then
				if self._view._scrollHeight < self._view._height then
					self._view._scrollHeight = self._view._height
				end
			end

			-- Override the scroll width if it is less than the width of the window
				if "number" == type( self._view._scrollWidth ) and "number" == type( self._view._width ) then
				if self._view._scrollWidth < self._view._width then
					self._view._scrollWidth = self._view._width
				end
			end
				
			-- override also if the values are nil
			if not self._view._scrollWidth then
				self._view._scrollWidth = self._view._width
			end
				
			if not self._view._scrollHeight then
				self._view._scrollHeight = self._view._height
			end
		end)
		
		-- Create the scrollBar
		if not opt.hideScrollBar then
			if self._view._scrollBar then
				display.remove( self._view._scrollBar )
				self._view._scrollBar = nil
			end
			
			if not self._view._isLocked then
				-- Need a delay here also..
				timer.performWithDelay( 2, function()
					--[[
					Currently only vertical scrollBar's are provided, so don't show it if they can't scroll vertically
					--]]
					
					-- because this is performed with a delay, we have to check if we still have the scrollHeight property. This prevents
					-- issues when removing the scrollview after creation in the same frame.
					if self._view._scrollHeight then										
						if not self._view._scrollBar and not self._view._isVerticalScrollingDisabled and self._view._scrollHeight > self._view._height then
							self._view._scrollBar = self._momentumScrolling.createScrollBar( self._view, opt.scrollBarOptions )
						end
					end
				end)
			end
		end

		-- after the contentWidth / Height updates are complete, scroll the view to the position it was at before inserting the new object
		self:scrollToPosition( { x = origX, y = origY, time = 0 } )
	end

    function scrollView:insert( arg1, arg2 )
        local index, obj
        
        if arg1 and type( arg1 ) == "number" then
            index = arg1
        elseif arg1 and type( arg1 ) == "table" then
            obj = arg1
        end
        
        if arg2 and type( arg2 ) == "table" then
            obj = arg2
        end
        
        if index then
           	self._collectorGroup:insert( index, obj )
        else
        	self._collectorGroup:insert( obj )
        end

		-- Override the removeself method for this object (so we can recalculate the content size after it is removed)
		-- If we haven't already over-ridden it
		if nil == obj._cachedRemoveSelf then
			obj._cachedRemoveSelf = obj.removeSelf

			local function removeSelf( self )
				self:_cachedRemoveSelf()
				
				-- Update the scroll area size
				if self and self._widgetName == "widget.newScrollView" then
					self:updateScrollAreaSize()
				end
			end
			
			obj.removeSelf = removeSelf
		end

		-- Update the scroll area size
		self:updateScrollAreaSize()
    end
    
	function scrollView:remove( arg1 )
        local index, obj
        
        if type( arg1 ) == "number" then
            index = arg1
        elseif type( arg1 ) == "table" then
            obj = arg1
        end

        if index then
            self._collectorGroup:remove( index )
            
        elseif obj then
       		self._collectorGroup:remove( obj )
        end

		-- Update the scroll area size
		self:updateScrollAreaSize()
    end

    
    -- isLocked setter function
	function scrollView:setIsLocked( lockedState, direction )
		return self._view:_setIsLocked( lockedState, direction )
	end
	
	-- function for handling mouse scrolling on the scrollview widget
	function scrollView:mouse( event )
		if (event.scrollX ~= 0) or (event.scrollY ~= 0) then
			local x, y = self:getContentPosition()
			local mAbs = math.abs
			x = x - event.scrollX
			y = y - event.scrollY
			
			-- treat constraints
			
			-- on y
			if y > self._view._topPadding then
				y = self._view._topPadding
			elseif y < ( - self._view.contentHeight + self._view._bottomPadding + self.contentHeight ) then
				y = - self._view.contentHeight + self._view._bottomPadding + self.contentHeight
			end
			
			-- on x
			if x > self._view._leftPadding then
				x = self._view._leftPadding
			elseif x < ( - self._view.contentWidth + self._view._rightPadding + self.contentWidth ) then
				x = - self._view.contentWidth + self._view._rightPadding + self.contentWidth
			end
			
			self:scrollToPosition({ x = x, y = y, time = 0})
			-- display the scrollbar
			if self._view._scrollBar then
				if self._view.autoHideScrollBar then
					self._view._scrollBar:show()
				end
				self._view._scrollBar:move()
			end
		elseif ( event.scrollY == 0 and event.type == "scroll" and not self._view._isUsedInPickerWheel ) then
			if self._view._scrollBar then
				if self._view.autoHideScrollBar then
					self._view._scrollBar:hide()
				end		
			end
		end
	end
	
	if ( _widget.mouseEventsEnabled ) then
		scrollView:addEventListener( "mouse", scrollView )
	end

	-- Transfer touch from the view's background to the view's content
	function viewBackground:touch( event )		
		view:touch( event )
		
		return true
	end
	
	viewBackground:addEventListener( "touch" )
	
	-- Handle touches on the scrollview
	function view:touch( event )

		local phase = event.phase

		-- the event.target is the tableView row. however, the row has calculations in the enterFrame listener that prevent the table from scrolling
		-- when the limit is hit. In this case, only if the view is used in picker, we set the target to the tableview's background, and that will allow
		-- free movement independently.

		-- Set the time held
		if "began" == phase then
			-- print("began main touch")
			-- display.getCurrentStage():setFocus( event.target )
			self._timeHeld = event.time
			event.target.lastX = event.x
			event.target.touch_began_time = event.time
			-- Set the initial touch

			-- By default we allow touch events for our rows
			self._permitRowTouches = true

			-- If the velocity is over 0.05, we prevent touch events on the rows as press/tap events should only result in the view's momentum been stopped
			if mAbs( self._velocity ) > 0.05 then
				-- if the view is at the bottom or at the top, allow the touch, because in the momentum we have a timer that causes the above if
				-- to determine that the view is still in motion, although it's not.
				if not self._hasHitBottomLimit and not self._hasHitTopLimit then
					self._permitRowTouches = false
				else
					self._velocity = 0
				end
			end
		end

		-- Distance moved
		local dy = mAbs( event.y - event.yStart )
		local dx = mAbs( event.x - event.xStart )

		local moveThresh = _margin_touch_offset

		if "moved" == phase then

			-- New phase is now nil, since it was moved
			self._newPhase = nil
	
			if mAbs( self._velocity ) < 0.01 then
				if event.target.isList and dx > moveThresh then
					event.target.deltaX = (event.x - event.target.lastX)
					event.target.lastX = event.x
					event.target.x = event.target.x + event.target.deltaX
					event.target.move_time = event.time

					if not self._isLocked then
						-- print("lock")
						view:_setIsLocked( true, "vertical" )
						self._velocity = 0
					end

					if config.isAndroid then
				    	if event.target.x > _margin then
				    		event.target.x = _margin
		    			elseif -(event.target.x - view._width)-_margin > event.target.width  then
		    				event.target.x = - (event.target.width) + view._width - _margin
		    			end
	    			end						
				end
			end
		end

		-- Set the view's phase so we can access it in the enterFrame listener below
		self._phase = event.phase

		-- Handle momentum scrolling (if the view isn't locked)
		if not self._isLocked then
			scrollView._momentumScrolling._touch( self, event )
		end

		-- Execute the listener if one is specified
		if "function" == type( self._listener ) then
			self._listener( event )
		end

		-- Set the view's target row (the row we touched) so we can access it in the enterFrame listener below
		self._targetRow = event.target

		-- Handle swipe events on the tableView
		if "ended" == phase or "cancelled" == phase then
			-- print("ended")
			if event.target.isList and self._isLocked then
				display.getCurrentStage():setFocus( event.target, nil )
				view:_setIsLocked( false, "vertical" )
				self._velocity = 0

				-- smooth scroll animations.
				local _speed = event.time - event.target.touch_began_time

				local _dist = math.abs(event.xStart - event.x)

				local _number_of_items = 0
				if _dist < event.target._width then
					_number_of_items = 1
				elseif _dist < event.target._width*2 then
					_number_of_items = 2
				elseif _dist < event.target._width*3 then
					_number_of_items = 3
				else
					_number_of_items = 4
				end

				if event.xStart < event.x then -- left
					local _pos = ((math.round(event.target.x/(event.target._width + event.target.spacing) ) ) + _number_of_items)*(event.target._width + event.target.spacing)
					local _x = _pos
					if _x > 0 then
			    		_x = 0
	    			end
					transition.to( event.target, {time = _speed + 200, x = _x, transition=easing.outCirc} )
				elseif event.xStart > event.x then -- right
					local _pos = (math.abs(math.round(event.target.x/(event.target._width + event.target.spacing) ) ) + _number_of_items)*(event.target._width + event.target.spacing)

					local _x = _pos
					if _x > event.target.width - view._width then
	    				_x = event.target.width - view._width
	    			end
					transition.to( event.target, {time = _speed + 200, x = -_x, transition=easing.outCirc} )
				end
			end
			-- This wasn't the initial touch

			if mAbs( self._velocity ) < 0.01 then
				local xStart = event.xStart
				local xEnd = event.x
				local yStart = event.yStart
				local yEnd = event.y

				local xDistance = mAbs( xEnd - xStart )
				local yDistance = mAbs( yEnd - yStart )

				if xDistance + yDistance < _margin_touch_offset then
					if self._onRowTouch then-- and event.target.isRow then
						self._onRowTouch( {
								phase = "ended",
								target = event.target,
							} )
					end
				end
			end
		end

		return true
	end
	
	view:addEventListener( "touch" )
	
	
  	-- EnterFrame listener for our scrollView
	function view:enterFrame( event )
		local _scrollView = self.parent

		-- Handle momentum @ runtime
		_scrollView._momentumScrolling._runtime( self, event )		
		
		-- Constrain x/y scale values to 1.0
		if _scrollView and _scrollView.xScale ~= 1.0 then
			_scrollView.xScale = 1.0
			print( "WARNING: control does not support scaling" )
		end
		
		if _scrollView and _scrollView.yScale ~= 1.0 then
			_scrollView.yScale = 1.0
			print( "WARNING: control does not support scaling" )
		end

		-- Update the top position of the scrollView (if moved)
		if _scrollView and _scrollView.y ~= self._top then
			self._top = _scrollView.y
		end

		return true
	end
	
	Runtime:addEventListener( "enterFrame", view )
	
	-- _getContentPosition
	-- returns the x,y coordinates of the scrollview
	function view:getContentPosition()
		return self:_getContentPosition()
	end
	
	function view:_getContentPosition()
		local returnX = self.x
		local returnY = self.y
		
		return returnX, returnY
	end
	
	-- isLocked variable setter function
	function view:_setIsLocked( lockedState, direction )
		if type( lockedState ) ~= "boolean" then
			return
		end
		
		if direction and type ( direction ) ~= "string" then
			return
		end
		
		-- if we received a direction to set a lockstate on, proceed
		if direction then
			if "horizontal" == direction then
				self._isHorizontalScrollingDisabled = lockedState
			elseif "vertical" == direction then
				self._isVerticalScrollingDisabled = lockedState
			end
		-- otherwise set both directions to the received lockstate
		else
			self._isVerticalScrollingDisabled = lockedState
			self._isHorizontalScrollingDisabled = lockedState
		end
		
		-- if both scroll axis variables are disabled, then the scrollview is locked
		if self._isHorizontalScrollingDisabled and self._isVerticalScrollingDisabled then
			self._isLocked = true
		else
			self._isLocked = false
		end
		
		-- if we unlock the scrollview and the scrollview's content is bigger than the widget bounds, init the scrollbar.
		if not opt.hideScrollBar then
			if self._scrollBar then
				display.remove( self._scrollBar )
				self._scrollBar = nil
			end
			
			if not self._isLocked then
				-- Need a delay here also..
				timer.performWithDelay( 2, function()
					--[[
					Currently only vertical scrollBar's are provided, so don't show it if they can't scroll vertically
					--]]								
					if not self._scrollBar and not self._isVerticalScrollingDisabled and self._scrollHeight > self._height then
						self._scrollBar = self.parent._momentumScrolling.createScrollBar( self, opt.scrollBarOptions )
					end
				end)
			end
		end			
	end


	-- Send row touch event's to the view
	local function _handleRowTouch( event )
		view:touch( event )
		return true
	end

	local function createListItem()
		local group = display.newGroup()

		return group
	end

	-- Function to create a tableView row
	function view:_createRow( row, isReRender )
		local currentRow = row

		-- Set the upper and lower category limits

		if isReRender then
			if currentRow._view then
				display.remove( currentRow._view )
				currentRow._view = nil
			end
		elseif currentRow._view then
			display.remove( currentRow._view )
			currentRow._view = nil
		end
		-- Create the row's view (a row is a display group)
		currentRow._view = display.newGroup()
		currentRow._view.x = currentRow.x
		currentRow._view.isRow = true -- flag for touch events when there are now rows.
		currentRow._view._width = currentRow._width
		currentRow._view._height = currentRow._height

		-- -- ATV reference
		-- -- print("PRE START !!!!!!!!", #self._referenceIndex)
		-- for i = 1, #self._referenceIndex do
		-- 	-- print("START!!!!!!!!")
		-- 	if self._referenceIndex[i].id == row.id then
		-- 		self._referenceIndex[i].item = row 
		-- 		-- print("OK!!!!!!!!")
		-- 		-- error()
		-- 	end
		-- end

		local bg = display.newRect( currentRow._view, 0, 0, currentRow._width, currentRow._height )
		if currentRow.backgroundColor then
			bg:setFillColor( unpack(currentRow.backgroundColor) )
		else
			bg.isVisible = false
			bg.isHitTestable = true
		end
		currentRow._view.bg = bg

		local curY = currentRow.y
		
		currentRow._view.y = curY

		-- Assign properties to the row
		currentRow._view.index = currentRow.index
		currentRow._view.id = currentRow.id
		currentRow._view.isCategory = currentRow.isCategory
		if currentRow._view.isCategory then -- remove touch from cateogry
			currentRow._view.isRow = false
		end

		currentRow._view.isList = currentRow.isList
		if currentRow._view.isList then -- remove touch from cateogry
			currentRow._view.isRow = false
			currentRow._view.spacing = currentRow.spacing
			currentRow._view.x = opt.itemXOffset
			bg.anchorX = 0
			bg.x = - view._width*.5

			for i = 1, #currentRow.items do
				q:add(nil, currentRow.id..i, 
					function() 
						local item = createListItem()
						currentRow.items[i]._view = item
						currentRow._view:insert(item)
						item.x = currentRow.items[i].x
						item.params = currentRow.items[i].params
						item.data = currentRow.items[i].data
						item.isList = false
						item.isListItem = true
						item.isCategory = false
						item.isRow = false
						item.contentWidth = currentRow.items[i].width
						item.contentHeight = currentRow.items[i].height
						item.index = i

						currentRow.items[i].isList = false
						currentRow.items[i].isListItem = true
						currentRow.items[i].isCategory = false
						currentRow.items[i].isRow = false

						-- item:addEventListener( "touch", _handleRowTouch )

						local function listItemListener( event )
							
							if event.phase == "began" then
								-- print("began item touch")
								display.getCurrentStage():setFocus( event.target )
								event.target.parent.lastX = event.x
								event.target.parent.deltaX = 0
								event.target.parent.touch_began_time = event.time

							elseif event.phase == "moved" then
								local xDistance = mAbs( event.x - event.xStart )
								local yDistance = mAbs( event.y - event.yStart )
								if xDistance > _margin_touch_offset then
									display.getCurrentStage():setFocus( nil )
									display.getCurrentStage():setFocus(event.target.parent )
									-- scrollView:takeFocus( event )
								elseif yDistance > _margin_touch_offset then
									scrollView:takeFocus( event )
								end
								return true
							elseif event.phase == "ended" then
								-- print("ended item touch", self._velocity)

								display.getCurrentStage():setFocus( nil )
								-- event.target.parent._isFocus = false
								if mAbs( self._velocity ) < 0.01 then
									local xDistance = mAbs( event.x - event.xStart )
									local yDistance = mAbs( event.y - event.yStart )
									if xDistance + yDistance < _margin_touch_offset then
										if self._onRowTouch then
											self._onRowTouch( {
													phase = "ended",
													target = event.target,
												} )
										end
									end
								end
							end
							return true
						end
						
						item:addEventListener( "touch", listItemListener )

						-- Create the rowRender event
						local rowEvent =
						{
							name = "rowRender",
							row = item,
							-- target = self.parent,
						}

						-- If an onRowRender event exists, execute it
						if self._onRowRender and "function" == type( self._onRowRender ) then
							self._onRowRender( rowEvent )
						end
						currentRow._view.bg.width = currentRow._view.width + (#currentRow.items*view._verticalSpacing)

					end)
			end
		end
		-- add the custom params to the row
		currentRow._view.params = currentRow.params
		currentRow._view.data = currentRow.data	

		-- Insert the row into the view
		self:insert( currentRow._view )

		currentRow._view:addEventListener( "touch", _handleRowTouch )
		-- currentRow._view:addEventListener( "tap", _handleRowTap )
	
		if not currentRow._view.isList then
			-- Create the rowRender event
			local rowEvent =
			{
				name = "rowRender",
				row = currentRow._view,
				-- target = self.parent,
			}

			-- If an onRowRender event exists, execute it
			if self._onRowRender and "function" == type( self._onRowRender ) then
				self._onRowRender( rowEvent )
			end
		end
	end

	function view:_updateItemsPositions()
		for i = 1, #self._rows do
			self._rows[i].index = i
			if i == 1 then
				self._columnYPos = ( self._rows[i]._height * 0.5 ) - self.parent.height * 0.5
			end

			self._rows[i].x = self._columnsPos[self._columnXIndex]

			self._rows[i].y = self._columnYPos

			if self._columnXIndex >= self._columns then
				self._columnXIndex = 1
				self._scrollHeight = self._scrollHeight + self._rows[i]._height
				self._columnYPos = self._columnYPos + self._rows[i]._height
				
			else
				self._columnXIndex = self._columnXIndex + 1
			end
			if self._rows[i]._view then
				self._rows[i]._view.x = self._rows[i].x
				self._rows[i]._view.y = self._rows[i].y
			end
		end
	end

	function view:_insertItem( options, reRender )
		if not self.parent then return end
		-- Create the row
		self._rows[#self._rows + 1] = {}

		-- Are we re-rendering this row?
		local isReRender = reRender

		-- Retrieve passed in row customization variables
		local rowIndex = #self._rows

		-- the passed row params
		local rowParams = options.params or {}
		local rowData = options.data or {}


		
		-- Assign public properties to the row
		self._rows[rowIndex].id = options.id or rowIndex
		self._rows[rowIndex].index = rowIndex
		self._rows[rowIndex].tv_index = 0
		self._rows[rowIndex].isCategory = options.isCategory
		self._rows[rowIndex].isList = options.isList
		self._rows[rowIndex].backgroundColor = options.backgroundColor


		-- add the params table to the row variable
		self._rows[rowIndex].params = rowParams
		self._rows[rowIndex].data = rowData

		-- Assign private properties to the row
		self._rows[rowIndex]._width = options.width or self._width
		self._rows[rowIndex]._height = options.height or toPx(40)
		self._rows[rowIndex]._view = nil
		self._rows[rowIndex].isRendered = false
		self._rows[rowIndex].renderInProgress = false
		self._rows[rowIndex].removeInProgress = false
		self._rows[rowIndex].spacing = options.spacing or 0


		-- increment the table rows variable
		self._numberOfRows =  self._numberOfRows + 1

		-- Calculate and set the row's y position
		-- if view._columns == 1 then
		


		if self._rows[rowIndex].isCategory then
		
			view._columnXIndex = view._columns
			self._scrollHeight = self._scrollHeight + self._rows[rowIndex]._height + self._verticalSpacing
			if rowIndex == 1 then
				view._columnYPos = ( self._rows[rowIndex]._height * 0.5 ) - self.parent.height * 0.5 + self._verticalSpacing
			else
				view._columnYPos = view._columnYPos + self._rows[rowIndex-1]._height*.5 + self._rows[rowIndex]._height*.5 + self._verticalSpacing
			end
			self._rows[rowIndex].x = 0
			self._rows[rowIndex].y = view._columnYPos

		elseif self._rows[rowIndex].isList then
			
			view._columnXIndex = view._columns
			self._scrollHeight = self._scrollHeight + self._rows[rowIndex]._height + self._verticalSpacing
			if rowIndex == 1 then
				view._columnYPos = ( self._rows[rowIndex]._height * 0.5 ) - self.parent.height * 0.5 + self._verticalSpacing
			else
				view._columnYPos = view._columnYPos + self._rows[rowIndex-1]._height*.5 + self._rows[rowIndex]._height*.5 + self._verticalSpacing
			end
			self._rows[rowIndex].x = 0
			self._rows[rowIndex].y = view._columnYPos
			self._rows[rowIndex].items = {}

			-- atv reference
			if config.isTv then
				self._referenceIndex[#self._referenceIndex+1] = { isList = true }
				self._rows[rowIndex].tv_index = #self._referenceIndex
			end

		
		else
			self._rows[rowIndex].isRow = true

			if view._columnXIndex >= view._columns then
				view._columnXIndex = 1
				self._scrollHeight = self._scrollHeight + self._rows[rowIndex]._height + self._verticalSpacing
				if rowIndex == 1 then
					view._columnYPos = ( self._rows[rowIndex]._height * 0.5 ) - self.parent.height * 0.5 + self._verticalSpacing
				else
					view._columnYPos = view._columnYPos + self._rows[rowIndex-1]._height*.5 + self._rows[rowIndex]._height*.5 + self._verticalSpacing
				end
			else
				if rowIndex > 1 then
					view._columnXIndex = view._columnXIndex + 1
				else
					view._columnYPos = ( self._rows[rowIndex]._height * 0.5 ) - self.parent.height * 0.5 + self._verticalSpacing
				end
			end
			
			-- atv reference
			if config.isTv then
				if view._columnXIndex == 1 then
					-- print("XXX", view._columnXIndex )
					self._referenceIndex[#self._referenceIndex+1] = {}
					self._referenceIndex[#self._referenceIndex][1] = self._rows[rowIndex]
				else
					self._referenceIndex[#self._referenceIndex][ #self._referenceIndex[#self._referenceIndex] + 1 ] = self._rows[rowIndex]
				end
				self._rows[rowIndex].tv_index = #self._referenceIndex
			end

			self._rows[rowIndex].x = view._columnsPos[view._columnXIndex]

			self._rows[rowIndex].y = view._columnYPos + view._topMargin
		end
		
		-- Reposition the scrollbar, if it exists
		if self._scrollBar then
			self._scrollBar:repositionY()
		end
	end

	function view:_insertListItem( id, options, reRender )

		local row_index = 0 
		local row_tv_index = 0
		local _y = 0
		for i = 1, #self._rows do
			if self._rows[i].id == id then
				row_index = i
				row_tv_index = self._rows[i].tv_index
				_y = self._rows[i].y
				break
			end
		end
		if row_index == 0 then
			print("Warrning: list not found")
		end

		local _item_options = {}
		for k,v in pairs(options) do
			_item_options[k] = v
		end


		local itemIndex = #self._rows[row_index].items+1

		-- Are we re-rendering this row?
		local isReRender = reRender

		-- Retrieve passed in row customization variables
		local rowIndex = #self._rows

		-- the passed row params
		local rowParams = options.params or {}
		local rowData = options.data or {}



		-- Assign public properties to the row
		_item_options.index = itemIndex

		-- add the params table to the row variable
		_item_options.params = rowParams
		_item_options.data = rowData

		-- Assign private properties to the row
		_item_options._width = options.width or self._width
		_item_options._height = options.height or toPx(40)
		_item_options._view = nil
		_item_options.isRendered = false
		_item_options.renderInProgress = false
		_item_options.removeInProgress = false
		_item_options.y = _y


		if itemIndex == 1 then
			_item_options.x = - self._width*.5 + _item_options._width*.5 + self._rows[row_index].spacing
		else
			_item_options.x = self._rows[row_index].items[itemIndex - 1].x + self._rows[row_index].items[itemIndex - 1]._width*.5 + _item_options._width*.5 + self._rows[row_index].spacing
		end
		self._rows[row_index].items[itemIndex] = _item_options

		-- atv reference
		if config.isTv then
			self._referenceIndex[row_tv_index][ #self._referenceIndex[row_tv_index] + 1 ] = self._rows[row_index].items[itemIndex]
		end
		
		-- Reposition the scrollbar, if it exists
		if self._scrollBar then
			self._scrollBar:repositionY()
		end
	end

	function view:_removeAllItems()
		scrollView:scrollTo( "top", {time = 0} )
		for i = #self._rows, 1, -1 do
			if self._onRowRemoved then
				self._onRowRemoved({
					name = "rowRemoved",
					row = self._rows[i]._view,
					target = self.parent,
				})
			end
			display.remove(self._rows[i]._view)
			table.remove(self._rows, i)
		end
		self._numberOfRows = 0
		self._columnXIndex = 1
		for i = #self._referenceIndex, 1, -1 do
			self._referenceIndex[i] = nil
		end
		scrollView:updateScrollSize()
	end

	function view:_removeItem(index)
		for i = #self._rows, 1, -1 do
			if self._rows[i].index == index then
				if self._onRowRemoved then
					self._onRowRemoved({
						name = "rowRemoved",
						row = self._rows[i]._view,
						target = self.parent,
					})
				end
				display.remove(self._rows[i]._view)
				table.remove(self._rows, i)
				break
			end
		end
		view:_updateItemsPositions()
		scrollView:updateScrollSize()
	end

	-- ATV + remote
	local activeItem = { 
		current = {
			v = 1, 
			h = 1
		},
		last = {
			v = 1,
			h = 1
		}
	}

	function view:_navigate(state) -- start, end
		if not self._referenceIndex[ activeItem.current.v ] or not self._referenceIndex[ activeItem.current.v ][ activeItem.current.h ] then return end
		
		local _item = self._referenceIndex[ activeItem.current.v ][ activeItem.current.h ]

		if _item._view then
			if state == "start" then
				_item._view:toFront()
				transition.to( _item._view, { time = 150, xScale = 1.1, yScale = 1.1 } )
			elseif state == "stop" then
				transition.to( _item._view, { time = 150, xScale = 1, yScale = 1 } )
			else
				if activeItem.current.v == activeItem.last.v and activeItem.current.h == activeItem.last.h then -- do nothing is on the same item 
					return
				else
					transition.to( self._referenceIndex[ activeItem.last.v ][ activeItem.last.h ]._view, { time = 150, xScale = 1, yScale = 1 } )

					activeItem.last.v = activeItem.current.v
					activeItem.last.h = activeItem.current.h
					transition.to( _item._view, { time = 150, xScale = 1.1, yScale = 1.1 } )

					_item._view:toFront()
				end 
			end


			if self._referenceIndex[ activeItem.current.v ].isList then
				if _item.x > self._navigateYOffset then
					transition.to( _item._view.parent, {time = 250, x = -_item.x, transition=easing.outCirc} )
				elseif _item._view.parent.x < 0 then
					transition.to( _item._view.parent, {time = 250, x = opt.itemXOffset, transition=easing.outCirc} )
				end
			end
		end

		
		if _item.y and _item.y > self._navigateYOffset then
			scrollView:scrollToPosition( {y = - _item.y + self._navigateYOffset, time = 250 } )
		elseif view.y < 0 then
			scrollView:scrollToPosition( {y = 0, time = 250 } )
		end
		
	end

	local function clamp()
		if activeItem.current.v > #view._referenceIndex then
			activeItem.current.v = #view._referenceIndex
		elseif activeItem.current.v <= 0 then
			activeItem.current.v = 1
		elseif activeItem.current.h > #view._referenceIndex[activeItem.current.v] then
			activeItem.current.h = #view._referenceIndex[activeItem.current.v]
		elseif activeItem.current.h <= 0 then
			activeItem.current.h = 1
		end
	end

	function view:_remote(direction) -- "left, right, down, up, start, stop"

		if direction == "down" then
			activeItem.current.v = activeItem.current.v + 1 

		elseif direction == "up" then
			activeItem.current.v = activeItem.current.v - 1 
		elseif direction == "left" then
			activeItem.current.h = activeItem.current.h - 1 
			if activeItem.current.h <= 0 then
				activeItem.current.h = 1 -- change it back to 1 before callback
				self._onRowTouch( {
					phase = "ended",
					state = "left_limit",
				} )
			end
		elseif direction == "right" then
			activeItem.current.h = activeItem.current.h + 1 
		elseif direction == "ok" or direction == "enter" or direction == "center" then
			self._onRowTouch( {
				phase = "ended",
				state = "ok",
				target = self._referenceIndex[ activeItem.current.v ][ activeItem.current.h ],
			} )

			transition.to( self._referenceIndex[ activeItem.current.v ][ activeItem.current.h ]._view, {alpha = 0.7, time = 150} )
			transition.to( self._referenceIndex[ activeItem.current.v ][ activeItem.current.h ]._view, {alpha = 1, delay = 150, time = 150} )
		end
		clamp()
		self:_navigate()
	end

	-- Function to manage all row's lifeCycle
	function view:_manageRowLifeCycle()
	
		-- Set the upper and lower category limits
		local upperLimit = self._background.y - ( self._background.contentHeight)
		local lowerLimit = self._background.y + ( self._background.contentHeight)

		-- print(upperLimit)
		local temp = 0
		-- Loop through all of the rows contained in the tableView
		for i = 1, #self._rows do
			-- print(i)
		
			local currentRow = self._rows[i]

			local isRowWithinBounds = ( currentRow.y + self.y ) + currentRow._height * 2 > upperLimit and ( currentRow.y + self.y ) - currentRow._height * 2 < lowerLimit
			
			if isRowWithinBounds then
				if not currentRow.isRendered and not currentRow.renderInProgress then
					currentRow.renderInProgress = true
					-- currentRow.removeInProgress = false
					q:add(nil, "index_"..i, 
						function() 
							currentRow.renderInProgress = false
							currentRow.isRendered = true
							
							self:_createRow( currentRow ) 
						end)
				elseif currentRow.removeInProgress and not currentRow.renderInProgress then
					currentRow.removeInProgress = false
					currentRow.renderInProgress = false
					currentRow.isRendered = true
					q:cancel("index_"..i)
				end
			else
				if currentRow.isRendered and not currentRow.removeInProgress then
					currentRow.removeInProgress = true
					-- currentRow.renderInProgress = false
						q:add(nil, "index_"..i, 
							function() 
								currentRow.isRendered = false
								currentRow.removeInProgress = false
								-- currentRow.renderInProgress = false
								display.remove( currentRow._view )
								currentRow._view = nil
							end )
				elseif currentRow.renderInProgress then
					currentRow.removeInProgress = false
					currentRow.renderInProgress = false
					currentRow.isRendered = false
					q:cancel("index_"..i)
				end
			end
	
		end
	end

	local manage_cycle_timer = timer.performWithDelay( 25, 
		function() view:_manageRowLifeCycle() end, 0 )
	view:_manageRowLifeCycle()
	
	function scrollView:updateScrollSize()
		local _height = 0
		local _column_count = 0
		local _row_height = 0
		-- isRow
		for i = 1, #view._rows do
			_row_height = view._rows[i]._height
		
			if view._rows[i].isRow then
				

				if view._columns > 1 then
					_column_count = _column_count + 1
					if _column_count == view._columns then
						_column_count = 0
						_row_height = 0
					elseif _column_count == 1 then

						_height = _height + (_row_height + view._verticalSpacing)
					end
				else
					_height = _height + _row_height + view._verticalSpacing
				end
			else
				_height = _height + _row_height + view._verticalSpacing
			end
		end

		_height = _height + view._verticalSpacing
		if _height == 0 then _height = 1 end
		self:setScrollHeight( _height )
	end
	-- Finalize function for the scrollView
	local function finalizeListener()
		-- Remove the runtime listener
		if manage_cycle_timer then
			timer.cancel(manage_cycle_timer)
		end

		Runtime:removeEventListener( "enterFrame", scrollView._view )
		for i = 1, #view._rows do
			q:cancel("index_"..i)
		end

		q:finalize()
				
		-- Remove scrollBar if it exists
		if scrollView._view._scrollBar then
			display.remove( scrollView._view._scrollBar )
			scrollView._view._scrollBar = nil
		end
	end

	scrollView.finalize = finalizeListener
    scrollView:addEventListener( "finalize" )
			
	return scrollView
end


-- Function to create a new scrollView object ( widget.newScrollView )
function M.new( options )	
	local customOptions = options or {}
	
	-- Create a local reference to our options table
	local opt = {}
	
	-------------------------------------------------------
	-- Properties
	-------------------------------------------------------

	-- Positioning & properties
	opt.left = customOptions.left or 0
	opt.top = customOptions.top or 0
	opt.x = customOptions.x or nil
	opt.y = customOptions.y or nil
	if customOptions.x and customOptions.y then
		opt.left = 0
		opt.top = 0
	end
	opt.width = customOptions.width or display.contentWidth
	opt.height = customOptions.height or display.contentHeight
	opt.id = customOptions.id
	opt.baseDir = customOptions.baseDir or system.ResourceDirectory
	opt.maskFile = customOptions.maskFile
	opt.listener = customOptions.listener
		
	-- Properties
	opt.shouldHideBackground = customOptions.hideBackground or false
	opt.backgroundColor = customOptions.backgroundColor or { 255, 255, 255, 0 }
	opt.topPadding = customOptions.topPadding or 0
	opt.bottomPadding = customOptions.bottomPadding or 0
	opt.leftPadding = customOptions.leftPadding or 0
	opt.rightPadding = customOptions.rightPadding or 0
	opt.isHorizontalScrollingDisabled = customOptions.horizontalScrollDisabled or false
	opt.isVerticalScrollingDisabled = customOptions.verticalScrollDisabled or false
	opt.horizontalScrollingDisabledInConstructor = customOptions.horizontalScrollDisabled or false
	opt.verticalScrollingDisabledInConstructor = customOptions.verticalScrollDisabled or false
	opt.friction = customOptions.friction or 0.972
	opt.maxVelocity = customOptions.maxVelocity or toPx(2.5)
	opt.scrollWidth = customOptions.scrollWidth or opt.width
	opt.scrollHeight = customOptions.scrollHeight or opt.height
	opt.hideScrollBar = customOptions.hideScrollBar or false
	opt.isLocked = customOptions.isLocked or false
	opt.scrollStopThreshold = customOptions.scrollStopThreshold or toPx(250)
	opt.isBounceEnabled = true
	opt.onRowRender = customOptions.onRowRender or function() print("render function not defined") end
	opt.onRowRemoved = customOptions.onRowRemoved
	opt.onRowTouch = customOptions.onRowTouch
	opt.onTakeFocus = customOptions.onTakeFocus
	opt.columns = customOptions.columns or 1
	opt.verticalSpacing = customOptions.verticalSpacing or 0
	opt.navigateYOffset = customOptions.navigateYOffset or 0
	opt.horizontalSpacing = customOptions.horizontalSpacing or 0
	opt.itemWidth = customOptions.itemWidth or opt.width/opt.columns -- item size for grid.
	opt.itemXOffset = customOptions.itemXOffset or 0 -- move all items. usefull if you have fixed item size and what to adjust X pos.
	opt.topMargin = customOptions.topMargin or 0 -- margin to give space at the top - mainly for ATV
	opt.renderSpeed = customOptions.renderSpeed

	if nil == customOptions.isBounceEnabled then 
		if config.isAndroid then
	    	opt.isBounceEnabled = false
		elseif config.isIos then
	    	opt.isBounceEnabled = true
	    end
	else
	    opt.isBounceEnabled = customOptions.isBounceEnabled

	end

	opt.autoHideScrollBar = true
	if nil ~= customOptions.autoHideScrollBar and customOptions.autoHideScrollBar == false then
		opt.autoHideScrollBar = false
	end
	
	-- Set the scrollView to locked if both horizontal and vertical scrolling are disabled
	if opt.isHorizontalScrollingDisabled and opt.isVerticalScrollingDisabled then
		opt.isLocked = true
	end
	
	-- Ensure scroll width/height values are at a minimum, equal to the scroll window width/height
	if opt.scrollHeight then
		if opt.scrollHeight < opt.height then
			opt.scrollHeight = opt.height
		end
	end
	
	if opt.scrollWidth then
		if opt.scrollWidth < opt.width then
			opt.scrollWidth = opt.width
		end
	end
	
	-- ScrollBar options
	if nil ~= customOptions.scrollBarOptions then
	    opt.scrollBarOptions =
	    {
		    sheet = customOptions.scrollBarOptions.sheet,
		    topFrame = customOptions.scrollBarOptions.topFrame,
		    middleFrame = customOptions.scrollBarOptions.middleFrame,
		    bottomFrame = customOptions.scrollBarOptions.bottomFrame,
	    }
	else
	    opt.scrollBarOptions = {}
	end

			
	-------------------------------------------------------
	-- Create the scrollView
	-------------------------------------------------------
		
	-- Create the scrollView object
	local scrollView = _widget._newContainer
	{
		left = opt.left,
		top = opt.top,
		id = opt.id or "widget_scrollView",
		baseDir = opt.baseDir,
		widgetType = "scrollView",
	}

	-- Create the scrollView
	createScrollView( scrollView, opt )	

	
	scrollView.width = opt.width
	scrollView.height = opt.height + 2 -- to eliminate weird bug at the top of the scroll
	
	local x, y = _widget._calculatePosition( scrollView, opt )
	scrollView.x, scrollView.y = x, y	
	
	return scrollView
end

return M
