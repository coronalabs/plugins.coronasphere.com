
-- Code is MIT licensed; see https://www.coronalabs.com/links/code/license
---------------------------------------------------------------------------------------

local widget = 
{
	version = "2.0",
	themeName = "default",
	mouseEventsEnabled = false
}

---------------------------------------------------------------------------------
-- PRIVATE METHODS
---------------------------------------------------------------------------------

-- Modify factory function to ensure widgets are properly cleaned on group removal
-- local cached_displayNewGroup = display.newGroup
-- function display.newGroup()
-- 	local newGroup = cached_displayNewGroup()
	
-- 	-- Function to find/remove widgets within group
-- 	local function removeWidgets( group )
-- 		if group.numChildren then
-- 			for i = group.numChildren, 1, -1 do
-- 				if group[i]._isWidget then
-- 					group[i]:removeSelf()
				
-- 				elseif not group[i]._isWidget and group[i].numChildren then
-- 					-- Nested group (that is not a widget)
-- 					removeWidgets( group[i] )
-- 				end
-- 			end
-- 		end
-- 	end
	
-- 	-- Store a reference to the original removeSelf method
-- 	local cached_removeSelf = newGroup.removeSelf
	
-- 	-- Subclass the removeSelf method
-- 	function newGroup:removeSelf()
-- 		-- Remove widgets first
-- 		removeWidgets( self )
		
-- 		-- Continue removing the group as usual
-- 		if self.parent and self.parent.remove then
-- 			self.parent:remove( self )
-- 		end
-- 	end
	
-- 	return newGroup
-- end

-- Override removeSelf() method for new widgets


-- Dummy function to remove focus from a widget, any widget can override this function to remove focus if needed.
function widget._loseFocus()
	return
end

-- Widget constructor. Every widget object is created from this method
function widget._new( options )

	local newWidget

	newWidget = display.newGroup() -- All Widget* objects are display groups, except scrollview and tableview
	newWidget.id = options.id or "widget*"
	newWidget.baseDir = options.baseDir or system.ResourceDirectory
	newWidget._isWidget = true
	newWidget._widgetType = options.widgetType
	newWidget._loseFocus = widget._loseFocus
	
	return newWidget
end

-- G2.0 constructor for tableview / scrollview
function widget._newContainer( options )

	local newWidget = display.newContainer( display.contentWidth, display.contentHeight )

	newWidget.id = options.id or "widget*"
	newWidget.baseDir = options.baseDir or system.ResourceDirectory
	newWidget._isWidget = true
	newWidget._widgetType = options.widgetType
	newWidget._loseFocus = widget._loseFocus

	return newWidget

end


-- Function to retrieve a frame index from an imageSheet data file
function widget._getFrameIndex( theme, frame )
	if theme then
		if theme.data then
			if "function" == type( require( theme.data ).getFrameIndex ) then
				return require( theme.data ):getFrameIndex( frame )
			end
		end
	end
end

-- Function to check if the requirements for creating a widget have been met
function widget._checkRequirements( options, theme, widgetName )
	-- If we are using single images, just return
	if options.defaultFile or options.overFile then
		return
	end
	
	-- If there isn't an options table and there isn't a theme set, throw an error
	local noParams = not options and not theme
	
	if noParams then
		error( "WARNING: Either you haven't set a theme using widget.setTheme or the widget theme you are using does not support " .. widgetName, 3 )
	end
	
	-- If the user hasn't provided the necessary image sheet lua file (either via custom sheet or widget theme)
	local noData = not options.data and not theme.data

	if noData then
		if widget.theme then
			error( "ERROR: " .. widgetName .. ": theme data file expected, got nil", 3 )
		else
			error( "ERROR: " .. widgetName .. ": Attempt to create a widget with no custom imageSheet data set and no theme set, if you want to use a theme, you must call widget.setTheme( theme )", 3 )
		end
	end
	
	-- Throw error if the user hasn't defined a sheet and has defined data or vice versa.
	local noSheet = not options.sheet and not theme.sheet
	
	if noSheet then
		if widget.theme then
			error( "ERROR: " .. widgetName .. ": Theme sheet expected, got nil", 3 )
		else
			error( "ERROR: " .. widgetName .. ": Attempt to create a widget with no custom imageSheet set and no theme set, if you want to use a theme, you must call widget.setTheme( theme )", 3 )
		end
	end		
end

-- Enables mouse events on widgets
function widget.setMouseEventsEnabled( boolVariable )
	widget.mouseEventsEnabled = boolVariable
end

-- Check if the theme is ios7
function widget.isSeven()
	return false
end

function widget.isHolo()
	return true
end


-- Function to check if an object is within bounds
function widget._isWithinBounds( object, event )
	local bounds = object.contentBounds
    local x, y = event.x, event.y
	local isWithinBounds = true
		
	if "table" == type( bounds ) then
		if "number" == type( x ) and "number" == type( y ) then
			isWithinBounds = bounds.xMin <= x and bounds.xMax >= x and bounds.yMin <= y and bounds.yMax >= y
		end
	end
	
	return isWithinBounds
end

------------------------------------------------------------------------------------------
-- PUBLIC METHODS
------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------
-- newScrollView widget
-----------------------------------------------------------------------------------------

function widget.newScrollView( options )
	local _scrollView = require( "plugin.ui_framework.libs.widget_scrollview" )
	return _scrollView.new( options )
end

-----------------------------------------------------------------------------------------
-- utility methods
-----------------------------------------------------------------------------------------


-- widget position calculation based on defined anchor point
function widget._calculatePosition( object, opt )
	local x, y = opt.x, opt.y
	local xNonFloor, yNonFloor = x, y

	if not opt.x or not opt.y then
		local leftPos = opt.left
		local topPos = opt.top

		x = leftPos + object.contentWidth * 0.5
		y = topPos + object.contentHeight * 0.5
		xNonFloor = x
		yNonFloor = y

	end
	return x, y, xNonFloor, yNonFloor
end

-- determine if a file exists. Used for determining if custom assets passed to constructors actually exist in the project.
function widget._fileExists( fileName, baseDir )
    local baseDir = baseDir or system.ResourceDirectory
    local filePath = system.pathForFile( fileName, baseDir, true )
    return( filePath )
end

-- Get platform
local platformName = system.getInfo( "platformName" )
local isSimulator = "Mac OS X" == platformName or "Win" == platformName
local isAndroid = "Android" == platformName


return widget
