

local Config = {}



Config.screenScale = "auto" -- "auto", "manual"
Config.plugins = {}

local DeviceUtil = require("plugin.ui_framework.utils.device_util")
Config.isAndroid = DeviceUtil.isAndroid
Config.isIos = DeviceUtil.isIos
Config.isTv = DeviceUtil.isTv

function Config:setOs(os)
	if os == "ios" then
		Config.isIos = true
	elseif os == "android" then
		Config.isAndroid = true
	elseif os == "androidtv" then
		Config.isAndroid = true
		Config.isTv = true
	else

	end

	DeviceUtil.isAndroid = Config.isAndroid
	DeviceUtil.isIos = Config.isIos
	DeviceUtil.isTv = Config.isTv
end

function Config:setThemeColor(a)--{primary, primaryDark, primaryLite, secondary, secondaryDark, secondaryLite)
	if a.primary then 
		Config.primaryColor = a.primary
	end

	if a.primaryExtraLite then
		Config.primaryExtraLite = a.primaryExtraLite
	end
	
	if a.primaryLite then
		Config.primaryColorLite = a.primaryLite
	end

	if a.primaryDark then
		Config.primaryColorDark = a.primaryDark
	end

	if a.secondary then 
		Config.secondaryColor = a.secondary
	end
	
	if a.secondaryLite then
		Config.secondaryColorLite = a.secondaryLite
	end

	if a.secondaryDark then
		Config.secondaryColorDark = a.secondaryDark
	end

	if a.accent then
		Config.accentColor = a.accent
	end
end

function Config:colorContract(colorName)
	if type(colorName) ~= "table" then error("Color has to be a table value") end
end

function Config:setScreenScale(screenScale)
	if screenScale then
		Config.screenScale = screenScale
	end
end

return Config