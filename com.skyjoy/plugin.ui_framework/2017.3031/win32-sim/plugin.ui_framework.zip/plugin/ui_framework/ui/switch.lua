local colors = require("plugin.ui_framework.css.colors")
local Shadow = require("plugin.ui_framework.ui.shadow")
local Config = require("plugin.ui_framework.config")
local TransitionColor = require("plugin.ui_framework.utils.transition_util").new
local cancelTransitionColor = require("plugin.ui_framework.utils.transition_util").cancel
local toPx = require("plugin.ui_framework.utils.screen_util").toPx


local _style_android = {
	flat = {
		x = 0,
		y = 0,
		width = toPx(36),
		height = toPx(14),
		margin = toPx(16),
		cornerRadius = toPx(8),
		backgroundColorOn = {Config.primaryColor[1], Config.primaryColor[2], Config.primaryColor[3], .3},
		backgroundColorOff = colors.gray,
		circleColorOn = Config.primaryColor,
		circleColorOff = colors.white,
		circleRadius = toPx(10),
		shadow = {isActive = false},
		transitionTime = 350,
		touchEffect = "android",
	},
}

local _style_ios = {
	flat = {
		x = 0,
		y = 0,
		width = toPx(52),
		height = toPx(32),
		margin = toPx(12),
		cornerRadius = toPx(16),
		backgroundColorOn = colors.green,
		backgroundColorOff = colors.white,
		circleColorOn = colors.white,
		circleColorOff = colors.white,
		circleRadius = toPx(14),
		strokeColor = colors.gray,
		strokeWidth = toPx(2),
		shadow = {isActive = false},
		transitionTime = 350,
		touchEffect = "ios"
	},
}


local function render(group, a)
	
	local circleSideOffset = a.circleSideOffset or 0
	local circleSize = a.circleRadius*2

	local backgroundPath = ""
	local circlePath = ""

	if a.isAndroid then
		backgroundPath = "plugin/ui_framework/images/switch/android/background.png"
		circlePath = "plugin/ui_framework/images/switch/android/circle.png"
	else
		backgroundPath = "plugin/ui_framework/images/switch/ios/background.png"
		circlePath = "plugin/ui_framework/images/switch/ios/circle.png"
	end

	local background = display.newImageRect( group, backgroundPath, a.width, a.height ) 
	--display.newRoundedRect( group, 0, 0, a.width, a.height, a.cornerRadius )
	background.isHitTestable = true

	local backgroundBorder = display.newRoundedRect( group, 0, 0, a.width, a.height, a.cornerRadius )
	backgroundBorder:setFillColor( 0,0,0,0 )

	local circleGroup = display.newGroup()
	local circle = display.newImageRect( circleGroup, circlePath, circleSize, circleSize )

	local _shadow = Shadow({width = circleSize, height = circleSize, radius = a.circleRadius, offset = a.shadow.offset})
	circleGroup:insert(_shadow)
	_shadow:toBack()

	group:insert(circleGroup)


	-- visual transition
	function group:setOn(isOn)
		a.isOn = isOn
		cancelTransitionColor("switch")
		transition.cancel("switch")
		if a.isOn then
			backgroundBorder.strokeWidth = 0
			transition.to( circleGroup, {time = a.transitionTime, x = background.x + background.width*.5 - circleSize*.5 - circleSideOffset, transition = easing.outCubic, tag = "switch" } )
			TransitionColor(background, {time = a.transitionTime, startColor = a.backgroundColorOff, endColor = a.backgroundColorOn, tag = "switch" })
			TransitionColor(circle, {time = a.transitionTime, startColor = a.circleColorOff, endColor = a.circleColorOn, tag = "switch"  })
		else
			backgroundBorder.strokeWidth = a.strokeWidth
			transition.to( circleGroup, {time = a.transitionTime, x = background.x - background.width*.5 + circleSize*.5 + circleSideOffset, transition = easing.outCubic, tag = "switch" } )
			TransitionColor(background, {time = a.transitionTime, startColor = a.backgroundColorOn, endColor = a.backgroundColorOff, tag = "switch" })
			TransitionColor(circle, {time = a.transitionTime, startColor = a.circleColorOn, endColor = a.circleColorOff, tag = "switch" })
		end
	end

	function group:toggle()
		if a.isOn then
			a.isOn = false
		else
			a.isOn = true
		end
		group:setOn(a.isOn)
	end

	-- initial visual status
	if a.isOn then
		if a.strokeColor then
			backgroundBorder.strokeWidth = 0
			backgroundBorder:setStrokeColor( unpack(a.strokeColor) )
		end
		circleGroup.x = background.x + background.width*.5 - circleSize*.5 - circleSideOffset
		background:setFillColor( unpack(a.backgroundColorOn) )
		circle:setFillColor( unpack(a.circleColorOn) )
	else
		if a.strokeColor then
			backgroundBorder.strokeWidth = a.strokeWidth
			backgroundBorder:setStrokeColor( unpack(a.strokeColor) )
		end
		circleGroup.x = background.x - background.width*.5 + circleSize*.5 + circleSideOffset
		background:setFillColor( unpack(a.backgroundColorOff) )
		circle:setFillColor( unpack(a.circleColorOff) )
	end

	group.background = background

end


local function setTouchCallback(group, a)
	group:addEventListener("touch", 
		function(e)
			if e.phase == "began" and a.isActive then      
		        display.getCurrentStage():setFocus( e.target )
		    elseif e.phase == "ended" or e.phase == "cancelled" then
		    	group:toggle()
		    	e.isOn = a.isOn
				a.touchCallback(e)
				display.getCurrentStage():setFocus( nil )
			end
		end )
end

local function Switch(a)
	if not a then a = {} end
	if a.isActive == nil then a.isActive = true end

	local group = display.newGroup( )
	if not a.isOn then a.isOn = false end

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = Config.isAndroid end
	if a.isIos == nil then a.isIos = Config.isIos end
	
	-- set proper default values based on os
	if not a.style then a.style = "flat" end
	if a.isIos then
		if _style_ios[a.style] == nil then error("This style is not valid") end
		for k,v in pairs(_style_ios[a.style]) do
			if a[k] == nil then
				a[k] = v
			end
		end
		-- custom variable for difference in iOS.
		a.circleSideOffset = a.strokeWidth
	else
		if _style_android[a.style] == nil then error("This style is not valid") end
		for k,v in pairs(_style_android[a.style]) do
			if a[k] == nil then
				a[k] = v
			end
		end
	end
	render(group, a)

	
	group.x = a.x
	group.y = a.y


	-- touch callback is defined
	if a.touchCallback then
		setTouchCallback(group, a)
	end

	function group:setTouchCallback(touchCallback)
		if a.touchCallback == nil then
			a.touchCallback = touchCallback
			setTouchCallback(group, a)
		end
	end

	function group:setIsActive(isActive)
		a.isActive = isActive
		if isActive then
			group.alpha = 1
		else
			group.alpha = .8
		end
	end
	

	if a.parent then
		a.parent:insert(group)
	end

	return group
end

return Switch