local TouchEffect = {}

local function ios_on(group)
    group.alpha = .7
end

local function ios_off(group)
    group.alpha = 1
end

local function android(group, a)
    print("touch effect")
    local touchEffectConfig = a.config.touchEffectConfig or {}
    if touchEffectConfig.radius == nil then touchEffectConfig.radius = 50 end
    if touchEffectConfig.endScale == nil then touchEffectConfig.endScale = group.background.width / touchEffectConfig.radius end
    if touchEffectConfig.startScale == nil then touchEffectConfig.startScale = .1 end
    if touchEffectConfig.duration == nil then touchEffectConfig.duration = 600 end
    local circle = display.newCircle( group.container, 0, 0, touchEffectConfig.radius )
    circle.xScale = touchEffectConfig.startScale
    circle.yScale = touchEffectConfig.startScale
    if a.config.touchEffectColor then
        circle:setFillColor( unpack(a.config.touchEffectColor) )
    else
        circle:setFillColor( 0,0,0 )
    end
    circle.alpha = .2
    transition.to( circle, { 
        time = touchEffectConfig.duration, 
        xScale = touchEffectConfig.endScale, 
        yScale = touchEffectConfig.endScale, 
        alpha = 0.01, 
        onComplete = function() display.remove(circle) end} )
end

function TouchEffect:on(group, a)
    if a.config.touchEffect == "ios" then
        ios_on(group, a)
    elseif a.config.touchEffect == "android" then
        android(group, a)
    end
end

function TouchEffect:off(group, a)
    if a.config.touchEffect == "ios" then
        ios_off(group, a)
    end
end

return TouchEffect