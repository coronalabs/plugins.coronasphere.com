local colors = require("plugin.ui_framework.css.colors")
local StringUtil = require("plugin.ui_framework.utils.string_util")
local TouchEffect = require("plugin.ui_framework.ui.touch_effect")
local Shadow = require("plugin.ui_framework.ui.shadow")
local config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local fonts = require("plugin.ui_framework.css.fonts")
local utf8

local _w = display.contentWidth

local _style_android = {
	icon = {
		config = {
			width = 1,
			minWidth = toPx(36),
			height = toPx(36),
			margin = toPx(16),
			color = colors.transparent,
			x = 0,
			y = 0,
			touchEffect = "android",
			renderer = "icon"
		},
		icon = {
			text = fonts.icon.options,
			font = fonts.icons,
			fontSize = toPx(fonts.back.iconFontSize),
			x = 0,
			y = 0,
			color = config.secondaryColor,
			isActive = true
		},
		label = {
			text = "",
			x = 0,
			y = 0,
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = config.secondaryColor,
			isActive = true
		}
	},

	back = {
		config = {
			width = 1,
			minWidth = toPx(36),
			height = toPx(36),
			margin = toPx(16),
			color = colors.transparent,
			x = 0,
			y = 0,
			touchEffect = "android",
			renderer = "android_back"
		},
		icon = {
			text = fonts.back.icon,
			font = fonts.icons,
			fontSize = toPx(fonts.back.iconFontSize),
			x = 0,
			y = 0,
			color = config.secondaryColor
		},
	},

	flat = {
		config = {
			width = 1,
			minWidth = toPx(36),
			maxWidth = _w,
			height = toPx(36),
			color = colors.transparent,
			touchEffect = "android",
			x = 0,
			y = 0,
			shadow = {isActive = false},
			cornerRadius = toPx(2),
			margin = toPx(16),
			renderer = "default"
		},
		label = {
			text = "flat",
			x = 0,
			y = 0,
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = config.primaryColor
		}
	},

	flat_fill = {
		config = {
			width = 1,
			minWidth = toPx(88),
			maxWidth = _w,
			height = toPx(36),
			margin = toPx(16),
			cornerRadius = toPx(2),
			color = config.primaryColor,
			touchEffect = "android",
			x = 0,
			y = 0,
			shadow = {isActive = false},
			renderer = "default"
		},
		label = {
			text = "flat fill",
			x = 0,
			y = 0,
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = config.secondaryColor
		}
	},

	raised = {
		config = {
			width = 1,
			minWidth = toPx(88),
			maxWidth = _w,
			height = toPx(36),
			margin = toPx(16),
			cornerRadius = toPx(2),
			color = colors.white,
			touchEffect = "android",
			x = 0,
			y = 0,
			shadow = {isActive = true, offset = (2), strokeWidth = toPx(4)},
			renderer = "default"
		},
		label = {
			text = "raised",
			x = 0,
			y = 0,
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = config.primaryColor
		}
	},

	raised_fill = {
		config = {
			width = 1,
			minWidth = toPx(88),
			maxWidth = _w,
			height = toPx(36),
			margin = toPx(16),
			cornerRadius = toPx(2),
			color = config.primaryColor,
			touchEffect = "android",
			x = 0,
			y = 0,
			shadow = {isActive = true, offset = (2), strokeWidth = toPx(4)},
			renderer = "default"
		},
		label = {
			text = "raised fill",
			x = 0,
			y = 0,
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = config.secondaryColor
		}
	},

	float = {
		config = {
			margin = 0,
			radius = toPx(32),
			color = config.primaryColor,
			touchEffect = "android",
			x = 0,
			y = 0,
			shadow = {isActive = true, offset = (1), strokeWidth = toPx(4)},
			touchEffectConfig = {radius = toPx(32), startScale = .1, endScale = 1, duration = 400},
			renderer = "float"
		},
		label = {
			text = "+",
			x = 0,
			y = 0,
			font = fonts.button.font,
			fontSize = toPx(30),
			color = config.secondaryColor
		}
	},
}

local _style_androidtv = {
	flat = {
		config = {
			width = toPx(160),
			minWidth = toPx(80),
			maxWidth = _w,
			height = toPx(64),
			color = colors.transparent,
			touchEffect = "android",
			touchEffectColor = colors.white,
			x = 0,
			y = 0,
			shadow = {isActive = false},
			cornerRadius = toPx(2),
			margin = toPx(16),
			renderer = "flat_tv"
		},
		label = {
			text = "flat",
			x = 0,
			y = 0,
			font = fonts.condensed,
			fontSize = toPx(16),
			color = colors.white
		}
	},
	default = {
		config = {
			width = 0,
			minWidth = toPx(80),
			maxWidth = _w,
			height = toPx(54),
			color = colors.transparent,
			touchEffect = "android",
			touchEffectColor = colors.white,
			x = 0,
			y = 0,
			shadow = {isActive = false},
			cornerRadius = toPx(2),
			margin = toPx(16),
			renderer = "default_tv"
		},
		label = {
			text = "flat",
			x = 0,
			y = 0,
			font = fonts.condensed,
			fontSize = toPx(16),
			color = colors.white
		}
	},

	settings = {
		config = {
			width = toPx(100),
			height = toPx(160),
			margin = toPx(16),
			color = colors.transparent,
			x = 0,
			y = 0,
			touchEffect = "android",
			renderer = "settings_tv"
		},
		icon = {
			text = fonts.icon.options,
			font = fonts.icons,
			fontSize = toPx(56),
			x = 0,
			y = -toPx(30),
			color = config.secondaryColor,
			isActive = true
		},
		label = {
			text = "",
			x = 0,
			y = toPx(24),
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = config.secondaryColor,
			isActive = true
		}
	},

}

local _style_ios = {
	icon = {
		config = {
			width = 1,
			minWidth = toPx(28),
			height = toPx(28),
			margin = toPx(12),
			color = colors.transparent,
			x = 0,
			y = 0,
			touchEffect = "ios",
			renderer = "icon"
		},
		icon = {
			text = fonts.back.icon,
			x = 0,
			y = 0,
			font = fonts.icons,
			fontSize = toPx(23),
			color = config.secondaryColor,
			isActive = true
		},
		label = {
			text = "",
			x = 0,
			y = 0,
			color = config.secondaryColor,
			font = fonts.back.font,
			fontSize = toPx(fonts.back.fontSize),
			isActive = false
		}
	},
	back = {
		config = {
			width = 1,
			minWidth = toPx(50),
			height = toPx(28),
			margin = toPx(12),
			color = colors.transparent,
			x = 0,
			y = 0,
			touchEffect = "ios",
			renderer = "ios_back"
		},
		icon = {
			text = fonts.icon.back,
			x = 0,
			y = 0,
			font = fonts.icons,
			fontSize = toPx(fonts.back.iconFontSize),
			color = config.secondaryColor
		},
		label = {
			text = "",
			x = 0,
			y = 0,
			color = config.secondaryColor,
			font = fonts.back.font,
			fontSize = toPx(fonts.back.fontSize),
		}
	},

	flat = {
		config = {
			width = 1,
			minWidth = toPx(50),
			maxWidth = _w,
			height = toPx(28),
			margin = toPx(12),
			color = colors.transparent,
			x = 0,
			y = 0,
			cornerRadius = 0,
			touchEffect = "ios",
			renderer = "default",
		},
		label = {
			text = "flat",
			x = 0,
			y = 0,
			font = "",
			fontSize = toPx(15),
			color = config.primaryColor
		}
	},

	flat_fill = {
		config = {
			width = 1,
			minWidth = toPx(100),
			maxWidth = _w,
			height = toPx(28),
			margin = toPx(12),
			color = config.primaryColor,
			x = 0,
			y = 0,
			cornerRadius = toPx(4),
			touchEffect = "ios",
			renderer = "default",
		},
		label = {
			text = "flat fill",
			x = 0,
			y = 0,
			font = "",
			fontSize = toPx(15),
			color = config.secondaryColor
		}
	},

	raised = {
		config = {
			width = 1,
			minWidth = toPx(100),
			maxWidth = _w,
			height = toPx(28),
			margin = toPx(12),
			color = config.primaryColor,
			-- strokeColor = config.primaryColor,
			x = 0,
			y = 0,
			cornerRadius = toPx(4),
			touchEffect = "ios",
			renderer = "default",
		},
		label = {
			text = "raised",
			x = 0,
			y = 0,
			font = "",
			fontSize = toPx(15),
			color = config.secondaryColor
		}
	},

	raised_fill = {
		config = {
			width = 1,
			minWidth = toPx(100),
			maxWidth = _w,
			height = toPx(28),
			margin = toPx(12),
			color = config.primaryColor,
			x = 0,
			y = 0,
			cornerRadius = toPx(4),
			touchEffect = "ios",
			renderer = "default",
		},
		label = {
			text = "raised fill",
			x = 0,
			y = 0,
			font = "",
			fontSize = toPx(15),
			color = config.secondaryColor
		}
	},

	float = {
		config = {
			margin = 0,
			color = config.primaryColor,
			x = 0,
			y = 0,
			radius = toPx(27),
			touchEffect = "ios",
			shadow = {isActive = true, offset = (1), strokeWidth = toPx(2)},
			renderer = "float",
		},
		label = {
			text = fonts.icon.plus,
			x = 0,
			y = 0,
			font = fonts.icons,
			fontSize = toPx(26),
			color = config.secondaryColor
		}
	},
}

local renderers = {}

function renderers.settings_tv(group, a)
	local background = display.newRect( group, 0, 0, a.config.width, a.config.height )
	background.isHitTestable = true
	background.alpha = 0
	group.background = background

	if a.icon and a.icon.isActive then
		local _icon = ""
		if type(a.icon.text) == "table" then
			_icon = a.icon.text.default
		else
			_icon = a.icon.text
		end
		local icon = display.newText( group, _icon, a.icon.x, a.icon.y , a.icon.font, a.icon.fontSize )	
		icon:setFillColor( unpack(a.icon.color) )
		group.icon = icon
	else
		print("warrning: icon is required!")
	end

	if a.label and a.label.isActive then
		local label = display.newText( {
			parent = group, 
			text = a.label.text, 
			x = a.label.x, 
			y = a.label.y, 
			font = a.label.font, 
			fontSize = a.label.fontSize,
			width = a.config.width,
			align = "center"
		} )	
		group.label = label
		label.anchorY = 0
		if a.label.color then
			label:setFillColor( unpack(a.label.color) )
		end
	end

	if a.config.width == 1 then
		if (group.width + a.config.margin) < a.config.minWidth then
			background.width = a.config.minWidth + a.config.margin
		else
			background.width = group.width + a.config.margin*2
		end
		a.config.width = background.width
	end
end

function renderers.default_tv(group, a)

	if a.config.width > a.config.maxWidth then
		a.config.width = a.config.maxWidth
	end  

	if config.plugins.utf8 then
		a.label.text = config.plugins.utf8.upper(a.label.text)
	else
		a.label.text = string.upper(a.label.text)
	end
	local label = display.newText( {parent = group, 
		text = a.label.text, 
		font = a.label.font, 
		fontSize = a.label.fontSize,
		width = a.config.width - a.config.margin *2,
		align = "center",
		} )	
	group.label = label

	label:setFillColor( unpack(a.label.color) )

	if a.config.width == 0 then
		if (label.width + a.config.margin) < a.config.minWidth then
			a.config.width = a.config.minWidth + a.config.margin*3
		else
			a.config.width = label.width + a.config.margin*3
		end
	end

	local background = display.newRoundedRect( group, 0, 0, a.config.width, a.config.height-toPx(4), toPx(5) )
	background.isHitTestable = true
	background.isVisible = false
	background.alpha = 0.2
	background:toBack()

	group.background = background


	if a.config.shadow and a.config.shadow.isActive then
		local _shadow = Shadow({width = background.width, height = background.height, radius = a.config.cornerRadius, offset = a.config.shadow.offset, strokeWidth = a.config.shadow.strokeWidth or nil})
		group:insert(_shadow)
		_shadow:toBack()
	end

	function group.setHover(is_focus)
		if is_focus then
			background.isVisible = true
		else
			background.isVisible = false
		end
	end

end

function renderers.flat_tv(group, a)

	if a.config.width > a.config.maxWidth then
		a.config.width = a.config.maxWidth
	end  

	local background = display.newRoundedRect( group, 0, 0, a.config.width, a.config.height-toPx(4), toPx(5) )
	background.isHitTestable = true
	background.isVisible = false
	background.alpha = 0.2

	group.background = background

	local label = display.newText( {parent = group, 
		text = a.label.text, 
		font = a.label.font, 
		fontSize = a.label.fontSize,
		x = -a.config.width*.5 + a.config.margin
		} )	
	group.label = label
	label.anchorX = 0

	label:setFillColor( unpack(a.label.color) )

	if a.config.width == 1 then
		if (label.width + a.config.margin) < a.config.minWidth then
			background.width = a.config.minWidth + a.config.margin
		else
			background.width = label.width + a.config.margin*2
		end
		a.config.width = background.width
	end



	if a.config.shadow and a.config.shadow.isActive then
		local _shadow = Shadow({width = background.width, height = background.height, radius = a.config.cornerRadius, offset = a.config.shadow.offset, strokeWidth = a.config.shadow.strokeWidth or nil})
		group:insert(_shadow)
		_shadow:toBack()
	end

	function group.setHover(is_focus)
		if is_focus then
			background.isVisible = true
		else
			background.isVisible = false
		end
	end

end

function renderers.icon(group, a)
	local background = display.newRect( group, 0, 0, a.config.width, a.config.height )
	background.isHitTestable = true
	-- background.isVisible = false
	if a.config.color then
		background:setFillColor( unpack(a.config.color) )
	else
		background.alpha = 0
	end
	group.background = background

	if a.icon and a.icon.isActive then
		local _icon = ""
		if type(a.icon.text) == "table" then
			_icon = a.icon.text.default
		else
			_icon = a.icon.text
		end
		local icon = display.newText( group, _icon, a.icon.x, a.icon.y , a.icon.font, a.icon.fontSize )	
		icon:setFillColor( unpack(a.icon.color) )
		group.icon = icon
	else
		print("warrning: icon is required!")
	end

	if a.label and a.label.isActive then
		local label = display.newText( group, a.label.text, a.label.x, a.label.y, a.label.font, a.label.fontSize )	
		group.label = label
		if a.label.color then
			label:setFillColor( unpack(a.label.color) )
		end
	end

	if a.config.width == 1 then
		if (group.width + a.config.margin) < a.config.minWidth then
			background.width = a.config.minWidth + a.config.margin
		else
			background.width = group.width + a.config.margin*2
		end
		a.config.width = background.width
	end
end

function renderers.ios_back(group, a)
	local background = display.newRect( group, 0, 0, a.config.width, a.config.height )
	background.isHitTestable = true
	background:setFillColor( unpack(a.config.color) )
	group.background = background

	local textGroup = display.newGroup() -- additional group to center both texts properly
	if a.icon then
		local icon = display.newText( textGroup, a.icon.text, 0, 0, a.icon.font, a.icon.fontSize )	
		icon:setFillColor( unpack(a.icon.color) )
		icon.anchorX = 0
		group.icon = icon
	else
		print("warrning: icon is required!")
	end 

	if a.label and a.label.text then
		local label = display.newText( textGroup, a.label.text, 0, 0, a.label.font, a.label.fontSize )	
		label:setFillColor( unpack(a.label.color) )
		label.anchorX = 0
		group.label = label

		if group.icon then
			label.x = group.icon.width + toPx(4)
		end
	end

	textGroup.x = - textGroup.width*.5
	group:insert(textGroup)

	if a.config.width == 1 then
		if (group.width + a.config.margin) < a.config.minWidth then
			background.width = a.config.minWidth + a.config.margin
		else
			background.width = group.width + a.config.margin*2
		end
		a.config.width = background.width
	end
end

function renderers.android_back(group, a)
	local background = display.newRect( group, 0, 0, a.config.width, a.config.height )
	background.isHitTestable = true
	background:setFillColor( unpack(a.config.color) )

	group.background = background

	local icon = display.newText( group, a.icon.text, 0, 0, a.icon.font, a.icon.fontSize )	
	icon:setFillColor( unpack(a.icon.color) )
	group.icon = icon

	if a.config.width == 1 then
		if (icon.width + a.config.margin) < a.config.minWidth then
			background.width = a.config.minWidth + a.config.margin
		else
			background.width = icon.width + a.config.margin*2
		end
	end
end

function renderers.float(group, a)
	local background = display.newCircle( group, 0, 0, a.config.radius)
	background.isHitTestable = true
	background:setFillColor( unpack(a.config.color) )

	local paint = {
        type = "gradient",
        color1 = a.config.color or { 0, 0, 0, 0.3 },
        color2 = { 0, 0, 0, 0 },
        direction = "down"
    }
    background.stroke = paint
    background.strokeWidth = 2

	group.background = background

	local label = display.newText( group, a.label.text, 0, 0, a.label.font, a.label.fontSize )	
	group.label = label

	label:setFillColor( unpack(a.label.color) )

	if a.config.width == 1 then
		if (label.width + a.config.margin) < a.config.minWidth then
			background.width = a.config.minWidth + a.config.margin
		else
			background.width = label.width + a.config.margin*2
		end
		a.config.width = background.width
	end

	if a.config.shadow and a.config.shadow.isActive then
		local _shadow = Shadow({width = background.width, height = background.height, radius = a.config.radius, offset = a.config.shadow.offset, strokeWidth = a.config.shadow.strokeWidth or nil})
		group:insert(_shadow)
		_shadow:toBack()
	end
end

function renderers.default(group, a)

	if a.config.width > a.config.maxWidth then
		a.config.width = a.config.maxWidth
	end  

	local background = display.newRoundedRect( group, 0, 0, a.config.width, a.config.height, a.config.cornerRadius )
	background.isHitTestable = true
	background:setFillColor( unpack(a.config.color) )

	if a.config.strokeColor then
		background.strokeWidth = toPx(1)
		background:setStrokeColor( unpack(a.config.strokeColor) )
	end

	group.background = background

	local label = display.newText( group, a.label.text, 0, 0, a.label.font, a.label.fontSize )	
	group.label = label

	label:setFillColor( unpack(a.label.color) )

	if a.config.width == 1 then
		if (label.width + a.config.margin) < a.config.minWidth then
			background.width = a.config.minWidth + a.config.margin
		else
			background.width = label.width + a.config.margin*2
		end
		a.config.width = background.width
	end



	if a.config.shadow and a.config.shadow.isActive then
		local _shadow = Shadow({width = background.width, height = background.height, radius = a.config.cornerRadius, offset = a.config.shadow.offset, strokeWidth = a.config.shadow.strokeWidth or nil})
		group:insert(_shadow)
		_shadow:toBack()
	end
end




local function setTouchCallback(group, a)
	group:addEventListener("touch", 
		function(e)
			if e.phase == "began" and a.config.isActive then      
		        TouchEffect:on(group, a)
		        display.getCurrentStage():setFocus( e.target )

		    elseif a.config.isActive and ( e.phase == "ended" or e.phase == "cancelled" ) then

				TouchEffect:off(group, a)
				a.config.touchCallback(e)
				display.getCurrentStage():setFocus( nil )
			end
			return true
		end )
end

local function showStyleError(_style)
	local str = "This style is not valid. Valid styles: "
	for k,v in pairs(_style) do
		str = str .. ", "..k
	end

	return str
end

local button = {}
function button.new(a)
	if not a then a = {} end
	if not a.config then a.config = {} end
	if a.config.isActive == nil then a.config.isActive = true end

	local group = display.newGroup( )

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isTv == nil then a.isTv = config.isTv end
	if a.isIos == nil then a.isIos = config.isIos end
	
	if not a.config.style then a.config.style = "flat" end

	if a.isIos then
		if _style_ios[a.config.style] == nil then error(showStyleError(_style_ios)) end
		for k,v in pairs(_style_ios[a.config.style]) do
			if a[k] == nil then
				a[k] = v
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end
		end
		if a.label and a.label.text then
			a.label.text = StringUtil:upperFirst(a.label.text)
		end
	else
		local _style
		if a.isTv then
			_style = _style_androidtv[a.config.style]
			if _style == nil then error(showStyleError(_style_androidtv)) end
		else
			_style = _style_android[a.config.style]
			if _style == nil then error(showStyleError(_style_android)) end
		end
		
		for k,v in pairs(_style) do
			if a[k] == nil then
				a[k] = v
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end			
		end
		if a.label and a.label.text then
			if a.isTv then
				a.label.text = StringUtil:upperFirst(a.label.text)
			else
				if config.plugins.utf8 then
					a.label.text = config.plugins.utf8.upper(a.label.text)
				else
					a.label.text = string.upper(a.label.text)
				end
			end
		end
	end

	renderers[a.config.renderer](group, a)

	if not a.config.width or a.config.width == 1 then
		a.config.width = group.width
	end
	if not a.config.height or a.config.height == 1 then
		a.config.height = group.height
	end
	
	if a.config.touchEffect == "android" then
		local container = display.newContainer( a.config.width, a.config.height )
		group:insert(container)
		group.container = container
	end
	
	group.x = a.config.x
	group.y = a.config.y


	-- touch callback is defined
	if a.config.touchCallback then
		setTouchCallback(group, a)
	end

	function group.touchCallback(e)
		if a.config.touchCallback then
			a.config.touchCallback(e)
		end
	end

	function group:setTouchCallback(touchCallback)
		if a.config.touchCallback == nil then
			a.config.touchCallback = touchCallback
			setTouchCallback(group, a)
		end
	end

	function group:setIsActive(isActive)
		a.config.isActive = isActive
		if isActive then
			group.alpha = 1
		else
			group.alpha = .7
		end
	end


	function group:press()
		if a.config.touchCallback then
			TouchEffect:on(group, a)
			a.config.touchCallback()
		end
	end

	function group:setFocus(is_focus)
		if is_focus then
			group.background.alpha = 0.2
		else
			group.background.alpha = 0
		end
	end
	

	if a.parent then
		a.parent:insert(group)
	end

	return group
end

function button.getSetting(a)
	if not a then a = {} end
	if not a.config then a.config = {} end

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isIos == nil then a.isIos = config.isIos end

	if not a.config.style then a.config.style = "flat" end

	if a.isAndroid then
		return _style_android[a.config.style]
	else
		return _style_ios[a.config.style]
	end
end

function button.setStyle(a)
	if not a then error("You have to proved setting paramaters.") end

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isIos == nil then a.isIos = config.isIos end

	if not a.config.style then a.config.style = "flat" end

	if a.isAndroid then
		if a.config and _style_android[a.config.style].config then
			for k,v in pairs(a.config) do
				_style_android[a.config.style].config[k] = v
			end
		end

		if a.icon and _style_android[a.config.style].icon then
			for k,v in pairs(a.icon) do
				_style_android[a.config.style].icon[k] = v
			end
		end

		if a.label and _style_android[a.config.style].label then
			for k,v in pairs(a.label) do
				_style_android[a.config.style].label[k] = v
			end
		end
	elseif a.isIos then
		if a.config and _style_ios[a.config.style].config then
			for k,v in pairs(a.config) do
				_style_ios[a.config.style].config[k] = v
			end
		end

		if a.icon and _style_ios[a.config.style].icon then
			for k,v in pairs(a.icon) do
				_style_ios[a.config.style].icon[k] = v
			end
		end

		if a.label and _style_ios[a.config.style].label then
			for k,v in pairs(a.label) do
				_style_ios[a.config.style].label[k] = v
			end
		end
	end
end

return button