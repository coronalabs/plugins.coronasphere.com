local colors = require("plugin.ui_framework.css.colors")
local Shadow = require("plugin.ui_framework.ui.shadow")
local Config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx

local _style_android = {
	flat = {
		x = 0,
		y = 0,
		width = display.contentWidth - toPx(32),
		height = toPx(2),
		margin = toPx(16),
		cornerRadius = 0,
		progressColor = Config.primaryColor,
		backgroundColor = colors.gray,
		circleColorOn = Config.primaryColor,
		circleColorOff = colors.white,
		circleRadius = toPx(10),
		circleRadiusOn = toPx(14),
		shadow = {isActive = false},
		circleShadow = {isActive = false},
		transitionTime = 350,
		touchEffect = "android",
	},
}

local _style_ios = {
	flat = {
		x = 0,
		y = 0,
		width = display.contentWidth - toPx(32),
		height = toPx(2),
		margin = toPx(16),
		cornerRadius = toPx(2),
		progressColor = Config.primaryColor,
		backgroundColor = colors.grayDark,
		circleColorOn = colors.white,
		circleColorOff = colors.white,
		circleRadius = toPx(15),
		circleRadiusOn = toPx(15),
		shadow = {isActive = false},
		circleShadow = {isActive = true},
		transitionTime = 350,
		touchEffect = "ios"
	},
}

local function setProgress(group, a)
	if a.progress == nil or a.progress < 0 or a.progress > 1 then error("Progress has to be between 0 and 1") end
	if a.progress > 0 then
		group.fill.width = a.progress*group.background.width
		group.circleGroup.x = group.fill.x + group.fill.width
	else
		group.circleGroup.x = group.fill.x
	end
	-- calculate progress
	group.progress = math.round(group.fill.width/group.background.width*100)*.01
end


local function render(group, a)
	
	local circleSize = a.circleRadius*2

	-- background bar
	local background = display.newRoundedRect( group, 0, 0, a.width, a.height, a.cornerRadius )
	background:setFillColor( unpack(a.backgroundColor) )
	group.background = background

	-- fill bar
	local fill = display.newRoundedRect( group, background.x - background.width*.5, 0, 1, a.height, a.cornerRadius )
	fill.anchorX = 0
	fill:setFillColor( unpack(a.progressColor) )
	group.fill = fill

	-- circle
	local circleGroup = display.newGroup()
	local circlePath = ""
	if a.isAndroid then
		circlePath = "plugin/ui_framework/images/switch/android/circle.png"
	else
		circlePath = "plugin/ui_framework/images/switch/ios/circle.png"
	end
	local circle = display.newImageRect( circleGroup, circlePath, circleSize, circleSize )
	circle:setFillColor( unpack(a.circleColorOn) )
	circleGroup.circle = circle
	group.circleGroup = circleGroup

	if a.circleShadow and a.circleShadow.isActive then
		local _shadow = Shadow({width = circleSize, height = circleSize, radius = a.circleRadius, offset = a.shadow.offset})
		circleGroup:insert(_shadow)
		_shadow:toBack()
	end

	-- set circle at default position
	setProgress(group, a)
	
	-- store inital position
	circleGroup.x0 = circleGroup.x

	group:insert(circleGroup)
end


local function setTouchCallback(group, a)
	group.circleGroup:addEventListener("touch", 
		function(e)
			if e.phase == "began" and a.isActive then      
				group.circleGroup.x0 = e.x - group.circleGroup.x
		        display.getCurrentStage():setFocus( e.target )

		        if a.touchEffect == "android" then
			        group.circleGroup.circle.xScale = 1.5
			        group.circleGroup.circle.yScale = 1.5
			    end
		        group.isFocus = true
		    elseif group.isFocus then
			    if e.phase == "ended" or e.phase == "cancelled" then
			     	-- return progress
			    	e.progress = group.progress
					a.touchCallback(e)
					group.circleGroup.circle.xScale = 1
		        	group.circleGroup.circle.yScale = 1
					display.getCurrentStage():setFocus( nil )
					group.isFocus = false
				elseif e.phase == "moved" then
					group.circleGroup.x = (e.x - group.circleGroup.x0  )

					if group.circleGroup.x <= -group.background.width*.5 then -- minimum / 0
						group.circleGroup.x = -group.background.width*.5 + 1
					elseif group.circleGroup.x >= group.background.width*.5 then -- max / full / 1
						group.circleGroup.x = group.background.width*.5 + 1
					end

					-- make sure the visible progress is minimum 1px
					local fillWidth = group.circleGroup.x + group.background.width*.5
					if fillWidth <= 0 then 
						fillWidth = 1 
					end

					-- calculate progress
					group.progress = math.round(fillWidth/group.background.width*100)*.01
					e.progress = group.progress

					group.fill.width = fillWidth
				end
			end
		end )
end

local function Slider(a)
	if not a then a = {} end
	if a.isActive == nil then a.isActive = true end
	if a.progress == nil or a.progress < 0 or a.progress > 1 then a.progress = 0 end

	local group = display.newGroup( )
	if not a.isOn then a.isOn = false end
	group.progress = 0

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = Config.isAndroid end
	if a.isIos == nil then a.isIos = Config.isIos end
	
	-- set proper default values based on os
	if not a.style then a.style = "flat" end
	if a.isIos then
		if _style_ios[a.style] == nil then error("This style is not valid") end
		for k,v in pairs(_style_ios[a.style]) do
			if a[k] == nil then
				a[k] = v
			end
		end
		-- custom variable for difference in iOS.
		a.circleSideOffset = a.strokeWidth
	else
		if _style_android[a.style] == nil then error("This style is not valid") end
		for k,v in pairs(_style_android[a.style]) do
			if a[k] == nil then
				a[k] = v
			end
		end
	end
	render(group, a)

	group.x = a.x
	group.y = a.y

	-- touch callback is defined
	if a.touchCallback then
		setTouchCallback(group, a)
	end

	function group:setTouchCallback(touchCallback)
		if a.touchCallback == nil then
			a.touchCallback = touchCallback
			setTouchCallback(group, a)
		end
	end

	function group:setIsActive(isActive)
		a.isActive = isActive
		if isActive then
			group.alpha = 1
		else
			group.alpha = .8
		end
	end

	function group:setProgress(progress)
		a.progress = progress
		setProgress(group, a)
	end
	
	if a.parent then
		a.parent:insert(group)
	end

	return group
end

return Slider