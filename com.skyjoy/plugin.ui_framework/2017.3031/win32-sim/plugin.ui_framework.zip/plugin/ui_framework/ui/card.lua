local colors = require("plugin.ui_framework.css.colors")
local Shadow = require("plugin.ui_framework.ui.shadow")
local Config = require("plugin.ui_framework.config")
local Button = require("plugin.ui_framework.ui.button").new
local toPx = require("plugin.ui_framework.utils.screen_util").toPx

local _style_android = {
	flat = {
		x = 0,
		y = 0,
		width = display.contentWidth - toPx(32),
		height = toPx(24 + 48 + 120),
		margin = toPx(16),
		cornerRadius = toPx(2),
		backgroundColor = colors.white,

		title = "",
		titleMargin = toPx(24),
		titleFontSize = toPx(24),
		subtitle = "",
		subtitleMargin = toPx(12),
		subtitleFontSize = toPx(14),
		subtitleColor = colors.grayDark,
		description = "",
		descriptionMargin = toPx(16),
		descriptionFontSizen = toPx(14),
		buttons = {
			--{title = "", touchCallback = function() end}
		},
		buttonsMargin = toPx(8)
	},
}

local _style_ios = {
	flat = {
		x = 0,
		y = 0,
		width = display.contentWidth - toPx(32),
		height = toPx(24 + 48 + 120),
		margin = toPx(12),
		cornerRadius = toPx(4),
		backgroundColor = colors.white,

		title = "",
		titleMargin = toPx(16),
		titleFontSize = toPx(24),
		subtitle = "",
		subtitleMargin = toPx(8),
		subtitleFontSize = toPx(15),
		subtitleColor = colors.grayDark,
		description = "",
		descriptionMargin = toPx(16),
		descriptionFontSizen = toPx(15),
		buttons = {
			--{title = "", touchCallback = function() end}
		},
		buttonsSeparator = {isActive = true},
		buttonsMargin = toPx(4)
	},
}

local yMargin = toPx(16)

local function render(group, a)

	-- Background	
	local background = display.newRoundedRect( group, 0, 0, a.width, 1, a.cornerRadius )
	background.anchorY = 0
	background:setFillColor( unpack(a.backgroundColor) )
	group.background = background

	local yPos = 0
	-- title
	if a.title ~= "" then
		yPos = yPos + a.titleMargin

		local title = display.newText( group, a.title, 0, yPos, a.width - a.margin*2, 0, "", a.titleFontSize )
		title:setFillColor( 0,0,0 )
		title.anchorY = 0
		yPos = yPos + title.height
	end

	if a.subtitle ~= "" then
		yPos = yPos + a.subtitleMargin
		local subtitle = display.newText( group, a.subtitle, 0, yPos, a.width - a.margin*2, 0,"", a.subtitleFontSize )
		subtitle:setFillColor( unpack(a.subtitleColor) )
		subtitle.anchorY = 0
		yPos = yPos + subtitle.height
	end

	if a.description ~= "" then
		yPos = yPos + a.descriptionMargin
		local description = display.newText( group, a.description, 0, yPos, a.width - a.margin*2, 0, "", a.descriptionFontSizen )
		description:setFillColor( 0,0,0 )
		description.anchorY = 0
		yPos = yPos + description.height
	end

	if #a.buttons > 0 then
		group.buttons = {}

		if a.buttonsSeparator then
			yPos = yPos + yMargin
			local line = display.newRect( group, 0, yPos, a.width, 1 )
			line:setFillColor( unpack(colors.gray) )
			yPos = yPos + yMargin/4
		end

		local xButtonPos = -a.width*.5
		for i = 1, #a.buttons do
			--a.buttons[i].width = a.width/#a.buttons
			local button = Button(a.buttons[i])
			group:insert(button)

			if i == 1 then
				yPos = yPos + a.buttonsMargin + button.height*.5
				xButtonPos = xButtonPos + button.width*.5
			else
				xButtonPos = xButtonPos + button.width
			end
			button.y = yPos
			button.x = xButtonPos

			if i == #a.buttons then
				yPos = yPos + a.buttonsMargin
			end

			if a.buttons[i].tag then
				group.buttons[a.buttons[i].tag] = button
			end
		end
	end

	background.height = yPos + yMargin
	local _shadow = Shadow({width = background.width, height = background.height, radius = a.cornerRadius, anchorY = 0})
	group:insert(_shadow)
	_shadow:toBack()
end


local function Card(a)
	if not a then a = {} end
	if a.isActive == nil then a.isActive = true end

	local group = display.newGroup()
	if not a.isOn then a.isOn = false end

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = Config.isAndroid end
	if a.isIos == nil then a.isIos = Config.isIos end
	
	-- set proper default values based on os
	if not a.style then a.style = "flat" end
	if a.isIos then
		if _style_ios[a.style] == nil then error("This style is not valid") end
		for k,v in pairs(_style_ios[a.style]) do
			if a[k] == nil then
				a[k] = v
			end
		end
		-- custom variable for difference in iOS.
		a.circleSideOffset = a.strokeWidth
	else
		if _style_android[a.style] == nil then error("This style is not valid") end
		for k,v in pairs(_style_android[a.style]) do
			if a[k] == nil then
				a[k] = v
			end
		end
	end
	render(group, a)

	group.x = toPx(a.x)
	group.y = toPx(a.y)

	function group:setIsActive(isActive)
		a.isActive = isActive
		if isActive then
			group.alpha = 1
		else
			group.alpha = .8
		end
	end
	
	if a.parent then
		a.parent:insert(group)
	end

	return group
end

return Card