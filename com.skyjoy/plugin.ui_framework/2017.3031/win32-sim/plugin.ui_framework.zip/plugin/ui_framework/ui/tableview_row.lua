local colors = require("plugin.ui_framework.css.colors")
local Config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local downloadImage = require("plugin.ui_framework.utils.download_image_util")
local fonts = require("plugin.ui_framework.css.fonts")

local config = {
	what_os = Config.os
}

local renderers = {}

-- row size 48h

renderers.singleLine = function(rowGroup, a) -- {title}
	local title = display.newText({
		parent = rowGroup, 
		text = a.title,
		x = toPx(16),
		y = toPx(24),
		fontSize = toPx(fonts.body2.fontSize),
		font = fonts.body2.font,
		width = a.width - toPx(32),
		align = "left"} )-- [parentGroup,], text, x, y, font [, fontSize] )
	title:setFillColor( 0,0,0 )
	title.anchorX = 0
end

renderers.twoLine = function() -- {title, subtitle}

end

renderers.imageTwoLine = function(rowGroup, a) -- {title, subtitle} -- 72px

	if a.title then
		local t_title = display.newText({
			parent = rowGroup, 
			text = a.title,
			x = toPx(72),
			y = toPx(26),
			fontSize = toPx(fonts.body2.fontSize),
			font = fonts.body2.font,
			width = a.width - toPx(32),
			align = "left"} )-- [parentGroup,], text, x, y, font [, fontSize] )
		t_title:setFillColor( 0,0,0 )
		t_title.anchorX = 0
	end

	if a.description then
		local t_desc = display.newText({
			parent = rowGroup, 
			text = a.description,
			x = toPx(72),
			y = toPx(44),
			fontSize = toPx(fonts.body1.fontSize),
			font = fonts.body1.font,
			width = a.width - toPx(32),
			align = "left"} )-- [parentGroup,], text, x, y, font [, fontSize] )
		t_desc:setFillColor( 0.1,0.1,0.1 )
		t_desc.anchorX = 0
	end

	if a.imageUrl then
		local image = downloadImage:get({group = rowGroup, id = a.title, url = a.imageUrl, 
			params = {width = toPx(54), height = toPx(54), x = toPx(36), y = toPx(36)}})
	end
end

local function TableviewRow(a)
	if not a.style then a.style = "singleLine" end
	if not a.width then a.width = toPx(320) end
	local rowGroup = display.newGroup( )	

	if renderers[a.style] then
		renderers[a.style](rowGroup, a)
	end

	return rowGroup
end

return TableviewRow