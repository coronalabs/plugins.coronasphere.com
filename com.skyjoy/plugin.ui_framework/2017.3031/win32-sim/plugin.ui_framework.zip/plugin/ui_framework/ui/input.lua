local colors = require("plugin.ui_framework.css.colors")
local StringUtil = require("plugin.ui_framework.utils.string_util")
local TouchEffect = require("plugin.ui_framework.ui.touch_effect")
local config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local fonts = require("plugin.ui_framework.css.fonts")

local items = {}
local uid = 0

local _style_android = {
	default = {
		config = {
			width = toPx(160),
			minWidth = toPx(36),
			maxWidth = display.contentWidth,
			height = toPx(44),
			margin = toPx(16),
			x = 0,
			y = 0,
			renderer = "android_default"
			-- touchEffect = "android",
		},
		background = {
			color = colors.transparent,
			boarderWidth = 0,
			borderColor = colors.transparent,
			cornerRadius = toPx(4),
		},
		label = {
			text = "",
			x = 0,
			y = 0,
			--font = fonts.button.font,
			fontSize = toPx(16),
			color = colors.blackLite,
			isActive = true
		},
		placeholder = {
			text = "",
			x = 0,
			y = 0,
			--font = fonts.button.font,
			fontSize = toPx(16),
			color = colors.gray,
			activeColor = config.primaryColor,
			isActive = true
		},
		line = {
			color = colors.gray,
			activeColor = config.primaryColor,
			isActive = true
		}
	},
	search = {
		config = {
			width = toPx(160),
			minWidth = toPx(36),
			maxWidth = display.contentWidth,
			height = toPx(44),
			margin = toPx(16),
			x = 0,
			y = 0,
			renderer = "android_search"
			-- touchEffect = "android",
		},
		background = {
			color = colors.transparent,
			boarderWidth = 0,
			borderColor = colors.transparent,
			cornerRadius = toPx(4),
		},
		label = {
			text = "",
			x = 0,
			y = 0,
			--font = fonts.button.font,
			fontSize = toPx(16),
			color = colors.blackLite,
			isActive = true
		},
		placeholder = {
			text = "",
			x = 0,
			y = 0,
			--font = fonts.button.font,
			fontSize = toPx(16),
			color = colors.gray,
			activeColor = config.primaryColor,
			isActive = true
		},
		line = {
			color = colors.gray,
			activeColor = config.primaryColor,
			isActive = false
		}
	},
}

local _style_androidtv = {
	default = {
		config = {
			width = toPx(160),
			minWidth = toPx(36),
			maxWidth = display.contentWidth,
			height = toPx(64),
			margin = toPx(18),
			x = 0,
			y = 0,
			-- touchEffect = "android",
			renderer = "androidtv_default"
		},
		input = {
			-- width = toPx(160),
			margin = toPx(18),
		},
		background = {
			color = colors.transparent,
			boarderWidth = 0,
			borderColor = colors.transparent,
			cornerRadius = toPx(4),
		},
		label = {
			text = "",
			x = 0,
			y = 0,
			--font = fonts.button.font,
			fontSize = toPx(14),
			color = colors.white,
			isActive = true
		},
		placeholder = {
			text = "",
			x = 0,
			y = 0,
			--font = fonts.button.font,
			fontSize = toPx(16),
			color = colors.white,
			activeColor = config.white,
			isActive = true
		},
		line = {
			color = colors.white,
			activeColor = config.white,
			isActive = true
		}
	},
}

local _style_ios = {
	default = {
		config = {
			width = toPx(160),
			minWidth = toPx(44),
			maxWidth = display.contentWidth,
			height = toPx(28),
			margin = toPx(14),
			x = 0,
			y = 0,
			touchEffect = "ios",
			renderer = "ios_default"
		},
		input = {
			margin = toPx(6),
		},
		background = {
			color = colors.white,
			strokeWidth = toPx(1),
			strokeColor = colors.grayDark,
			activeColor = colors.white,
			activeStrokeColor = colors.grayDark,
			cornerRadius = toPx(4),
		},
		label = {
			text = "",
			x = 0,
			y = 0,
			color = colors.blackLite,
			-- font = fonts.back.font,
			fontSize = toPx(16),
			isActive = true,
			width = nil,
			xOffset = 0
		},
		placeholder = {
			text = "",
			x = 0,
			y = 0,
			--font = fonts.button.font,
			fontSize = toPx(16),
			color = colors.grayDark,
			isActive = true,
			xOffset = 0
		},
		icon = {
			text = "",
			fontSize = toPx(20),
			font = fonts.icons,
			color = colors.grayDark,
			xOffset = -toPx(4),
			align = "left"
		}
	},
	search = {
		config = {
			width = toPx(160),
			minWidth = toPx(44),
			maxWidth = display.contentWidth,
			height = toPx(28),
			margin = toPx(14),
			x = 0,
			y = 0,
			touchEffect = "ios",
			renderer = "ios_default"
		},
		input = {
			xOffset = toPx(14),
			margin = toPx(6),
		},
		background = {
			color = colors.grayLite,
			strokeWidth = 0,
			strokeColor = colors.transparent,
			activeColor = colors.grayLite,
			activeStrokeColor = colors.transparent,
			cornerRadius = toPx(6),
		},
		label = {
			text = "",
			x = 0,
			y = 0,
			color = colors.blackLite,
			-- font = fonts.back.font,
			fontSize = toPx(14),
			isActive = true,
			xOffset = toPx(22)
		},
		placeholder = {
			text = "Search",
			x = 0,
			y = 0,
			--font = fonts.button.font,
			fontSize = toPx(14),
			color = colors.grayDark,
			isActive = true,
			xOffset = toPx(22)
		},
		icon = {
			text = fonts.icon.search,
			fontSize = toPx(18),
			font = fonts.icons,
			color = colors.grayDark,
			xOffset = toPx(14),
			align = "left"
		}
	},
}



local isSamsung = false 
local model = system.getInfo( "model" )
local samsungModels = {"GT-", "SAMSUNG", "SCH-", "SHV-", "SM-", "SPH-"}
if model then 
	for i = 1, #samsungModels do 
		if string.lower( model ):find(string.lower( samsungModels[i] )) then  
			isSamsung = true 
			break 
		end 
	end 
end


local function passwordDisplayText(source_text, a) 

	local str = ""
	local dot = ""
	if isSamsung then 
		dot = "•"
	elseif a.isIos then 
		dot = "•"
	else 
		dot = "• "--"●"IMPRTANT! ITS NOT NORMAL SPACE, THAT SINGLE SPACE IS SPECIAL CHAR. LITTLE BIT WIDER THAN NORMAL SPACE/PAWELK
	end 
	
	-- print(source_text)
	-- print(string.len(source_text))
	for i = 1, string.len(source_text) do
		-- print(i)
		str = str..dot
	end
	return str
end 


local function buildNativeInput(parentGroup, a)
	local group = display.newGroup()
	group.is_focus = false
	group.value = ""
	group.display_text = ""

	local bg = display.newRect( group, 0, 0, a.input.width, a.config.height )
	bg.isVisible = false
	bg.isHitTestable = true
	parentGroup.background = bg

	bg:addEventListener("touch", 
		function(e)
			if group.is_focus == false and a.config.isActive then
				if e.phase == "began" then      
			        TouchEffect:on(parentGroup, a)
			        display.getCurrentStage():setFocus( e.target )
			    elseif ( e.phase == "ended" or e.phase == "cancelled" ) then
					TouchEffect:off(parentGroup, a)
					group:buildInput() 
					display.getCurrentStage():setFocus( nil )
				end
			end
			return true
		end )


	local function textListener( event )
 
	    if ( event.phase == "began" ) then
	        -- User begins editing "defaultField"
	 		event.target.text = group.value
	 		if group.value ~= "" then
	 			event.target:setSelection( string.len(group.value), string.len(group.value) )
	 		end
	 		if a.config.beganCallback then
	    		a.config.beganCallback(event.text, event.oldText, event.newCharacters )
	    	end
	    elseif ( event.phase == "ended" or event.phase == "submitted" ) then
	        -- Output resulting text from "defaultField"
	        group.value = event.target.text
	        
	        if a.config.isSecure then
	        	group.display_text = passwordDisplayText(event.target.text, a) 
	        else
	        	group.display_text = event.target.text
	    	end

	    	if a.config.submittedCalllback then
	    		a.config.submittedCalllback(group.value)
	    	end
	        -- print( event.target.text )
	 		-- group:removeInput()
	    elseif ( event.phase == "editing" ) then
	    	group.value = event.target.text
	    	if a.config.isSecure then
	        	group.display_text = passwordDisplayText(event.target.text, a) 
	        else
	        	group.display_text = event.target.text
	    	end
	    	if a.config.edittingCallback then
	    		a.config.edittingCallback(event.text, event.oldText, event.newCharacters )
	    	end
	    	if parentGroup.editing then
	    		parentGroup:editing(event.text)
	    	end
	        -- print( event.newCharacters )
	        -- print( event.oldText )
	        -- print( event.startPosition )
	        -- print( event.text )
	    end
	end


	function group:buildInput()
		for i = 1,#items do
			if items[i].native_input.is_focus then
				items[i].native_input:removeInput()
			end
		end
		
		group.is_focus = true

		-- Create text field
		local _inputWidth = a.input.width - a.input.xOffset*2
			print(a.input)
		if a.input.margin then
			_inputWidth = _inputWidth - a.input.margin*2
		end
		
		group.input = native.newTextField( 
			a.input.xOffset, 
			-a.config.height, 
			_inputWidth, 
			a.config.height )
		group.input.hasBackground = false
		if a.config.isSecure then
			group.input.isSecure = true
		end

		if a.config.inputType then
			group.input.inputType = a.config.inputType
		end

		group.input.font = native.newFont( a.label.font, a.label.fontSize )
		group.input:setTextColor(unpack(a.label.color))
		group.input:resizeHeightToFitFont()

		group.input:addEventListener( "userInput", textListener )
		group:insert(group.input)

		native.setKeyboardFocus(group.input)

		group.input.y = 0

		parentGroup:nativeIsActive(true)
	end

	function group:removeInput()
		group.is_focus = false
		if group.input then
			group.input:removeEventListener( "userInput", textListener )
			display.remove(group.input)
			group.input = nil
		end

		native.setKeyboardFocus(nil)

		parentGroup:setLabel(group.display_text)
		parentGroup:nativeIsActive(false)

	end

	return group
end

local renderer = {}

function renderer.androidtv_default(parentGroup, a) 
	local group = display.newGroup()

	local bg = display.newRoundedRect( group, 0, 0, a.config.width, a.config.height, toPx(5) )
	bg.alpha = .2
	bg.isVisible = false

	local placeholder = display.newText({parent = group, text = a.placeholder.text, width = a.config.width - a.config.margin*2, font = a.placeholder.font, fontSize = a.placeholder.fontSize})
	placeholder:setFillColor( unpack(a.placeholder.color) )
	-- placeholder.y = bgY

	-- helper for triming long text
	local container = display.newContainer( a.config.width, a.config.height )
	group:insert(container)

	local label = display.newText({parent = container, text = "", width = a.config.width - a.config.margin*2, font = a.label.font, fontSize = a.label.fontSize})
	label:setFillColor( unpack(a.label.color) )

	local line = display.newRect( group, 0, 0, a.config.width - a.config.margin*2, toPx(2) )
	line.y = label.y + label.height*.5 + toPx(9)
	line:setFillColor( unpack(a.line.color) )
	line.alpha = .5


	function parentGroup:setLabel(text)
		label.text = text
	end

	function parentGroup:setHover(is_focus)
		if is_focus then
			bg.isVisible = true
		else
			bg.isVisible = false
		end
	end
	

	function parentGroup:nativeIsActive(is_active)
		parentGroup:setHover(false)
	

		if is_active then
			label.isVisible = false
			line.alpha = 1

			if label.text == "" then
				transition.to( placeholder, {time = 500, y = label.y - toPx(19), size = toPx(11), transition = easing.outQuad} )
			end
		else
			label.isVisible = true
			line:setFillColor( unpack(a.line.color) )
			line.alpha = .5

			if label.text == "" then
				transition.to( placeholder, {time = 500, y = label.y, size = a.placeholder.fontSize, transition = easing.outQuad} )
			else
				placeholder.y = label.y - toPx(19)
				placeholder.size = toPx(11)
			end

		end
	end

	return group
end


function renderer.android_default(parentGroup, a) 
	local group = display.newGroup()

	local bg = display.newRect( group, 0, 0, a.config.width, a.config.height )
	bg:setFillColor(unpack(a.background.color) )
	bg.strokeWidth = a.background.strokeWidth
	bg.stroke = a.background.color

	local placeholder = display.newText({parent = group, text = a.placeholder.text, width = a.config.width, font = a.placeholder.font, fontSize = a.placeholder.fontSize})
	placeholder:setFillColor( unpack(a.placeholder.color) )

	-- helper for triming long text
	local container = display.newContainer( a.config.width, a.config.height )
	group:insert(container)

	local label = display.newText({parent = container, text = "", x = - a.config.width*.5, font = a.label.font, fontSize = a.label.fontSize})
	label.anchorX = 0
	label:setFillColor( unpack(a.label.color) )

	local line = display.newRect( group, 0, 0, a.config.width, toPx(1) )
	line.y = label.y + label.height*.5 + toPx(9)
	line:setFillColor( unpack(a.line.color) )


	function parentGroup:setLabel(text)
		label.text = text
	end
	

	function parentGroup:nativeIsActive(is_active)
		if is_active then
			label.isVisible = false
			line:setFillColor( unpack(a.line.activeColor) )
			line.height = toPx(2)	
			placeholder:setFillColor( unpack(a.placeholder.activeColor) )

			if label.text == "" then
				transition.to( placeholder, {time = 500, y = label.y - toPx(19), size = toPx(11), transition = easing.outQuad} )
			end
		else
			label.isVisible = true
			line:setFillColor( unpack(a.line.color) )
			line.height = toPx(1)
			placeholder:setFillColor( unpack(a.placeholder.color) )

			if label.text == "" then
				transition.to( placeholder, {time = 500, y = label.y, size = a.placeholder.fontSize, transition = easing.outQuad} )
			else
				placeholder.y = label.y - toPx(19)
				placeholder.size = toPx(11)
			end

		end
	end

	return group
end

function renderer.android_search(parentGroup, a) 
	local group = display.newGroup()

	local bg = display.newRect( group, 0, 0, a.config.width, a.config.height )
	bg:setFillColor(unpack(a.background.color) )
	bg.strokeWidth = a.background.strokeWidth
	bg.stroke = a.background.color

	local placeholder = display.newText({parent = group, x = toPx(2), text = a.placeholder.text, width = a.config.width, font = a.placeholder.font, fontSize = a.placeholder.fontSize})
	placeholder:setFillColor( unpack(a.placeholder.color) )

	-- helper for triming long text
	local container = display.newContainer( a.config.width, a.config.height )
	group:insert(container)

	local label = display.newText({parent = container, text = "", x = - a.config.width*.5+toPx(2), font = a.label.font, fontSize = a.label.fontSize})
	label.anchorX = 0
	label:setFillColor( unpack(a.label.color) )


	function parentGroup:setLabel(text)
		label.text = text
	end
	

	function parentGroup:nativeIsActive(is_active)
		if is_active then
			label.isVisible = false
		else
			label.isVisible = true
		end
	end

	function parentGroup:editing(text)
		if text == "" then
			placeholder.isVisible = true
		else
			placeholder.isVisible = false
		end
	end

	return group
end


function renderer.ios_default(parentGroup, a) 
	local group = display.newGroup()


	local bg = display.newRoundedRect( group, 0, 0, a.config.width, a.config.height, a.background.cornerRadius )
	bg:setFillColor(unpack(a.background.color) )
	bg.strokeWidth = a.background.strokeWidth
	bg.stroke = a.background.strokeColor

	local placeholder = display.newText({parent = group, text = a.placeholder.text, x = - a.config.width*.5 + toPx(6) + a.placeholder.xOffset, font = a.placeholder.font, fontSize = a.placeholder.fontSize})
	placeholder.anchorX = 0
	placeholder:setFillColor( unpack(a.placeholder.color) )

	local container = display.newContainer( a.config.width, a.config.height )
	group:insert(container)

	local label = display.newText({parent = container, text = "", x = - a.config.width*.5 + toPx(6) + a.label.xOffset, font = a.label.font, fontSize = a.label.fontSize})
	label.anchorX = 0
	label:setFillColor( unpack(a.label.color) )

	if a.icon.text ~= "" then
		local icon = display.newText( {
			parent = group, 
			text = a.icon.text, 
			fontSize = a.icon.fontSize, 
			font = a.icon.font,
		} )
		icon:setFillColor( unpack(a.icon.color) )
		if a.icon.align == "left" then
			icon.x = -a.config.width*.5 + a.icon.xOffset
		elseif a.icon.align == "right" then
			icon.x = a.config.width*.5 + a.icon.xOffset
		else
			icon.x = a.icon.xOffset
		end
	end

	function parentGroup:setLabel(text)
		label.text = text
	end

	function parentGroup:nativeIsActive(is_active)
		if is_active then
			label.isVisible = false
			bg.stroke = a.background.activeStrokeColor
			bg:setFillColor(unpack(a.background.activeColor))
		else
			label.isVisible = true
			bg.stroke = a.background.strokeColor
			bg:setFillColor(unpack(a.background.color))
		end
	end

	function parentGroup:editing(text)
		if text == "" then
			placeholder.isVisible = true
		else
			placeholder.isVisible = false
		end
	end

	return group
end


local function newInput(a)
	if not a then a = {} end
	if not a.config then a.config = {} end
	if a.config.isActive == nil then a.config.isActive = true end

	uid = uid + 1
	local group = display.newGroup()
	group.uid = uid

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isTv == nil then a.isTv = config.isTv end
	if a.isIos == nil then a.isIos = config.isIos end

	if not a.config.style then a.config.style = "default" end


	if a.isIos then
		if _style_ios[a.config.style] == nil then print(a.config.style) error("This style is not valid") end
		for k,v in pairs(_style_ios[a.config.style]) do
			if a[k] == nil then
				a[k] = v
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				elseif type(v2) == "table" then
					for k3,v3 in pairs(v2) do
						if a[k][k2][k3] == nil then
							a[k][k2][k3] = v3
						end
					end
				end
			end
		end
		if a.placeholder and a.placeholder.text then
			a.placeholder.text = StringUtil:upperFirst(a.placeholder.text)
		end
	else
		local _style
		if a.isTv then
			_style = _style_androidtv[a.config.style]
		else
			_style = _style_android[a.config.style]
		end
		if _style == nil then error("This style is not valid") end
		for k,v in pairs(_style) do
			if a[k] == nil then
				a[k] = v
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
				
			end			
		end
	
		if a.placeholder and a.placeholder.text then
			a.placeholder.text = StringUtil:upperFirst(a.placeholder.text)
		end
	end

	if a.config.width > a.config.maxWidth then
		a.config.width = a.config.maxWidth
	end

	if a.input == nil then
		a.input = {}
	end
	if a.input.width == nil then
		a.input.width = a.config.width
	end

	if not a.input.xOffset then
		a.input.xOffset = 0
	end

	group.native_input = buildNativeInput(group, a)
	group:insert(group.native_input)

	group.ui = renderer[a.config.renderer](group, a)
	group:insert(group.ui)

	if a.config.touchEffect == "android" then
		local container = display.newContainer( group.width, group.height )
		group:insert(container)
		group.container = container
	end

	group.x = a.config.x
	group.y = a.config.y

	function group:setIsActive(isActive)
		a.config.isActive = isActive
		if isActive then
			group.alpha = 1
		else
			group.alpha = .7
		end
	end

	function group:setFocus()
		group.native_input:buildInput()
	end

	function group:press()
		group:setFocus()
	end

	function group:removeFocus()
		group.native_input:removeInput()
	end

	function group:setText(text)
		group.native_input.value = text
		group.native_input.display_text = text
		group:setLabel(text)
		group:nativeIsActive(false)
	end

	function group:setSubmittedCallback(callback)
		if a.config.submittedCalllback then
			a.config.submittedCalllback = nil
		end
		a.config.submittedCalllback = callback
	end

	function group:setBeganCallback(callback)
		if a.config.beganCallback then
			a.config.beganCallback = nil
		end
		a.config.beganCalllback = callback
	end

	function group:getValue()
		return group.native_input.value
	end

	if a.parent then
		a.parent:insert(group)
	end

	-- keep reference for helper  use
	items[#items+1] = group
	-- remove reference when object is destroyed
	group.finalize = function()
		for i = #items, 1, -1 do
			if items[i].uid == group.uid then
				table.remove(items, i)
			end
		end

		if #items == 0 then
			native.setKeyboardFocus(nil)
		end
	end
    group:addEventListener( "finalize" )

	return group
end 

return newInput