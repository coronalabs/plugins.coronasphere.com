local colors = require("plugin.ui_framework.css.colors")
local StringUtil = require("plugin.ui_framework.utils.string_util")
local config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local fonts = require("plugin.ui_framework.css.fonts")

local loader = {}
loader.cache = {}

local _style_android = {
	default = {
		config = {
			width = 1,
			minWidth = toPx(36),
			height = toPx(36),
			margin = toPx(16),
			x = 0,
			y = 0,
		},
		icon = {
			text = fonts.icon.loader,
			font = fonts.icons,
			fontSize = toPx(44),
			x = 0,
			y = 0,
			color = config.primaryColor,
			isActive = true
		},
		label = {
			text = "",
			x = 0,
			y = 0,
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = colors.white,
			isActive = true
		}
	},
}

local _style_ios = {
	default = {
		config = {
			width = 1,
			minWidth = toPx(28),
			height = toPx(28),
			margin = toPx(12),
			x = 0,
			y = 0,
		},
		icon = {
			text = fonts.icon.loader,
			font = fonts.icons,
			fontSize = toPx(30),
			x = 0,
			y = 0,
			color = colors.grayDark,--config.secondaryColor,
			isActive = true
		},
		label = {
			text = "",
			x = 0,
			y = 0,
			color = colors.grayDark,
			-- font = fonts.back.font,
			fontSize = toPx(14),
			isActive = false
		}
	},
}


local renderers = {}

renderers.ios = {}
renderers.android = {}

function renderers.android.default(group, a)
	local loader = display.newText( {
		parent = group,
		text = a.icon.text,
		fontSize = a.icon.fontSize,
		font = a.icon.font} )

	loader:setFillColor( unpack(a.icon.color) )

	transition.to( loader, {time = 1000, rotation = 360, iterations = 0} )
end

function renderers.ios.default(group, a)
	local loader = display.newText( {
		parent = group,
		text = a.icon.text,
		fontSize = a.icon.fontSize,
		font = a.icon.font} )

	loader:setFillColor( unpack(a.icon.color) )

	transition.to( loader, {time = 1800, rotation = 360, iterations = 0} )

	local label = display.newText( {
		parent = group, 
		text = a.label.text, 
		font = a.label.font, 
		fontSize = a.label.fontSize,
		align = "center"} )
	label:setFillColor( unpack(a.label.color) )
	label.y = loader.y + loader.height*.5 + label.height*.5
	group.label = label
end

function loader.new(a)
	if not a then a = {} end
	if not a.config then a.config = {} end
	if a.config.isActive == nil then a.config.isActive = true end

	local group = display.newGroup( )
	-- allows remove items globaly
	if a.tag then
		group.tag = a.tag
		loader.cache[#loader.cache+1] = group
	end

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isIos == nil then a.isIos = config.isIos end
	
	if not a.config.style then a.config.style = "default" end

	if a.isIos then
		if _style_android[a.config.style] == nil then error("This style is not valid. Valid styles: flat, flat_fill, raised, raised_fill") end
		for k,v in pairs(_style_ios[a.config.style]) do
			if a[k] == nil then
				a[k] = v
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end
		end
		if a.label and a.label.text then
			a.label.text = StringUtil:upperFirst(a.label.text)
		end
	else
		if _style_android[a.config.style] == nil then error("This style is not valid. Valid styles: flat, flat_fill, raised, raised_fill") end
		for k,v in pairs(_style_android[a.config.style]) do
			if a[k] == nil then
				a[k] = v
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end			
		end
		if a.label and a.label.text then
			a.label.text = string.upper(a.label.text)
		end
	end


	if a.isAndroid then
		renderers.android[a.config.style](group, a)
	elseif a.isIos then
		renderers.ios[a.config.style](group, a)
	end
	
	group.x = a.config.x
	group.y = a.config.y

	function group.setLabel(text)
		if group.label then
			group.label.text = text
		end
	end
	

	if a.parent then
		a.parent:insert(group)
	end

	return group
end

function loader.remove(tag)
	if tag then
		for i = #loader.cache, 1, -1 do
			if loader.cache[i].tag then
				if loader.cache[i].tag == tag then
					display.remove(loader.cache[i])
					table.remove(loader.cache, i)
				end
			end
		end
	end
end

return loader