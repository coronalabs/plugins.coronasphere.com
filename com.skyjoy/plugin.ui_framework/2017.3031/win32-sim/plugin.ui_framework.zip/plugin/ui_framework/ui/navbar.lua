local colors = require("plugin.ui_framework.css.colors")
local Config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local fonts = require("plugin.ui_framework.css.fonts")
local Button = require("plugin.ui_framework.ui.button").new
local StackPanel = require("plugin.ui_framework.ui.stack_panel")
local StringUtil = require("plugin.ui_framework.utils.string_util")


local config = {
	primaryColor = Config.primaryColor
}

local _style_android = {
	font = fonts.title.font,
	fontSize = toPx(fonts.title.fontSize),
	width = display.contentWidth,
	height = toPx(56),
	textColor = Config.secondaryColor,
	fillColor = Config.primaryColor,
	iconMargin = toPx(20),
	titleMargin = toPx(8)
}

local _style_ios = {
	font = fonts.subheading.font,
	fontSize = toPx(fonts.subheading.fontSize),
	width = display.contentWidth,
	height = toPx(48),
	textColor = colors.white,
	buttonColor = Config.secondaryColor,
	fillColor = Config.primaryColor
}


local renderers = {}

local function renderRightButtons(parentGroup, a)
	local stackPanel = StackPanel({orientation = "horizontal", direction = "left", height = a.height, width = a.width})
	stackPanel.x = a.width*.5
	parentGroup:insert(stackPanel)
	parentGroup.rightButtons = stackPanel

	if #a.buttons.right == 0 then
		local padding = display.newRect( 0, 0, toPx(4), a.height )
		padding.isVisible = false
		stackPanel:insert(padding)
	else
		for i = 1, #a.buttons.right do
			if not a.buttons.right[i].icon then
				a.buttons.right[i].icon = {}
			end
			if not a.buttons.right[i].icon.color then
				a.buttons.right[i].icon.color = a.buttonColor
			end

			if not a.buttons.right[i].label then
				a.buttons.right[i].label = {}
			end
			if not a.buttons.right[i].label.color then
				a.buttons.right[i].label.color = a.buttonColor
			end

			a.buttons.right[i].config.height = a.height

			local btn = Button(a.buttons.right[i])
			if i == 1 then
				btn.padding = {right = toPx(4)}
			end
			stackPanel:insert(btn)
		end
	end
end

function renderers.android(parentGroup, a) -- {title, subtitle}
	local bg = display.newRect( parentGroup, 0, 0, a.width, a.height )
	bg:setFillColor( unpack(a.fillColor) )

	local xPosLeft = bg.x - bg.width*.5 + toPx(16) -- initial margin
	if a.buttons then
		if a.buttons.left then
			if not a.buttons.left.config.style then
				a.buttons.left.config.style = "back"
			end
			if not a.buttons.left.icon then
				a.buttons.left.icon = {}
			end
			if not a.buttons.left.icon.color then
				a.buttons.left.icon.color = a.buttonColor
			end

			if not a.buttons.left.label then
				a.buttons.left.label = {}
			end
			if not a.buttons.left.label.color then
				a.buttons.left.label.color = a.buttonColor
			end

			a.buttons.left.parent = parentGroup
			a.buttons.left.config.height = a.height
			local btn_left = Button(a.buttons.left)
			btn_left.x = bg.x - bg.width*.5 + btn_left.icon.width*.5 + a.iconMargin
			xPosLeft = btn_left.x + btn_left.width*.5 + a.titleMargin
		end
		if not a.buttons then a.buttons = {} end
		if not a.buttons.right then a.buttons.right = {} end
		renderRightButtons(parentGroup, a)
	end

	if a.title then
		local title = display.newText( {text = a.title, parent = parentGroup, x = xPosLeft, font = a.font, fontSize = a.fontSize, align = "left"} )
		title.anchorX = 0
		title:setFillColor( unpack(a.textColor) )
		parentGroup.title = title
	elseif a.image then
		local image = display.newImageRect( parentGroup, a.image.fileName, a.image.width, a.image.height )
		image.anchorX = 0
		image.x = xPosLeft
	end
end

function renderers.ios(parentGroup, a) -- {title}
	
	local bg = display.newRect( parentGroup, 0, 0, a.width, a.height )
	bg:setFillColor( unpack(a.fillColor) )

	local xPosLeft = bg.x - bg.width*.5 + toPx(16) -- initial margin
	if a.buttons then
		if a.buttons.left then
			if not a.buttons.left.config.style then
				a.buttons.left.config.style = "back"
			end

			if not a.buttons.left.icon then
				a.buttons.left.icon = {}
			end
			if not a.buttons.left.icon.color then
				a.buttons.left.icon.color = a.buttonColor
			end

			if not a.buttons.left.label then
				a.buttons.left.label = {}
			end
			if not a.buttons.left.label.color then
				a.buttons.left.label.color = a.buttonColor
			end

			a.buttons.left.parent = parentGroup
			a.buttons.left.config.height = a.height
			a.buttons.left.config.minWidth = 0
			a.buttons.left.config.margin = toPx(8)
			
			local btn_left = Button(a.buttons.left)
			btn_left.x = bg.x - bg.width*.5 + btn_left.width*.5
			xPosLeft = btn_left.x + btn_left.width*.5
		end
		if not a.buttons then a.buttons = {} end
		if not a.buttons.right then a.buttons.right = {} end
		renderRightButtons(parentGroup, a)
	end

	if a.title then
		local title = display.newText( {text = a.title, parent = parentGroup, font = a.font, fontSize = a.fontSize, align = "center"} )
		title:setFillColor( unpack(a.textColor) )
		parentGroup.title = title
		print("yyy")
	elseif a.image then
		print("XXXX")
		local image = display.newImageRect( parentGroup, a.image.fileName, a.image.width or toPx(80), a.image.height or toPx(40) )
	end
	print("xxx")

	local line = display.newRect( parentGroup, bg.x, bg.height*.5 - 1, bg.width, 1 )
	line:setFillColor( 0,0,0,.1)
end

local function Navbar(a)
	if not a then a = {} end
	local group = display.newGroup( )	

	if a.isAndroid == nil then a.isAndroid = Config.isAndroid end
	if a.isIos == nil then a.isIos = Config.isIos end

	if a.isAndroid then
		for k,v in pairs(_style_android) do
			if a[k] == nil then
				a[k] = v
			end
		end
		-- a.title = string.upper(a.title)
	else
		for k,v in pairs(_style_ios) do
			if a[k] == nil then
				a[k] = v
			end
		end
		-- a.title = StringUtil:upperFirst(a.title)
	end

	if a.isAndroid then
		renderers.android(group, a)
	else
		renderers.ios(group, a)
	end

	-- return all params
	function group:getParams()
		return a
	end

	function group.setTitle(text)
		if group.title then
			group.title.text = text
		end
	end

	if a.parent then
		a.parent:insert(group)
	end

	return group
end

return Navbar