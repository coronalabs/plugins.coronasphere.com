local colors = require("plugin.ui_framework.css.colors")
local config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
-- local downloadImage = require("plugin.ui_framework.utils.download_image_util")
local fonts = require("plugin.ui_framework.css.fonts")
local newSwitch = require("plugin.ui_framework.ui.switch")
local newButton = require("plugin.ui_framework.ui.button").new


local _w = display.contentWidth

local _style_android = {
	default = {
		config = {
			width = _w,
			maxWidth = _w,
			height = toPx(64),
			heightTwoRows = toPx(79),
			color = colors.transparent,
			x = 0,
			y = 0,
			margin = toPx(16),
			renderer = "androidSettings"
		},
		title = {
			text = "title",
			x = 0,
			y = 0,
			font = fonts.regular,
			fontSize = toPx(17),
			width = _w,
			color = colors.blackLite
		},
		description = {
			text = "",
			x = 0,
			y = 0,
			font = fonts.regular,
			fontSize = toPx(15),
			color = colors.grayDarkExtra,
			isActive = false
		},
		switch = {
			x = 0,
			y = 0,
			isActive = false,
		},
		button = {
			text = "flat",
			x = 0,
			y = 0,
			height = toPx(64),
			margin = toPx(32),
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = config.primaryColor,
			isActive = false,
		},
		arrow = {
			isActive = false,
		},
		line = {
			height = toPx(1),
			color = colors.gray,
			align = "bottom",
			isActive = false
		}
	},

	settings_category = {
		config = {
			width = _w,
			maxWidth = _w,
			height = toPx(44),
			heightTwoRows = toPx(44),
			color = colors.transparent,
			x = 0,
			y = 0,
			margin = toPx(16),
			renderer = "androidSettings"
		},
		title = {
			text = "title",
			x = 0,
			y = toPx(8),
			font = fonts.medium,
			fontSize = toPx(15),
			width = _w,
			color = config.primaryColor
		},
		description = {
			isActive = false,
		},
		switch = {
			isActive = false,
		},
		button = {
			isActive = false,
		},
		arrow = {
			isActive = false,
		},
		line = {
			height = toPx(1),
			color = colors.gray,
			align = "bottom",
			isActive = false
		}
	},
	settings = {
		config = {
			width = _w,
			maxWidth = _w,
			height = toPx(64),
			heightTwoRows = toPx(79),
			color = colors.transparent,
			x = 0,
			y = 0,
			margin = toPx(16),
			renderer = "androidSettings"
		},
		title = {
			text = "title",
			x = 0,
			y = 0,
			font = fonts.regular,
			fontSize = toPx(17),
			width = _w,
			color = colors.blackLite
		},
		description = {
			text = "",
			x = 0,
			y = 0,
			font = fonts.regular,
			fontSize = toPx(15),
			color = colors.grayDarkExtra,
			isActive = false
		},
		switch = {
			x = 0,
			y = 0,
			isActive = false,
		},
		button = {
			text = "flat",
			x = 0,
			y = 0,
			height = toPx(64),
			margin = toPx(32),
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = config.primaryColor,
			isActive = false,
		},
		arrow = {
			isActive = false,
		},
		line = {
			height = toPx(1),
			color = colors.gray,
			align = "bottom",
			isActive = false
		}
	},
}

local _style_ios = {
	default = {
		config = {
			width = _w,
			maxWidth = _w,
			height = toPx(44),
			heightTwoRows = toPx(59),
			color = colors.transparent,
			x = 0,
			y = 0,
			margin = toPx(16),
			renderer = "androidSettings"
		},
		title = {
			text = "title",
			x = 0,
			y = 0,
			font = fonts.button.font,
			fontSize = toPx(17),
			width = _w,
			color = colors.blackLite
		},
		description = {
			text = "",
			x = 0,
			y = 0,
			font = fonts.button.font,
			fontSize = toPx(15),
			color = colors.grayDarkExtra,
			isActive = false
		},
		switch = {
			x = 0,
			y = 0,
			isActive = false,
		},
		button = {
			text = "flat",
			x = 0,
			y = 0,
			height = toPx(44),
			margin = toPx(32),
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = config.primaryColor,
			isActive = false,
		},
		arrow = {
			isActive = false,
		},
		line = {
			height = toPx(1),
			color = colors.grayDark,
			align = "bottom",
			isActive = false
		}
	},

	settings_category = {
		config = {
			width = _w,
			maxWidth = _w,
			height = toPx(36),
			heightTwoRows = toPx(36),
			color = colors.gray,
			x = 0,
			y = 0,
			margin = toPx(16),
			renderer = "androidSettings"
		},
		title = {
			text = "title",
			x = 0,
			y = 0,
			font = fonts.regular,
			fontSize = toPx(12),
			width = _w,
			color = colors.grayDarkExtra,
			uppert = true
		},
		description = {
			isActive = false,
		},
		switch = {
			isActive = false,
		},
		button = {
			isActive = false,
		},
		arrow = {
			isActive = false,
		},
		line = {
			height = toPx(1),
			color = colors.grayDark,
			align = "bottom",
			isActive = true
		}
	},
	settings = {
		config = {
			width = _w,
			maxWidth = _w,
			height = toPx(44),
			heightTwoRows = toPx(59),
			color = colors.transparent,
			x = 0,
			y = 0,
			margin = toPx(16),
			renderer = "androidSettings"
		},
		title = {
			text = "title",
			x = 0,
			y = 0,
			font = fonts.regular,
			fontSize = toPx(14),
			width = _w,
			color = colors.blackLite
		},
		description = {
			text = "",
			x = 0,
			y = 0,
			font = fonts.regular,
			fontSize = toPx(12),
			color = colors.blackLite,
			isActive = false
		},
		switch = {
			x = 0,
			y = 0,
			isActive = false,
		},
		button = {
			text = "flat",
			x = 0,
			y = 0,
			height = toPx(44),
			margin = toPx(32),
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = config.primaryColor,
			isActive = false,
		},
		arrow = {
			text = fonts.icon.arrow_right,
			x = 0,
			y = 0,
			margin = toPx(18),
			font = fonts.icons,
			fontSize = toPx(24),
			color = colors.grayDark,
			isActive = true,
		},
		line = {
			height = toPx(1),
			color = colors.grayDark,
			align = "bottom",
			isActive = false
		}
	},
}


local function setTouchCallback(group, a)
	group:addEventListener("touch", 
		function(e)
			if e.phase == "began" and a.config.isActive then      
		        display.getCurrentStage():setFocus( e.target )

		    elseif a.config.isActive and ( e.phase == "ended" or e.phase == "cancelled" ) then
				a.config.touchCallback(e)
				display.getCurrentStage():setFocus( nil )
			end
			return true
		end )
end

local renderers = {}

function renderers.androidSettings(group, a)

	local bg = display.newRect( group, 0, 0, a.config.width, a.config.height )
	bg:setFillColor( unpack(a.config.color) )
	bg.isHitTestable = true

	local textGroup = display.newGroup()
	group:insert(textGroup)

	local title
	if a.title.isActive then
		if a.title.upper then
			a.title.text = string.upper(a.title.text)
		end
		title = display.newText( { 
			parent = textGroup, 
			text = a.title.text, 
			font = a.title.font, 
			fontSize = a.title.fontSize, 
			width = a.title.width - a.config.margin*2,
			y = a.title.y } )
		title:setFillColor( unpack(a.title.color) )
		group.title = title
	else
		title = {y = 0, height = 0, x = 0}
	end

	if a.description.isActive then 
		title.y = title.height*.5
		
		local sub_title = display.newText( { 
			parent = textGroup, 
			text = a.description.text, 
			font = a.description.font, 
			fontSize = a.description.fontSize,
			width = a.title.width - a.config.margin*2 } )
		sub_title.x = title.x
		sub_title.y = title.y + title.height*.5 + sub_title.height*.5 + toPx(2)
		sub_title:setFillColor( unpack(a.description.color) )
		textGroup.y = - textGroup.height*.5
		group.description = sub_title
	end

	if a.line.isActive then
		local line = display.newRect( group, 0, a.config.height*.5 - math.abs(a.line.height*.5), a.config.width, a.line.height )
		line:setFillColor( unpack(a.line.color) )
		if a.line.align == "top" then
			line.y = - a.config.height*.5 + math.abs(a.line.height*.5)
		end
	end

	if a.switch.isActive then
		local switch = newSwitch(a.switch)
		switch.x = _w*.5 - switch.width*.5 - a.config.margin
		switch.y = title.y
		textGroup:insert(switch)
		group.switch = switch
	elseif a.button.isActive then
		local button = newButton({
			config = {
				style = a.button.style,
				x = a.button.x,
				y = a.button.y,
				height = a.button.height,
				touchCallback = a.button.touchCallback,
				margin = a.button.margin,
			},
			label = {
				text = a.button.text,
				fontSize = a.button.fontSize,
				font = a.button.font,
				color = a.button.color,
			}
		})
		button.x = _w*.5 - button.width*.5
		button.y = title.y
		textGroup:insert(button)
		group.button = button
	elseif a.arrow.isActive then
		local arrow = display.newText( { 
			parent = group, 
			text = a.arrow.text, 
			font = a.arrow.font, 
			fontSize = a.arrow.fontSize,
			} )
		arrow.x = a.config.width*.5 - arrow.width*.5 - a.arrow.margin
		arrow:setFillColor( unpack(a.arrow.color) )
	end

	if a.debug then
		local bg = display.newRect( group, 0, 0, a.config.width, a.config.height )
		bg:setFillColor( math.random(255)/255, math.random(255)/255, math.random(255)/255 )
		bg:toBack()
	end
end



local row = {}
function row.new(a)
	if not a then a = {} end
	if not a.config then a.config = {} end
	if a.config.isActive == nil then a.config.isActive = true end

	local group = display.newGroup( )

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isIos == nil then a.isIos = config.isIos end
	
	if not a.config.style then a.config.style = "default" end

	if a.isIos then
		if _style_ios[a.config.style] == nil then 
			local _valid_styles = ""
			for k,v in pairs(_style_ios) do
				_valid_styles = _valid_styles..k..", "
			end
			error("This style is not valid. Valid styles: ".._valid_styles ) 
		end
		for k,v in pairs(_style_ios[a.config.style]) do
			if a[k] == nil then
				a[k] = v
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end
		end
	else
		if _style_android[a.config.style] == nil then 
			local _valid_styles = ""
			for k,v in pairs(_style_android) do
				_valid_styles = _valid_styles..k..", "
			end
			error("This style is not valid. Valid styles: ".._valid_styles ) 
		end
		for k,v in pairs(_style_android[a.config.style]) do
			if a[k] == nil then
				a[k] = v
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end			
		end
	end
 
	if a.description.isActive then
		if a.config.style == "settings_category" then -- 
			-- keep size
		else
			a.config.height = a.config.height + a.description.fontSize
		end
	end

	-- set proper button height depending on row height.
	if a.button.isActive then
		if a.description.isActive then
			a.button.height = a.config.height*.5
		else
			a.button.height = a.config.height
		end
		if a.arrow then
			a.arrow.isActive = false
		end
	end

	-- print(a.config)
	renderers[a.config.renderer](group, a)

	if not a.config.width then
		a.config.width = group.width
	end
	if not a.config.height then
		a.config.height = group.height
	end
	
	group.x = a.config.x
	group.y = a.config.y


	-- touch callback is defined
	if a.config.touchCallback then
		setTouchCallback(group, a)
	end

	function group:setTouchCallback(touchCallback)
		if a.config.touchCallback == nil then
			a.config.touchCallback = touchCallback
			setTouchCallback(group, a)
		end
	end

	function group:setIsActive(isActive)
		a.config.isActive = isActive
		if isActive then
			group.alpha = 1
		else
			group.alpha = .7
		end
	end
	

	if a.parent then
		a.parent:insert(group)
	end

	return group
end

function row.getSetting(a)
	if not a then a = {} end
	if not a.config then a.config = {} end

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isIos == nil then a.isIos = config.isIos end

	if not a.config.style then a.config.style = "default" end

	if a.isAndroid then
		return _style_android[a.config.style]
	else
		return _style_ios[a.config.style]
	end
end

return row