local panel = display.panel

local enum = {
    orientation = 
    {
        VERTICAL = "vertical",
        HORIZONTAL = "horizontal"
    },
    direction = 
    {
        LEFT = "left", 
        RIGHT = "right"
    }
}

local function setPosition(group, item)
    if group._orientation == "horizontal" then
        if group.numChildren == 1 then -- set first item
            if group._direction == "left" then
                item.x = math.floor(item._width*item.anchorX + item.padding.right) * group._directionOperator
            else
                item.x = math.floor(item._width*item.anchorX + item.padding.left)
            end
        else -- all next items
            if group._direction == "left" then
                item.x = math.floor( group._xPos + item._width*item.anchorX + item.padding.right) * group._directionOperator
            else
                item.x = math.floor( group._xPos + item._width*item.anchorX + item.padding.left) * group._directionOperator 
            end
        end
        panel(group, item)
    elseif group._orientation == "vertical" then
        if group.numChildren == 1 then -- set first item
            
            item.y = math.floor( item.height * item.anchorY + item.padding.top + group._spacing )
    
        else -- all next items
            item.y = math.floor( group._yPos + item.height * item.anchorY + item.padding.top + group._spacing )
        end
        
        panel(group, item)
    else
        print("orientation", group._orientation)
        error("Warning: Wrong orientation")
    end

    group._yPos = math.round(group._yPos + item.height + item.padding.top + item.padding.bottom)
    if group._spacing then
        group._yPos = group._yPos + group._spacing
        group._xPos = group._xPos + group._spacing
    end
    group._xPos = math.round(group._xPos + item.width + item.padding.left + item.padding.right)
end

local function insert(group, item)

    if not item.padding then item.padding = {} end -- obsługa paddingów
    if not item.padding.left then item.padding.left = 0 end
    if not item.padding.right then item.padding.right = 0 end
    if not item.padding.top then item.padding.top = 0 end
    if not item.padding.bottom then item.padding.bottom = 0 end

    if not item._width then item._width = item.width end
    if not item._anchorY then item._anchorY = item.anchorY end
    if not item._anchorX then item._anchorX = item.anchorX end

    group:old_insert(item)

    setPosition(group, item)    

    if group._debug then
        item.debugBg = display.newRect( item.x, item.y, item.width, item.height )
        item.debugBg.anchorY = item._anchorY
        item.debugBg.anchorX = item._anchorX
        item.debugBg:setFillColor( math.random(1,100)/100,math.random(1,100)/100,math.random(1,100)/100, .5 )
        group:old_insert( item.debugBg )
    end
end

-- public methods
local function StackPanel(a)--x, y, width, height, orientation, direction, debug, spacing
    if not a then a = {} end
    if not a.x then a.x = 0 end
    if not a.y then a.y = 0 end
    if not a.height then a.height = display.contentHeight end
    if not a.width then a.width = display.contentWidth end
    if not a.orientation then a.orientation = "vertical" end
    if not a.direction then a.direction =  "down" end
    if not a.debug then a.debug = false end
    if not a.spacing then a.spacing = 0 end
    
    local group = display.newGroup( )
    group.x = a.x
    group.y = a.y

    group._orientation = a.orientation
    if group._orientation == "horizontal" then
        group._anchorX = 0
    end
    group._width = a.width
    group._xLeft = - group._width*.5
    group._xRight = group._width*.5
    group._debug = a.debug
    group._direction = a.direction
    group.dock = a.dock
    group.padding = a.padding
    group._spacing = a.spacing


    group.old_insert = group.insert
    function group:insert(item)
        insert(group, item)
    end

    function group:refresh()
        group._xPos = 0
        group._yPos = 0
        for i = 1, group.numChildren do
            setPosition(group, group[i])
        end
    end


    function group:clear(tag)
        if tag then
            for i = group.numChildren, 1, -1 do
                if group[i].tag == tag then
                    display.remove(group[i])
                end
            end
        else
            for i = group.numChildren, 1, -1 do
                display.remove(group[i])
            end
        end
        group:refresh()
    end

    -- globa x pos to properly track anchor objects positions
    group._xPos = 0
    group._yPos = 0

    group._directionOperator = 1
    if group._direction == "left" then
        group._directionOperator = -1
    end

    if a.parent then
        a.parent:insert(group)    
    end 

    return group
end

return StackPanel