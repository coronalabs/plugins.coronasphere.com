local colors = require("plugin.ui_framework.css.colors")
local config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local Shadow = require("plugin.ui_framework.ui.shadow")
local fonts = require("plugin.ui_framework.css.fonts")
local _w = display.contentWidth

local function aspectRation_16_9(width)
	return math.round(width*0.5625)
end



local text_size = {}
local function getTextHeight(font_size, font, rows, codename)
	if text_size[codename] then
		return text_size[codename]
	else
		local _str = ""
		for i=1,rows do
			_str = _str.."Jj"
			if i < rows then
				_str = _str.."\n"
			end
		end
		local temp = display.newText( {text = _str, font = font, fontSize = font_size} )
		text_size[codename] = temp.height
		display.remove(temp)
		-- print(_str, text_size[codename])
		return text_size[codename]
	end
end

local sizes = {
	atv = {
		w = (_w / 4) - toPx(20),
		h = aspectRation_16_9((_w / 4) - toPx(20) + toPx(80)),
	},
	atv_vod = {
		w = (_w / 5) - toPx(20),
		h = ( (_w / 5) - toPx(20) )*1.5 + toPx(40),
		image_h = ( (_w / 5) - toPx(20) )*1.5
	}
}
local _style_androidtv = {
	default = {
		config = {
			width = sizes.atv.w,
			minWidth = toPx(36),
			height = sizes.atv.h,
			margin = 0,--toPx(4),
			color = {54/255, 71/255, 79/255},
			activeColor = config.primaryColor,
			x = 0,
			y = 0,
			renderer = "video",
			-- columns = _how_many_will_fit
		},
		image = {
			fileName = "",
			width = sizes.atv.w,
			height = aspectRation_16_9(sizes.atv.w),
		},
		title = {
			text = "",
			x = 0,
			y = 0,
			font = fonts.medium,
			rows = 1,
			margin = toPx(8),
			fontSize = toPx(14),
			color = colors.white,
			isActive = true
		},
		description = {
			text = "",
			x = 0,
			y = 0,
			font = fonts.light,
			margin = toPx(16),
			fontSize = toPx(16),
			color = colors.black,
			isActive = true
		},
	},
	vod = {
		config = {
			width = sizes.atv_vod.w,
			minWidth = toPx(36),
			height = sizes.atv_vod.h,
			margin = 0,--toPx(4),
			color = {54/255, 71/255, 79/255},
			activeColor = config.primaryColor,
			x = 0,
			y = 0,
			renderer = "video",
			-- columns = _how_many_will_fit
		},
		image = {
			fileName = "",
			width = sizes.atv_vod.w,
			height = sizes.atv_vod.image_h,
		},
		title = {
			text = "",
			x = 0,
			y = 0,
			font = fonts.medium,
			rows = 1,
			margin = toPx(8),
			fontSize = toPx(14),
			color = colors.white,
			isActive = true
		},
		description = {
			isActive = false
		},
	}
}

local _style_android = {
	default = {
		config = {
			width = _w,
			maxWidth = _w,
			height = toPx(64),
			heightTwoRows = toPx(79),
			color = colors.transparent,
			x = 0,
			y = 0,
			margin = toPx(16),
			renderer = "androidSettings"
		},
		title = {
			text = "title",
			x = 0,
			y = 0,
			font = fonts.regular,
			fontSize = toPx(17),
			width = _w,
			color = colors.blackLite
		},
		description = {
			text = "",
			x = 0,
			y = 0,
			font = fonts.regular,
			fontSize = toPx(15),
			color = colors.grayDarkExtra,
			isActive = false
		},
		switch = {
			x = 0,
			y = 0,
			isActive = false,
		},
		button = {
			text = "flat",
			x = 0,
			y = 0,
			height = toPx(64),
			margin = toPx(32),
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = config.primaryColor,
			isActive = false,
		},
		arrow = {
			isActive = false,
		},
		line = {
			height = toPx(1),
			color = colors.gray,
			align = "bottom",
			isActive = false
		}
	},
}

local _style_ios = {
	default = {
		config = {
			width = _w,
			maxWidth = _w,
			height = toPx(44),
			heightTwoRows = toPx(59),
			color = colors.transparent,
			x = 0,
			y = 0,
			margin = toPx(16),
			renderer = "androidSettings"
		},
		title = {
			text = "title",
			x = 0,
			y = 0,
			font = fonts.button.font,
			fontSize = toPx(17),
			width = _w,
			color = colors.blackLite
		},
		description = {
			text = "",
			x = 0,
			y = 0,
			font = fonts.button.font,
			fontSize = toPx(15),
			color = colors.grayDarkExtra,
			isActive = false
		},
		switch = {
			x = 0,
			y = 0,
			isActive = false,
		},
		button = {
			text = "flat",
			x = 0,
			y = 0,
			height = toPx(44),
			margin = toPx(32),
			font = fonts.button.font,
			fontSize = toPx(fonts.button.fontSize),
			color = config.primaryColor,
			isActive = false,
		},
		arrow = {
			isActive = false,
		},
		line = {
			height = toPx(1),
			color = colors.grayDark,
			align = "bottom",
			isActive = false
		}
	},
}


local function setTouchCallback(group, a)
	group:addEventListener("touch", 
		function(e)
			if e.phase == "began" and a.config.isActive then      
		        display.getCurrentStage():setFocus( e.target )

		    elseif a.config.isActive and ( e.phase == "ended" or e.phase == "cancelled" ) then
				a.config.touchCallback(e)
				display.getCurrentStage():setFocus( nil )
			end
			return true
		end )
end

local renderers = {}

function renderers.video(group, a)

	local bg = display.newRoundedRect( group, 0, 0, a.config.width, a.config.height, toPx(1) )
	bg:setFillColor(unpack(a.config.color) )
	bg.isHitTestable = true

	local image_y = -a.config.height*.5 + a.image.height*.5

	if a.image.fileName and a.image.fileName ~= "" then
		if a.image.codename == nil then a.image.codename = a.title.text end
		local image = ui.downloadImage:get({
			group = group,
			id = a.image.codename.."_image", 
			url = a.image.fileName, 
			params = {
				width = a.image.width, 
				height = a.image.height,
				y = image_y,
				-- fade = true,
			} 
		} ) 
	else
		local image_bg = display.newRect( group, 0, image_y, a.image.width, a.image.height )
		image_bg:setFillColor(1, 1, 1, .5 )
	end

	local title_height = getTextHeight(a.title.fontSize, a.title.font, a.title.rows, "title_default")

	local title = display.newText( {parent = group, text = a.title.text, width = a.config.width - a.title.margin*2, height = title_height, fontSize = a.title.fontSize, font = a.title.font} )
	title.y = image_y + a.image.height*.5 + title.height*.5 + toPx(6)
	title:setFillColor( unpack(a.title.color) )

	if a.description.isActive then
		local desc_height = getTextHeight(a.description.fontSize, a.description.font, 4, "description_default")
		local description = display.newText( {parent = group, text = a.description.text, width = a.config.width - a.title.margin*2, height = desc_height, fontSize = a.description.fontSize, font = a.description.font} )
		description.y = description.height*.5 + toPx(5)
		description:setFillColor( unpack(a.description.color) )
	end

	local _shadow = Shadow({width = bg.width, height = bg.height, radius = toPx(1), offset = 0, strokeWidth = toPx(6)})
	
	group:insert(_shadow)
	_shadow:toBack()
end



local tile = {}
local function setDefaultValues(a)
	if not a then a = {} end
	if not a.config then a.config = {} end

	if a.config.isActive == nil then a.config.isActive = true end
	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isIos == nil then a.isIos = config.isIos end
	if a.isTv == nil then a.isTv = config.isTv end
	
	if not a.config.style then a.config.style = "default" end
end

function tile.new(a)	
	local group = display.newGroup( )

	setDefaultValues(a)
	
	if a.isAndroid then
		if a.isTv then
			if _style_androidtv[a.config.style] == nil then 
				local _valid_styles = ""
				for k,v in pairs(_style_androidtv) do
					_valid_styles = _valid_styles..k..", "
				end
				error("This style is not valid. Valid styles: ".._valid_styles ) 
			end
			for k,v in pairs(_style_androidtv[a.config.style]) do
				if a[k] == nil then
					a[k] = v
				end
				for k2,v2 in pairs(v) do
					if a[k][k2] == nil then
						a[k][k2] = v2
					end
				end			
			end
		else
			if _style_android[a.config.style] == nil then 
				local _valid_styles = ""
				for k,v in pairs(_style_android) do
					_valid_styles = _valid_styles..k..", "
				end
				error("This style is not valid. Valid styles: ".._valid_styles ) 
			end
			for k,v in pairs(_style_android[a.config.style]) do
				if a[k] == nil then
					a[k] = v
				end
				for k2,v2 in pairs(v) do
					if a[k][k2] == nil then
						a[k][k2] = v2
					end
				end			
			end
		end
	else
		if _style_ios[a.config.style] == nil then 
			local _valid_styles = ""
			for k,v in pairs(_style_ios) do
				_valid_styles = _valid_styles..k..", "
			end
			error("This style is not valid. Valid styles: ".._valid_styles ) 
		end
		for k,v in pairs(_style_ios[a.config.style]) do
			if a[k] == nil then
				a[k] = v
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end
		end
	end
 
	-- print(a.config)
	renderers[a.config.renderer](group, a)

	if not a.config.width then
		a.config.width = group.width
	end
	if not a.config.height then
		a.config.height = group.height
	end
	
	group.x = a.config.x
	group.y = a.config.y


	-- touch callback is defined
	if a.config.touchCallback then
		setTouchCallback(group, a)
	end

	function group:setTouchCallback(touchCallback)
		if a.config.touchCallback == nil then
			a.config.touchCallback = touchCallback
			setTouchCallback(group, a)
		end
	end

	function group:setIsActive(isActive)
		a.config.isActive = isActive
		if isActive then
			group.alpha = 1
		else
			group.alpha = .7
		end
	end
	

	if a.parent then
		a.parent:insert(group)
	end

	return group
end

function tile.getSetting(a)

	setDefaultValues(a)

	if a.isAndroid then
		if a.isTv then
			if _style_androidtv[a.config.style] then
				return _style_androidtv[a.config.style]
			else
				print("android tv style")
				print(a.config.style)
				error("This style is not defined!")
			end
		else
			if _style_android[a.config.style] then
				return _style_android[a.config.style]
			else
				print("android style")
				print(a.config.style)
				error("This style is not defined!")
			end
		end
	else
		if _style_ios[a.config.style] then
			return _style_ios[a.config.style]
		else
			print("ios style")
			print(a.config.style)
			error("This style is not defined!")
		end
	end
end

function tile.extend(renderer, setting)
	if not a or not a.config or not a.config.style then error("You have to provide at least style name") end
	setDefaultValues(a)

	if a.isAndroid then
		if a.isTv then
			_style_androidtv[a.config.style] = a
		else
			_style_android[a.config.style] = a
		end
	else
		_style_ios[a.config.style] = a
	end

	renderers[a.config.style] = renderer
end

return tile