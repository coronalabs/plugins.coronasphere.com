local colors = require("plugin.ui_framework.css.colors")
local Config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local fonts = require("plugin.ui_framework.css.fonts")
local Button = require("plugin.ui_framework.ui.button_legacy")
local GridPanel = require("plugin.ui_framework.ui.grid_panel")


local config = {
	isAndroid = Config.isAndroid,
	isIos = Config.isIos,
	primaryColor = Config.primaryColor
}

local _style_android = {
	font = fonts.title.font,
	fontSize = toPx(fonts.title.fontSize),
	width = display.contentWidth,
	height = toPx(48),
	textColor = {1,1,1},
	fillColor = Config.primaryColor,
}

local _style_ios = {
	font = fonts.subheading.font,
	fontSize = toPx(fonts.subheading.fontSize),
	width = display.contentWidth,
	height = toPx(44),
	textColor = colors.black,
	fillColor = colors.grayLite,
}

local renderers = {}

local function setActiveAndroid(parentGroup, index, speed)
	for j = 1, #parentGroup.items do
		parentGroup.items[j].label.alpha = .6
	end
	parentGroup.items[index].label.alpha = 1
	transition.to( parentGroup.under, {time = speed or 400, x = parentGroup.items[index]._x} )
end

local function setActiveIos(parentGroup, index)
	for j = 1, #parentGroup.items do
		-- parentGroup.items[j].icon.alpha = .6
		if parentGroup.items[j].label then
			-- parentGroup.items[j].label.alpha = .6
		end

		if parentGroup.items[j].icon_outline then
			parentGroup.items[j].icon.text = parentGroup.items[j].icon_outline
		end
	end

	-- parentGroup.items[index].icon.alpha = 1
	if parentGroup.items[index].icon_default then
		parentGroup.items[index].icon.text = parentGroup.items[index].icon_default
	end

	if parentGroup.items[index].label then
		-- parentGroup.items[index].label.alpha = 1
	end
end

function renderers.android(parentGroup, a) -- {{items = { {title, tag} }}, subtitle}
	if a.items then
		local item_width = a.width/#a.items
		for i = 1, #a.items do
			local _textColor = a.textColor or {1,1,1}
			if a.items[i].textColor then
				_textColor = a.items[i].textColor
			end

			local _cell = parentGroup.grid:getCell({column = i})
			local btn = Button({
				text = a.items[i].text, 
				textColor = _textColor,
				touchCallback = function()
					parentGroup.touchCallback({tag = a.items[i].tag, index = i, x = _cell.x }) 
					setActiveAndroid(parentGroup, i)
				end,
				height = a.height,
				width = item_width
				})
			btn.tag = a.items[i].tag
			btn._x = _cell.x
			_cell:insert(btn)
			parentGroup.items[#parentGroup.items+1] = btn
		end
		local under = display.newRect(parentGroup, 0, 0, item_width, toPx(3))
		under.y = a.height*.5 - under.height*.5
		parentGroup.under = under
	end
end

function renderers.ios(parentGroup, a) -- {title}
	local item_width = a.width/#a.items
	for i = 1, #a.items do
		if not a.items[i].icon then a.items[i].icon = "" end

		local _textColor = a.textColor
		if a.items[i].textColor then
			_textColor = a.items[i].textColor
		end

		local _icon_default = ""
		if a.items[i].icon.default then
			_icon_default = a.items[i].icon.default
		else
			_icon_default = a.items[i].icon
		end

		local _icon_outline = ""
		if a.items[i].icon.outline then
			_icon_outline = a.items[i].icon.outline
		else
			_icon_outline = a.items[i].icon
		end

		local _cell = parentGroup.grid:getCell({column = i})
		local btn = Button({
			style = "icon",
			icon = _icon_default, 
			iconY = toPx(-4),
			iconFontSize = toPx(28),
			text = a.items[i].text,
			fontSize = toPx(10),
			textY = toPx(15),
			textColor = _textColor,
			touchCallback = function()
				parentGroup.touchCallback({tag = a.items[i].tag, index = i, x = _cell.x })
				setActiveIos(parentGroup, i)
			end,
			height = a.height,
			width = item_width
			})
		btn.tag = a.items[i].tag
		btn._x = _cell.x
		btn.icon_default = _icon_default
		btn.icon_outline = _icon_outline
		_cell:insert(btn)
		parentGroup.items[#parentGroup.items+1] = btn
	end
	local line = display.newRect( parentGroup, 0, - a.height*.5 + 1, a.width, 1 )
	line:setFillColor( 0,0,0,.1)
end

local function buildGrid(parentGroup, a)
	local bg = display.newRect( parentGroup, 0, 0, a.width, a.height )
	bg:setFillColor( unpack(a.fillColor) )

	local _grid_columns = {}
	for i = 1, #a.items do
		_grid_columns[#_grid_columns+1] = "*"
	end

	local item_width = a.width/#a.items

	local grid = GridPanel({
		width = a.width,
		height = a.height,
		-- rows = {"*","*"},
		columns = _grid_columns,
		debug = false})

	parentGroup:insert(grid)
	parentGroup.grid = grid
end

local function TabMenu(a)
	if not a then a = {} end
	local group = display.newGroup()	

	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isIos == nil then a.isIos = config.isIos end

	if a.isAndroid then
		for k,v in pairs(_style_android) do
			if a[k] == nil then
				a[k] = v
			end
		end
	else
		for k,v in pairs(_style_ios) do
			if a[k] == nil then
				a[k] = v
			end
		end
	end

	-- table for items reference
	group.items = {}

	-- fire touch callback
	function group.touchCallback(e)
		if a.touchCallback then
			a.touchCallback(e)
		end
	end

	function group:setTouchCallback(callback)
		if callback then
			a.touchCallback = callback
		end
	end

	function group:setActiveTab(index)
		if index then
			setActiveAndroid(group, index)
		end
	end

	function group:render(_a)
		if _a then
			for k,v in pairs(_a) do
				a[k] = v
			end
		end
		buildGrid(group, a)
		if a.isAndroid then
			renderers.android(group, a)
			if a.active_tab_index then
				setActiveAndroid(group, a.active_tab_index, 0)
			else
				setActiveAndroid(group, 1, 0)		
			end
		else
			renderers.ios(group, a)
			-- return group
			if a.active_tab_index then
				setActiveIos(group, a.active_tab_index)
			else
				setActiveIos(group, 1)
			end
		end
	end

	if a.items then
		group:render()
	end

	-- return all params
	function group:getParams()
		return a
	end

	if a.parent then
		a.parent:insert(group)
	end

	group.x = a.x or 0
	group.y = a.y or 0

	return group
end

return TabMenu