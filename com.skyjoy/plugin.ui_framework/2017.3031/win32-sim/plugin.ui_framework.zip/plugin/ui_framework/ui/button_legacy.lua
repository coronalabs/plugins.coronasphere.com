local colors = require("plugin.ui_framework.css.colors")
local StringUtil = require("plugin.ui_framework.utils.string_util")
local TouchEffect = require("plugin.ui_framework.ui.touch_effect")
local Shadow = require("plugin.ui_framework.ui.shadow")
local Config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local fonts = require("plugin.ui_framework.css.fonts")


-- icon = {
-- 		config = {
-- 			width
-- 			height
-- 			color
-- 			touchEffect
-- 			x
-- 			y
-- 			minWidth
-- 		},
-- 		icon = {
-- 			text
-- 			font
-- 			fontSize
-- 			x
-- 			y
-- 			color
-- 		},
-- 		label = {
-- 			text
-- 			x
-- 			y
-- 			font
-- 			fontSize
-- 			color
-- 		}
-- 	},


local _style_android = {
	icon = {
		icon = fonts.back.icon,
		iconFont = fonts.icons,
		iconFontSize = toPx(fonts.back.iconFontSize),
		iconX = 0,
		iconY = 0,
		iconColor = colors.white,
		x = 0,
		y = 0,
		width = 1,
		minWidth = toPx(36),
		height = toPx(36),
		margin = toPx(18),
		textColor = colors.white,
		textY = 0,
		textX = 0,
		fillColor = colors.transparent,
		touchEffect = "android",
	},

	back = {
		text = "",
		icon = fonts.back.icon,
		iconFont = fonts.back.iconFont,
		iconFontSize = toPx(fonts.back.iconFontSize),
		iconX = 0,
		iconY = 0,
		iconColor = colors.white,
		x = 0,
		y = 0,
		font = fonts.back.font,
		fontSize = toPx(fonts.back.fontSize),
		width = 1,
		minWidth = toPx(36),
		height = toPx(36),
		margin = toPx(16),
		cornerRadius = toPx(1),
		textColor = Config.primaryColor,
		fillColor = colors.transparent,
		shadow = {isActive = false},
		touchEffect = "android",
	},

	flat = {
		text = "flat",
		x = 0,
		y = 0,
		font = fonts.button.font,
		fontSize = toPx(fonts.button.fontSize),
		width = 1,
		minWidth = toPx(36),
		height = toPx(36),
		margin = toPx(16),
		cornerRadius = toPx(1),
		textColor = Config.primaryColor,
		fillColor = colors.transparent,
		shadow = {isActive = false},
		touchEffect = "android",
	},

	flat_fill = {
		text = "flat fill",
		x = 0,
		y = 0,
		font = fonts.button.font,
		fontSize = toPx(fonts.button.fontSize),
		width = 1,
		minWidth = toPx(88),
		height = toPx(36),
		margin = toPx(16),
		cornerRadius = toPx(1),
		textColor = colors.white,
		fillColor = Config.primaryColor,
		shadow = {isActive = false},
		touchEffect = "android",
	},

	raised = {
		text = "raised",
		x = 0,
		y = 0,
		font = fonts.button.font,
		fontSize = toPx(fonts.button.fontSize),
		width = 1,
		minWidth = toPx(88),
		height = toPx(36),
		margin = toPx(16),
		cornerRadius = toPx(1),
		textColor = Config.primaryColor,
		fillColor = colors.white,
		shadow = {isActive = true, offset = (2), strokeWidth = toPx(4)},
		touchEffect = "android"
	},

	raised_fill = {
		text = "raised fill",
		x = 0,
		y = 0,
		font = fonts.button.font,
		fontSize = toPx(fonts.button.fontSize),
		width = 1,
		minWidth = toPx(88),
		height = toPx(36),
		margin = toPx(16),
		cornerRadius = toPx(1),
		textColor = colors.white,
		fillColor = Config.primaryColor,
		shadow = {isActive = true, offset = toPx(1), strokeWidth = toPx(4)},
		touchEffect = "android"
	},

	float = {
		text = "+",
		x = 0,
		y = 0,
		font = fonts.button.font,
		fontSize = toPx(30),
		margin = 0,
		radius = toPx(32),
		textColor = colors.white,
		fillColor = Config.primaryColor,
		shadow = {isActive = true, offset = toPx(1), strokeWidth = toPx(4) },
		touchEffect = "android",
		touchEffectConfig = {radius = toPx(32), startScale = .1, endScale = 1, duration = 400}
	},
}

local _style_ios = {
	icon = {
		icon = fonts.back.icon,
		iconFont = fonts.icons,
		iconFontSize = toPx(fonts.back.iconFontSize),
		iconX = 0,
		iconY = 0,
		iconColor = colors.blackLite,
		x = 0,
		y = 0,
		width = 1,
		minWidth = toPx(44),
		height = toPx(28),
		margin = toPx(12),
		textColor = colors.blackLite,
		textY = 0,
		textX = 0,
		fillColor = colors.transparent,
		touchEffect = "ios",
	},
	back = {
		text = "",
		icon = fonts.back.icon,
		iconFont = fonts.back.iconFont,
		iconFontSize = toPx(fonts.back.iconFontSize),
		iconX = 0,
		iconY = 0,
		iconColor = Config.primaryColor,
		x = 0,
		y = 0,
		font = fonts.back.font,
		fontSize = toPx(fonts.back.fontSize),
		width = 1,
		minWidth = toPx(50),
		height = toPx(28),
		margin = toPx(12),
		cornerRadius = 0,
		textColor = Config.primaryColor,
		fillColor = colors.transparent,
		touchEffect = "ios"
	},
	flat = {
		text = "flat",
		x = 0,
		y = 0,
		font = "",
		fontSize = toPx(15),
		width = 1,
		minWidth = toPx(50),
		height = toPx(28),
		margin = toPx(12),
		cornerRadius = 0,
		textColor = Config.primaryColor,
		fillColor = colors.transparent,
		touchEffect = "ios"
	},
	flat_fill = {
		text = "flat fill",
		x = 0,
		y = 0,
		font = "",
		fontSize = toPx(15),
		width = 1,
		minWidth = toPx(100),
		height = toPx(28),
		margin = toPx(12),
		cornerRadius = toPx(4),
		textColor = colors.white,
		fillColor = Config.primaryColor,
		touchEffect = "ios"
	},

	raised = {
		text = "raised",
		x = 0,
		y = 0,
		font = "",
		fontSize = toPx(15),
		width = 1,
		minWidth = toPx(100),
		height = toPx(28),
		margin = toPx(12),
		cornerRadius = toPx(4),
		textColor = Config.primaryColor,
		fillColor = colors.white,
		strokeColor = Config.primaryColor,
		touchEffect = "ios"
	},

	raised_fill = {
		text = "raised fill",
		x = 0,
		y = 0,
		font = "",
		fontSize = toPx(15),
		width = 1,
		minWidth = toPx(100),
		height = toPx(28),
		margin = toPx(12),
		cornerRadius = toPx(4),
		textColor = colors.white,
		fillColor = Config.primaryColor,
		touchEffect = "ios"
	},

	float = {
		text = "+",
		x = 0,
		y = 0,
		font = fonts.button.font,
		fontSize = toPx(24),
		margin = 0,
		radius = toPx(25),
		textColor = colors.white,
		fillColor = Config.primaryColor,
		touchEffect = "ios",
		touchEffectConfig = {radius = toPx(25), startScale = .1, endScale = 1, duration = 400}
	},
}


local renderers = {}

renderers.ios = {}
renderers.android = {}

function renderers.icon(group, a)
	local background = display.newRect( group, 0, 0, a.width, a.height )
	background.isHitTestable = true
	background.isVisible = false
	-- background:setFillColor( 1,0,0 )
	group.background = background

	if a.icon then
		local icon = display.newText( group, a.icon, a.iconX, a.iconY , a.iconFont, a.iconFontSize )	
		icon:setFillColor( unpack(a.iconColor) )
		group.icon = icon
	else
		print("warrning: icon is required!")
	end

	if a.text then
		local label = display.newText( group, a.text, a.textX, a.textY, a.font, a.fontSize )	
		group.label = label
		if a.textColor then
			label:setFillColor( unpack(a.textColor) )
		end
	end

	if a.width == 1 then
		if (group.width + a.margin) < a.minWidth then
			background.width = a.minWidth + a.margin
		else
			background.width = group.width + a.margin*2
		end
	end
end

function renderers.ios.back(group, a)
	local background = display.newRoundedRect( group, 0, 0, a.width, a.height, a.cornerRadius )
	background.isHitTestable = true
	background:setFillColor( unpack(a.fillColor) )

	group.background = background

	local textGroup = display.newGroup() -- additional group to center both texts properly

	local icon = display.newText( textGroup, a.icon, 0, 0, a.iconFont, a.iconFontSize )	
	icon:setFillColor( unpack(a.iconColor) )
	icon.anchorX = 0

	if a.text then
		local label = display.newText( textGroup, a.text, 0, 0, a.font, a.fontSize )	
		label:setFillColor( unpack(a.textColor) )
		label.x = icon.width + toPx(4)
		label.anchorX = 0
		group.label = label
	end

	textGroup.x = - textGroup.width*.5
	group:insert(textGroup)

	if a.width == 1 then
		if (group.width + a.margin) < a.minWidth then
			background.width = a.minWidth + a.margin
		else
			background.width = group.width + a.margin*2
		end
	end
end

function renderers.android.back(group, a)
	local background = display.newRoundedRect( group, 0, 0, a.width, a.height, a.cornerRadius )
	background.isHitTestable = true
	background:setFillColor( unpack(a.fillColor) )

	group.background = background

	local icon = display.newText( group, a.icon, 0, 0, a.iconFont, a.iconFontSize )	
	group.icon = icon

	icon:setFillColor( unpack(a.textColor) )

	if a.width == 1 then
		if (icon.width + a.margin) < a.minWidth then
			background.width = a.minWidth + a.margin
		else
			background.width = icon.width + a.margin*2
		end
	end
end

function renderers.float(group, a)
	local background = display.newCircle( group, 0, 0, a.radius)
	background.isHitTestable = true
	background:setFillColor( unpack(a.fillColor) )

	local paint = {
        type = "gradient",
        color1 = a.fillColor or { 0, 0, 0, 0.3 },
        color2 = { 0, 0, 0, 0 },
        direction = "down"
    }
    background.stroke = paint
    background.strokeWidth = 2

	group.background = background

	local label = display.newText( group, a.text, 0, 0, a.font, a.fontSize )	
	group.label = label

	label:setFillColor( unpack(a.textColor) )

	if a.width == 1 then
		if (label.width + a.margin) < a.minWidth then
			background.width = a.minWidth + a.margin
		else
			background.width = label.width + a.margin*2
		end
	end

	if a.shadow and a.shadow.isActive then
		local _shadow = Shadow({width = background.width, height = background.height, radius = a.radius, offset = a.shadow.offset, strokeWidth = a.shadow.strokeWidth or nil})
		group:insert(_shadow)
		_shadow:toBack()
	end
end

local function render(group, a)

	local background = display.newRoundedRect( group, 0, 0, a.width, a.height, a.cornerRadius )
	background.isHitTestable = true
	background:setFillColor( unpack(a.fillColor) )

	if a.strokeColor then
		background.strokeWidth = toPx(1)
		background:setStrokeColor( unpack(a.strokeColor) )
	end

	group.background = background

	local label = display.newText( group, a.text, 0, 0, a.font, a.fontSize )	
	group.label = label

	label:setFillColor( unpack(a.textColor) )

	if a.width == 1 then
		if (label.width + a.margin) < a.minWidth then
			background.width = a.minWidth + a.margin
		else
			background.width = label.width + a.margin*2
		end
	end

	if a.shadow and a.shadow.isActive then
		local _shadow = Shadow({width = background.width, height = background.height, radius = a.cornerRadius, offset = a.shadow.offset, strokeWidth = a.shadow.strokeWidth or nil})
		group:insert(_shadow)
		_shadow:toBack()
	end
end

local function setTouchCallback(group, a)
	group:addEventListener("touch", 
		function(e)
			if e.phase == "began" and a.isActive then      
		        TouchEffect:on(group, a)
		        display.getCurrentStage():setFocus( e.target )

		    elseif ( e.phase == "ended" or e.phase == "cancelled" ) then

				TouchEffect:off(group, a)
				a.touchCallback(e)
				display.getCurrentStage():setFocus( nil )
			end
			return true
		end )
end

local function Button(a)
	if not a then a = {} end
	if a.isActive == nil then a.isActive = true end

	local group = display.newGroup( )

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = Config.isAndroid end
	if a.isIos == nil then a.isIos = Config.isIos end
	
	if not a.style then a.style = "flat" end

	if a.isIos then
		if _style_android[a.style] == nil then error("This style is not valid") end
		for k,v in pairs(_style_ios[a.style]) do
			if a[k] == nil then
				a[k] = v
			end
		end
		if a.text then
			a.text = StringUtil:upperFirst(a.text)
		end
	else
		if _style_android[a.style] == nil then error("This style is not valid") end
		for k,v in pairs(_style_android[a.style]) do
			if a[k] == nil then
				a[k] = v
			end
		end
		if a.text then
			a.text = string.upper(a.text)
		end
	end

	if a.style == "back" then
		if a.isAndroid then
			renderers.android.back(group, a)
		elseif a.isIos then
			renderers.ios.back(group, a)
		end
	elseif a.style == "icon" then
		renderers.icon(group, a)
	elseif a.style == "float" then
		renderers.float(group, a)
	else
		render(group, a)
	end

	if a.touchEffect == "android" then
		local container = display.newContainer( group.width, group.height )
		group:insert(container)
		group.container = container
	end
	
	group.x = a.x
	group.y = a.y


	-- touch callback is defined
	if a.touchCallback then
		setTouchCallback(group, a)
	end

	function group:setTouchCallback(touchCallback)
		if a.touchCallback == nil then
			a.touchCallback = touchCallback
			setTouchCallback(group, a)
		end
	end

	function group:setIsActive(isActive)
		a.isActive = isActive
		if isActive then
			group.alpha = 1
		else
			group.alpha = .7
		end
	end
	

	if a.parent then
		a.parent:insert(group)
	end

	return group
end

return Button