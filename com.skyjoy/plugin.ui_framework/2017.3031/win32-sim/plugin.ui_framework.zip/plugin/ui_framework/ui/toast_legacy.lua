local Config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local colors = require("plugin.ui_framework.css.colors") 
local fonts = require("plugin.ui_framework.css.fonts")


local function Toast(str, delay)
	local groupToast = display.newGroup() 
	groupToast.alpha = 0

	if not str or type(str) ~= "string" then return false end 
	if groupToast[groupToast.numChildren] then
		groupToast.lastHide = transition.to( groupToast[groupToast.numChildren], {time = 300, alpha = 0, onComplete = function(e)
			display.remove(e)
			e = nil
		end } )
	end 

	if not a then a = {} end

	local txtCss = {
		fontName = native.systemFont,
		fontSize = toPx(12),
		color = {1, 1, 1, 1},
	}

	local paint = {
		type = "gradient",
		color1 = { 0.1, 0.1, 0.1, 0.8 },
		color2 = { 0, 0, 0, 0 },
		direction = "down"
	}	

	local roundCorner = toPx(16)
	local bgColor = { 0.1, 0.1, 0.1, 0.8 }

	if Config.isIos then
		roundCorner = toPx(4)
		bgColor = { 213/255, 215/255, 218/255, 1 }
		paint.color1 = { 213/255, 215/255, 218/255, 1 }
		txtCss.color = { 85/255, 87/255, 90/255, 1 }
	end

	if a.color then
		bgColor = a.color
		paint.color1 = a.color
	end

	local label = display.newText( groupToast, str, 0, 0, txtCss.fontName, txtCss.fontSize )
	label:setFillColor( unpack(txtCss.color) )

	local toastWidth = 0
	local toastHeight = 0
	if label.width > toPx(300) then
		display.remove( label )

		local label = display.newText( groupToast, str, 0, 0, toPx(300), 0, txtCss.fontName, txtCss.fontSize )
		label:setFillColor( unpack(txtCss.color) )

		toastWidth = label.width
		toastHeight = label.height
	else
		toastWidth = label.width
		toastHeight = label.height
	end


	local background = display.newRoundedRect( groupToast, 0, 0, toastWidth + toPx(35), toastHeight + toPx(22), roundCorner )
	background:toBack()
	background.strokeWidth = 1
	background.stroke = paint
	background:setFillColor( unpack(bgColor) )

	groupToast.x = display.contentWidth*.5
	groupToast.y = display.contentHeight - groupToast.height*.5 - toPx(40)
	
	if a.x then
		groupToast.x = toPx(a.x)
	end

	if a.y then
		groupToast.y = toPx(a.y)
	end

	if a.rotation then
		groupToast.rotation = a.rotation
	end


	groupToast.initTrans = transition.to(groupToast, {time = 300, alpha = 1, transition = easing.inOutQuad , onComplete = function()
		groupToast.duration = timer.performWithDelay( delay or 2000, 
			function() 
				groupToast.clearTrans = transition.to(groupToast, {
					time = 300, 
					alpha = 0, 
					transition = easing.inOutQuad, 
					onComplete = 
						function()
							display.remove(groupToast)
						end})
			end )
	end })
	
	groupToast:toFront() 
end
return Toast