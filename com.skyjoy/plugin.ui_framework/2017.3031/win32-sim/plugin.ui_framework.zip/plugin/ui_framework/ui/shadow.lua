local Shadow = {}
local toPx = require("plugin.ui_framework.utils.screen_util").toPx

function Shadow(a) -- {width, height, radius, startScale, endScale}
    if a.offset == nil and a.strokeWidth == nil then
        a.strokeWidth = toPx(5)
    end
    if a.offset == nil then
        a.offset = toPx(2)
    end
    if a.strokeWidth == nil then
        a.strokeWidth = a.offset * 2
    end

    if a.startAlpha == nil then
        a.startAlpha = 0.3
    end
    local strokeWidth = a.strokeWidth

    

    local shadow = display.newRoundedRect(0, a.offset, a.width, a.height, a.radius)
    shadow:setFillColor(0,0,0,0)
    if a.anchorY then
        shadow.anchorY = a.anchorY
        -- anchor applied to shadow as well and there's a wrong offset which has to be adjusted manually.
        if a.anchorY == 0 then
            shadow.y = shadow.y - strokeWidth*.5
        elseif a.anchorY == 1 then
            shadow.y = shadow.y + strokeWidth*.5
        end
    end
    
    local paint = {
        type = "gradient",
        color1 = color or { 0, 0, 0, a.startAlpha },
        color2 = { 0, 0, 0, 0 },
        direction = "down"
    }
    shadow.stroke = paint
    shadow.strokeWidth = strokeWidth

    return shadow
end

return Shadow