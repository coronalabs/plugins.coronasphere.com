local colors = require("plugin.ui_framework.css.colors")
local Config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local fonts = require("plugin.ui_framework.css.fonts")
local Button = require("plugin.ui_framework.ui.button_legacy")

local config = {
	primaryColor = Config.primaryColor
}

local _style_android = {
	font = fonts.title.font,
	fontSize = toPx(fonts.title.fontSize),
	width = display.contentWidth,
	height = toPx(56),
	textColor = {1,1,1},
	fillColor = Config.primaryColor,
	iconMargin = toPx(20),
	titleMargin = toPx(16)
}

local _style_ios = {
	font = fonts.subheading.font,
	fontSize = toPx(fonts.subheading.fontSize),
	width = display.contentWidth,
	height = toPx(44),
	textColor = colors.blackLite,
	buttonColor = Config.primaryColor,
	fillColor = colors.grayLite,
}


local renderers = {}

function renderers.android(parentGroup, a) -- {title, subtitle}
	local bg = display.newRect( parentGroup, 0, 0, a.width, a.height )
	bg:setFillColor( unpack(a.fillColor) )

	local xPosLeft = bg.x - bg.width*.5 + toPx(16) -- initial margin
	if a.buttons then
		if a.buttons.back then
			if not a.buttons.back.textColor then
				a.buttons.back.textColor = {1,1,1}
			end
			a.buttons.back.parent = parentGroup
			a.buttons.back.style = "back"
			a.buttons.back.height = a.height
			local btn_back = Button(a.buttons.back)
			btn_back.x = bg.x - bg.width*.5 + btn_back.icon.width*.5 + a.iconMargin
			xPosLeft = btn_back.x + btn_back.width*.5 + a.titleMargin
		elseif a.buttons.icon then
			a.buttons.icon.style = "icon"
			a.buttons.icon.height = a.height
			local btn_icon = Button(a.buttons.icon)
			btn_icon.x = bg.x - bg.width*.5 + btn_icon.width*.5
			parentGroup:insert(btn_icon)
			xPosLeft = btn_icon.x + btn_icon.width*.5 + a.titleMargin
		end
	end

	if a.title then
		local title = display.newText( {text = a.title, parent = parentGroup, x = xPosLeft, font = a.font, fontSize = a.fontSize, align = "left"} )
		title.anchorX = 0
	end
end

function renderers.ios(parentGroup, a) -- {title}
	
	local bg = display.newRect( parentGroup, 0, 0, a.width, a.height )
	bg:setFillColor( unpack(a.fillColor) )

	local xPosLeft = bg.x - bg.width*.5 + toPx(16) -- initial margin
	if a.buttons then
		if a.buttons.back then
			local btn_back = Button({text = a.buttons.back.text, style = "back", textColor = a.buttonColor, minWidth = 0, margin = toPx(8), parent = parentGroup, touchCallback = a.buttons.back.touchCallback})--, })
			btn_back.x = bg.x - bg.width*.5 + btn_back.width*.5
			xPosLeft = btn_back.x + btn_back.width*.5
		elseif a.buttons.icon then
			a.buttons.icon.style = "icon"
			local btn_icon = Button(a.buttons.icon)
			btn_icon.x = bg.x - bg.width*.5 + btn_icon.width*.5
			parentGroup:insert(btn_icon)
			xPosLeft = btn_icon.x + btn_icon.width*.5
		end
	end

	if a.title then
		local title = display.newText( {text = a.title, parent = parentGroup, font = a.font, fontSize = a.fontSize, align = "center"} )
		title:setFillColor( unpack(a.textColor) )
	end

	local line = display.newRect( parentGroup, bg.x, bg.height*.5 - 1, bg.width, 1 )
	line:setFillColor( 0,0,0,.1)
end

local function Navbar(a)
	if not a then a = {} end
	local group = display.newGroup( )	

	if a.isAndroid == nil then a.isAndroid = Config.isAndroid end
	if a.isIos == nil then a.isIos = Config.isIos end

	if a.isAndroid then
		for k,v in pairs(_style_android) do
			if a[k] == nil then
				a[k] = v
			end
		end
	else
		for k,v in pairs(_style_ios) do
			if a[k] == nil then
				a[k] = v
			end
		end
	end

	if a.isAndroid then
		renderers.android(group, a)
	else
		renderers.ios(group, a)
	end

	-- return all params
	function group:getParams()
		return a
	end

	return group
end

return Navbar