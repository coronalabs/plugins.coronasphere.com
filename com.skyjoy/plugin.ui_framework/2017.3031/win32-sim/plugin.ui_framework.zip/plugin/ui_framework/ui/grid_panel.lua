local panel = display.panel

local function _cellContract(cell, cellId)
    if not cell then
        error("This cell is not defined "..cellId)
    end
end

local function GridPanel(a)--{x, y, width, height, columns, rows, debug}
    if not a then a = {} end

    local columns = a.columns or {"*"}
    local rows = a.rows or {"*"}
    local width = a.width or display.contentWidth
    local height = a.height or display.contentHeight
    local x = a.x or 0
    local y = a.y or 0
    local debug = a.debug or false

    local singleAutoSizeItemWidth = 0
    local singleAutoSizeItemHeight = 0
    local numberOfAutoSizeColumnItems = 0

    local numberOfAutoSizeRowItems = 0
    local totalFixedSizeItemsWidth = 0
    local totalFixedSizeItemsHeight = 0

    ----------
    -- columns
    ----------
    for i=1,#columns do
        if type(columns[i]) == "number" then
            totalFixedSizeItemsWidth = totalFixedSizeItemsWidth + columns[i]
        elseif type(columns[i]) == "string" then
            if columns[i] == "*" then
                numberOfAutoSizeColumnItems = numberOfAutoSizeColumnItems + 1
            else
                columns[i] = math.round( (width * .01 ) * tonumber(columns[i]) )
                totalFixedSizeItemsWidth = totalFixedSizeItemsWidth + columns[i]
            end
        end

    end

    if numberOfAutoSizeColumnItems > 0 then -- calculate * single size
        singleAutoSizeItemWidth = ( width - totalFixedSizeItemsWidth ) / numberOfAutoSizeColumnItems
    end

    for i=1,#columns do -- change * to preper size
        if type(columns[i]) == "string" then
            columns[i] = singleAutoSizeItemWidth
        end
    end

    -------
    -- rows
    -------
    for i=1,#rows do
        if type(rows[i]) == "number" then
            totalFixedSizeItemsHeight = totalFixedSizeItemsHeight + rows[i]
        elseif type(rows[i]) == "string" then

            if rows[i] == "*" then
                numberOfAutoSizeRowItems = numberOfAutoSizeRowItems + 1
            else
                rows[i] = math.round( (height * .01 ) * tonumber(rows[i]) )
                totalFixedSizeItemsHeight = totalFixedSizeItemsHeight + rows[i]
            end
        end

    end

    if numberOfAutoSizeRowItems > 0 then -- calculate * single size
        singleAutoSizeItemHeight = ( height - totalFixedSizeItemsHeight ) / numberOfAutoSizeRowItems
    end

    for i=1,#rows do -- change * to preper size
        if type(rows[i]) == "string" then
            rows[i] = singleAutoSizeItemHeight
        end
    end
    

    local group = display.newGroup( )
    group.bottom = display.newGroup( )
    group:insert(group.bottom)
    group.cells = {}
    group._width = width
    group._height = height
    group.x = x
    group.y = y


    for i = 1, #columns do

        for j = 1, #rows do

            local tile = display.newGroup( )
            group:insert( tile )
            group.cells[i.."_"..j] = tile

            tile.old_insert = tile.insert

            tile.bg = bg
            tile._width = columns[i]--bg.width
            tile._height = rows[j]--bg.height
            if debug then
                local bg = display.newRect( tile, 0, 0, columns[i], rows[j] )
                bg.dontDestroy = true
                bg:setFillColor( math.random(1,100)/100, math.random(1,100)/100, math.random(1,100)/100 )
            end
            if j == 1 then
                tile.y = -height*.5 + rows[j]*.5
            else
                tile.y = group.cells[i.."_"..j-1].y + group.cells[i.."_"..j-1]._height*.5 + group.cells[i.."_"..j]._height*.5
            end

            if i == 1 then
                tile.x = -width*.5 + columns[i]*.5
            else
                tile.x = group.cells[(i-1).."_"..j].x + group.cells[(i-1).."_"..j]._width*.5 + group.cells[i.."_"..j]._width*.5
            end

            tile._x = tile.x
            tile._y = tile.y           
             
            tile._xLeft = -tile._width*.5
            tile._xRight = tile._width*.5
            tile.whatType = "grid"

            function tile:clear()
                for i = tile.numChildren, 1, -1 do
                    if tile[i].dontDestroy then
                    else
                        display.remove(tile[i])
                    end
                end
            end

            function tile:insert(item)
                self:old_insert(item)
                panel(self, item)
            end
        end
    end

    function group:insert( item )
        -- allow to use Control or object
        if item.grid then
            if item.grid.row and item.grid.column then
                item.cellId = item.grid.column.."_"..item.grid.row
            elseif item.grid.row then
                item.cellId = "1_"..item.grid.row
            elseif item.grid.column then
                item.cellId = item.grid.column.."_1"
            end
        end
        if not item.cellId then
            group.bottom:insert(item)
            panel(group.bottom, item)
        else
            _cellContract(group.cells[item.cellId], item.cellId)
            group.cells[item.cellId]:insert(item) 
            -- panel(group.cells[item.cellId], item)
        end
    end


    function group:setBackgroundColor(color, cellId)
        if cellId then
            local _cellId = "1_1"
            if cellId.row and cellId.column then
                _cellId = cellId.column.."_"..cellId.row
            else
                print("Warrning, you have to provide both values.")
                return false
            end
            _cellContract(group.cells[_cellId])
            group.cells[_cellId].bg:setFillColor( unpack(color) )
            group.cells[_cellId].bg.isVisible = true
        else
            for k,v in pairs(group.cells) do
                v.bg:setFillColor( unpack(color) )
                v.bg.isVisible = true
            end
        end
    end


    function group:get(key, cellId)
        if not cellId then
            return group[key]
        else
            local _cellId = "1_1"
            if cellId.row and cellId.column then
                _cellId = cellId.column.."_"..cellId.row
            elseif cellId.row then
                _cellId = "1_"..cellId.row
            elseif cellId.column then
                _cellId = cellId.column.."_1"
            end
            if not group.cells[_cellId] then
                print(_cellId)
                error("this cell does not exist. check your grid")
            end
            return group.cells[_cellId][key]
        end
    end

    function group:getCell(cellId)
        local _cellId = "1_1"
        if cellId.row and cellId.column then
            _cellId = cellId.column.."_"..cellId.row
        elseif cellId.row then
            _cellId = "1_"..cellId.row
        elseif cellId.column then
            _cellId = cellId.column.."_1"
        end
        return group.cells[_cellId]
    end

    function group:setTouchListener(listener, cellId)
        local cell = group.cells[cellId]
        cell.bg.isHitTestable = true -- set hitTestable only when callback is set
        cell.bg:addEventListener( "tap", function(e)
            listener(e)
        end )
    end

    function group:clear(cellId)
        if cellId then
            local _cellId = "1_1"
            if cellId.row and cellId.column then
                _cellId = cellId.column.."_"..cellId.row
            elseif cellId.row then
                _cellId = "1_"..cellId.row
            elseif item.grid.column then
                _cellId = cellId.column.."_1"
            end
            if group.cells[_cellId] then
                group.cells[_cellId]:clear()
            end
        else
            for k,v in pairs(group.cells.cells) do
                v:clear()
            end
        end
    end

    return group
end


return GridPanel