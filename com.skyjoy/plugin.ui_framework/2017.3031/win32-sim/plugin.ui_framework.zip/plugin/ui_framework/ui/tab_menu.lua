local colors = require("plugin.ui_framework.css.colors")
local Config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local fonts = require("plugin.ui_framework.css.fonts")
local Button = require("plugin.ui_framework.ui.button").new
local GridPanel = require("plugin.ui_framework.ui.grid_panel")
local StackPanel = require("plugin.ui_framework.ui.stack_panel")
local deviceUtil = require("plugin.ui_framework.utils.device_util")
local _w = display.contentWidth

local _style_android = {
	x = 0,
	y = 0,
	width = _w,
	tabs_width = _w,
	height = toPx(48),
	color = Config.primaryColor,
	tab = {
		config = {
			height = toPx(44),
			style = "icon"
		},
		icon = {
			isActive = false,
		},
		label = {
			font = fonts.subheading.font,
			fontSize = toPx(14),
		}
	}
}

local _style_ios = {
	x = 0,
	y = 0,
	width = _w,
	tabs_width = _w,
	height = toPx(46),
	color = colors.grayLite,
	tab = {
		config = {
			height = toPx(44),
			style = "icon"
		},
		icon = {
			color = Config.primaryColor,
			colorInActive = colors.blackLite,--Config.secondaryColor,
			fontSize = toPx(28),
			y = toPx(-4),
		},
		label = {
			fontSize = toPx(10),
			y = toPx(14),
			color = Config.primaryColor,
			colorInActive = colors.blackLite,
			isActive = true
		}
	}
}


local renderers = {}

local function setActiveAndroid(parentGroup, index, speed)
	if not parentGroup.tabs[index] then return end
	parentGroup.active_tab_index = index
	
	for j = 1, #parentGroup.tabs do
		parentGroup.tabs[j].label.alpha = .6
	end
	parentGroup.tabs[index].label.alpha = 1
	transition.cancel("set_activd")
	transition.to( parentGroup.under, {time = speed or 250, x = parentGroup.tabs[index]._x, width = parentGroup.tabs[index].width, tag = "set_activd",
		onComplete = function()
			parentGroup.transition_is_complete = true
		end} )
end 

local function setActiveIos(parentGroup, index, a)
	parentGroup.active_tab_index = index
	
	for j = 1, #parentGroup.tabs do
		if parentGroup.tabs[j].label then
			parentGroup.tabs[j].label:setFillColor( unpack(a.tab.label.colorInActive) )
		end

		if parentGroup.tabs[j].icon_outline then
			parentGroup.tabs[j].icon.text = parentGroup.tabs[j].icon_outline
			parentGroup.tabs[j].icon:setFillColor( unpack(a.tab.icon.colorInActive) )
		end
	end

	if parentGroup.tabs[index].icon_default then
		parentGroup.tabs[index].icon.text = parentGroup.tabs[index].icon_default
		parentGroup.tabs[index].icon:setFillColor( unpack(a.tab.icon.color) )
	end

	if parentGroup.tabs[index].label then
		parentGroup.tabs[index].label:setFillColor( unpack(a.tab.label.color)  )
	end

end

function renderers.android(parentGroup, a) -- {{items = { {title, tag} }}, subtitle}
	if a.tabs then
		local item_width = a.width/#a.tabs
		for i = 1, #a.tabs do
			local _cell = parentGroup.grid:getCell({column = i})
			local _index = i
			a.tabs[i].config.touchCallback = function()
				if parentGroup.transition_is_complete and i ~= parentGroup.active_tab_index then
					parentGroup.transition_is_complete = false
					parentGroup.touchCallback({tag = a.tabs[i].config.tag, index = i, x = _cell.x }) 
					setActiveAndroid(parentGroup, i)
				end
			end
			a.tabs[i].config.width = item_width
			local btn = Button(a.tabs[i])
			btn.tag = a.tabs[i].config.tag
			btn._x = _cell.x
			_cell:insert(btn)
			parentGroup.tabs[#parentGroup.tabs+1] = btn
		end
		local under = display.newRect(parentGroup, 0, 0, item_width, toPx(3))
		under.y = a.height*.5 - under.height*.5
		under:setFillColor( unpack(Config.accentColor) )
		parentGroup.under = under
	end
end

function renderers.androidTablet(parentGroup, a)
	local bg = display.newRect( parentGroup, 0, 0, a.width, a.height )
	bg:setFillColor( unpack(a.color) )
	
	local stackPanel = StackPanel({
		x = -_w*.5, 
		orientation = "horizontal", 
		height = a.height, 
		width = a.width })
	parentGroup:insert(stackPanel)
	
	local margin = display.newRect( 0, 0, toPx(24), 1 )
	margin.isVisible = false
	stackPanel:insert(margin)

	if a.tabs then
		local item_width = 0
		for i = 1, #a.tabs do
			-- local _cell = parentGroup.grid:getCell({column = i})
			local _x = 0
			a.tabs[i].config.touchCallback = function()
				if parentGroup.transition_is_complete and i ~= parentGroup.active_tab_index then
					parentGroup.transition_is_complete = false
					parentGroup.touchCallback({tag = a.tabs[i].config.tag, index = i, x = _x }) 
					setActiveAndroid(parentGroup, i)
				end
			end
			-- a.tabs[i].config.width = item_width

			a.tabs[i].config.margin = toPx(30)
			local btn = Button(a.tabs[i])
			btn.tag = a.tabs[i].config.tag
			stackPanel:insert(btn)
			parentGroup.tabs[#parentGroup.tabs+1] = btn

			-- it is on stack panel so we have to move it to the left _w*.5
			btn._x = btn.x - _w*.5
			_x = btn.x
			if i == 1 then
				item_width = btn.width
			end
		end
		local under = display.newRect(parentGroup, 0, 0, item_width, toPx(3))
		under.y = a.height*.5 - under.height*.5
		under:setFillColor( unpack(Config.accentColor) )
		parentGroup.under = under
	end

end

function renderers.ios(parentGroup, a) -- {title}
	local item_width = a.width/#a.tabs
	for i = 1, #a.tabs do

		local _cell = parentGroup.grid:getCell({column = i})
		a.tabs[i].config.touchCallback = function()
				if i ~= parentGroup.active_tab_index then
					parentGroup.touchCallback({tag = a.tabs[i].config.tag, index = i, x = _cell.x })
					setActiveIos(parentGroup, i, a)
				end
			end
		local btn = Button(a.tabs[i])

		btn.tag = a.tabs[i].config.tag
		btn._x = _cell.x
		btn.index = "b"..i

		if type(a.tabs[i].icon.text) == "table" then
			if a.tabs[i].icon.text.default then
				btn.icon_default = a.tabs[i].icon.text.default
			end
			if a.tabs[i].icon.text.outline then
				btn.icon_outline = a.tabs[i].icon.text.outline
			end
		else
			btn.icon_default = a.tabs[i].icon.text
		end

		_cell:insert(btn)
		parentGroup.tabs[#parentGroup.tabs+1] = btn
	end
	local line = display.newRect( parentGroup, 0, - a.height*.5 + 1, a.width, 1 )
	line:setFillColor( 0,0,0,.1)
end

local function buildGrid(parentGroup, a)
	local bg = display.newRect( parentGroup, 0, 0, a.width, a.height )
	bg:setFillColor( unpack(a.color) )

	local _grid_columns = {}
	for i = 1, #a.tabs do
		_grid_columns[#_grid_columns+1] = "*"
	end

	local item_width = a.width/#a.tabs

	local grid = GridPanel({
		width = a.tabs_width,
		height = a.height,
		-- rows = {"*","*"},
		columns = _grid_columns,
		debug = false})

	parentGroup:insert(grid)
	parentGroup.grid = grid
end

local function TabMenu(a)
	if not a then a = {} end
	local group = display.newGroup()	

	if a.isAndroid == nil then a.isAndroid = Config.isAndroid end
	if a.isIos == nil then a.isIos = Config.isIos end
	if a.active_tab_index == nil then a.active_tab_index = 1 end

	if a.isAndroid then
		for k,v in pairs(_style_android) do
			if k ~= "tabs" then
				if a[k] == nil then
					a[k] = v
				end
			end
		end
		if a.tabs then
			for i = 1, #a.tabs do
				for k,v in pairs(_style_android.tab) do
					if a.tabs[i].config == nil then a.tabs[i].config = {} end
					if a.tabs[i].icon == nil then a.tabs[i].icon = {} end
					if a.tabs[i].label == nil then a.tabs[i].label = {} end

					for k2,v2 in pairs(v) do
						if a.tabs[i][k][k2] == nil then
							a.tabs[i][k][k2] = v2
						end
					end
				end
			end
		end
	elseif a.isIos then
		for k,v in pairs(_style_ios) do
			if k ~= "tabs" then
				if a[k] == nil then
					a[k] = v
				end
			end
		end
		if a.tabs then
			for i = 1, #a.tabs do
				for k,v in pairs(_style_ios.tab) do
					if a.tabs[i].config == nil then a.tabs[i].config = {} end
					if a.tabs[i].icon == nil then a.tabs[i].icon = {} end
					if a.tabs[i].label == nil then a.tabs[i].label = {} end

					-- print(a.tabs[i])
					for k2,v2 in pairs(v) do
						if a.tabs[i][k][k2] == nil then
							a.tabs[i][k][k2] = v2
						end
					end
				end
			end
		end
	end

	-- table for items reference
	group.tabs = {}
	-- variable for android tab animation. prevent many taps before animation is finish.
	group.transition_is_complete = true
	-- reference for active tab so you can't click many time the same tab
	group.active_tab_index = a.active_tab_index

	-- fire touch callback
	function group.touchCallback(e)
		if a.touchCallback then
			a.touchCallback(e)
		end
	end

	function group:setTouchCallback(callback)
		if callback then
			a.touchCallback = callback
		end
	end

	function group:setActiveTab(index)
		if index then
			if a.isAndroid then
				setActiveAndroid(group, index, 0)
			elseif a.isIos then
				setActiveIos(group, index, a)
			end
		end
	end

	function group:render(_a)
		if _a then
			for k,v in pairs(_a) do
				a[k] = v
			end
		end
		if a.isAndroid then
			if deviceUtil.getOrientation() == "portrait" then
				buildGrid(group, a)
				renderers.android(group, a)
			else
				renderers.androidTablet(group, a)
			end
			setActiveAndroid(group, group.active_tab_index, 0)
		elseif a.isIos then
			if deviceUtil.getOrientation() == "landscape" then
				a.tabs_width = toPx(320)
			end
			buildGrid(group, a)
			renderers.ios(group, a)
			setActiveIos(group, group.active_tab_index, a)
		end
	end

	if a.tabs then
		group:render()
	end

	-- return all params
	function group:getParams()
		return a
	end

	if a.parent then
		a.parent:insert(group)
	end

	group.x = a.x or 0
	group.y = a.y or 0

	return group
end

return TabMenu