function display.panel(group, item)

	if not item.padding then item.padding = {} end -- obsługa paddingów
    if not item.padding.left then item.padding.left = 0 end
    if not item.padding.right then item.padding.right = 0 end
    if not item.padding.top then item.padding.top = 0 end
    if not item.padding.bottom then item.padding.bottom = 0 end
    if not item._anchorX then item._anchorX = item.anchorX end
    if not group._width then group._width = group.width end
    if not group._height then group._height = group.height end

    if not item.dock then return end
    if type(item.dock) ~= "table" then error("Dock is a table value. {top,bottom,left,right}") end
	
    if item.dock.left then
        item.x = - group._width*.5 + item.width*item.anchorX + item.padding.left

    elseif item.dock.right then
        item.x = group._width*.5 - item.width*item.anchorX - item.padding.right
    
    end

    if item.dock.top then -- układanie elementów na środku dla dock, left, right
        item.y = item.height*item.anchorY - group._height*.5 + item.padding.top

    elseif item.dock.bottom then -- układanie elementów na środku dla dock, left, right
        item.y = - item.height*item.anchorY + group._height*.5 - item.padding.bottom

    end
end

local panel = display.panel

function display.dockGroup()

    local group = display.newGroup()
    group.old_insert = group.insert
    
    function group:insert(item)
        group:old_insert(item)
        panel(group, item)
    end
	
    return group
end