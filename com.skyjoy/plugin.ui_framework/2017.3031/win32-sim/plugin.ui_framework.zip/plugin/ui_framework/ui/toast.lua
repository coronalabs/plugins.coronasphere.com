local Config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local colors = require("plugin.ui_framework.css.colors") 
local fonts = require("plugin.ui_framework.css.fonts")

local _style_android = {
	default = {
		config = {
			width = 1,
			minWidth = toPx(36),
			height = 1,
			margin = toPx(16),
			color = { 0.1, 0.1, 0.1, 0.8 },
			roundCorner = toPx(16),
			timeout = 2000,
		},
		label = {
			text = "",
			x = 0,
			y = 0,
			font = native.systemFont,
			fontSize = toPx(12),
			color = colors.white,
			isActive = true
		}
	},
}

local _style_ios = {
	default = {
		config = {
			width = 1,
			minWidth = toPx(36),
			height = 1,
			margin = toPx(16),
			color = colors.grayDark,
			roundCorner = toPx(4),
			timeout = 2000,
		},
		label = {
			text = "",
			x = 0,
			y = 0,
			font = native.systemFont,
			fontSize = toPx(12),
			color = colors.blackLite,
			isActive = true
		}
	},
}


local renderers = {}

function renderers.ios(group, a)
	local paint = {
		type = "gradient",
		color1 = a.config.color,
		color2 = { 0, 0, 0, 0 },
		direction = "down"
	}	

	local label = display.newText( {parent = group, text = a.label.text, font = a.label.font, fontSize = a.label.fontSize } )
	label:setFillColor( unpack(a.label.color) )

	local toastWidth = 0
	local toastHeight = 0
	if label.width > toPx(300) then
		display.remove( label )

		local label = display.newText( {parent = group, text = a.label.text, width = toPx(300), font = a.label.font, fontSize = a.label.fontSize } )
		label:setFillColor( unpack(a.label.color) )

		toastWidth = label.width
		toastHeight = label.height
	else
		toastWidth = label.width
		toastHeight = label.height
	end


	local background = display.newRoundedRect( group, 0, 0, toastWidth + toPx(35), toastHeight + toPx(22), a.config.roundCorner )
	background:toBack()
	background.strokeWidth = 1
	background.stroke = paint
	background:setFillColor( unpack(a.config.color) )
	

	group.initTrans = transition.to(group, {time = 300, alpha = 1, transition = easing.inOutQuad , onComplete = function()
		group.duration = timer.performWithDelay( a.config.timeout, 
			function() 
				group.clearTrans = transition.to(group, {
						time = 300, 
					alpha = 0, 
					transition = easing.inOutQuad, 
					onComplete = 
						function()
							display.remove(group)
						end})
			end )
	end })
	
	group:toFront()
end

function renderers.android(group, a)

	local paint = {
		type = "gradient",
		color1 = a.config.color,
		color2 = { 0, 0, 0, 0 },
		direction = "down"
	}	

	local label = display.newText( {parent = group, text = a.label.text, font = a.label.font, fontSize = a.label.fontSize } )
	label:setFillColor( unpack(a.label.color) )

	local toastWidth = 0
	local toastHeight = 0
	if label.width > toPx(300) then
		display.remove( label )

		local label = display.newText( {parent = group, text = a.label.text, width = toPx(300), font = a.label.font, fontSize = a.label.fontSize } )
		label:setFillColor( unpack(a.label.color) )

		toastWidth = label.width
		toastHeight = label.height
	else
		toastWidth = label.width
		toastHeight = label.height
	end


	local background = display.newRoundedRect( group, 0, 0, toastWidth + toPx(35), toastHeight + toPx(22), a.config.roundCorner )
	background:toBack()
	background.strokeWidth = 1
	background.stroke = paint
	background:setFillColor( unpack(a.config.color) )
	

	group.initTrans = transition.to(group, {time = 300, alpha = 1, transition = easing.inOutQuad , onComplete = function()
		group.duration = timer.performWithDelay( a.config.timeout, 
			function() 
				group.clearTrans = transition.to(group, {
						time = 300, 
					alpha = 0, 
					transition = easing.inOutQuad, 
					onComplete = 
						function()
							display.remove(group)
						end})
			end )
	end })
	
	group:toFront() 
end

local toast = {}


function toast.new(a)
	if not a then a = {} end
	if not a.config then a.config = {} end
	if a.config.isActive == nil then a.config.isActive = true end

	local group = display.newGroup( )

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = Config.isAndroid end
	if a.isIos == nil then a.isIos = Config.isIos end
	
	if not a.config.style then a.config.style = "default" end

	if a.isIos then
		if _style_ios[a.config.style] == nil then error("This style is not valid. Valid styles: flat, flat_fill, raised, raised_fill") end
		for k,v in pairs(_style_ios[a.config.style]) do
			if a[k] == nil then
				a[k] = {}
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end
		end
	else
		if _style_android[a.config.style] == nil then error("This style is not valid. Valid styles: flat, flat_fill, raised, raised_fill") end
		for k,v in pairs(_style_android[a.config.style]) do
			if a[k] == nil then
				a[k] = {}
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end			
		end
	end

	if a.isAndroid then
		renderers.android(group, a)
	elseif a.isIos then
		renderers.ios(group, a)
	end


	if a.config.x == nil then
		group.x = display.contentWidth*.5
	else
		group.x = a.config.x
	end

	if a.config.y == nil then
		group.y = display.contentHeight - group.height*.5 - toPx(40)
	else
		group.y = a.config.y
	end
end

return toast