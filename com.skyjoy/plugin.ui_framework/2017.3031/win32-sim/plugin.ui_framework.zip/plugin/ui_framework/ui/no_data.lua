local colors = require("plugin.ui_framework.css.colors")
local StringUtil = require("plugin.ui_framework.utils.string_util")
local TouchEffect = require("plugin.ui_framework.ui.touch_effect")
local Shadow = require("plugin.ui_framework.ui.shadow")
local config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local fonts = require("plugin.ui_framework.css.fonts")
local Button = require("plugin.ui_framework.ui.button").new


local class = {}
class.cache = {}

local _style_android = {
	search = {
		config = {
			width = display.contentWidth - toPx(24),
			margin = toPx(16),
			x = 0,
			y = 0,
		},
		image = {
			fileName = "plugin/ui_framework/images/other/sad_search_android.png",
			width = toPx(128),
			height = toPx(128),
			x = 0,
			y = 0,
			color = config.primaryColor,
			isActive = true
		},
		title = {
			text = "No results found.",
			x = 0,
			y = 0,
			font = native.systemFontBold,
			fontSize = toPx(24),
			color = colors.blackLite,
			isActive = true
		},
		description = {
			text = "We can't find any items matching your search.",
			x = 0,
			y = 0,
			font = native.systemFont,
			fontSize = toPx(18),
			color = colors.grayDark,
			isActive = true
		},
		button = {
			config = {
				style = "flat",
				width = display.contentWidth - toPx(24)
			},
			label = {
				text = "Try again",
			},
			isActive = false
		}
	},
}

local _style_ios = {
	search = {
		config = {
			width = display.contentWidth - toPx(24),
			margin = toPx(16),
			x = 0,
			y = 0,
		},
		image = {
			fileName = "plugin/ui_framework/images/other/sad_search_ios.png",
			width = toPx(96),
			height = toPx(96),
			x = 0,
			y = 0,
			color = colors.grayDarkExtra,
			isActive = true
		},
		title = {
			text = "No results found.",
			x = 0,
			y = 0,
			font = native.systemFontBold,
			fontSize = toPx(22),
			color = colors.blackLite,
			isActive = true
		},
		description = {
			text = "We can't find any items matching your search.",
			x = 0,
			y = 0,
			font = native.systemFont,
			fontSize = toPx(16),
			color = colors.grayDarkExtra,
			isActive = true
		},
		button = {
			config = {
				style = "flat",
				width = display.contentWidth - toPx(24)
			},
			label = {
				text = "Try again",
			},
			isActive = false
		}
	},
}


local renderer = {}

renderer.ios = {}
renderer.android = {}


function renderer.android.search(parentGroup, a)
	local group = display.newGroup()


	local title = display.newText( {
		parent = group,
		text = a.title.text,
		fontSize = a.title.fontSize,
		font = a.title.font,
		width = a.config.width,
		align = "center"
	} )
	title:setFillColor( unpack(a.title.color) )
	parentGroup.title = title
	
	if a.image.isActive then
		local image = display.newImageRect( group, a.image.fileName, a.image.width, a.image.height )
		image:setFillColor( unpack(a.image.color) )
		image.y = image.height*.5
		title.y = image.y + image.height*.5 + title.height*.5
		parentGroup.image = image
	end

	local description = display.newText( {
		parent = group,
		text = a.description.text,
		fontSize = a.description.fontSize,
		font = a.description.font,
		width = a.config.width,
		align = "center"
	} )
	description.y = title.y + title.height*.5 + description.height*.5 + toPx(8)
	description:setFillColor( unpack(a.description.color) )
	parentGroup.description = description

	if a.button.isActive then
		local btn = Button(a.button)
		group:insert(btn)
		btn.y = description.y + description.height*.5 + btn.height*.5 + toPx(24)

		if not a.button.config.touchCallback then
			print("Warrning: no_data button does not have callback set up!")
		end
		parentGroup.button = btn
	end


	parentGroup:insert(group)
	group.y = - group.height*.5
end


function renderer.ios.search(parentGroup, a)
	renderer.android.search(parentGroup, a)
end


function class.new(a)
	if not a then a = {} end
	if not a.config then a.config = {} end
	if a.config.isActive == nil then a.config.isActive = true end

	local group = display.newGroup( )
	if a.tag then
		group.tag = a.tag
		class.cache[#class.cache+1] = group
	end

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isIos == nil then a.isIos = config.isIos end
	
	if not a.config.style then a.config.style = "search" end

	if a.isIos then
		if _style_ios[a.config.style] == nil then error("This style is not valid. Valid styles: flat, flat_fill, raised, raised_fill") end
		for k,v in pairs(_style_ios[a.config.style]) do
			if a[k] == nil then
				a[k] = v
			end-- add else so if exists, add defaults anyway
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end
		end
	else
		if _style_android[a.config.style] == nil then error("This style is not valid. Valid styles: flat, flat_fill, raised, raised_fill") end
		for k,v in pairs(_style_android[a.config.style]) do
			if a[k] == nil then
				a[k] = v
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end			
		end
	end

	if a.isAndroid then
		renderer.android[a.config.style](group, a)
	elseif a.isIos then
		 renderer.ios[a.config.style](group, a)
	end
	
	group.x = a.config.x
	group.y = a.config.y


	if a.parent then
		a.parent:insert(group)
	end

	return group
end

function class.remove(tag)
	print(1)
	if tag then
		print(2)
		for i = #class.cache, 1, -1 do
			if class.cache[i].tag then
				if class.cache[i].tag == tag then
					display.remove(class.cache[i])
					table.remove(class.cache, i)
					break
				end
			end
		end
	end
end

return class