local colors = require("plugin.ui_framework.css.colors")
local config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local fonts = require("plugin.ui_framework.css.fonts")
local Button = require("plugin.ui_framework.ui.button").new
local Input = require("plugin.ui_framework.ui.input")

local StackPanel = require("plugin.ui_framework.ui.stack_panel")


local _style_android = {
	default = {
		config = {
			width = display.contentWidth,
			height = toPx(54),
		},
		background = {
			color = colors.white,
		},
		placeholder = {
			text = "Search"
		},
		cancel = {
			text = "Cancel",
			margin = toPx(20),
			color = colors.gray,
		}
	}
}

local _style_ios = {
	default = {
		config = {
			width = display.contentWidth,
			height = toPx(54),
		},
		background = {
			color = colors.white,
		},
		placeholder = {
			text = "Search"
		},
		cancel = {
			text = "Cancel",
			margin = toPx(20),
			color = config.primaryColor,
		}
	}
}


local renderers = {}

local function renderRightButtons(parentGroup, a)
	
end

function renderers.android(parentGroup, a) -- {title, subtitle}

	local bg = display.newRect( parentGroup, 0, 0, a.config.width, a.config.height )
	bg:setFillColor( unpack(a.background.color) )

	local inputBg = display.newRoundedRect( parentGroup, 0, 0, a.config.width - toPx(16), a.config.height - toPx(16), toPx(2) )
	bg:setFillColor( unpack(config.primaryColor) )

	local btn_cancel = Button({
		parent = parentGroup,
		config = {
			height = a.config.height,
			style = "back",
			touchCallback = a.cancel.touchCallback,
		},
		icon = {
			color = a.cancel.color
		}
	})
	btn_cancel.x = bg.x - bg.width*.5 + btn_cancel.icon.width*.5 + a.cancel.margin
	parentGroup.cancel = btn_cancel

	local input = Input({
		parent = parentGroup,
		config = {
			style = "search",
			width = a.config.width - btn_cancel.width - a.cancel.margin*1,
			submittedCalllback = a.config.submittedCalllback,
			edittingCallback = a.config.edittingCallback
		},
		placeholder = {
			text = a.placeholder.text
		}
		})

	input.x = bg.x - bg.width*.5 + input.width*.5 + btn_cancel.width

	parentGroup.input = input
end

function renderers.ios(parentGroup, a) -- {title}
	
	local bg = display.newRect( parentGroup, 0, 0, a.config.width, a.config.height )
	bg:setFillColor( unpack(a.background.color) )

	local btn_cancel = Button({
		parent = parentGroup,
		config = { 
			style = "flat",
			height = a.config.height,
			minWidth = 0,
			margin = 0,
			touchCallback = a.cancel.touchCallback,
		},
		label = {
			text = a.cancel.text,
			color = a.cancel.color,
		}
	})
	btn_cancel.x = bg.x + bg.width*.5 - btn_cancel.width*.5 - a.cancel.margin
	parentGroup.cancel = btn_cancel

	local input = Input({
		parent = parentGroup,
		config = {
			style = "search",
			width = a.config.width - btn_cancel.width - a.cancel.margin*3,
			submittedCalllback = a.config.submittedCalllback,
			edittingCallback = a.config.edittingCallback
		},
		placeholder = {
			text = a.placeholder.text
		}
		})

	input.x = bg.x - bg.width*.5 + input.width*.5 + a.cancel.margin

	parentGroup.input = input

	local line = display.newRect( parentGroup, bg.x, bg.height*.5 - 1, bg.width, 1 )
	line:setFillColor( 0,0,0,.1)
end

local function Navbar(a)
	if not a then a = {} end
	local group = display.newGroup( )	

	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isIos == nil then a.isIos = config.isIos end

	if not a.config then a.config = {} end
	if not a.config.style then a.config.style = "default" end

	if a.isIos then
		if _style_ios[a.config.style] == nil then print(a.config.style) error("This style is not valid") end
		for k,v in pairs(_style_ios[a.config.style]) do
			if a[k] == nil then
				a[k] = v
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end
		end
	else
		if _style_android[a.config.style] == nil then error("This style is not valid") end
		for k,v in pairs(_style_android[a.config.style]) do
			if a[k] == nil then
				a[k] = v
			end
			for k2,v2 in pairs(v) do
				if a[k][k2] == nil then
					a[k][k2] = v2
				end
			end			
		end
	end

	if a.isAndroid then
		renderers.android(group, a)
	else
		renderers.ios(group, a)
	end

	function group:setSubmittedCallback(callback)
		group.input:setSubmittedCallback(callback)
	end

	function group:setCancelTouchCallback(callback)
		group.cancel:setTouchCallback(callback)
	end

	function group:setFocus()
		group.input:setFocus()
	end

	function group:removeFocus()
		group.input:removeFocus()
	end

	-- return all params
	function group:getParams()
		return a
	end

	if a.parent then
		a.parent:insert(group)
	end

	return group
end

return Navbar