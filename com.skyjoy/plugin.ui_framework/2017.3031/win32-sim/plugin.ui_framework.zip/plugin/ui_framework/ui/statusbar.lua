local colors = require("plugin.ui_framework.css.colors")
local config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx


local _style = {
	color = config.primaryColor,
	isAndroid = config.isAndroid,
	isIos = config.isIos,
	isActive = true,
	mode = "default"
}

local lastMode = ""


local renderer = {}
function renderer.ios(group, a)

	local background = display.newRect( group, 0, 0, display.contentWidth, display.topStatusBarContentHeight )
	background:setFillColor( unpack(a.color) )

	
end

function renderer.android(group, a)
	local background = display.newRect( group, 0, 0, display.contentWidth, display.topStatusBarContentHeight )
	background:setFillColor( unpack(a.color) )

	local background_dark = display.newRect( group, 0, 0, display.contentWidth, display.topStatusBarContentHeight )
	background_dark:setFillColor( 0,0,0,.1 )
end

local statusbar = {}

function statusbar.setMode(mode)
	_style.mode = mode
end

function statusbar.isVisible(is_visible)
	if is_visible then
		if _style.mode == "lite" then
			display.setStatusBar( display.LightTransparentStatusBar )
		elseif _style.mode == "dark" then
			display.setStatusBar( display.DarkTransparentStatusBar )
		else
			display.setStatusBar( display.DefaultStatusBar )
		end
	else
		display.setStatusBar( display.HiddenStatusBar )
	end
end

function statusbar.new(a)
	if not a then a = {} end

	local group = display.newGroup( )

	for k,v in pairs(_style) do
		if a[k] == nil then
			a[k] = v
		end
	end

	if lastMode ~= a.mode then
		if a.mode == "lite" then
			display.setStatusBar( display.LightTransparentStatusBar )
		elseif a.mode == "dark" then
			display.setStatusBar( display.DarkTransparentStatusBar )
		else
			display.setStatusBar( display.DefaultStatusBar )
		end
		lastMode = a.mode
	end
		
	if config.isIos then
		renderer.ios(group, a)
	elseif config.isAndroid then
		renderer.android(group, a)
	end

	group.x = display.contentWidth*.5
	group.y = group.height*.5
	

	if a.parent then
		a.parent:insert(group)
	end

	return group
end

return statusbar