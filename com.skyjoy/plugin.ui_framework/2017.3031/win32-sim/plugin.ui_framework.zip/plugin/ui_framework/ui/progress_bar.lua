local colors = require("plugin.ui_framework.css.colors")
local Shadow = require("plugin.ui_framework.ui.shadow")
local Config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx


local _style_android = {
	default = {
		x = 0,
		y = 0,
		width = display.contentWidth - 32,
		height = 4,
		cornerRadius = 0,
		progressColor = Config.primaryColor,
		backgroundColor = colors.gray,
	},
}

local _style_ios = {
	default = {
		x = 0,
		y = 0,
		width = display.contentWidth - 32,
		height = 4,
		cornerRadius = toPx(2),
		progressColor = Config.primaryColor,
		backgroundColor = colors.grayDark,
	},
}

local function setProgress(group, a, transitionTime)
	if a.progress == nil or a.progress < 0 or a.progress > 1 then error("Progress has to be between 0 and 1") end
	if a.progress > 0 then
		group.fill.isVisible = true
		if transitionTime then
			transition.to( group.fill, {time = transitionTime, width = a.progress*group.background.width} )
		else
			group.fill.width = a.progress*group.background.width
		end
	elseif a.progress == 0 then
		group.fill.isVisible = false
	end
end


local function render(group, a)
	
	-- background bar
	local background = display.newRoundedRect( group, 0, 0, a.width, a.height, a.cornerRadius )
	background:setFillColor( unpack(a.backgroundColor) )
	group.background = background

	-- fill bar
	local fill = display.newRoundedRect( group, background.x - background.width*.5, 0, 1, a.height, a.cornerRadius )
	fill.anchorX = 0
	fill:setFillColor( unpack(a.progressColor) )
	group.fill = fill

	-- set circle at default position
	setProgress(group, a)
end

local progressBar = {}
function progressBar.new(a)
	if not a then a = {} end
	if a.isActive == nil then a.isActive = true end
	if a.progress == nil or a.progress < 0 or a.progress > 1 then a.progress = 0 end

	local group = display.newGroup( )
	if not a.isOn then a.isOn = false end
	group.progress = 0

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = Config.isAndroid end
	if a.isIos == nil then a.isIos = Config.isIos end
	
	-- set proper default values based on os
	if not a.style then a.style = "default" end
	if a.isIos then
		if _style_ios[a.style] == nil then error("This style is not valid") end
		for k,v in pairs(_style_ios[a.style]) do
			if a[k] == nil then
				a[k] = v
			end
		end
		-- custom variable for difference in iOS.
		a.circleSideOffset = a.strokeWidth
	else
		if _style_android[a.style] == nil then error("This style is not valid") end
		for k,v in pairs(_style_android[a.style]) do
			if a[k] == nil then
				a[k] = v
			end
		end
	end
	render(group, a)

	
	group.x = a.x
	group.y = a.y

	function group:setIsActive(isActive)
		a.isActive = isActive
		if isActive then
			group.alpha = 1
		else
			group.alpha = .8
		end
	end

	function group:setProgress(progress, transitionTime)
		a.progress = progress
		setProgress(group, a, transitionTime)
	end
	

	if a.parent then
		a.parent:insert(group)
	end

	return group
end


function progressBar.set(a)
	if a.isAndroid == nil then a.isAndroid = Config.isAndroid end
	if a.isIos == nil then a.isIos = Config.isIos end
	if not a.style then a.style = "default" end

	if a.isIos then
		if _style_ios[a.style] == nil then error("This style is not valid") end
		for k,v in pairs(a) do
			_style_ios[a.style][k] = v
		end
		-- custom variable for difference in iOS.
		a.circleSideOffset = a.strokeWidth
	else
		if _style_android[a.style] == nil then error("This style is not valid") end
		for k,v in pairs(a) do
			_style_android[a.style][k] = v
		end
	end
end

return progressBar