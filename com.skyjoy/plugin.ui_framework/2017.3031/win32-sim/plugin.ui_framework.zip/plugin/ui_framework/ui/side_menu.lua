local colors = require("plugin.ui_framework.css.colors")
local Config = require("plugin.ui_framework.config")
local toPx = require("plugin.ui_framework.utils.screen_util").toPx
local fonts = require("plugin.ui_framework.css.fonts")
local Button = require("plugin.ui_framework.ui.button").new
local GridPanel = require("plugin.ui_framework.ui.grid_panel")
local StackPanel = require("plugin.ui_framework.ui.stack_panel")
local _w = display.contentWidth
local _h = display.contentHeight


local _style_androidtv = {
	config = {
		x = 0,
		y = 0,
		width = toPx(280),
		-- height = toPx(30),
		color = Config.primaryColor,
		renderer = "atv",
		activeTab = 1
	},
	image = {
		fileName = "",
		width = toPx(200),
		height = toPx(100),
		x = toPx(130),
		y = toPx(64),
		isActive = false
	},
	item = {
		config = {
			height = toPx(46),
			width = toPx(200),
			color = Config.secondaryColor
		},
		label = {
			text = "",
		}
	}
}

local _style_android = {
	config = {
		x = 0,
		y = 0,
		width = _w,
		height = toPx(48),
		color = Config.primaryColor,
		activeTab = 1
	},
	item = {
		config = {
			height = toPx(44),
			style = "icon"
		},
		icon = {
			isActive = false,
		},
		label = {
			font = fonts.subheading.font,
			fontSize = toPx(14),
		}
	}
}

local _style_ios = {
	config = {
		x = 0,
		y = 0,
		width = _w,
		height = toPx(44),
		color = colors.grayLite,
		activeTab = 1
	},
	item = {
		config = {
			height = toPx(44),
			style = "icon"
		},
		icon = {
			color = Config.primaryColor,
			colorInActive = colors.blackLite,--Config.secondaryColor,
			fontSize = toPx(28),
			y = toPx(-4),
		},
		label = {
			fontSize = toPx(10),
			y = toPx(14),
			color = Config.primaryColor,
			colorInActive = colors.blackLite,
			isActive = true
		}
	}
}


local renderers = {}

local function setActiveAndroidTv(parentGroup, index, dontMove)
	parentGroup.active_tab_index = index
	-- transition.cancel( "active_menu_item" )
	
	for i = 1, #parentGroup.items do
		parentGroup.items[i].label.xScale = 1
		parentGroup.items[i].label.yScale = 1
		parentGroup.items[i].label.alpha = .8
	end
	if not dontMove then
		parentGroup.buttons.y = toPx(160)-( (index-1) * parentGroup.items[index].height)
	end

	if parentGroup.items[index] == nil then 
		index = 1
	end

	parentGroup.items[index].label.xScale = 1.2
	parentGroup.items[index].label.yScale = 1.2
	parentGroup.items[index].label.alpha = 1

	if parentGroup.items[index].touchCallback then
		parentGroup.items[index].touchCallback(parentGroup.items[index])
	end
end 



function renderers.atv(parentGroup, a)
	local bg = display.newRect( parentGroup, 0, 0, a.config.width, _h )
	bg.anchorX = 0
	bg.anchorY = 0
	bg:setFillColor( unpack(a.config.color) )


	if a.items then
		local stackPanel = StackPanel({
			y = toPx(160),
			x = a.config.width*.5,
		})
		parentGroup:insert(stackPanel)
		parentGroup.buttons = stackPanel

		for i = 1, #a.items do
			local btn = Button(
				{ 
					config = 
					{ 
						style = "flat", 
						touchCallback = function()
							parentGroup.touchCallback(parentGroup.items[i])
						end, 
						width = a.item.config.width,
						height = a.item.config.height,
					}, 
					label = 
					{
						text = a.items[i].label.text,
						color = a.item.config.color
					} 
				})
			stackPanel:insert(btn)
			btn.index = i
			parentGroup.items[#parentGroup.items + 1] = btn
		end
	end
	
	if a.image and a.image.isActive then
		local image_bg = display.newRect( parentGroup, a.config.width*.5, a.image.y, a.config.width, a.image.height + toPx(16) )
		image_bg:setFillColor( unpack(a.config.color) )

		local image = display.newImageRect(parentGroup, a.image.fileName, a.image.width, a.image.height )
		image.x = a.image.x
		image.y = a.image.y
	end
end


local sideMenu = {}

function sideMenu.new(a)
	if not a then a = {} end
	local group = display.newGroup()	

	if a.isAndroid == nil then a.isAndroid = Config.isAndroid end
	if a.isTv == nil then a.isTv = Config.isTv end
	if a.isIos == nil then a.isIos = Config.isIos end
	if a.config and a.config.activeTab == nil then a.config.activeTab = 1 end

	if a.isAndroid then
		if a.isTv then
			for k,v in pairs(_style_androidtv) do
				if k ~= "items" then
					if a[k] == nil then
						a[k] = v
					end
				end
			end
			for k,v in pairs(_style_androidtv.config) do
				if a.config[k] == nil then
					a.config[k] = v
				end
			end
			for k,v in pairs(_style_androidtv.image) do
				if a.image[k] == nil then
					a.image[k] = v
				end
			end
			if a.items then
				for i = 1, #a.items do
					for k,v in pairs(_style_androidtv.item) do
						if a.items[i].config == nil then a.items[i].config = {} end
						if a.items[i].label == nil then a.items[i].label = {} end
					end
				end
			end
		else

			for k,v in pairs(_style_android) do
				if k ~= "items" then
					if a[k] == nil then
						a[k] = v
					end
				end
			end
			if a.items then
				for i = 1, #a.items do
					for k,v in pairs(_style_android.item) do
						if a.items[i].config == nil then a.items[i].config = {} end
						if a.items[i].label == nil then a.items[i].label = {} end

						for k2,v2 in pairs(v) do
							if a.items[i][k][k2] == nil then
								a.items[i][k][k2] = v2
							end
						end
					end
				end
			end
		end
	else
		for k,v in pairs(_style_ios) do
			if k ~= "items" then
				if a[k] == nil then
					a[k] = v
				end
			end
		end
		if a.items then
			for i = 1, #a.items do
				for k,v in pairs(_style_ios.item) do
					if a.items[i].config == nil then a.items[i].config = {} end
					if a.items[i].label == nil then a.items[i].label = {} end

					for k2,v2 in pairs(v) do
						if a.items[i][k][k2] == nil then
							a.items[i][k][k2] = v2
						end
					end
				end
			end
		end
	end

	-- table for items reference
	group.items = {}
	-- variable for android tab animation. prevent many taps before animation is finish.
	group.transition_is_complete = true
	-- reference for active tab so you can't click many time the same tab
	group.active_tab_index = a.config.activeTab or 1

	-- fire touch callback
	function group.touchCallback(e)
		if a.touchCallback then
			a.touchCallback(e)
		end
	end

	function group:setTouchCallback(callback)
		if callback then
			a.touchCallback = callback
		end
	end

	function group.setActiveTab(index)
		if index then
			if a.isAndroid then
				if a.isTv then
					setActiveAndroidTv(group, index, a.config.dontMove)
				else
					-- setActiveAndroid(group, index, 0)
				end
			elseif a.isIos then
				-- setActiveIos(group, index, a)
			end
		end
	end

	function group.remote(direction)
		if direction == "up" or direction == "down" then
			if direction == "up" then
				group.active_tab_index = group.active_tab_index - 1
			elseif direction == "down" then
				group.active_tab_index = group.active_tab_index + 1
			end
			
			if group.active_tab_index <= 0 then 
				group.active_tab_index = 1
			elseif group.active_tab_index > #group.items then
				group.active_tab_index = #group.items
			end

			group.setActiveTab(group.active_tab_index)
		else
			if direction == "right" then
				group.touchCallback({direction = "right"})
			elseif direction == "back" then
				group.touchCallback({direction = "back"})
			end
		end
	end

	function group:render(_a)
		if _a then
			for k,v in pairs(_a) do
				a[k] = v
			end
		end
		renderers[a.config.renderer](group, a) 
		if group.active_tab_index then
			group.setActiveTab(group.active_tab_index)
		end
	end

	if a.items then
		group:render()
	end

	-- return all params
	function group:getParams()
		return a
	end

	if a.parent then
		a.parent:insert(group)
	end

	group.x = a.config.x or 0
	group.y = a.config.y or 0

	return group
end


function sideMenu.getSetting(a)
	if not a then a = {} end
	if not a.config then a.config = {} end

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isIos == nil then a.isIos = config.isIos end
	if a.isTv == nil then a.isTv = config.isTv end

	if a.isAndroid then
		return _style_android[a.config.style]
	else
		return _style_ios[a.config.style]
	end
end

function sideMenu.setStyle(a)
	if not a then error("You have to proved setting paramaters.") end

	-- set button type manually or auto is not given
	if a.isAndroid == nil then a.isAndroid = config.isAndroid end
	if a.isIos == nil then a.isIos = config.isIos end
	if a.isTv == nil then a.isTv = config.isTv end

	if not a.config.style then a.config.style = "flat" end

	if a.isAndroid then
		if a.config and _style_android[a.config.style].config then
			for k,v in pairs(a.config) do
				_style_android[a.config.style].config[k] = v
			end
		end

		if a.items and _style_android[a.config.style].item then
			for k,v in pairs(a.item) do
				_style_android[a.config.style].item[k] = v
			end
		end
	elseif a.isIos then
		if a.config and _style_ios[a.config.style].config then
			for k,v in pairs(a.config) do
				_style_ios[a.config.style].config[k] = v
			end
		end

		if a.items and _style_ios[a.config.style].item then
			for k,v in pairs(a.item) do
				_style_ios[a.config.style].item[k] = v
			end
		end

	elseif a.isTv then
		if a.config and _style_androidtv[a.config.style].config then
			for k,v in pairs(a.config) do
				_style_androidtv[a.config.style].config[k] = v
			end
		end

		if a.item and _style_androidtv[a.config.style].item then
			for k,v in pairs(a.item) do
				_style_androidtv[a.config.style].item[k] = v
			end
		end

	end
end

return sideMenu