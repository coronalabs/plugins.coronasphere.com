local Library = require "CoronaLibrary"

-- Create library
local lib = Library:new{ name='plugin.chartboost', publisherId='com.swipeware' }

-------------------------------------------------------------------------------
-- BEGIN (Insert your implementation startine here)
-------------------------------------------------------------------------------

-- This sample implements the following Lua:
-- 
--    local PLUGIN_NAME = require "plugin_PLUGIN_NAME"
--    PLUGIN_NAME:showPopup()
--    

local function showWarning()
    print( '!WARNING! > The chartboost plugin is only supported on an Android & iOS devices. Please build for device' );
end

function lib.getPluginVersion()
    showWarning()
    return "(no version)"
end

function lib.init()
    showWarning()
end

function lib.config()
    showWarning()
end

function lib.cache()
    showWarning()
end

function lib.show()
    showWarning()
    return false
end

function lib.startSession()
    showWarning()
end

function lib.hasCachedInterstitial()
    showWarning()
    return false
end

function lib.hasCachedMoreApps()
    showWarning()
    return false
end

function lib.hasCachedRewardedVideo()
    showWarning()
    return false
end

function lib.autoCacheAds()
    showWarning()
    return false
end

function lib.isAnyAdVisible()
    showWarning()
    return false
end

function lib.prefetchVideo()
    showWarning()
    return false
end

function lib.closeImpression()
    showWarning()
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return lib
