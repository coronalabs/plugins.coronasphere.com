local Library = require "CoronaLibrary"

local lib = Library:new{ name='amplitude', publisherId='com.amplitude' }

lib.init = function( api_key, user_id )
     -- stub
end

lib.logEvent = function( event, properties )
     -- stub
end

lib.logRevenue = function( amount )
     -- stub
end

lib.setUserId = function( user_id )
     -- stub
end

lib.setUserProperties = function( properties )
     -- stub
end

return lib
