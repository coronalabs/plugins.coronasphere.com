local Library = require "CoronaLibrary"

-- Create library
local GameThriveObject = Library:new{ name='GameThrivePushNotifications', publisherId='REVERSE_PUBLISHER_URL' }

-------------------------------------------------------------------------------
-- BEGIN
-------------------------------------------------------------------------------

-- Easy to use object to handle push notifications for you

GameThriveObject.TagPlayerWithTable = function(keyValueTable)
	print("Called GameThrive.TagPlayerWithTable")
end

GameThriveObject.TagPlayer = function(key, value)
	print("Called GameThrive.TagPlayer(" .. key .. ", " .. value .. ")")
	GameThriveObject.TagPlayerWithTable({[key] = value})
end

GameThriveObject.DisableAutoRegister = function()
	print("Called GameThrive.DisableAutoRegister()")
end

GameThriveObject.RegisterForNotifications = function()
	print("Called GameThrive.RegisterForNotifications()")
end

GameThriveObject.HandleLaunchArgs = function(launchArgs, appId, callback)
	print("ERROR!!!")
	print("HandleLaunchArgs is no longer vaild in this version of GameThrive.")
	print("Must use GameThrive.Init(appId, googleProjectNumber, DidReceiveRemoteNotification) instead.")
	print("You must also remove the whole notification = {} selection from your config.lua.")
	print('Lastly for iOS under plist = add UIBackgroundModes = {"remote-notification"},')
	print('Read our documentation or the Corona forums for more details.')
end

GameThriveObject.Init = function(appId, googleProjectNumber, notificationOpenedCallBack)
	print("Starting Corona GameThrive SDK v1.8.0")
	print("WARNING: GameThrive does not run in the simulator, however you will see messages here when GameThrive methods are called for debuging.")
	print("NOTE: On a Android device watch the logcat or the Xcode log on iOS for messages to debug issues.")
	print("Called GameThrive.Init(" .. appId .. ", " .. googleProjectNumber .. ", callback)")
end

GameThriveObject.PlayerPurchase = function(amount)
	print("Called GameThrive.PlayerPurchase(" .. amount .. ")")
end

GameThriveObject.IdsAvailableCallback = function(callback)
	print("Called GameThrive.IdsAvailableCallback()")
end

GameThriveObject.GetTags = function(callback)
	print("Called GameThrive.GetTags")
end

GameThriveObject.DeleteTags = function(keys)
	print("Called GameThrive.DeleteTags")
end

GameThriveObject.DeleteTag = function(key)
	print("Called GameThrive.DeleteTag")
end

GameThriveObject.ClearAllNotifications = function()
	print("Called GameThrive.ClearAllNotifications")
end

GameThriveObject.EnableVibrate = function(enable)
	print("Called GameThrive.EnableVibrate")
end
GameThriveObject.EnableSound = function(enable)
	print("Called GameThrive.EnableSound")
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return GameThriveObject
