local Library = require "CoronaLibrary"

-- Create library
local GameThriveObject = Library:new{ name='GameThrivePushNotifications', publisherId='REVERSE_PUBLISHER_URL' }

-------------------------------------------------------------------------------
-- BEGIN
-------------------------------------------------------------------------------

-- GameThrive v1.1.2
-- Easy to use object to handle push notifications for you

GameThriveObject.TagPlayerWithTable = function(keyValueTable)
	print("Called TagPlayerWithTable")
end

GameThriveObject.TagPlayer = function(key, value)
	print("Called TagPlayer(" .. key .. ", " .. value .. ")")
	GameThriveObject.TagPlayerWithTable({[key] = value})
end

GameThriveObject.HandleLaunchArgs = function( inLaunchArgs, appid, notificationOpenedCallBack)
	print("WARNING: GameThrive does not run in the simulator, however you will see messages here when other GameThrive messages are called for debuging.")
	print("NOTE: On a Android device watch the logcat or the Xcode log on iOS for messages to debug issues.")
	print("Called GameThriveObject.HandleLaunchArgs(..., " .. appid .. ", callback)")
end

GameThriveObject.PlayerPurchase = function(amount)
	print("Called GameThriveObject.PlayerPurchase(" .. amount .. ")")
end

GameThriveObject.IdsAvailableCallback = function(callback)
	print("Called GameThriveObject.IdsAvailableCallback()")
end

GameThriveObject.GetTags = function(callback)
	print("Called GameThriveObject.GetTags")
end

GameThriveObject.DeleteTags = function(keys)
	print("Called GameThriveObject.DeleteTags")
end

GameThriveObject.DeleteTag = function(key)
	print("Called GameThriveObject.DeleteTag")
end

-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return GameThriveObject
