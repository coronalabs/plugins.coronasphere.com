-- plugin.Trialpay.lua
print( "Loading Trialpay Corona SDK (Lua)" )

local Library = require "CoronaLibrary"
local lib = Library:new{ name='plugin.Trialpay', publisherId='com.trialpay' }

lib.OFFERWALL_OPEN = "offerwall_open"
lib.OFFERWALL_CLOSE = "offerwall_close"
lib.BALANCE_UPDATE = "balance_update"
				
lib.UNKNOWN = 0
lib.MALE = "M"
lib.FEMALE = "F"
		
lib.TPOfferwallDispatchPrefixUrl = 1;
lib.TPBalancePrefixUrl = 2;
lib.TPDealspotTouchpointPrefixUrl = 3;
lib.TPDealspotGeoPrefixUrl = 4;
lib.TPUserPrefixUrl = 5;
lib.TPSrcPrefixUrl = 6;
lib.TPDeaslpotAvailabilityPrefixUrl = 7;
lib.TPNavigationBarPrefixUrl = 8;

-- Default implementations
local function platformNotAvailable()
	print( "WARNING: The '" .. lib.name .. "' library is not available on this platform." )
end

-- Create stub library for simulator
lib.sdkVersionWrapper = platformNotAvailable
lib.setSidWrapper = platformNotAvailable
lib.registerVicWrapper = platformNotAvailable
lib.addEventListenerWrapper = platformNotAvailable
lib.openWrapper = platformNotAvailable
lib.initiateBalanceChecksWrapper = platformNotAvailable
lib.withdrawBalanceWrapper = platformNotAvailable
lib.isAvailable = platformNotAvailable
lib.startAvailabilityCheck = platformNotAvailable
lib.setAgeWrapper = platformNotAvailable
lib.setGenderWrapper = platformNotAvailable
lib.updateLevelWrapper = platformNotAvailable
lib.setCustomParamWrapper = platformNotAvailable
lib.clearCustomParamWrapper = platformNotAvailable
lib.updateVcPurchaseInfoWrapper = platformNotAvailable
lib.updateVcBalanceWrapper = platformNotAvailable
lib.setCustomPrefixUrlWrapper = platformNotAvailable
lib.hasCustomPrefixUrlWrapper = platformNotAvailable

-- Return lib instead of using 'module()' which pollutes the global namespace
return lib