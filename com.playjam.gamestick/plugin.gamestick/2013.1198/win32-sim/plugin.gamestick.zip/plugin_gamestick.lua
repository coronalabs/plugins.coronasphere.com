local Library = require "CoronaLibrary"

-- Create library
local gamestick = Library:new{ name='gamestick', publisherId='com.playjam.gamestick' }


gamestick.LBGetTop50 = function()
	native.showAlert("Unavailable on this format", "GameStick functions are only compatible on GameStick devices", {"OK"})
end

gamestick.LBSaveScore = function()
	native.showAlert("Unavailable on this format", "GameStick functions are only compatible on GameStick devices", {"OK"})
end

gamestick.SaveState = function()
	native.showAlert("Unavailable on this format", "GameStick functions are only compatible on GameStick devices", {"OK"})
end

gamestick.LoadState = function()
	native.showAlert("Unavailable on this format", "GameStick functions are only compatible on GameStick devices", {"OK"})
end

gamestick.GetAllAchievements = function()
	native.showAlert("Unavailable on this format", "GameStick functions are only compatible on GameStick devices", {"OK"})
end

gamestick.SetAchievementComplete = function()
	native.showAlert("Unavailable on this format", "GameStick functions are only compatible on GameStick devices", {"OK"})
end

gamestick.IAPGetItemsForPurchase = function()
	native.showAlert("Unavailable on this format", "GameStick functions are only compatible on GameStick devices", {"OK"})
end

gamestick.IAPGetPurchasedItemURL = function()
	native.showAlert("Unavailable on this format", "GameStick functions are only compatible on GameStick devices", {"OK"})
end

gamestick.IAPGetPurchasedItems = function()
	native.showAlert("Unavailable on this format", "GameStick functions are only compatible on GameStick devices", {"OK"})
end

gamestick.IAPPurchaseItem = function()
	native.showAlert("Unavailable on this format", "GameStick functions are only compatible on GameStick devices", {"OK"})
end


-------------------------------------------------------------------------------
-- END
-------------------------------------------------------------------------------

-- Return an instance
return gamestick
