local lib = require('CoronaLibrary'):new{name = 'plugin.spiralcode.facebook', publisherId = 'com.spiralcodestudio'}

local api = {
    'init',
    'getDeferredAppLinkData',
    'logEvent',
    'logPurchase',
    'setLimitEventAndDataUsage'
}

local function setStubs(t, node)
    for i = 1, #t do
        local name = t[i]
        local notice = 'plugin.spiralcode.facebook: ' .. name .. '() is not supported on this platform.'
        node[name] = function()
            print(notice)
        end
    end
end

setStubs(api, lib)

return lib
