local Library = require('CoronaLibrary')

-- Create stub library for simulator
local lib = Library:new{name = 'plugin.nfc', publisherId = 'com.spiralcodestudio'}

local function default()
    print("WARNING: The '" .. lib.name .. "' library is not available on this platform.")
end

lib.enableDebug = default

lib.init = default

lib.show = default

lib.close = default

lib.setListener = default

lib.removeListener = default

lib.writeTag = default

lib.releaseTag = default

lib.beam = default

lib.cancelBeam = default

-- Return an instance
return lib