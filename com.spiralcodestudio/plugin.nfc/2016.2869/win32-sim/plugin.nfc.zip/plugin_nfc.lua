local Library = require('CoronaLibrary')

-- Create stub library for simulator
local lib = Library:new{name = 'plugin.nfc', publisherId = 'com.spiralcodestudio'}

local function default()
    print("WARNING: The '" .. lib.name .. "' library is not available on this platform.")
end

lib.init = default

lib.setListener = default

lib.removeListener = default

-- Return an instance
return lib