local Library = require('CoronaLibrary')

-- Create stub library for simulator
local lib = Library:new{name = 'plugin.flashlight', publisherId = 'com.spiralcodestudio'}

lib.on = function()
    print("WARNING: The '" .. lib.name .. "' library is not available on this platform.")
end

lib.off = function()
    print("WARNING: The '" .. lib.name .. "' library is not available on this platform.")
end

-- Return an instance
return lib