local lib = require('CoronaLibrary'):new{name = 'plugin.bluetooth', publisherId = 'com.spiralcodestudio'}

local api = {
    'init',
    'setName',
    'startScan',
    'stopScan',
    'connect',
    'newServer',
    'startAdvertising',
    'stopAdvertising'
}

local function setStubs(t, node)
    for i = 1, #t do
        local name = t[i]
        local notice = 'plugin.bluetooth: ' .. name .. '() is not supported on this platform.'
        node[name] = function()
            print(notice)
        end
    end
end

setStubs(api, lib)

return lib
