local Library = require('CoronaLibrary')

-- Create stub library for simulator
local lib = Library:new{ name='plugin.toast', publisherId='com.spiralcodestudio' }

lib.show = function(message)
    print("WARNING: The '" .. lib.name .. "' library is not available on this platform.")
    print('plugin.toast', message)
end

-- Return an instance
return lib