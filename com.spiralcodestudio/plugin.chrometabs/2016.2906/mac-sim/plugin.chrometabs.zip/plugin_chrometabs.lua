local lib = require('CoronaLibrary'):new{name = 'plugin.chrometabs', publisherId = 'com.spiralcodestudio'}

local api = {
    'init',
    'warmup',
    'newSession',
    'mayLaunchUrl',
    'show'
}

local function setStubs(t, node)
    for i = 1, #t do
        local name = t[i]
        local notice = 'plugin.chrometabs: ' .. name .. '() is not supported on this platform.'
        node[name] = function()
            print(notice)
        end
    end
end

setStubs(api, lib)

return lib
