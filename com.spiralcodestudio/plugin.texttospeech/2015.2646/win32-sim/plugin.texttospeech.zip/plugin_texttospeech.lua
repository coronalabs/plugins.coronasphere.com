local Library = require('CoronaLibrary')

-- Create stub library for simulator
local lib = Library:new{name = 'plugin.texttospeech', publisherId = 'com.spiralcodestudio'}

local function default()
    print("WARNING: The '" .. lib.name .. "' library is not available on this platform.")
end

lib.speak = default

lib.stop = default

-- Return an instance
return lib