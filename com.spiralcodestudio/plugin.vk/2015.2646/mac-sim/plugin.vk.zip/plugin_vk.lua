local Library = require('CoronaLibrary')

-- Create stub library for simulator
local lib = Library:new{ name='plugin.vk', publisherId='com.spiralcodestudio' }

local function default()
    print("WARNING: The '" .. lib.name .. "' library is not available on this platform.")
end

lib.enableDebug = default
lib.init = default
lib.login = default
lib.logout = default
lib.isLoggedIn = default
lib.getUserId = default
lib.getAccessToken = default
lib.request = default
lib.showShareDialog = default

-- Return an instance
return lib